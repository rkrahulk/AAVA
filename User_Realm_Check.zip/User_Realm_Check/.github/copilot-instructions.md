# Workspace Instructions for User and Realm Checking Project

## Project Overview
Python project for user and realm verification in PostgreSQL with Excel export functionality.

## Setup Progress
- [x] Verify copilot-instructions.md file exists
- [x] Project requirements clarified (Python project with PostgreSQL)
- [x] Scaffold the project
- [x] Customize the project
- [x] Install required extensions (None required for Python)
- [x] Compile the project (Dependencies installed)
- [x] Create and run task (tasks.json created)
- [x] Launch the project (Ready to run)
- [x] Ensure documentation is complete

## Key Technologies
- Python 3.7+
- PostgreSQL (psycopg2)
- pandas
- openpyxl

## Getting Started
1. Install dependencies: `pip install -r requirements.txt`
2. Configure database connection in `user_realm_check.py`
3. Run the script: `python user_realm_check.py`

## Project Structure
```
.
├── user_realm_check.py       # Main script
├── requirements.txt           # Dependencies
├── README.md                  # Documentation
└── .github/
    └── copilot-instructions.md
```
