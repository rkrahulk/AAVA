# User and Realm Checking Script

A Python script to verify if users belong to specific realms in PostgreSQL and export results to Excel.

## Features

- ✓ Connects to PostgreSQL database
- ✓ Performs 3-part verification (Realm → User → User-Realm association)
- ✓ Handles multiple user checks
- ✓ Exports results to formatted Excel file
- ✓ Color-coded status (Green=PASS, Red=FAIL)
- ✓ Detailed error messages

## Requirements

- Python 3.7+
- PostgreSQL database with rbac schema

## Installation

### 1. Install Python dependencies:

```bash
pip install -r requirements.txt
```

Or install individually:
```bash
pip install psycopg2-binary pandas openpyxl
```

### 2. Verify Installation

Test the script to see available options:
```bash
python user_realm_check.py --help
```

## Usage

### Command-Line Interface

Run the script with all parameters from the command line:

**Basic command:**
```bash
python user_realm_check.py -r "Ascendion" -e "Krithik.b@hp.com" -H localhost -d mydb -u postgres -p password
```

**With all options:**
```bash
python user_realm_check.py \
  --realm "Ascendion" \
  --email "Krithik.b@hp.com" \
  --host localhost \
  --database mydb \
  --user postgres \
  --password password \
  --port 5432 \
  --output results.xlsx
```

**Short flags example:**
```bash
python user_realm_check.py -r "Ascendion" -e "user@hp.com" -H localhost -d mydb -u postgres -p password -o my_results.xlsx
```

**Help message:**
```bash
python user_realm_check.py --help
```

### Arguments Reference

| Argument | Short | Type | Required | Default | Description |
|----------|-------|------|----------|---------|-------------|
| `--realm` | `-r` | string | Yes | - | Realm name (e.g., Ascendion) |
| `--email` | `-e` | string | Yes | - | User email address |
| `--host` | `-H` | string | Yes | - | PostgreSQL host (localhost, IP, or hostname) |
| `--database` | `-d` | string | Yes | - | Database name |
| `--user` | `-u` | string | Yes | - | Database username |
| `--password` | `-p` | string | Yes | - | Database password |
| `--port` | - | integer | No | 5432 | PostgreSQL port |
| `--output` | `-o` | string | No | user_realm_check_results.xlsx | Output Excel filename |

### Examples

**Example 1: Check user in Ascendion realm**
```bash
python user_realm_check.py -r "Ascendion" -e "Krithik.b@hp.com" -H localhost -d company_db -u admin -p admin123
```

**Example 2: Check user with custom database host and output file**
```bash
python user_realm_check.py \
  --realm "Accenture" \
  --email "john.doe@company.com" \
  --host 192.168.1.100 \
  --database rbac_db \
  --user dbuser \
  --password dbpass \
  --port 5432 \
  --output john_doe_check.xlsx
```

**Example 3: Check user with default port on remote server**
```bash
python user_realm_check.py -r "Tech" -e "tech.user@company.com" -H db-server.internal -d postgres -u postgres -p secure_password
```

### Python API Usage

You can also import and use the `UserRealmChecker` class directly in your Python code:

```python
from user_realm_check import UserRealmChecker

# Initialize
checker = UserRealmChecker(
    host='localhost',
    database='mydb',
    user='postgres',
    password='password',
    port=5432
)

# Connect
if not checker.connect():
    print("Connection failed")
    exit(1)

# Check single user
result = checker.check_user_realm('Ascendion', 'Krithik.b@hp.com')
print(result)

# Close connection
checker.close()
```

### Check Multiple Users (Python API)

```python
from user_realm_check import UserRealmChecker

users_to_check = [
    ('Ascendion', 'Krithik.b@hp.com'),
    ('Ascendion', 'john.doe@hp.com'),
    ('Accenture', 'jane.smith@hp.com'),
]

checker = UserRealmChecker('localhost', 'mydb', 'postgres', 'password')
checker.connect()
checker.check_multiple_users(users_to_check)
checker.print_summary()
checker.export_to_excel('results.xlsx')
checker.close()
```

## Script Logic

### PART-1: Fetch Realm ID
```sql
SELECT id FROM rbac.realm WHERE realm_name = ?
```

### PART-2: Fetch User ID
```sql
SELECT user_id FROM rbac.users WHERE email = ?
```

### PART-3: Verify User-Realm Association
```sql
SELECT COUNT(*) FROM rbac.user_realm WHERE user_id = ? AND realm_id = ?
```

## Output

### Console Output
```
✓ Successfully connected to PostgreSQL database

✓ PART-1: Found realm 'Ascendion' with ID: 101
✓ PART-2: Found user 'Krithik B' with ID: 1, Email: Krithik.b@hp.com
✓ PART-3: User is part of realm. User ID: 1, Realm ID: 101

======================================================================
SUMMARY
======================================================================
Total checks: 1
Passed: 1
Failed: 0
======================================================================

✓ Results exported to 'user_realm_check_results.xlsx'
```

### Excel Output
A formatted Excel file with columns:
- Realm Name
- User Email
- User ID
- Realm ID
- Status (PASS/FAIL) - Color-coded
- Message

## Error Handling

The script provides detailed error messages for:
- Realm not found
- User not found
- User not part of realm
- Database connection errors
- SQL errors

## Note: SQL Server (MSSQL) Alternative

If you need to use SQL Server instead of PostgreSQL:
1. Replace `psycopg2` with `pymssql`
2. Update connection parameters to SQL Server format
3. Adjust SQL syntax if needed (T-SQL)

```bash
pip install pymssql
```

## Troubleshooting

### Connection Refused
- Check PostgreSQL is running
- Verify host, port, credentials
- Ensure database exists

### Module Not Found
```bash
pip install --upgrade psycopg2-binary pandas openpyxl
```

### Permission Denied
- Verify database user has SELECT permissions on rbac tables
- Check schema ownership
