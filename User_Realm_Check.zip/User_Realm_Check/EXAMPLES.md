# Command Examples - User and Realm Checking Script

## Basic Usage

### Example 1: Simple check with default port
```powershell
python user_realm_check.py -r "Ascendion" -e "Krithik.b@hp.com" -H localhost -d mydb -u postgres -p password
```

### Example 2: Using long-form arguments
```powershell
python user_realm_check.py \
  --realm "Ascendion" \
  --email "Krithik.b@hp.com" \
  --host localhost \
  --database mydb \
  --user postgres \
  --password password
```

### Example 3: Custom port and output file
```powershell
python user_realm_check.py \
  -r "Ascendion" \
  -e "Krithik.b@hp.com" \
  -H localhost \
  -d mydb \
  -u postgres \
  -p password \
  --port 5432 \
  -o "my_results.xlsx"
```

### Example 4: Remote database server
```powershell
python user_realm_check.py \
  -r "Accenture" \
  -e "john.doe@hp.com" \
  -H 192.168.1.100 \
  -d company_db \
  -u dbadmin \
  -p secure_password123 \
  --port 5432
```

### Example 5: With specific output location
```powershell
python user_realm_check.py `
  -r "Ascendion" `
  -e "user.name@hp.com" `
  -H db-server.internal `
  -d postgres `
  -u postgres `
  -p pass123 `
  -o "C:\Results\check_result.xlsx"
```

## Argument Reference

### Required Arguments
- `-r, --realm`: Realm name to check (e.g., "Ascendion")
- `-e, --email`: User email address to check (e.g., "user@hp.com")
- `-H, --host`: PostgreSQL server address (localhost, IP address, or hostname)
- `-d, --database`: Database name (e.g., "mydb", "postgres")
- `-u, --user`: Database username (e.g., "postgres", "admin")
- `-p, --password`: Database password

### Optional Arguments
- `--port`: PostgreSQL port (default: 5432)
- `-o, --output`: Excel output filename (default: user_realm_check_results.xlsx)

## Output

The script will:
1. Display connection status and check progress in console
2. Show detailed results for each part of the verification
3. Print a summary with pass/fail count
4. Export results to an Excel file with formatting:
   - Blue header row
   - Green cells for PASS status
   - Red cells for FAIL status
   - Properly formatted columns

## Common Connection Strings

### localhost (Development)
```powershell
python user_realm_check.py -r "Ascendion" -e "test@hp.com" -H localhost -d mydb -u postgres -p password
```

### IP Address
```powershell
python user_realm_check.py -r "Ascendion" -e "test@hp.com" -H 192.168.1.100 -d mydb -u postgres -p password
```

### Domain Name
```powershell
python user_realm_check.py -r "Ascendion" -e "test@hp.com" -H db.domain.com -d mydb -u postgres -p password
```

### Custom Port
```powershell
python user_realm_check.py -r "Ascendion" -e "test@hp.com" -H localhost -d mydb -u postgres -p password --port 55432
```

## Help

To see all available options:
```powershell
python user_realm_check.py --help
```
