"""
User and Realm Checking Script
Connects to PostgreSQL database and checks if a user belongs to a realm.
Exports results to Excel using pandas and openpyxl.
"""

import psycopg2
from psycopg2 import sql
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from datetime import datetime
import sys
import argparse

class UserRealmChecker:
    def __init__(self, host, database, user, password, port=5432):
        """Initialize database connection."""
        self.host = host
        self.database = database
        self.user = user
        self.password = password
        self.port = port
        self.conn = None
        self.results = []
        
    def connect(self):
        """Establish database connection."""
        try:
            self.conn = psycopg2.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password,
                port=self.port
            )
            print("✓ Successfully connected to PostgreSQL database")
            return True
        except psycopg2.Error as e:
            print(f"✗ Database connection failed: {e}")
            return False
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            print("✓ Database connection closed")
    
    def check_user_realm(self, realm_name, user_email):
        """
        Check if user belongs to realm.
        
        Args:
            realm_name (str): Name of the realm
            user_email (str): Email of the user
            
        Returns:
            dict: Contains user_id, realm_id, status, and message
        """
        cursor = self.conn.cursor()
        result = {
            'realm_name': realm_name,
            'user_email': user_email,
            'user_id': None,
            'realm_id': None,
            'status': 'FAIL',
            'message': ''
        }
        
        try:
            # PART-1: Fetch realm_id
            cursor.execute(
                "SELECT id, realm_name FROM rbac.realm WHERE realm_name = %s",
                (realm_name,)
            )
            realm_row = cursor.fetchone()
            
            if not realm_row:
                result['message'] = f'Realm "{realm_name}" not found'
                return result
            
            realm_id = realm_row[0]
            result['realm_id'] = realm_id
            print(f"\n✓ PART-1: Found realm '{realm_name}' with ID: {realm_id}")
            
            # PART-2: Fetch user_id
            cursor.execute(
                "SELECT user_id, user_name, email FROM rbac.users WHERE email = %s",
                (user_email,)
            )
            user_row = cursor.fetchone()
            
            if not user_row:
                result['message'] = f'User with email "{user_email}" not found'
                return result
            
            user_id = user_row[0]
            user_name = user_row[1]
            result['user_id'] = user_id
            print(f"✓ PART-2: Found user '{user_name}' with ID: {user_id}, Email: {user_email}")
            
            # PART-3: Check if user is part of realm
            cursor.execute(
                "SELECT COUNT(*) FROM rbac.user_realm WHERE user_id = %s AND realm_id = %s",
                (user_id, realm_id)
            )
            count = cursor.fetchone()[0]
            
            if count == 0:
                result['message'] = f'User "{user_email}" is not part of realm "{realm_name}"'
                return result
            
            result['status'] = 'PASS'
            result['message'] = f'User successfully verified in realm'
            print(f"✓ PART-3: User is part of realm. User ID: {user_id}, Realm ID: {realm_id}")
            
            return result
            
        except psycopg2.Error as e:
            result['message'] = f'Database error: {str(e)}'
            print(f"✗ Error: {result['message']}")
            return result
        finally:
            cursor.close()
    
    def check_multiple_users(self, check_list):
        """
        Check multiple users against realms.
        
        Args:
            check_list (list): List of tuples [(realm_name, user_email), ...]
        """
        print("\n" + "="*70)
        print("USER AND REALM CHECKING")
        print("="*70)
        
        self.results = []
        for realm_name, user_email in check_list:
            result = self.check_user_realm(realm_name, user_email)
            self.results.append(result)
        
        return self.results
    
    def export_to_excel(self, filename='user_realm_check_results.xlsx'):
        """
        Export results to Excel file with formatting.
        
        Args:
            filename (str): Output Excel filename
        """
        if not self.results:
            print("No results to export")
            return
        
        # Create DataFrame
        df = pd.DataFrame(self.results)
        df = df[['realm_name', 'user_email', 'user_id', 'realm_id', 'status', 'message']]
        df.columns = ['Realm Name', 'User Email', 'User ID', 'Realm ID', 'Status', 'Message']
        
        # Write to Excel
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Results', index=False)
            
            # Format the worksheet
            worksheet = writer.sheets['Results']
            
            # Set column widths
            column_widths = [20, 25, 12, 12, 10, 40]
            for i, width in enumerate(column_widths, 1):
                worksheet.column_dimensions[chr(64 + i)].width = width
            
            # Format header
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_font = Font(bold=True, color="FFFFFF")
            
            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # Color code status column
            pass_fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
            fail_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
            white_font = Font(color="FFFFFF", bold=True)
            
            for row in worksheet.iter_rows(min_row=2, max_row=len(df) + 1, min_col=5, max_col=5):
                for cell in row:
                    if cell.value == 'PASS':
                        cell.fill = pass_fill
                        cell.font = white_font
                    elif cell.value == 'FAIL':
                        cell.fill = fail_fill
                        cell.font = white_font
                    cell.alignment = Alignment(horizontal='center')
            
            # Center align numeric columns
            for row in worksheet.iter_rows(min_row=2, max_row=len(df) + 1, min_col=3, max_col=4):
                for cell in row:
                    cell.alignment = Alignment(horizontal='center')
        
        print(f"\n✓ Results exported to '{filename}'")
    
    def print_summary(self):
        """Print summary of results."""
        if not self.results:
            return
        
        passed = sum(1 for r in self.results if r['status'] == 'PASS')
        failed = len(self.results) - passed
        
        print("\n" + "="*70)
        print("SUMMARY")
        print("="*70)
        print(f"Total checks: {len(self.results)}")
        print(f"Passed: {passed}")
        print(f"Failed: {failed}")
        print("="*70 + "\n")


# ============================================================
# USAGE EXAMPLE
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description='User and Realm Checking Script',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python user_realm_check.py -r "Ascendion" -e "Krithik.b@hp.com" -H localhost -d mydb -u postgres -p password
  python user_realm_check.py --realm "Accenture" --email "john@hp.com" --host 192.168.1.1 --database mydb --user admin --password secret --port 5432
  python user_realm_check.py -r "Ascendion" -e "user@hp.com" -H localhost -d mydb -u postgres -p password -o results.xlsx
        """
    )
    
    # Required arguments
    parser.add_argument('-r', '--realm', 
                       required=True, 
                       help='Realm name (e.g., Ascendion)')
    parser.add_argument('-e', '--email', 
                       required=True, 
                       help='User email address (e.g., Krithik.b@hp.com)')
    
    # Database configuration arguments
    parser.add_argument('-H', '--host', 
                       required=True, 
                       help='PostgreSQL host (e.g., localhost or 192.168.1.1)')
    parser.add_argument('-d', '--database', 
                       required=True, 
                       help='Database name')
    parser.add_argument('-u', '--user', 
                       required=True, 
                       help='Database username')
    parser.add_argument('-p', '--password', 
                       required=True, 
                       help='Database password')
    parser.add_argument('--port', 
                       type=int, 
                       default=5432, 
                       help='PostgreSQL port (default: 5432)')
    
    # Optional output file
    parser.add_argument('-o', '--output', 
                       default='user_realm_check_results.xlsx',
                       help='Output Excel filename (default: user_realm_check_results.xlsx)')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Create DB config from arguments
    DB_CONFIG = {
        'host': args.host,
        'database': args.database,
        'user': args.user,
        'password': args.password,
        'port': args.port
    }
    
    # Initialize checker
    checker = UserRealmChecker(**DB_CONFIG)
    
    # Connect to database
    if not checker.connect():
        sys.exit(1)
    
    try:
        # Check single user
        users_to_check = [(args.realm, args.email)]
        checker.check_multiple_users(users_to_check)
        
        # Print summary
        checker.print_summary()
        
        # Export results to Excel
        checker.export_to_excel(args.output)
        
    finally:
        # Close connection
        checker.close()


if __name__ == "__main__":
    main()
