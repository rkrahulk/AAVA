# KB Creation Process - Script 1: User & Realm Checking
## Detailed Technical Design Document

### Document Version
- **Version**: 2.0
- **Date**: 2026-03-26
- **Status**: Implementation Complete
- **Scope**: Script 1 - User and Realm Validation

---

## Executive Summary

Script 1 is the first gatekeeper in the KB (Knowledge Base) creation pipeline. It validates that:
1. A specified realm exists in the RBAC system
2. A specified user exists in the RBAC system
3. The user is a member of the specified realm

Only when all three conditions are met does the script output `realm_id` and `user_id`, which are required inputs for Script 2 (KB Master Insert). The script is designed to handle both single records and batch processing from Excel files.

---

## High-Level Design (HLD)

### 1. System Architecture

```
┌─────────────────────────────────────────────────────────┐
│           ASCENDION KB CREATION PIPELINE                │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────┐│
│  │  Input Data  │────▶│  Script 1    │────▶│ Script 2 ││
│  │  (Excel)     │     │  Validate    │     │  KB      ││
│  │  - Realm     │     │  User/Realm  │     │  Master  ││
│  │  - User      │     │              │     │  Insert  ││
│  └──────────────┘     └──────────────┘     └──────────┘│
│                             │                     │      │
│                             ▼                     ▼      │
│                        ┌─────────┐          ┌─────────┐ │
│                        │ realm_id │          │   KB    │ │
│                        │ user_id  │          │ Records │ │
│                        └─────────┘          └─────────┘ │
│                                                          │
└─────────────────────────────────────────────────────────┘

Database: RBAC Schema
├── rbac.realm
├── rbac.users
└── rbac.user_realm
```

### 2. Data Flow

```
Input Source: Excel File
        │
        ▼
┌───────────────────────────────────────┐
│  Load & Validate Excel Structure      │
│  - Check columns: realm_name, user_mail
│  - Validate no nulls                  │
└───────────────────────────┬───────────┘
                            │
                            ▼
        ┌───────────────────────────────────────┐
        │  For Each Row in Excel               │
        └───────────────────────┬───────────────┘
                                │
                    ┌───────────┴───────────┐
                    │                       │
                    ▼                       ▼
        Part 1: Fetch realm_id    Part 2: Fetch user_id
        SELECT id FROM rbac.realm  SELECT user_id FROM 
        WHERE realm_name = ?        rbac.users WHERE 
                                   email = ?
                    │                       │
                    └───────────┬───────────┘
                                │
                                ▼
                    Part 3: Validate Membership
                    SELECT COUNT(*) FROM 
                    rbac.user_realm WHERE 
                    user_id = ? AND realm_id = ?
                                │
                    ┌───────────┴───────────┐
                    │                       │
                YES │                       │ NO
                    │                       │
                    ▼                       ▼
                SUCCESS               FAILED
                Mark as               Mark as
                SUCCESS               FAILED
                                      Record error
                    │                       │
                    └───────────┬───────────┘
                                │
                                ▼
                    Write Result to CSV:
                    - row_number, realm_name, user_mail
                    - realm_id, user_id, status, error
                                │
                                ▼
                    Output CSV File with All Results
                    Output Log File with Details
```

### 3. Component Responsibilities

| Component | Responsibility |
|-----------|-----------------|
| **Excel Reader** | Parse Excel, validate columns, extract rows |
| **Database Layer** | Execute 3 validation queries against RBAC |
| **Validator Class** | Orchestrate 3-part validation, return status |
| **CSV Writer** | Format and write results with appropriate statuses |
| **Logger** | Track progress, errors, and statistics |

---

## Low-Level Design (LLD)

### 1. Database Queries

#### Query 1: Fetch realm_id
```sql
SELECT id, realm_name
FROM rbac.realm 
WHERE realm_name = ?
```
**Expected Output**: Single row with id and realm_name
**Error Handling**: If no row → realm_id = None → Status: FAILED

#### Query 2: Fetch user_id
```sql
SELECT user_id, user_name, email
FROM rbac.users 
WHERE email = ?
```
**Expected Output**: Single row with user_id, user_name, email
**Error Handling**: If no row → user_id = None → Status: FAILED

#### Query 3: Validate membership
```sql
SELECT COUNT(*) as membership_count
FROM rbac.user_realm 
WHERE user_id = ? AND realm_id = ?
```
**Expected Output**: Single row with COUNT
**Condition**: If COUNT >= 1 → Status: SUCCESS, else → Status: FAILED

### 2. Class Structure

```python
class UserRealmValidator:
    
    def __init__(self, db_connection):
        # Initialize with database connection
    
    def fetch_realm_id(self, realm_name: str) → Optional[int]:
        # Execute Query 1
        # Return id or None
        # Log result
    
    def fetch_user_id(self, user_mail: str) → Optional[int]:
        # Execute Query 2
        # Return user_id or None
        # Log result
    
    def validate_user_realm_membership(self, realm_name, user_mail) → bool:
        # Execute Query 3
        # Return True/False
        # Log result
    
    def validate(self, realm_name: str, user_mail: str) → Dict:
        # Orchestrate all 3 queries
        # Return result dict with status and IDs
        # Reset state for each validation

def validate_from_excel(excel_file, connection_string, output_file):
    # Read Excel
    # Validate structure
    # For each row: call validator.validate()
    # Collect results
    # Write CSV
    # Print summary
    # Return summary dict
```

### 3. Data Structures

#### Input: Excel Row
```python
{
    "realm_name": str,    # e.g., "Ascendion"
    "user_mail": str      # e.g., "krithik.b@hp.com"
}
```

#### Processing: Validation Result
```python
{
    "status": str,        # SUCCESS, FAILED, ERROR, SKIPPED
    "realm_name": str,
    "user_mail": str,
    "realm_id": int | None,
    "user_id": int | None,
    "error": str | None
}
```

#### Output: CSV Row
```
row_number,realm_name,user_mail,realm_id,user_id,status,error
2,Ascendion,user@example.com,85,456,SUCCESS,
3,Ascendion,invalid@example.com,85,,FAILED,"User not found: invalid@example.com"
```

### 4. Error Handling Strategy

| Error Condition | Detection Point | Action | Status |
|-----------------|-----------------|--------|--------|
| Missing realm_name/user_mail | Excel read | Skip row | SKIPPED |
| Realm not in database | Query 1 | Record error | FAILED |
| User not in database | Query 2 | Record error | FAILED |
| User not in realm | Query 3 | Record error | FAILED |
| Database connection error | Init | Exit script | N/A |
| Missing Excel columns | Structure validate | Exit script | N/A |
| File not found | Init | Exit script | N/A |
| Invalid connection string | DB connect | Exit script | N/A |

### 5. State Management

```
Validator Instance (reused for all rows):

Per-validation (reset each validate() call):
├── realm_id: Initially None
├── user_id: Initially None
└── error_message: Clear before validation

Across validations:
├── db_connection: Persistent throughout batch
└── Results list: Accumulate all results
```

---

## Interface Specifications

### Function: validate_from_excel

**Signature**:
```python
def validate_from_excel(
    excel_file: str,
    connection_string: str,
    output_file: Optional[str] = None
) → Dict
```

**Parameters**:
- `excel_file` (str): Path to Excel file with columns: realm_name, user_mail
- `connection_string` (str): Database connection string for RBAC database
- `output_file` (Optional[str]): Output CSV path. Auto-generated if None.

**Returns**:
```python
{
    "status": "completed",
    "total_records": int,
    "successful": int,
    "failed": int,
    "error": int,
    "output_file": str
}
```

**Exceptions**:
- `SystemExit`: If fatal error (file not found, connection failed, missing columns)

### Function: validate (single record)

**Signature**:
```python
def validate(
    self,
    realm_name: str,
    user_mail: str
) → Dict
```

**Returns**:
```python
{
    "status": "SUCCESS" | "FAILED" | "ERROR",
    "realm_name": str,
    "user_mail": str,
    "realm_id": int | None,
    "user_id": int | None,
    "error": str | None
}
```

---

## Logging Strategy

### Log Levels

| Level | When Used | Example |
|-------|-----------|---------|
| INFO | Normal progress | "✓ Part 1 Passed: Realm 'Ascendion' found" |
| WARNING | Non-critical issues | "⚠ Row 5: Skipping - Missing user_mail" |
| ERROR | Record failure | "✗ Part 2 Failed: User not found" |

### Log Locations

1. **Console Output**: Real-time progress display
2. **File**: `user_realm_check.log` - Complete audit trail

### Summary Output

After batch processing:
```
================================================================================
VALIDATION SUMMARY
================================================================================
Total Records:    100
Successful:       95
Failed:           3
Error:            2
Skipped:          0
Output File:      user_realm_validation_20260326_143022.csv
================================================================================
```

---

## Performance Considerations

### Scalability

| Metric | Value | Notes |
|--------|-------|-------|
| Max records/batch | Unlimited | Limited by Excel capacity + memory |
| Typical throughput | 50-100 rec/sec | Depends on DB latency |
| Memory usage | ~10KB per record | For result storage |
| Avg query time | 20-50ms | Network + DB processing |

### Optimization Strategies

1. **Database Indexes**: Ensure indexes on:
   - `rbac.realm.realm_name`
   - `rbac.users.email`
   - `rbac.user_realm(user_id, realm_id)`

2. **Connection Pooling**: Reuse single connection for all 300+ queries

3. **Batch Sizing**: Process 1000-5000 records per batch for memory efficiency

---

## Integration Points

### Input Sources
- Excel files (.xlsx, .xls)
- CSV files (convert to Excel)
- Database queries (export to Excel)
- Manual entry (create Excel)

### Output Consumers
- Script 2 (KB Master Insert): Uses realm_id and user_id
- Analytics: CSV results for reporting
- Audit Trail: Log file for compliance

### Dependencies
- **pyodbc**: SQL Server connectivity
- **pandas**: Excel parsing
- **openpyxl**: Excel engine
- SQL Server ODBC Driver 17

---

## Deployment Checklist

- [ ] SQL Server ODBC Driver 17 installed
- [ ] Python packages installed: pandas, openpyxl, pyodbc
- [ ] Database connection string verified
- [ ] RBAC schema exists with all 3 tables
- [ ] User has SELECT permissions on RBAC tables
- [ ] Sample Excel file created with test data
- [ ] Script tested with single record validation
- [ ] Script tested with batch processing
- [ ] Log file directory is writable
- [ ] Output CSV directory is writable

---

## Testing Strategy

### Unit Tests (for individual methods)
```python
test_fetch_realm_id_success()
test_fetch_realm_id_not_found()
test_fetch_user_id_success()
test_fetch_user_id_not_found()
test_validate_membership_true()
test_validate_membership_false()
```

### Integration Tests
```python
test_single_record_success()
test_single_record_failure()
test_batch_processing_mixed()
test_batch_processing_all_success()
test_batch_processing_all_failed()
test_excel_missing_columns()
test_excel_empty_file()
```

### Database Tests
```python
test_realm_exists()
test_user_exists()
test_membership_exists()
test_db_connection_string()
```

### Sample Test Data
```
Realm: Ascendion, ID: 85
User: krithik.b@hp.com, ID: 456
Member: YES (in rbac.user_realm)
```

Expected result:
```json
{
  "status": "SUCCESS",
  "realm_id": 85,
  "user_id": 456
}
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-26 | Initial: CLI single record validation |
| 2.0 | 2026-03-26 | Added: Excel batch processing, CSV output, fault tolerance |

---

## Future Enhancements

1. **Database Support**: Add PostgreSQL, MySQL support
2. **Async Processing**: Process multiple rows in parallel
3. **Web API**: REST endpoint for validation
4. **Caching**: Cache realm and user lookups
5. **Audit Logging**: Separate audit table for compliance
6. **Email Validation**: Verify email format before query
7. **Duplicate Detection**: Warn if duplicate realm/user rows
8. **Retry Logic**: Automatic retry on transient DB errors

---

## Support & Troubleshooting

### Common Issues

**Issue**: "Realm not found"
- **Root Cause**: Realm name doesn't exist in database
- **Resolution**: Verify realm_name value, check rbac.realm table

**Issue**: "User not found"
- **Root Cause**: Email not in system
- **Resolution**: Verify email spelling, case-sensitivity, check rbac.users table

**Issue**: "User not member of realm"
- **Root Cause**: User not assigned to realm
- **Resolution**: Add entry to rbac.user_realm table

**Issue**: "Connection failed"
- **Root Cause**: Wrong connection string, DB offline, network issue
- **Resolution**: Test connection separately, verify connection string

---

## Document Control

| Field | Value |
|-------|-------|
| **Owner** | Ascendion Tools Team |
| **Last Updated** | 2026-03-26 |
| **Next Review** | 2026-04-26 |
| **Approval Status** | Approved |

