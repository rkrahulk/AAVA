# User and Realm Checking Script (Script 1)

## Overview
This script validates that users exist in specified realms by querying the RBAC (Role-Based Access Control) database. It supports both **single record validation** and **batch processing from Excel files**.

## Features

### ✓ Batch Excel Processing
- Reads multiple realm and user records from Excel files
- Validates each record against the RBAC database
- Continues processing on errors (fault-tolerant)
- Outputs results to CSV file with detailed status information
- Provides summary statistics

### ✓ Three-Part Validation
1. **Part 1**: Fetch `realm_id` from `rbac.realm` table
2. **Part 2**: Fetch `user_id` from `rbac.users` table  
3. **Part 3**: Validate user-realm membership in `rbac.user_realm` table

### ✓ Comprehensive Logging
- Console and file logging (`user_realm_check.log`)
- Detailed validation progress for each record
- Summary statistics at the end

## Installation

### Prerequisites
```bash
# For batch Excel processing
pip install pandas openpyxl

# For database connectivity
pip install pyodbc

# For SQL Server driver (Windows)
# Download: https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server
```

### Setup
1. Place the script in your working directory
2. Prepare Excel input file with required columns
3. Configure database connection string

---

## Usage

### Mode 1: Batch Excel Processing (RECOMMENDED)

#### Input Excel File Structure
Create an Excel file with the following columns:
```
| realm_name  | user_mail          |
|-------------|-------------------|
| Ascendion   | user1@example.com  |
| Ascendion   | user2@example.com  |
| DataFlow    | user3@example.com  |
```

#### Command
```bash
python user_realm_check.py <excel_file> <connection_string> [output_csv]
```

#### Examples

**SQL Server with Trusted Connection:**
```bash
python user_realm_check.py "input_data.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;Trusted_Connection=yes;" "results.csv"
```

**SQL Server with Username/Password:**
```bash
python user_realm_check.py "input_data.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=my_server;Database=rbac_db;UID=user;PWD=password;" "results.csv"
```

**Auto-generated Output Filename:**
```bash
python user_realm_check.py "input_data.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;"
# Output: user_realm_validation_20260326_143022.csv
```

#### Output CSV Format
```
row_number,realm_name,user_mail,realm_id,user_id,status,error
2,Ascendion,user1@example.com,85,456,SUCCESS,
3,Ascendion,user2@example.com,85,789,SUCCESS,
4,DataFlow,invalid@example.com,,,"FAILED","User not found: invalid@example.com"
```

#### Status Values
- **SUCCESS**: All validations passed
- **FAILED**: Validation failed (check error column)
- **SKIPPED**: Record skipped (missing data)
- **ERROR**: Unexpected error during processing

---

### Mode 2: Single Record Validation

For validating individual records without Excel:

#### Command
```bash
python user_realm_check.py <realm_name> <user_mail> <connection_string> --single
```

#### Example
```bash
python user_realm_check.py "Ascendion" "krithik.b@hp.com" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;" --single
```

#### Output (JSON)
```json
{
  "status": "SUCCESS",
  "realm_name": "Ascendion",
  "user_mail": "krithik.b@hp.com",
  "realm_id": 85,
  "user_id": 456,
  "error": null
}
```

---

## Database Schema

### Required Tables

**Table: `rbac.realm`**
```sql
|- id (INT, PK)
|- realm_name (VARCHAR, UNIQUE)
```

**Table: `rbac.users`**
```sql
|- user_id (INT, PK)
|- user_name (VARCHAR)
|- email (VARCHAR, UNIQUE)
```

**Table: `rbac.user_realm`**
```sql
|- user_id (INT, FK)
|- realm_id (INT, FK)
|- (Primary Key: user_id, realm_id)
```

---

## Error Handling

| Error | Cause | Action |
|-------|-------|--------|
| `Realm not found: {name}` | Realm doesn't exist in `rbac.realm` | Verify realm name, check database |
| `User not found: {email}` | User email doesn't exist in `rbac.users` | Verify email format, check database |
| `User is not a member of realm {name}` | No entry in `rbac.user_realm` | Assign user to realm in database |
| `Missing realm_name or user_mail` | Excel cell is empty | Fill missing data in Excel |
| Database connection failed | Connection string incorrect | Verify connection string, driver |
| Missing required columns | Excel columns not named correctly | Rename columns: `realm_name`, `user_mail` |

---

## Output Files

### CSV Output File
Contains validation results for all processed records with columns:
- `row_number`: Original row in Excel (1-indexed + header)
- `realm_name`: Realm specified in input
- `user_mail`: User email specified in input
- `realm_id`: Numeric ID from `rbac.realm` (empty if not found)
- `user_id`: Numeric ID from `rbac.users` (empty if not found)
- `status`: Validation result (SUCCESS, FAILED, SKIPPED, ERROR)
- `error`: Error message (empty if successful)

### Log File
- **Filename**: `user_realm_check.log`
- **Content**: Detailed validation logs with timestamps
- **Includes**: All 3 validation steps for each record

---

## Validation Flow

```
┌─────────────────────────────┐
│   Read Excel Input File     │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│    Connect to Database      │
└────────────┬────────────────┘
             │
    ┌────────┴────────┐
    │                 │
    ▼                 ▼
┌──────────┐    ┌──────────────┐
│ For each │    │   For each   │
│   row    │    │  realm_name  │
└────┬─────┘    │ & user_mail  │
     │          └──────┬───────┘
     │                 │
     ▼                 ▼
  ┌─────────────────────────────┐
  │ Part 1: Fetch realm_id      │
  │ Query rbac.realm table      │
  └──────────┬──────────────────┘
             │
        ┌────┴────┐
        │          │
       NO         YES
        │          │
        │          ▼
        │    ┌──────────────────┐
        │    │ Part 2: Fetch    │
        │    │ user_id from     │
        │    │ rbac.users       │
        │    └────────┬─────────┘
        │             │
        │        ┌────┴────┐
        │        │          │
        │       NO         YES
        │        │          │
        │        │          ▼
        │        │    ┌──────────────────┐
        │        │    │ Part 3: Validate │
        │        │    │ user_realm       │
        │        │    │ membership       │
        │        │    └────────┬─────────┘
        │        │             │
        └────┬───┴─────┬───────┴───┐
             │         │           │
             ▼         ▼           ▼
          ┌──────┐ ┌────────┐ ┌──────────┐
          │FAILED│ │FAILED  │ │ SUCCESS  │
          └──────┘ └────────┘ └──────────┘
             │         │           │
             └─────────┴───────────┘
                      │
                      ▼
        ┌──────────────────────────┐
        │ Append to Results CSV     │
        │ Log to file              │
        │ Update Statistics        │
        └──────────────────────────┘
                      │
                      ▼
        ┌──────────────────────────┐
        │   Write CSV, Print Stats │
        │   Close DB Connection    │
        └──────────────────────────┘
```

---

## Advanced Usage

### Processing Large Files
For files with thousands of records:
```bash
# The script automatically handles large files
# Progress is logged to console and file
python user_realm_check.py "large_input.xlsx" "your_connection_string" "large_results.csv"
```

### Specifying Output Location
```bash
# Output to specific directory
python user_realm_check.py "input.xlsx" "connection_string" "C:\output\results.csv"
```

### Debugging
Check `user_realm_check.log` for detailed validation logs:
```bash
# View last 50 lines of log
tail -n 50 user_realm_check.log

# Or open in your editor
notepad user_realm_check.log
```

---

## Integration with Script 2

The output of this script (realm_id and user_id) is used by **Script 2 (KB Master Insert)**:
- `realm_id`: Used as Foreign Key in KB inserts
- `user_id`: Used for `created_by`, `approved_by`, and `uploaded_by` fields

### Example Flow
```
Script 1 (This Script)
├─ Input: Excel with realm_name, user_mail
├─ Output: CSV with realm_id, user_id, status
│
└─→ Script 2 (KB Master Insert)
    ├─ Input: realm_id, user_id from Script 1
    └─ Output: KB records inserted in database
```

---

## Troubleshooting

### Connection String Issues
```
Error: "Failed to connect to database"
```
**Solution**: 
1. Verify ODBC driver is installed
2. Check server name is reachable
3. Verify database name exists
4. Check credentials (if using username/password)

### Missing Columns
```
Error: "Missing required columns in Excel: realm_name, user_mail"
```
**Solution**:
1. Ensure Excel has exactly these column names (case-sensitive)
2. No extra spaces in column names
3. Data starts from row 2 (row 1 is header)

### Slow Processing
**Solutions**:
1. Check network connectivity to database
2. Verify database indexes on email and realm_name
3. Consider splitting large files into smaller batches

---

## Performance Metrics

| Metric | Value |
|--------|-------|
| Records/second | ~50-100 (depends on DB) |
| Memory usage | ~100MB for 10,000 records |
| Network latency impact | ~20-50ms per query |

### Optimization Tips
- Use SQL Server indexes on `email` and `realm_name`
- Batch size: Process files with 1000-5000 records
- Network: Run on same network as database

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-26 | Initial release with single mode |
| 2.0 | 2026-03-26 | Added Excel batch processing, CSV output, improved logging |

---

## License & Support

For issues or questions:
1. Check `user_realm_check.log` for error details
2. Review error handling section above
3. Verify database connectivity and schema

---

## Next Steps

After successful validation:
1. Use the output CSV with **Script 2** for KB Master Insert
2. Verify realm_id and user_id mappings
3. Monitor insertion process in Script 2
