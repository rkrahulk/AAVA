# User & Realm Checking Script - QUICK START GUIDE

## 5-Minute Setup

### Step 1: Install Dependencies
```bash
# Install required packages
pip install pandas openpyxl pyodbc
```

### Step 2: Prepare Input Excel File
Create a file named `realm_user_input.xlsx` with this structure:

| realm_name  | user_mail          |
|-------------|-------------------|
| Ascendion   | user1@example.com  |
| DataFlow    | user2@example.com  |

### Step 3: Get Connection String

**For SQL Server (Trusted Connection):**
```
Driver={ODBC Driver 17 for SQL Server};Server=your_server;Database=your_db;Trusted_Connection=yes;
```

**For SQL Server (Username/Password):**
```
Driver={ODBC Driver 17 for SQL Server};Server=your_server;Database=your_db;UID=username;PWD=password;
```

### Step 4: Run Script

```bash
python user_realm_check.py "realm_user_input.xlsx" "YOUR_CONNECTION_STRING" "results.csv"
```

### Step 5: Check Results

Open `results.csv` to see validation results:
```
row_number,realm_name,user_mail,realm_id,user_id,status,error
2,Ascendion,user1@example.com,85,456,SUCCESS,
3,DataFlow,user2@example.com,99,789,SUCCESS,
```

---

## Common Use Cases

### Use Case 1: Single Record Validation
**Scenario**: Check if one user is in one realm

```bash
python user_realm_check.py "Ascendion" "krithik.b@hp.com" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;Trusted_Connection=yes;" --single
```

### Use Case 2: Batch Processing 100 Records
**Scenario**: Validate 100 users from Excel

```bash
python user_realm_check.py "users_batch.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=my_server;Database=rbac_db;Trusted_Connection=yes;" "batch_results.csv"
```

### Use Case 3: Auto-Named Output
**Scenario**: Let script generate output filename with timestamp

```bash
python user_realm_check.py "input.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;Trusted_Connection=yes;"
# Output: user_realm_validation_20260326_143022.csv
```

---

## Expected Output

### Success Case
```json
{
  "status": "SUCCESS",
  "realm_name": "Ascendion",
  "user_mail": "krithik.b@hp.com",
  "realm_id": 85,
  "user_id": 456,
  "error": null
}
```

### Failure Cases

**Realm not found:**
```json
{
  "status": "FAILED",
  "realm_name": "InvalidRealm",
  "user_mail": "user@example.com",
  "realm_id": null,
  "user_id": null,
  "error": "Realm not found: InvalidRealm"
}
```

**User not found:**
```json
{
  "status": "FAILED",
  "realm_name": "Ascendion",
  "user_mail": "notexist@example.com",
  "realm_id": 85,
  "user_id": null,
  "error": "User not found: notexist@example.com"
}
```

**User not in realm:**
```json
{
  "status": "FAILED",
  "realm_name": "Ascendion",
  "user_mail": "user@example.com",
  "realm_id": 85,
  "user_id": 456,
  "error": "User user@example.com is not a member of realm Ascendion"
}
```

---

## Troubleshooting

### Problem: "pyodbc not installed"
```bash
pip install pyodbc
```

### Problem: "pandas not installed"
```bash
pip install pandas openpyxl
```

### Problem: "ODBC Driver not found"
**Windows**: Download and install [ODBC Driver 17 for SQL Server](https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server)

### Problem: "File not found: realm_user_input.xlsx"
- Check Excel file exists in current directory
- Use full path: `C:\path\to\realm_user_input.xlsx`

### Problem: "Connect error: (18456, '[18456]')"
- Verify username and password
- Verify user has access to RBAC database
- Check server name is correct

### Problem: "Realm not found" for valid realm
- Check realm name spelling (case-sensitive)
- Verify realm exists in `rbac.realm` table
- Try: `SELECT * FROM rbac.realm WHERE realm_name LIKE '%your_realm%'`

### Problem: "User not found" for valid email
- Check email spelling (case-sensitive)
- Verify email exists in `rbac.users` table
- Try: `SELECT * FROM rbac.users WHERE email LIKE '%your_email%'`

---

## Sample Data to Test With

Create a test Excel file with this data:

```
realm_name,user_mail
Ascendion,admin@ascendion.com
Ascendion,analyst@ascendion.com
DataFlow,engineer@dataflow.com
```

First, verify this data exists in your database:
```sql
-- Check realms
SELECT id, realm_name FROM rbac.realm;

-- Check users
SELECT user_id, user_name, email FROM rbac.users;

-- Check memberships
SELECT user_id, realm_id FROM rbac.user_realm;
```

---

## Output Files Explained

### results.csv
Contains validation results for each row:
- `row_number`: Line number in Excel (1-indexed + header)
- `realm_name`: Input realm
- `user_mail`: Input email
- `realm_id`: Found ID (empty if not found)
- `user_id`: Found ID (empty if not found)
- `status`: SUCCESS / FAILED / SKIPPED / ERROR
- `error`: Error message (empty if successful)

### user_realm_check.log
Detailed log with:
- Timestamp
- Each validation step
- Database query results
- Summary statistics

**View log:**
```bash
# Windows PowerShell
Get-Content user_realm_check.log -Tail 50

# Unix/Mac
tail -n 50 user_realm_check.log
```

---

## Next Steps

After successful validation:
1. **Use realm_id and user_id** from CSV in Script 2
2. **Feed output CSV** to KB Master Insert script
3. **Monitor insertion** process
4. **Verify KB records** created successfully

---

## Tips & Best Practices

1. **Test with single record first** before batch processing
2. **Keep Excel simple** - only 2 columns: realm_name, user_mail
3. **No headers in data** - put actual data in row 2 onwards
4. **Check log file** when validation fails
5. **Use unique connection string** for each environment (dev, prod)
6. **Batch size recommendation** - 1000-5000 records per file
7. **Regular backups** of results.csv before re-running

---

## Command Reference

```bash
# Single record (with --single flag)
python user_realm_check.py "realm_name" "email@domain.com" "connection_string" --single

# Batch processing (default, no --single flag)
python user_realm_check.py "input.xlsx" "connection_string" "output.csv"

# Batch with auto-named output
python user_realm_check.py "input.xlsx" "connection_string"

# Show help
python user_realm_check.py
```

---

## Support Resources

1. **README**: See `USER_REALM_CHECK_README.md` for full documentation
2. **Design Doc**: See `KB_CREATION_SCRIPT1_DESIGN.md` for technical details
3. **Log File**: Check `user_realm_check.log` for error details
4. **Sample Input**: Use `sample_realm_user_input.csv` as template

---

## Summary

| Task | Command |
|------|---------|
| **Single record validation** | `python user_realm_check.py "realm" "email" "conn_str" --single` |
| **Batch validation** | `python user_realm_check.py "input.xlsx" "conn_str" "output.csv"` |
| **View results** | `Open results.csv in Excel` |
| **View log** | `Get-Content user_realm_check.log -Tail 100` |
| **Test connection** | Use SQL Server Management Studio |
