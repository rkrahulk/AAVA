"""
Script 1: User and Realm Checking (Enhanced for Batch Processing)
Purpose: Validate users against realms in the RBAC database from Excel input
Inputs: 
  - Excel file with columns: realm_name, user_mail
  - Database connection string

Flow:
  Part 1: Fetch realm_id from rbac.realm table
  Part 2: Fetch user_id from rbac.users table
  Part 3: Validate user-realm membership in rbac.user_realm table

Processing:
  - Reads all rows from Excel file
  - Validates each row
  - Continues on error, marks as FAILED
  - Outputs results to CSV file

Output: realm_id, user_id, validation_status for each row
"""

import sys
import logging
import os
from typing import Tuple, Optional, List, Dict
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('user_realm_check.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    logger.warning("pandas not installed. Excel reading will be skipped.")


class UserRealmValidator:
    """
    Validates user existence and realm membership against RBAC database.
    """
    
    def __init__(self, db_connection):
        """
        Initialize with database connection.
        
        Args:
            db_connection: Active database connection object
        """
        self.db_connection = db_connection
        self.realm_id = None
        self.user_id = None
    
    def fetch_realm_id(self, realm_name: str) -> Optional[int]:
        """
        Part 1: Query to fetch realm_id
        
        Args:
            realm_name (str): The realm name to look up
            
        Returns:
            int: The realm_id if found, None otherwise
        """
        query = """
        SELECT id, realm_name
        FROM rbac.realm 
        WHERE realm_name = ?
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (realm_name,))
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                self.realm_id = result[0]
                realm_name_fetched = result[1]
                logger.info(f"✓ Part 1 Passed: Realm '{realm_name_fetched}' found with ID: {self.realm_id}")
                return self.realm_id
            else:
                error_msg = f"Realm not found: {realm_name}"
                logger.error(f"✗ Part 1 Failed: {error_msg}")
                return None
                
        except Exception as e:
            error_msg = f"Error fetching realm_id for '{realm_name}': {str(e)}"
            logger.error(f"✗ Part 1 Exception: {error_msg}")
            return None
    
    def fetch_user_id(self, user_mail: str) -> Optional[int]:
        """
        Part 2: Query to fetch user_id
        
        Args:
            user_mail (str): The user's email address to look up
            
        Returns:
            int: The user_id if found, None otherwise
        """
        query = """
        SELECT user_id, user_name, email
        FROM rbac.users 
        WHERE email = ?
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (user_mail,))
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                self.user_id = result[0]
                user_name = result[1]
                email = result[2]
                logger.info(f"✓ Part 2 Passed: User '{user_name}' ({email}) found with ID: {self.user_id}")
                return self.user_id
            else:
                error_msg = f"User not found: {user_mail}"
                logger.error(f"✗ Part 2 Failed: {error_msg}")
                return None
                
        except Exception as e:
            error_msg = f"Error fetching user_id for '{user_mail}': {str(e)}"
            logger.error(f"✗ Part 2 Exception: {error_msg}")
            return None
    
    def validate_user_realm_membership(self, realm_name: str, user_mail: str) -> bool:
        """
        Part 3: Query to fetch whether user is part of the realm
        
        Args:
            realm_name (str): The realm name (for error message)
            user_mail (str): The user email (for error message)
            
        Returns:
            bool: True if user is a member of the realm, False otherwise
        """
        if self.user_id is None or self.realm_id is None:
            error_msg = "user_id or realm_id not set. Execute fetch_realm_id and fetch_user_id first."
            logger.error(f"✗ Part 3 Failed: {error_msg}")
            return False
        
        query = """
        SELECT COUNT(*) as membership_count
        FROM rbac.user_realm 
        WHERE user_id = ? AND realm_id = ?
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (self.user_id, self.realm_id))
            result = cursor.fetchone()
            cursor.close()
            
            count = result[0]
            
            if count >= 1:
                logger.info(f"✓ Part 3 Passed: User '{user_mail}' is a member of realm '{realm_name}'")
                return True
            else:
                error_msg = f"User {user_mail} is not a member of realm {realm_name}"
                logger.error(f"✗ Part 3 Failed: {error_msg}")
                return False
                
        except Exception as e:
            error_msg = f"Error validating user-realm membership: {str(e)}"
            logger.error(f"✗ Part 3 Exception: {error_msg}")
            return False
    
    def validate(self, realm_name: str, user_mail: str) -> Dict:
        """
        Execute all three validation parts in sequence.
        
        Args:
            realm_name (str): The realm name to validate
            user_mail (str): The user email to validate
            
        Returns:
            Dict: Validation result with status, realm_id, user_id, and error message (if any)
        """
        # Reset state for new validation
        self.realm_id = None
        self.user_id = None
        error_message = ""
        
        try:
            # Part 1: Fetch realm_id
            if self.fetch_realm_id(realm_name) is None:
                return {
                    "status": "FAILED",
                    "realm_name": realm_name,
                    "user_mail": user_mail,
                    "realm_id": None,
                    "user_id": None,
                    "error": f"Realm not found: {realm_name}"
                }
            
            # Part 2: Fetch user_id
            if self.fetch_user_id(user_mail) is None:
                return {
                    "status": "FAILED",
                    "realm_name": realm_name,
                    "user_mail": user_mail,
                    "realm_id": self.realm_id,
                    "user_id": None,
                    "error": f"User not found: {user_mail}"
                }
            
            # Part 3: Validate membership
            if not self.validate_user_realm_membership(realm_name, user_mail):
                return {
                    "status": "FAILED",
                    "realm_name": realm_name,
                    "user_mail": user_mail,
                    "realm_id": self.realm_id,
                    "user_id": self.user_id,
                    "error": f"User {user_mail} is not a member of realm {realm_name}"
                }
            
            # All validations passed
            return {
                "status": "SUCCESS",
                "realm_name": realm_name,
                "user_mail": user_mail,
                "realm_id": self.realm_id,
                "user_id": self.user_id,
                "error": None
            }
            
        except Exception as e:
            return {
                "status": "ERROR",
                "realm_name": realm_name,
                "user_mail": user_mail,
                "realm_id": None,
                "user_id": None,
                "error": str(e)
            }


def validate_from_excel(excel_file: str, connection_string: str, output_file: Optional[str] = None) -> Dict:
    """
    Batch process validations from an Excel file.
    
    Args:
        excel_file (str): Path to Excel file with realm_name and user_mail columns
        connection_string (str): Database connection string
        output_file (str): Optional output CSV file path. If None, generates with timestamp.
        
    Returns:
        Dict: Summary of processed validations
    """
    
    if not PANDAS_AVAILABLE:
        error_msg = "pandas is required for Excel processing. Install with: pip install pandas openpyxl"
        logger.error(f"✗ Fatal Error: {error_msg}")
        sys.exit(error_msg)
    
    # Check if Excel file exists
    if not os.path.exists(excel_file):
        error_msg = f"Excel file not found: {excel_file}"
        logger.error(f"✗ Fatal Error: {error_msg}")
        sys.exit(error_msg)
    
    # Generate output file path if not provided
    if output_file is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"user_realm_validation_{timestamp}.csv"
    
    logger.info(f"\n{'='*80}")
    logger.info("Starting Batch User and Realm Validation from Excel")
    logger.info(f"Input File: {excel_file}")
    logger.info(f"Output File: {output_file}")
    logger.info(f"{'='*80}\n")
    
    try:
        # Read Excel file
        logger.info("Reading Excel file...")
        df = pd.read_excel(excel_file, sheet_name=0)  # First sheet
        
        # Validate required columns
        required_columns = ['realm_name', 'user_mail']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            error_msg = f"Missing required columns in Excel: {', '.join(missing_columns)}\nFound columns: {', '.join(df.columns)}"
            logger.error(f"✗ Fatal Error: {error_msg}")
            sys.exit(error_msg)
        
        total_records = len(df)
        logger.info(f"✓ Loaded {total_records} records from Excel\n")
        
        # Establish database connection
        try:
            import pyodbc
            db_connection = pyodbc.connect(connection_string)
            logger.info("✓ Connected to database\n")
        except ImportError:
            error_msg = "pyodbc not installed. Please install: pip install pyodbc"
            logger.error(f"✗ Fatal Error: {error_msg}")
            sys.exit(error_msg)
        except Exception as e:
            error_msg = f"Failed to connect to database: {str(e)}"
            logger.error(f"✗ Fatal Error: {error_msg}")
            sys.exit(error_msg)
        
        # Process each record
        results = []
        success_count = 0
        failed_count = 0
        error_count = 0
        
        validator = UserRealmValidator(db_connection)
        
        for idx, row in df.iterrows():
            row_number = idx + 2  # Excel row number (1-indexed + header)
            realm_name = row['realm_name'].strip() if pd.notna(row['realm_name']) else ""
            user_mail = row['user_mail'].strip() if pd.notna(row['user_mail']) else ""
            
            if not realm_name or not user_mail:
                logger.warning(f"⚠ Row {row_number}: Skipping - Missing realm_name or user_mail")
                results.append({
                    "row_number": row_number,
                    "realm_name": realm_name,
                    "user_mail": user_mail,
                    "realm_id": "",
                    "user_id": "",
                    "status": "SKIPPED",
                    "error": "Missing realm_name or user_mail"
                })
                continue
            
            logger.info(f"Processing Row {row_number}: realm='{realm_name}', user='{user_mail}'")
            
            # Validate
            result = validator.validate(realm_name, user_mail)
            
            # Add row number to result
            result["row_number"] = row_number
            
            # Format realm_id and user_id for output
            if result["realm_id"] is None:
                result["realm_id"] = ""
            if result["user_id"] is None:
                result["user_id"] = ""
            
            results.append(result)
            
            # Track statistics
            if result["status"] == "SUCCESS":
                success_count += 1
                logger.info(f"  ✓ SUCCESS: realm_id={result['realm_id']}, user_id={result['user_id']}\n")
            elif result["status"] == "FAILED":
                failed_count += 1
                logger.warning(f"  ✗ FAILED: {result['error']}\n")
            else:  # ERROR
                error_count += 1
                logger.error(f"  ✗ ERROR: {result['error']}\n")
        
        # Close database connection
        db_connection.close()
        logger.info("Database connection closed\n")
        
        # Write results to CSV
        logger.info(f"Writing results to CSV file: {output_file}")
        results_df = pd.DataFrame(results)
        
        # Reorder columns for better readability
        column_order = ["row_number", "realm_name", "user_mail", "realm_id", "user_id", "status", "error"]
        results_df = results_df[column_order]
        
        results_df.to_csv(output_file, index=False)
        logger.info(f"✓ Results written to {output_file}\n")
        
        # Summary
        logger.info(f"\n{'='*80}")
        logger.info("VALIDATION SUMMARY")
        logger.info(f"{'='*80}")
        logger.info(f"Total Records:    {total_records}")
        logger.info(f"Successful:       {success_count}")
        logger.info(f"Failed:           {failed_count}")
        logger.info(f"Error:            {error_count}")
        logger.info(f"Skipped:          {len(results) - success_count - failed_count - error_count}")
        logger.info(f"Output File:      {output_file}")
        logger.info(f"{'='*80}\n")
        
        return {
            "status": "completed",
            "total_records": total_records,
            "successful": success_count,
            "failed": failed_count,
            "error": error_count,
            "output_file": output_file
        }
        
    except Exception as e:
        error_msg = f"Unexpected error during batch processing: {str(e)}"
        logger.error(f"✗ Fatal Error: {error_msg}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(error_msg)


def main():
    """
    Main entry point supporting both Excel batch processing and single record validation.
    
    Usage Mode 1 - Excel Batch Processing:
        python user_realm_check.py <excel_file> <db_connection_string> [output_csv_file]
    
    Example:
        python user_realm_check.py "input_data.xlsx" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;Database=rbac_db;" "results.csv"
    
    Usage Mode 2 - Single Record Validation (backwards compatible):
        python user_realm_check.py <realm_name> <user_mail> <db_connection_string> --single
    
    Example:
        python user_realm_check.py "Ascendion" "user@example.com" "Driver={ODBC Driver 17 for SQL Server};Server=localhost;..." --single
    """
    
    if len(sys.argv) < 3:
        print("\n" + "="*80)
        print("USER AND REALM VALIDATION SCRIPT")
        print("="*80)
        print("\nUsage Mode 1 - Excel Batch Processing (RECOMMENDED):")
        print("  python user_realm_check.py <excel_file> <connection_string> [output_csv]")
        print("\nUsage Mode 2 - Single Record Validation:")
        print("  python user_realm_check.py <realm_name> <user_mail> <connection_string> --single")
        print("\nConnection String Template:")
        print("  SQL Server: Driver={ODBC Driver 17 for SQL Server};Server=your_server;Database=your_db;Trusted_Connection=yes;")
        print("\n" + "="*80 + "\n")
        sys.exit("Error: Insufficient arguments. See usage above.")
    
    # Check if single mode or batch mode
    is_single_mode = "--single" in sys.argv
    
    if is_single_mode:
        # Single record mode
        if len(sys.argv) < 5:
            sys.exit("Error: Single mode requires <realm_name> <user_mail> <connection_string> --single")
        
        realm_name = sys.argv[1]
        user_mail = sys.argv[2]
        connection_string = sys.argv[3]
        
        logger.info("Running in Single Record Mode")
        
        try:
            import pyodbc
            db_connection = pyodbc.connect(connection_string)
        except ImportError:
            sys.exit("Error: pyodbc not installed. Install with: pip install pyodbc")
        except Exception as e:
            sys.exit(f"Error: Database connection failed - {str(e)}")
        
        try:
            validator = UserRealmValidator(db_connection)
            result = validator.validate(realm_name, user_mail)
            db_connection.close()
            
            import json
            print("\n" + json.dumps(result, indent=2))
            
            if result["status"] != "SUCCESS":
                sys.exit(1)
                
        except Exception as e:
            logger.error(f"Validation failed: {str(e)}")
            sys.exit(str(e))
    
    else:
        # Batch mode (Excel)
        excel_file = sys.argv[1]
        connection_string = sys.argv[2]
        output_file = sys.argv[3] if len(sys.argv) > 3 else None
        
        logger.info("Running in Batch Excel Processing Mode")
        summary = validate_from_excel(excel_file, connection_string, output_file)
        
        import json
        print("\n" + json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
