
from pydantic import BaseModel


class RuntimeLogs(BaseModel):
    progress: str | None = None
    content: str | None = None
    color: str | None = None
    sender: str | None = None
    executionId: str | None = None


def to_dict(self):
    return {
        "progress": self.progress,
        "content": self.content,
        "color": self.color,
        "sender": self.sender,
        "executionId": self.executionId,
    }
