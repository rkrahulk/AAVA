from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str

    class Config:
        json_schema_extra = {"example": {"status": "healthy"}}
