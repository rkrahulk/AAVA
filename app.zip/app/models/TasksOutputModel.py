from pydantic import BaseModel, Field


class TasksOutputModel(BaseModel):
    description: str = Field(
        description="Detailed description of what the task did or processed."
    )
    summary: str = Field(description="Concise summary of the task outcome.")
    expected_output: str = Field(
        description="The output that was anticipated or required from the task."
    )
    raw: str = Field(
        description="The raw output data, often in structured format (e.g., JSON)."
    )
