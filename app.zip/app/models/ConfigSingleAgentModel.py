from typing import Any

from pydantic import BaseModel, Field


class ConfigCollectionGoogle(BaseModel):
    aiEngine: str | None = Field(
        "GoogleAI", description="GCP AI Engine for embedding"
    )
    embedding_model: str | None = Field(
        None, description="Google embedding model name"
    )
    gcp_project_id: str = Field(..., description="Google Cloud Project ID")
    gcp_location: str = Field(..., description="Google Cloud location/region")
    index_collection: str | None = Field(
        None, description="Target collection index name"
    )


# ---- AZURE ----
class ConfigCollectionAzure(BaseModel):
    aiEngine: str | None = Field(
        "AzureOpenAI", description="Azure AI Engine for embedding"
    )
    embedding_model: str | None = Field(
        None, description="Azure embedding model name"
    )
    embedding_deployment_name: str | None = Field(
        None, description="Azure deployment name for embeddings"
    )
    embedding_api_version: str | None = Field(
        None, description="Azure API version for embeddings"
    )
    embedding_access_key: str | None = Field(
        None, description="Access key for Azure embeddings"
    )
    embedding_azure_endpoint: str | None = Field(
        None, description="Azure endpoint for embeddings"
    )
    index_collection: str | None = Field(
        None, description="Target collection index name"
    )


# ---- BEDROCK ----
class ConfigCollectionBedrock(BaseModel):
    aiEngine: str | None = Field(
        "AmazonBedrock", description="AWS AI Engine for embedding"
    )
    embedding_aws_key: str | None = Field(
        None, description="AWS access key for embedding"
    )
    embedding_aws_secret_key: str | None = Field(
        None, description="AWS secret key for embedding"
    )
    embedding_aws_region: str | None = Field(
        None, description="AWS region for embedding"
    )
    embedding_model_id: str | None = Field(
        None, description="Bedrock embedding model ID"
    )
    index_collection: str = Field(..., description="Target collection index name")


class AgentDetailsConfig(BaseModel):
    llm: dict[str, Any] | None = Field(
        default=None, description="LLM configuration block"
    )

    class Config:
        extra = "allow"


class ConfigBase(BaseModel):
    prompt: str = Field(..., description="The user prompt/query")
    user: str = Field(..., description="User identifier")
    use_case: str = Field(..., description="Use case or scenario for the query")

    # Langfuse
    langfuse_host: str = Field(..., description="Langfuse host for observability")
    langfuse_public_key: str = Field(..., description="Langfuse public API key")
    langfuse_secret_key: str = Field(..., description="Langfuse secret API key")

    # Chroma DB
    chroma_end_point: str | None = Field(None, description="Chroma DB endpoint")
    chroma_port: str | None = Field(None, description="Chroma DB port")

    # RAG
    context_record_number: int | None = Field(
        None, gt=0, description="Number of context records to retrieve"
    )
    rag_enable: bool = Field(..., description="Enable or disable RAG")
    rag_mode: str | None = Field(None, description="RAG mode (e.g., STRICT, HYBRID)")

    # logs
    sender: str | None = Field(None, description="Sender identifier for logging")
    executionId: str | None = Field(None, description="Execution ID for tracking")

    # Advanced options
    image: list[Any] | None = Field(
        default=None, description="Optional image data for vision-based models"
    )
    reranker: bool | None = Field(
        default=False, description="Enable reranking of retrieved contexts"
    )
    llm_lingua: bool | None = Field(
        default=False, description="Enable LLM Lingua constraints"
    )
    nemo_guardrails: bool | None = Field(
        default=False, description="Enable Nemo Guardrails (safety framework)"
    )
    colang_content: str | None = Field(
        default=None, description="Optional Colang DSL content for guardrails"
    )
    yaml_content: str | None = Field(
        default=None, description="Optional YAML content for guardrails"
    )

    # Agent and LLM config
    agent_details: AgentDetailsConfig | None = Field(
        default=None,
        description="Agent and llm configuration block (flexible, supports extra keys)",
    )
    collection_config: list[
        ConfigCollectionGoogle | ConfigCollectionAzure | ConfigCollectionBedrock
    ] = Field(None, description="List of embedding collection configs")
