# from pydantic import BaseModel, Field
# from typing import Optional

# class AgentLLM(BaseModel):
#     pass
# model: str = Field("gpt-4", description="The LLM model name to be used.")
# aiEngine: str = Field("openai", description="AI engine provider (e.g., openai, bedrock, vertexai).")
# temperature: float = Field(0.7, description="Sampling temperature to control randomness in output.")
# max_tokens: int = Field(2048, description="Maximum number of tokens to generate in the response.")
# top_p: float = Field(0.9, description="Nucleus sampling parameter for controlling diversity.")

# llmDeploymentName: Optional[str] = Field("gpt-deployment", description="Deployment name used with Azure OpenAI.")
# api_key: Optional[str] = Field("your-api-key", description="API key for authentication (OpenAI/Azure/Vertex AI).")
# base_url: Optional[str] = Field("https://your-resource.openai.azure.com", description="Azure OpenAI endpoint.")
# api_version: Optional[str] = Field("2023-05-15", description="API version for Azure OpenAI.")

# bedrockModelId: Optional[str] = Field("amazon.titan-text-lite-v1", description="Amazon Bedrock model ID.")
# aws_region_name: Optional[str] = Field("Your-region", description="Region for cloud provider (e.g., AWS region).")
# aws_access_key_id: Optional[str] = Field("Your-accesskey", description="AWS access key for Bedrock.")
# aws_secret_access_key: Optional[str] = Field("Your-secretkey", description="AWS secret access key for Bedrock.")

# vertexAIEndpoint: Optional[str] = Field("us-central1-aiplatform.googleapis.com", description="Vertex AI endpoint.")
# gcp_project_id: Optional[str] = Field("my-gcp-project", description="Google Cloud project ID.")
# location: Optional[str] = Field("us-central1", description="Google Cloud location for Vertex AI.")
