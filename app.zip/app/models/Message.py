from pydantic import BaseModel, Field


class Message(BaseModel):
    progress: str = Field(
        description="Current progress status of the task, represented as a percentage or status text."
    )
    content: str = Field(description="The main message content or status update.")
    sender: str = Field(
        description="Identifier for the sender of the message, e.g., agent or system component."
    )
    executionId: str = Field(
        description="Unique identifier associated with the ongoing execution."
    )
    pipelineId: str = Field(
        description="Identifier for the pipeline under which the execution is taking place."
    )
