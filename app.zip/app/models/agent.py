from pydantic import BaseModel

from app.models.agentDetails import AgentDetails


class Agent(BaseModel):
    serial: int
    agent: AgentDetails
