
from pydantic import BaseModel, Field

from .AgentTools import AgentTools, AgentUserTools


class PipelineRequest(BaseModel):
    pipeLineId: int = Field(
        description="Unique identifier for the pipeline to be executed."
    )
    executionId: str = Field(
        description="Optional execution ID for tracking the request."
    )
    userInputs: dict[str, str] = Field(
        description="Dictionary of user-provided inputs needed by the pipeline."
    )
    user: str = Field(
        description="Identifier or email of the user initiating the pipeline."
    )
    tools: list["AgentTools"] = Field(  # TODO
        default_factory=list,
        description="List of global tools used across the pipeline agents.",
    )
    userTools: list["AgentUserTools"] | None = Field(  # TODO
        default_factory=list,
        description="List of user-defined custom tools for the pipeline.",
    )

    class Config:
        title = "PipelineRequest"
        json_schema_extra = {
            "example": {
                "pipeLineId": 101,
                "executionId": "exec_20240729_001",
                "userInputs": {"language": "en", "priority": "high"},
                "user": "johndoe",
                "tools": [{"toolId": 1, "toolName": "ExampleTool", "parameters": []}],
                "userTools": [
                    {
                        "toolId": 2,
                        "toolName": "UserTool",
                        "toolClassName": "CustomToolClass",
                        "toolClassDef": "class CustomToolClass: pass",
                    }
                ],
            }
        }
