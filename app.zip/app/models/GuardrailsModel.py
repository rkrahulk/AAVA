
from typing import Optional
from pydantic import BaseModel

class GuardrailsModel(BaseModel):
    colang_content: str
    yaml_content: str
    llm: dict
    collection_config: Optional[dict] = {
            "index_collection": "factorial",
            "embedding_model": "text-embedding-ada-002",
            "embedding_deployment_name": "ava-text-embedding-ada-002",
            "embedding_api_version": "2023-05-15",
            "embedding_access_key": "39b5873bfa0040e48319e563464528e7",
            "embedding_azure_endpoint": "https://da-azurerm-cognitive-account-dev.openai.azure.com"
        }