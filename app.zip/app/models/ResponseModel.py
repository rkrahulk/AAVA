
from pydantic import BaseModel, Field


class Document(BaseModel):
    page_content: str = Field(
        "Sample extracted text from the document.",
        description="The main content of a document page.",
    )
    metadata: dict[str, str] = Field(
        {"source": "example.pdf", "page": "12"},
        description="Metadata such as source filename and page number.",
    )


class ResponseModel(BaseModel):
    input: str | None = Field(description="The user's query or input prompt.")
    answer: str | None = Field(description="The answer generated for the input.")
    context: list[Document] | None = Field(
        default_factory=list,
        description="List of documents used as context for the answer.",
    )
