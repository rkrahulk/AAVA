from pydantic import BaseModel, Field


class TestTool(BaseModel):
    class_name: str = Field(
        description="The name of the class that defines the tool logic."
    )
    class_definition: str = Field(
        description="Full string definition of the class, including method implementations."
    )
    inputs: dict = Field(
        default_factory=dict,
        example={"text": "The product was great!"},
        description="Dictionary of input parameters required by the tool class.",
    )
