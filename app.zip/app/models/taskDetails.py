
from pydantic import BaseModel, Field


class TaskDetails(BaseModel):
    description: str | None = Field(
        None, description="A brief description of the task the agent should perform."
    )  #
    expectedOutput: str | None = Field(
        None, description="The expected result or format of the task output."
    )  #
    guardrail: dict | None = Field(
        None, description="Guardrails configuration for the task, if any."
    )
