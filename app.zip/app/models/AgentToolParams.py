
from pydantic import BaseModel, Field


class AgentToolParams(BaseModel):
    id: int = Field(description="Unique identifier of the parameter.")
    parameterName: str = Field(description="Name of the parameter used by the tool.")
    parameterType: str = Field(
        description="Type of the parameter (e.g., string, number, boolean)."
    )
    value: str | None = Field(description="Value assigned to this parameter.")
