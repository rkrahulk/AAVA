
from pydantic import BaseModel, Field
from typing import Optional
from .AgentToolParams import AgentToolParams


class AgentTools(BaseModel):
    toolId: int = Field(description="ID of the predefined tool.")
    toolName: str = Field(description="Name of the tool.")
    toolClassName: Optional[str] = Field("", description="toolClassName")
    parameters: list[AgentToolParams] = Field(
        [], description="List of parameters required by the tool."
    )
    toolType: Optional[str] = Field("system", description="service account type realm based identification for AVAsecrets")


class AgentUserTools(BaseModel):
    toolId: int = Field(description="ID of the user-defined tool.")
    toolName: str = Field(description="Display name of the tool.")
    toolClassName: str = Field(description="Class name implementing the tool logic.")
    toolClassDef: str = Field(description="Full Python class definition of the tool.")
    toolType: Optional[str] = Field("", description="service account type realm based identification for AVAsecrets")

