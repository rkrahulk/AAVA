from urllib.parse import urlparse
from app.core.config import settings
import AVASecret

def is_valid_base_url(base_url: str, allowed_hosts: set[str]) -> bool:
    try:
        parsed = urlparse(base_url)
        MAX_LEN = 255

        # Must be HTTPS
        if parsed.scheme != "https":
            return False

        # No query, params, fragment allowed
        if parsed.query or parsed.params or parsed.fragment:
            return False

        # Host must exactly match allowed host
        if base_url not in allowed_hosts:
            return False

        if len(base_url) > MAX_LEN:
            return False

    
        return True

    except Exception as e:
        print(e)
        return False

def get_system_tool_secrets(action, tool_type, service_account_type="system"):
    account = ''
    if service_account_type and service_account_type.lower() != "system":
        account = f"_{service_account_type}"

    username = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_{tool_type}_{action}{account}_global")
    password = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_{tool_type}_{action}{account}_access")
    return username, password