import os
import re
import json
import base64
import requests
from typing import Optional

from pydantic import BaseModel, Field
from crewai.tools import BaseTool

import AVASecret
from app.core.config import settings
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

class JiraConnectorSchema(BaseModel):
    base_domain: str = Field(..., description="Jira base domain")
    operation: str = Field(..., description="Operation type: create_issue / modify_issue / link_issue / add_comment / modify_comment / delete_comment / upload_file / delete_file / download_file")
    issue_key: Optional[str] = None
    project_key: Optional[str] = None
    summary: Optional[str] = None
    description: Optional[str] = None
    issue_type: Optional[str] = None
    priority: str | None = Field(
        default=None,
        description="Priority name (High, Medium, Low, etc.)"
    )
    assignee: str | None = Field(
        default=None,
        description="Assignee username or accountId"
    )
    adf_type: Optional[str] = Field("paragraph", description="ADF content type: paragraph or codeBlock")
    code_language: Optional[str] = Field("json", description="Language for codeBlock if used")
    comment_text: Optional[str] = Field(
        default=None,
        description="comment_text field is for add_comment operation."
    )
    status: str | None = Field(
        default=None,
        description="Status name (To Do, In Progress, Done, etc.)"
    )

class JiraConnectorTool(BaseTool):
    name: str = "JiraConnectorTool"
    description: str = """
    Jira connector tool supporting multiple operations using fuzzy operation names.

    Supported operations (case-insensitive, fuzzy matching allowed):
    - create issue / create / create ticket / create_issue
    - modify issue / modify / modify ticket / modify_issue
    - update status / status / change status
    - add comment / comment / add_comment

    IMPORTANT OPERATION RULES:

    1) CREATE ISSUE
    Required:
    - base_domain
    - operation (any create variant)
    - project_key
    - summary
    - issue_type
    Optional:
    - description
    - priority
    - assignee

    Do NOT provide issue_key when creating.

    2) MODIFY ISSUE
    Required:
    - base_domain
    - operation (any modify variant)
    - issue_key
    Optional (at least one should be provided):
    - summary
    - description
    - priority
    - assignee
    - issue_type

    project_key should match the issue_key prefix if provided.

    3) UPDATE STATUS
    Required:
    - base_domain
    - operation (status/update status/change status)
    - issue_key
    - status

    4) ADD COMMENT
    Required:
    - base_domain
    - operation (add comment/comment)
    - issue_key
    - comment_text

    GENERAL RULES:
    - Do NOT mix create fields with modify fields.
    - Do NOT send irrelevant parameters.
    - Do NOT invent values.
    - Do NOT send empty strings.
    - Only include fields relevant to the selected operation.
    - If unsure about a field, omit it.
    - project_key must be uppercase and valid.
    - issue_key must be in format PROJECT-123.

    This tool performs write operations only.
    It does not read issue details.
    """

    service_account_type: str
    args_schema: type = JiraConnectorSchema

    def _get_api_info(self, base_domain, auth):
        """
        Detects if the instance is Cloud (v3) or Server/Data Center (v2).
        Returns the appropriate API version string and base URL.
        """
        try:
            # v3 is usually exclusive to Jira Cloud
            if ".atlassian.net" in base_domain:
                return "3", f"{base_domain}/rest/api/3"
        except Exception as e:
            import traceback
            print(traceback.format_exc())
        return "2", f"{base_domain}/rest/api/2"

    def _run(self, **kwargs):
        args = JiraConnectorSchema(**kwargs)
        if not args.base_domain:
            return "Error: Base url is required."

        base_domain = args.base_domain.strip().lower().rstrip('/')
        project_key = (args.project_key or "").strip().upper()
        if not args.operation:
            return "Error: Operation is required."

        operation = args.operation.strip().lower()

        allowed_base_urls = {
            url.strip().rstrip("/")
            for url in settings.JIRA_BASE_URL.replace(" ", "").split(",")
        }
        if not is_valid_base_url(base_url=base_domain, allowed_hosts=allowed_base_urls):
            return f"Invalid input: Provided Jira base URL ({base_domain}) is not allowed."

        username, password = get_system_tool_secrets(action="write", tool_type="jira", service_account_type=self.service_account_type)
        
        auth = (username, password)
        
        # 1. Intelligent Version Detection
        ver, api_url = self._get_api_info(base_domain, auth)

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        # 2. Operations Logic
        if operation in ("create issue", "create", "create ticket", "create_issue"):

            if not re.fullmatch(r"[A-Z0-9]+", project_key):
                return "Error: Invalid Jira project key."

            payload = {
                "fields": {
                    "project": {"key": args.project_key},
                    "summary": args.summary,
                    "issuetype": {"name": args.issue_type}
                }
            }
            priority, assignee = kwargs.get("priority"), kwargs.get("assignee")
            if priority:
                payload["fields"]["priority"] = {"name": priority}

            if assignee:
                if ver == "3":
                    payload["fields"]["assignee"] = {"accountId": assignee}
                else:
                    payload["fields"]["assignee"] = {"name": assignee}

            if args.description:
                # If v3, use ADF; if v2, use plain string
                payload["fields"]["description"] = (
                    self._build_adf_doc(args.description, args.adf_type, args.code_language) 
                    if ver == "3" else args.description
                )
            
            res = requests.post(f"{api_url}/issue", json=payload, headers=headers, auth=auth)
            res.raise_for_status()
            return f"{base_domain}/browse/{res.json()['key']}"

        elif operation in ("modify issue", "modify", "modify ticket", "modify_issue", "modify jira ticket"):
            if not args.issue_key:
                return "Error: Issue key is required for modifying a ticket."
            
            if not args.project_key.lower() in args.issue_key.lower():
                return "Error: Issue key and Project Key is not matching."

            payload = {"fields": {}}
            if args.summary:
                payload["fields"]["summary"] = args.summary
            if args.description:
                payload["fields"]["description"] = (
                    self._build_adf_doc(args.description, args.adf_type, args.code_language) 
                    if ver == "3" else args.description
                )

            if args.priority:
                payload["fields"]["priority"] = {
                    "name": args.priority
                }

            if args.assignee:
                if ver == "2":
                    payload["fields"]["assignee"] = {
                        "name": args.assignee
                    }
                else:
                    payload["fields"]["assignee"] = {
                        "accountId": args.assignee
                    }

            if args.issue_type:
                payload["fields"]["issuetype"] = {
                    "name": args.issue_type
                }

            res = requests.put(f"{api_url}/issue/{args.issue_key}", json=payload, headers=headers, auth=auth)
            res.raise_for_status()

            return f"{base_domain}/browse/{args.issue_key}"

        elif operation in ("status", "update status", "change status"):
            if args.status:
                transitions_url = f"{api_url}/issue/{args.issue_key}/transitions"

                t_response = requests.get(
                    transitions_url,
                    auth=auth,
                    headers=headers,
                    timeout=60
                )

                transitions = t_response.json().get("transitions", [])

                target_status = args.status.strip().lower()

                transition_id = next(
                    (t["id"] for t in transitions
                    if t["to"]["name"].strip().lower() == target_status),
                    None
                )

                if not transition_id:
                    return json.dumps({
                        "error": f"Status '{args.status}' not available for transition."
                    })

                tr_response = requests.post(
                    transitions_url,
                    json={"transition": {"id": transition_id}},
                    auth=auth,
                    headers=headers,
                    timeout=60
                )

                if not tr_response.ok:
                    logger.info("jira write: status update failed")
                    logger.info(tr_response.text)
                    return json.dumps({
                        "error": "Other fields are updated but status transition failed",
                        "details": tr_response.text
                    })
                
                return f"{base_domain}/browse/{args.issue_key}"
            else:
                return "Error: status is missing."

        elif operation in ("add comment", "comment", "add_comment"):
            if args.comment_text:
                # v3 expects ADF under 'body', v2 expects string under 'body'
                comment_content = (
                    self._build_adf_doc(args.comment_text) if ver == "3" else args.comment_text
                )
                payload = {"body": comment_content}
                res = requests.post(f"{api_url}/issue/{args.issue_key}/comment", json=payload, headers=headers, auth=auth)
                res.raise_for_status()
                return f"{base_domain}/browse/{args.issue_key}"
            else:
                return "Error: Missing comment_text"

    def _build_adf_doc(self, text: str, adf_type: str = "paragraph", language: str = "json"):
        """Helper to build ADF JSON structure for Jira v3."""
        if adf_type == "codeBlock":
            content = [{"type": "text", "text": text}]
            node = {"type": "codeBlock", "attrs": {"language": language}, "content": content}
        else:
            node = {"type": "paragraph", "content": [{"type": "text", "text": text}]}
            
        return {
            "version": 1,
            "type": "doc",
            "content": [node]
        }