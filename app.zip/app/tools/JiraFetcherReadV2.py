import requests
import re
import json
import base64
import logging
import cgi
from typing import List, Dict, Any, Type, Optional
from pydantic import BaseModel
from crewai.tools import BaseTool

from app.core.config import settings
from app.tools.tool_output_validation import validate_output
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

logger = logging.getLogger(__name__)


# =========================================================
# Schema (keep simple)
# =========================================================
class JiraFetcherRead(BaseModel):
    base_url: str
    operation: str
    max_results: int = 20
    project_key: Optional[str] = ""
    issue_key: Optional[str] = ""
    attachment_id: Optional[str] = ""
    include_history: Optional[bool] = False


# =========================================================
# Tool
# =========================================================
class JiraFetcherReadToolV2(BaseTool):

    name: str = "JiraFetcherReadToolV2"
    description: str = "Simple Jira reader (tasks, history, files)"
    llm_details: dict | None = None
    service_account_type: str
    args_schema: Type[BaseModel] = JiraFetcherRead

    # =========================================================
    # 🧠 INPUT NORMALIZATION
    # =========================================================
    def _normalize_operation(self, text: str) -> str:
        op = re.sub(r"[^a-z0-9\s]", "", text.lower())

        if any(k in op for k in ["task", "issue", "ticket", "work", "list", "show", "get"]):
            return "retrieve_issues"

        if any(k in op for k in ["history", "change", "log"]):
            return "retrieve_history"

        if any(k in op for k in ["download", "file", "attachment"]):
            return "download_file"

        return "unknown"

    def _extract_project_key(self, text: str) -> str:
        match = re.search(r"\b([A-Z]{2,10})\b", text.upper())
        return match.group(1) if match else ""

    def _extract_issue_key(self, text: str) -> str:
        match = re.search(r"\b([A-Z]+-\d+)\b", text.upper())
        return match.group(1) if match else ""

    def _extract_attachment_id(self, text: str) -> str:
        match = re.search(r"\b\d{3,}\b", text)
        return match.group(0) if match else ""

    # =========================================================
    # ADF TEXT PARSER
    # =========================================================
    @staticmethod
    def _extract_text(data: Any) -> str:
        if not data:
            return ""
        if isinstance(data, str):
            return data.strip()

        texts = []

        def walk(node):
            if isinstance(node, dict):
                if "text" in node:
                    texts.append(node["text"])
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for i in node:
                    walk(i)

        walk(data)
        return "\n".join(texts)

    # =========================================================
    # API FALLBACK (v3 → v2)
    # =========================================================
    def _request(self, path: str, auth, params=None, stream=False):
        for version in ["3", "2"]:
            try:
                url = f"{path.replace('/rest/api/', f'/rest/api/{version}/')}"
                res = requests.get(url, auth=auth, params=params, stream=stream, timeout=15)
                if res.ok:
                    return res
            except Exception:
                continue
        raise Exception("Jira API request failed (v2 & v3)")

    # =========================================================
    # ACCEPTANCE CRITERIA FIELD
    # =========================================================
    def _get_ac_field(self, base_url, auth):
        try:
            res = self._request(f"{base_url}/rest/api/3/field", auth)
            for f in res.json():
                if f.get("name", "").lower() == "acceptance criteria":
                    return f.get("id")
        except Exception:
            pass
        return None

    # =========================================================
    # HISTORY
    # =========================================================
    def _get_history(self, base_url, issue_key, auth):
        try:
            res = self._request(
                f"{base_url}/rest/api/3/issue/{issue_key}",
                auth,
                params={"expand": "changelog"}
            )

            histories = res.json().get("changelog", {}).get("histories", [])

            changes = []
            for h in histories:
                for item in h.get("items", []):
                    changes.append({
                        "field": item.get("field"),
                        "from": item.get("fromString"),
                        "to": item.get("toString")
                    })

            return changes
        except Exception as e:
            logger.info(f"History error: {str(e)}")
            return []

    # =========================================================
    # MAIN RUN
    # =========================================================
    def _run(self, **kwargs) -> str:

        try:
            base_url = kwargs.get("base_url", "").rstrip("/")
            raw_input = kwargs.get("operation", "")

            # normalize intent
            operation = self._normalize_operation(raw_input)

            # extract smart inputs
            project_key = kwargs.get("project_key") or self._extract_project_key(raw_input)
            issue_key = kwargs.get("issue_key") or self._extract_issue_key(raw_input)
            attachment_id = kwargs.get("attachment_id") or self._extract_attachment_id(raw_input)

            max_results = min(int(kwargs.get("max_results", 20)), 50)
            include_history = kwargs.get("include_history", False)

            # validate URL
            allowed_urls = {
                u.strip().rstrip("/")
                for u in settings.JIRA_BASE_URL.replace(" ", "").split(",")
            }

            if not is_valid_base_url(base_url, allowed_urls):
                return json.dumps({"error": "Invalid Jira URL"})

            username, password = get_system_tool_secrets(
                action="read",
                tool_type="jira",
                service_account_type=self.service_account_type
            )

            auth = (username, password)

            # =====================================================
            # UNKNOWN INTENT
            # =====================================================
            if operation == "unknown":
                return json.dumps({
                    "message": "I didn’t understand 😅",
                    "try": [
                        "show tasks",
                        "show ABC tasks",
                        "history of ABC-1",
                        "download file 123"
                    ]
                })

            # =====================================================
            # DOWNLOAD FILE
            # =====================================================
            if operation == "download_file":
                if not attachment_id:
                    return json.dumps({"error": "Please provide file id"})

                res = self._request(
                    f"{base_url}/rest/api/3/attachment/content/{attachment_id}",
                    auth,
                    stream=True
                )

                disposition = res.headers.get("Content-Disposition")
                file_name = "attachment"

                if disposition:
                    _, params = cgi.parse_header(disposition)
                    file_name = params.get("filename", "attachment")

                if file_name.endswith((".txt", ".json", ".csv")):
                    return json.dumps({
                        "file_name": file_name,
                        "content": res.content.decode("utf-8")
                    })

                return json.dumps({
                    "file_name": file_name,
                    "content_base64": base64.b64encode(res.content).decode()
                })

            # =====================================================
            # HISTORY
            # =====================================================
            if operation == "retrieve_history":
                if not issue_key:
                    return json.dumps({"error": "Tell me task id (example: ABC-1)"})

                history = self._get_history(base_url, issue_key, auth)

                return json.dumps({
                    "task_id": issue_key,
                    "changes": history
                }, indent=2)

            # =====================================================
            # FETCH TASKS
            # =====================================================
            if operation == "retrieve_issues":

                if not project_key:
                    return json.dumps({
                        "error": "Tell me project (example: ABC)"
                    })

                ac_field = self._get_ac_field(base_url, auth)

                fields = [
                    "summary", "description", "comment",
                    "attachment", "status", "assignee",
                    "priority", "issuetype"
                ]

                if ac_field:
                    fields.append(ac_field)

                res = self._request(
                    f"{base_url}/rest/api/3/search",
                    auth,
                    params={
                        "jql": f'project="{project_key}" ORDER BY created DESC',
                        "maxResults": max_results,
                        "fields": ",".join(fields)
                    }
                )

                issues = res.json().get("issues", [])
                records = []

                for issue in issues:
                    f = issue.get("fields", {})

                    comments = [
                        {
                            "author": c.get("author", {}).get("displayName"),
                            "text": self._extract_text(c.get("body"))
                        }
                        for c in f.get("comment", {}).get("comments", [])
                    ]

                    attachments = [
                        {
                            "id": a.get("id"),
                            "name": a.get("filename")
                        }
                        for a in f.get("attachment", [])
                    ]

                    history = self._get_history(base_url, issue.get("key"), auth) if include_history else []

                    records.append({
                        "task_id": issue.get("key"),
                        "title": f.get("summary"),
                        "details": self._extract_text(f.get("description")),
                        "what_to_do": self._extract_text(f.get(ac_field)) if ac_field else "",
                        "comments": comments,
                        "files": attachments,
                        "changes": history
                    })

                return validate_output(json.dumps({
                    "count": len(records),
                    "tasks": records
                }, indent=2))

        except Exception as e:
            return json.dumps({
                "error": "Something went wrong",
                "details": str(e)
            })