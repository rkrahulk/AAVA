import json
import logging
from typing import Any
import os
import boto3
# import chromadb
from crewai.tools.base_tool import BaseTool
from fastapi import HTTPException
from langchain_community.embeddings.bedrock import BedrockEmbeddings
# from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings
from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.redis_client import redis_client
from app.helpers.redis_logs import PipelineAILogs
from app.models.agentEmbedding import AgentEmbedding
from app.helpers.mongodb import MongoDBService
from pymongo import MongoClient
from app.tools.tool_output_validation import validate_output

USE_BEDROCK_CREDENTIALS = settings.USE_BEDROCK_CREDENTIALS

logger = logging.getLogger(__name__)
logger.info("Knowledge Base is starting up")


def parent_doc_retriever(docs):
    matching_documents = []
    text_list = []
    child_chunks = docs
    for chunk in child_chunks:
        metadata = json.loads(chunk.metadata["parent_metadata"])
        if chunk.metadata["parent_text"] not in text_list:
            matching_documents.append(
                Document(page_content=chunk.metadata["parent_text"], metadata=metadata)
            )
            text_list.append(chunk.metadata["parent_text"])
    return matching_documents



class FixedKnowledgeRAGToolSchema(BaseModel):
    """Input for KnowledgeRAGTool."""



class KnowledgeRAGToolSchema(FixedKnowledgeRAGToolSchema):
    """Input for ScrapeWebsiteTool."""

    input: str = Field(..., description="input to search from vector database")
    agentEmbedding: list[AgentEmbedding] | None = Field(
        default=None, description="Embedding LLM Details"
    )


class KnowledgeRAGTool(BaseTool):
    name: str = "Retrieve knowledge from vector database"
    description: str = (
        "A tool to be used to retrieve knowledge from vector database using a description"
    )
    input: str | None = None
    agentEmbedding: list[AgentEmbedding] | None = None
    chroma_client: str = ""
    mongo_client: MongoClient | None = None
    llm_details: dict | None = None
    args_schema: type[BaseModel] = KnowledgeRAGToolSchema

    def __init__(
        self,
        input: str | None = None,
        agentEmbedding: list[AgentEmbedding] | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if input is not None:
            self.args_schema = FixedKnowledgeRAGToolSchema
            self.input = input
            self.agentEmbedding = agentEmbedding
            self.description = f"A tool that can be used to read {input}'s content from knowledge base."
            self._generate_description()

    def _run(
        self,
        **kwargs: Any,
    ) -> Any:

        try:
            logger.info("Knowledge Base input is: %s", self.input)
            logger.info("Knowledge Base KArguments is: %s", kwargs)
            docs = []

            for embedding in self.agentEmbedding:

                logger.info("Knowledge Base AIEngine is: %s", embedding.aiEngine)

                if embedding.aiEngine == "AzureOpenAI":
                    try:
                        embedding_fn = AzureOpenAIEmbeddings(
                            model=embedding.embedding_model,
                            azure_deployment=embedding.embedding_deployment_name,
                            openai_api_version=embedding.embedding_api_version,
                            api_key=embedding.embedding_api_key,
                            azure_endpoint=embedding.embedding_azure_endpoint,
                        )
                        logger.info("AzureOpenAi Embedding_fn")
                        logger.info(embedding_fn)
                    except Exception as azure_error:
                        logger.error(
                            "Error initializing AzureOpenAI embedding: %s",
                            str(azure_error),
                        )
                        raise HTTPException(
                            status_code=500,
                            detail=f"AzureOpenAI embedding initialization failed: {str(azure_error)}",
                        )

                elif embedding.aiEngine == "AmazonBedrock":
                    try:
                        if USE_BEDROCK_CREDENTIALS.lower() == "true":
                            logger.debug(
                                "Bedrock Credentials are used. %s",
                                USE_BEDROCK_CREDENTIALS,
                            )
                            boto3_bedrock_runtime_embedding = boto3.client(
                                service_name="bedrock-runtime",
                                region_name=embedding.embedding_aws_region,
                                aws_access_key_id=embedding.embedding_aws_key,
                                aws_secret_access_key=embedding.embedding_aws_secret_key,
                            )
                        else:
                            logger.debug(
                                "Bedrock Credentials are not used. %s",
                                USE_BEDROCK_CREDENTIALS,
                            )

                            if settings.to_bool("IAM_AUTH_ENABLED") and os.environ.get("CLIENT_NAME","").lower() == "hp":
                                logger.info("IAM_AUTH_ENABLED is true for bedrock model")
                                role_arn = settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT
                                region = embedding.embedding_aws_region or settings.AWS_REGION
                                logger.info("Assume-role inputs role_arn=%s region=%s", role_arn, region)
                                creds = MongoDBService()._assume_role_credentials(
                                    role_arn=role_arn,
                                    region=region,
                                    session_name="aava-bedrock-embedding",
                                )

                                session = boto3.Session(
                                    aws_access_key_id=creds["AccessKeyId"],
                                    aws_secret_access_key=creds["SecretAccessKey"],
                                    aws_session_token=creds["SessionToken"],
                                    region_name=region,
                                )

                                boto3_bedrock_runtime_embedding = session.client("bedrock-runtime")
                            else:
                                logger.info("IAM_AUTH_ENABLED is false for bedrock model")
                                boto3_bedrock_runtime_embedding = boto3.client(
                                    service_name="bedrock-runtime",
                                    region_name=embedding.embedding_aws_region,
                                )

                        embedding_fn = BedrockEmbeddings(
                            model_id=embedding.embedding_model_id,
                            client=boto3_bedrock_runtime_embedding,
                        )
                        logger.info("Bedrock Embedding_fn")
                        logger.info(embedding_fn)
                    except Exception as bedrock_error:
                        logger.error(
                            "Error initializing AmazonBedrock embedding: %s",
                            str(bedrock_error),
                        )
                        raise HTTPException(
                            status_code=500,
                            detail=f"AmazonBedrock embedding initialization failed: {str(bedrock_error)}",
                        )

                elif embedding.aiEngine == "GoogleAI":
                    try:
                        embedding_fn = VertexAIEmbeddings(
                            location=embedding.embedding_gcp_location,
                            project=embedding.embedding_gcp_project_id,
                            model_name=embedding.embedding_model_id,
                        )
                    except Exception as google_error:
                        logger.error(
                            "Error initializing GoogleAI embedding: %s",
                            str(google_error),
                        )
                        raise HTTPException(
                            status_code=500,
                            detail=f"GoogleAI embedding initialization failed: {str(google_error)}",
                        )

                else:
                    logger.error("AIEngine is not assigned: %s", embedding)
                    raise HTTPException(
                        status_code=500, detail="AIEngine is not assigned"
                    )

                logger.info("Knowledge Base Embedding: %s", embedding)

                # Initialize Chroma vector database

                schema = {}

                if os.environ.get("CLIENT_NAME","").lower() == "hp":
                    
                    vectorstore,self.mongo_client = MongoDBService().initialize_store(embedding,embedding_fn)

                    docs_check = vectorstore.similarity_search(
                        query=self.input,
                        k=int(settings.K_FACTOR), 
                        oversampling_factor=int(settings.OVERSAMPLING_FACTOR)
                        )
                    logger.info("docs_check search result from vector search")
                    logger.info(docs_check)

                    if not docs_check:
                        logger.info("docs_check is None")
                        logger.info("Knowledgebase is empty!")
                        PipelineAILogs().publishLogs(f"Knowledgebase is empty", "blue", redisClient=redis_client)
                    else:
                        logger.info("Knowledgebase is retrieved")
                        logger.info(f"docs check length {len(docs_check)}")
                        logger.info(docs_check)
                        schema = docs_check[0].metadata or {}
                        logger.info("docs check metadata")
                        logger.info(schema)

                else:
                    if self.chroma_client:

                        remote_db = self.chroma_client

                    else:
                        remote_db = chromadb.HttpClient(
                            host=embedding.chroma_end_point, port=embedding.chroma_port
                        )
                        self.chroma_client = remote_db
                        logger.info("Knowledge Remote DB: %s", remote_db)

                    # Vector store representation
                    vectorstore = Chroma(
                        client=remote_db,
                        collection_name=embedding.index_collection,
                        embedding_function=embedding_fn,
                    )

                    metadata = vectorstore.get(limit=1)["metadatas"]

                    if len(metadata) == 0:

                        logger.info("Knowledgebase is empty!")

                        PipelineAILogs().publishLogs(f"Knowledgebase is empty", "blue", redisClient=redis_client)

                    else:
                        schema = metadata[0]

                logger.info("Knowledge Vector Store ============= %s", vectorstore)

                if "parent_text" in schema:

                    docs_temp = vectorstore.similarity_search(
                                    query=self.input,
                                    k=int(settings.K_FACTOR), 
                                    oversampling_factor=int(settings.OVERSAMPLING_FACTOR)
                                )


                    docs.extend(parent_doc_retriever(docs_temp))

                else:

                    docs.extend(
                            vectorstore.similarity_search(
                                query=self.input,
                                k=int(settings.K_FACTOR), 
                                oversampling_factor=int(settings.OVERSAMPLING_FACTOR)
                                )
                            )

                logger.info("Knowledgebase Search Result is: %s", docs)

                if self.mongo_client:
                    self.mongo_client.close()

                PipelineAILogs().publishLogs(
                    f"Knowledgebase Search Result is: {docs}",
                    "green",
                    redisClient=redis_client,
                )

            aggregated_docs = "\n\n".join(
                doc.page_content for doc in docs
                if doc.page_content
            )

            if docs:
                guardrails_validation = validate_output(
                    tool_name="knowledgeragtool",
                    content=aggregated_docs,
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]

            return docs

        except Exception as e:
            logger.error("Knowledge Base Tool error is %s", str(e))
            PipelineAILogs().publishLogs(
                "AAVA Pipeline Exception:" + str(e), "red", redisClient=redis_client
            )
            raise HTTPException(
                status_code=500, detail="Knowledge Base Tool error is " + str(e)
            )
