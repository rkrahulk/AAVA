import requests
from datetime import datetime
from typing import Any, Type, List
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
import re
import json

from app.core.config import settings
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets


class GithubWriterSchema(BaseModel):
    """
    Input schema for GithubWriterTool
    """

    scripts: str = Field(
        ...,
        description=(
            "JSON string list of files to commit. "
            "Each object must contain 'filename' and 'code'. "
            "Example: "
            "[{\"filename\":\"app.py\",\"code\":\"print('hello')\"}]"
        )
    )

    base_url: str = Field(
        ...,
        description="GitHub base URL",
        max_length=100,
        min_length=1
    )

    repo_owner: str = Field(
        ...,
        description="GitHub organization or user",
        max_length=100,
        min_length=1
    )

    repo: str = Field(
        ...,
        description="Repository name",
        max_length=100,
        min_length=1
    )

    branch: str = Field(
        default="main",
        description="Target branch"
    )

    email: str = Field(
        ...,
        description="Commit author email"
    )

    file_paths: str = Field(
        "",
        description=(
            "Optional comma separated repo file paths to update. "
            "Example: src/app.py,src/utils/helper.py"
        )
    )

    commit_message: str = Field(
        default="AI Agent commit",
        description="Git commit message"
    )


def sanitize_filename(filename: str) -> str:
    filename = filename.split("/")[-1].split("\\")[-1]
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)
    return filename


def sanitize_path(path: str) -> str:
    path = path.replace("\\", "/")
    parts = path.split("/")
    safe_parts = [sanitize_filename(p) for p in parts if p]
    return "/".join(safe_parts)


class GithubWriterTool(BaseTool):
    """
    Tool that behaves like a developer committing files to GitHub.
    Supports creating and updating files.
    """

    name: str = "github_writer_tool"

    description: str = (
        "Create or update files in a GitHub repository and push a commit"
    )

    service_account_type: str

    args_schema: Type[BaseModel] = GithubWriterSchema

    def _run(self, **kwargs) -> Any:
        try:

            scripts = json.loads(kwargs.get("scripts"))

            base_url = kwargs.get("base_url").strip().rstrip("/")
            repo_owner = kwargs.get("repo_owner").strip()
            repo = kwargs.get("repo").strip()
            branch = kwargs.get("branch", "main").strip()
            email = kwargs.get("email")
            commit_message = kwargs.get("commit_message")

            file_paths_raw = kwargs.get("file_paths", "")

            username, token = get_system_tool_secrets(
                action="write",
                tool_type="github",
                service_account_type=self.service_account_type
            )

            allowed_base_urls = {
                url.strip().rstrip("/")
                for url in settings.GITHUB_BASE_URL.replace(" ", "").split(",")
            }

            if not is_valid_base_url(base_url, allowed_base_urls):
                return f"Invalid GitHub base URL: {base_url}"

            headers = {
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "Content-Type": "application/json"
            }

            # GitHub API path
            if "api.github.com" in base_url:
                github_api = "https://api.github.com"
            elif base_url.endswith("/api/v3"):
                github_api = base_url
            else:
                github_api = f"{base_url}/api/v3"

            repo_api = f"{github_api}/repos/{repo_owner}/{repo}"

            # Parse file paths
            file_paths: List[str] = []
            if file_paths_raw:
                file_paths = [
                    sanitize_path(p.strip())
                    for p in file_paths_raw.split(",")
                    if p.strip()
                ]

            if file_paths and len(file_paths) != len(scripts):
                return "Error: file_paths count must match scripts count"

            # -------------------------------------------------
            # Step 1: get branch ref
            # -------------------------------------------------

            ref_resp = requests.get(
                f"{repo_api}/git/ref/heads/{branch}",
                headers=headers
            )
            ref_resp.raise_for_status()

            latest_commit_sha = ref_resp.json()["object"]["sha"]

            # -------------------------------------------------
            # Step 2: get commit info
            # -------------------------------------------------

            commit_resp = requests.get(
                f"{repo_api}/git/commits/{latest_commit_sha}",
                headers=headers
            )
            commit_resp.raise_for_status()

            base_tree_sha = commit_resp.json()["tree"]["sha"]

            # -------------------------------------------------
            # Step 3: fetch repo tree
            # -------------------------------------------------

            tree_resp = requests.get(
                f"{repo_api}/git/trees/{base_tree_sha}?recursive=1",
                headers=headers
            )
            tree_resp.raise_for_status()

            existing_files = {
                item["path"]: item["sha"]
                for item in tree_resp.json().get("tree", [])
                if item["type"] == "blob"
            }

            # -------------------------------------------------
            # Step 4: create blobs
            # -------------------------------------------------

            blobs = []
            default_dir = "auto_scripts"

            for idx, script in enumerate(scripts):

                filename = script.get("filename", "script.py")
                code = script.get("code", "")

                # resolve path
                if idx < len(file_paths):
                    safe_path = file_paths[idx]
                elif "/" in filename:
                    safe_path = sanitize_path(filename)
                else:
                    safe_path = f"{default_dir}/{sanitize_filename(filename)}"

                file_exists = safe_path in existing_files

                blob_resp = requests.post(
                    f"{repo_api}/git/blobs",
                    json={
                        "content": code,
                        "encoding": "utf-8"
                    },
                    headers=headers
                )

                blob_resp.raise_for_status()

                blob_sha = blob_resp.json()["sha"]

                blobs.append({
                    "path": safe_path,
                    "mode": "100644",
                    "type": "blob",
                    "sha": blob_sha
                })

            # -------------------------------------------------
            # Step 5: create tree
            # -------------------------------------------------

            tree_resp = requests.post(
                f"{repo_api}/git/trees",
                json={
                    "base_tree": base_tree_sha,
                    "tree": blobs
                },
                headers=headers
            )

            tree_resp.raise_for_status()

            new_tree_sha = tree_resp.json()["sha"]

            # -------------------------------------------------
            # Step 6: create commit
            # -------------------------------------------------

            commit_resp = requests.post(
                f"{repo_api}/git/commits",
                json={
                    "message": commit_message,
                    "tree": new_tree_sha,
                    "parents": [latest_commit_sha],
                    "author": {
                        "name": username,
                        "email": email
                    }
                },
                headers=headers
            )

            commit_resp.raise_for_status()

            new_commit_sha = commit_resp.json()["sha"]

            # -------------------------------------------------
            # Step 7: push commit
            # -------------------------------------------------

            update_resp = requests.patch(
                f"{repo_api}/git/refs/heads/{branch}",
                json={
                    "sha": new_commit_sha,
                    "force": False
                },
                headers=headers
            )

            update_resp.raise_for_status()

            return {
                "status": "success",
                "commit_sha": new_commit_sha,
                "branch": branch,
                "repo_url": f"{base_url}/{repo_owner}/{repo}/tree/{branch}"
            }

        except Exception as e:
            return f"GitHub commit failed: {str(e)}"