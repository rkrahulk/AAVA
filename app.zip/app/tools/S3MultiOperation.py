import os
import logging
import tempfile
from typing import Optional, Type, Dict

import boto3
import chardet
from boto3.s3.transfer import TransferConfig, S3Transfer
from botocore.exceptions import (
    ClientError,
    NoCredentialsError,
    EndpointConnectionError,
    ParamValidationError,
    BotoCoreError,
)

import AVASecret

from pydantic import BaseModel, Field
from crewai.tools import BaseTool

from app.tools.tool_output_validation import validate_output
from app.core.config import settings

logger = logging.getLogger(__name__)

def _assume_role_credentials(
    region: str
) -> Dict[str, str]:
    try:
        os.environ.pop("AWS_PROFILE", None)

        session = boto3.Session(region_name=region)
        sts = session.client("sts")

        identity = sts.get_caller_identity()
        role_arn = AVASecret.getValue('role_arn')
        logger.info("Assuming role for s3 access")

        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName="aava-s3-multi-operation",
            DurationSeconds=3600,
        )
        logger.info("Successfully assumed role %s for S3", role_arn)
        return response["Credentials"]

    except NoCredentialsError:
        logger.error("No credentials available to assume S3 role")
        raise
    except Exception as e:
        logger.error("Error assuming role for S3: %s", str(e))
        raise


def get_s3_client(region_name: str, is_iam_mode: bool):
    """
    IAM-first S3 client with explicit assume-role
    """
    try:
        if is_iam_mode:
            creds = _assume_role_credentials(
                region=region_name,
            )

            session = boto3.Session(
                aws_access_key_id=creds["AccessKeyId"],
                aws_secret_access_key=creds["SecretAccessKey"],
                aws_session_token=creds["SessionToken"],
                region_name=region_name,
            )
            return session.client("s3")

        else:
            base_session = boto3.Session(region_name=region_name)
            return base_session.client("s3")

    except Exception as e:
        logger.error(f"S3 client initialization failed: {e}")
        raise


# TOOL SCHEMA

class S3OperationSchema(BaseModel):
    operation: str = Field(
        ...,
        description="Operation: write | read | read_all | delete | generate_and_upload",
    )
    bucket_name: str = Field(..., description="S3 bucket name", max_length=100, min_length=1)
    region_name: str = Field(..., description="AWS region")
    file_path: Optional[str] = Field(None, description="S3 key or prefix")
    content: Optional[str] = Field(None, description="Content for write / generate_and_upload")


# TOOL IMPLEMENTATION

class S3MultiOperation(BaseTool):
    name: str = "S3 MultiOperation Tool"
    description: str = (
        "Performs S3 read/write/delete operations using IAM assume-role authentication "
        "aligned with aava Postgres and Bedrock patterns."
    )
    llm_details: dict | None = None
    args_schema: Type[BaseModel] = S3OperationSchema

    def _run(
        self,
        **kwargs
    ) -> str:
        try:

            operation = kwargs.get("operation", "")
            bucket_name = kwargs.get("bucket_name", "")
            region_name = kwargs.get("region_name", "")
            file_path = kwargs.get("file_path", "")
            content = kwargs.get("content", "")
            is_iam_mode = settings.IAM_AUTH_ENABLED

            ALLOWED_OPERATIONS = {
                "read",
                "read_all",
                "write",
                "delete",
                "generate_and_upload",
            }

            if not isinstance(operation, str) or operation not in ALLOWED_OPERATIONS:
                return "Invalid operation"

            s3 = get_s3_client(region_name, is_iam_mode)

            if ".." in file_path or file_path.startswith("/"):
                return "Invalid S3 object key"

            if operation == "write":
                if not file_path or content is None:
                    return "'file_path' and 'content' are required for write."

                s3.put_object(
                    Bucket=bucket_name,
                    Key=file_path,
                    Body=content.encode("utf-8"),
                )
                return f"Wrote to s3://{bucket_name}/{file_path}"

            elif operation in ["read_all", "read"]:
                read_data = ""

                if operation == "read":
                    if not file_path:
                        return "'file_path' is required for read."

                    response = s3.get_object(Bucket=bucket_name, Key=file_path)
                    data = response["Body"].read()
                    encoding = chardet.detect(data).get("encoding") or "utf-8"
                    read_data = data.decode(encoding)

                elif operation == "read_all":
                    if not file_path:
                        return "'file_path' (prefix) is required for read_all."

                    result = {}
                    paginator = s3.get_paginator("list_objects_v2")
                    MAX_OBJECTS = 100

                    for page in paginator.paginate(
                        Bucket=bucket_name, Prefix=file_path
                    ):
                        for obj in page.get("Contents", []):
                            key = obj["Key"]
                            body = (
                                s3.get_object(Bucket=bucket_name, Key=key)["Body"]
                                .read()
                                .decode("utf-8")
                            )
                            result[key] = body

                    read_data = f"Read multiple files:\n{json.dumps(result)}"
                if read_data:
                    guardrails_validation = validate_output(
                        tool_name="S3MultiOperation",
                        content=read_data,
                        llm_details=self.llm_details
                    )
                    logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                    if not guardrails_validation.get("success"):
                        return guardrails_validation["result"]
                return read_data

            elif operation == "delete":
                if not file_path:
                    return "'file_path' is required for delete."

                s3.delete_object(Bucket=bucket_name, Key=file_path)
                return f"Deleted s3://{bucket_name}/{file_path}"

            elif operation == "generate_and_upload":
                if not file_path or content is None:
                    return "'file_path' and 'content' are required."

                transfer_config = TransferConfig(
                    multipart_threshold=25 * 1024 * 1024,
                    multipart_chunksize=25 * 1024 * 1024,
                    max_concurrency=4,
                    use_threads=True,
                )

                with tempfile.NamedTemporaryFile(
                    mode="w+", delete=False, suffix=".md"
                ) as tmp:
                    tmp.write(content)
                    tmp_path = tmp.name

                try:
                    transfer = S3Transfer(s3, transfer_config)
                    transfer.upload_file(tmp_path, bucket_name, file_path)
                    return f"Generated and uploaded s3://{bucket_name}/{file_path}"
                finally:
                    os.remove(tmp_path)

            else:
                return f"Unknown operation: '{operation}'"

        except NoCredentialsError:
            return "Unable to assume IAM role for S3 access."
        except EndpointConnectionError as e:
            return f"Endpoint connection error: {str(e)}"
        except ClientError as e:
            err = e.response["Error"]
            return f"AWS ClientError ({err.get('Code')}): {err.get('Message')}"
        except ParamValidationError as e:
            return f"Parameter validation error: {str(e)}"
        except BotoCoreError as e:
            return f"BotoCore error: {str(e)}"
        except Exception as e:
            return "Unexpected error during S3 operation"
