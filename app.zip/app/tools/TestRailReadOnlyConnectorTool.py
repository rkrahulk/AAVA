import json
import logging
import requests
from typing import Any, Optional, Type, List
from crewai.tools import BaseTool
from pydantic import BaseModel, Field, field_validator
import AVASecret
from app.core.config import settings

from app.tools.tool_output_validation import validate_output


logger = logging.getLogger(__name__)


def _parse_tools_base_urls(raw_urls: str) -> List[str]:
    return [
        url.strip().rstrip("/")
        for url in raw_urls.split(",")
        if url.strip()
    ]

class TestRailFetchInput(BaseModel):
    project_id: int = Field(..., description="The ID of the project in TestRail.")
    suite_id: Optional[int] = Field(None, description="The ID of the test suite (optional).")
    section_id: Optional[int] = Field(None, description="The ID of the section (optional).")
    base_url: str = Field(..., description="The base URL of the TestRail instance.", min_length=1, max_length=100)


class TestRailReadOnlyConnectorTool(BaseTool):
    name: str = "fetch_testrail_cases"
    description: str = (
        "Useful for fetching test cases from a TestRail instance. "
        "Requires project_id, base_url."
        "Optionally supports suite_id and section_id."
    )
    llm_details: dict | None = None
    args_schema: Type[BaseModel] = TestRailFetchInput

    def _run(
        self,
        **kwargs
    ) -> Any:

        project_id = int(kwargs.get("project_id", "0"))
        base_url = kwargs.get("base_url", "").strip().rstrip("/")
        suite_id = kwargs.get("suite_id", "")
        section_id = kwargs.get("section_id", "")
        allowed_base_urls = {
            test_rail_base_url.strip().rstrip("/")
            for test_rail_base_url in settings.TEST_RAIL_READONLY_CONNECTOR_BASE_URL.replace(" ", "").split(",")
        }

        if not base_url in allowed_base_urls:
            return f"Error: Test Rail Readonly Connector base URL ({base_url}) is not allowed."

        username = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_test_rail_global")
        api_key = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_test_rail_access")

        if project_id <= 0:
            return "Invalid Project ID"
        if not username or not api_key:
            return "Missing TestRail credentials"

        url = f"{base_url}/index.php?/api/v2/get_cases/{project_id}"

        params = {}
        if suite_id:
            params["suite_id"] = suite_id
        if section_id:
            params["section_id"] = section_id

        try:
            response = requests.get(
                url,
                auth=(username, api_key),
                params=params,
                headers={"Content-Type": "application/json"},
                timeout=60
            )
            response.raise_for_status()
            if not "application/json" in response.headers.get("Content-Type", "").lower():
                return "Unexpected response format"
            resp = response.json()
            logger.info(f"TestRail connected successfully: {base_url}")

            if resp:
                guardrails_validation = validate_output(
                    tool_name="TestRailReadOnlyConnectorTool",
                    content=json.dumps(resp),
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]    

            return resp

        except requests.exceptions.RequestException as e:
            logger.error(f"Error connecting to TestRail: {e}")
            raise RuntimeError(f"Error connecting to TestRail")