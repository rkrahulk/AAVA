import requests
import re
import json
import logging
from typing import List, Dict, Any, Type, ClassVar, Optional
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
import AVASecret
from app.core.config import settings
from app.tools.tool_output_validation import validate_output
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

logger = logging.getLogger(__name__)

class JiraFetcherRead(BaseModel):
    base_url: str = Field(
        ..., description="Base URL of the Jira instance",
        max_length=100,
        min_length=1
    )
    max_results: int = Field(
        default=50, description="Maximum number of bug tickets to fetch"
    )
    project_key: str = Field(
        default="",
        description="Project key (e.g., ABC,SCRUM)"
    )
    issue_keys: Optional[str] = Field(
        default="",
        description="Comma-separated issue keys (e.g., ABC-1,ABC-2)"
    )
    issue_types: Optional[str] = Field(
        default="",
        description="Comma-separated issue types (e.g., Bug,Story)"
    )


class JiraFetcherReadTool(BaseTool):
    """
    JiraBugFetcherTool
    Fetches Bug-type issues from Jira and normalizes
    them into Excel-ready records.
    """
 
    name: str = "JiraBugFetcherTool"
    description: str = "Fetch Jira bug tickets and normalize them into Excel-ready records"
    llm_details: dict | None = None
    service_account_type: str
    args_schema: Type[BaseModel] = JiraFetcherRead

    @staticmethod
    def _extract_description(desc: Any) -> str:
        if desc is None:
            return ""
        if isinstance(desc, str):
            return desc.strip()

        texts = []

        def walk(node):
            if isinstance(node, dict):
                if isinstance(node.get("text"), str):
                    texts.append(node["text"])
                for v in node.values():
                    if isinstance(v, (dict, list)):
                        walk(v)
            elif isinstance(node, list):
                for i in node:
                    walk(i)

        walk(desc)
        return "\n".join(t.strip() for t in texts if t.strip())

    def _run(
        self,
        **kwargs
    ) -> str:
        
        try:
            base_url = kwargs.get("base_url", "").strip().rstrip("/")
            project_key = kwargs.get("project_key", "").strip()
            max_results =  min(int(kwargs.get("max_results", 50)), 50)
            issue_keys = kwargs.get("issue_keys", "") if kwargs.get("issue_keys", "") else ""
            issue_types = kwargs.get("issue_types", "") if kwargs.get("issue_types", "") else ""
            
            project_key = (project_key or "").strip().upper()
            if not re.fullmatch(r"[A-Z0-9]+", project_key):
                return "Error: Invalid Jira project key."


            allowed_base_urls = {
                url.strip().rstrip("/")
                for url in settings.JIRA_BASE_URL.replace(" ", "").split(",")
            }

            if not is_valid_base_url(base_url=base_url, allowed_hosts=allowed_base_urls):
                return f"Invalid input: Provided Jira base URL ({base_url}) is not allowed."

            project_key = (project_key or "").strip().upper()
            fields_param = ",".join([
                "summary",
                "description",
                "status",
                "resolution",
                "reporter",
                "assignee",
                "components",
                "created",
                "resolutiondate",
                "priority",
                "issuetype"
            ])
 
            if not re.fullmatch(r"[A-Z0-9]+", project_key):
                return "Error: Invalid Jira project key."

            # 2. Get Credentials
            username, password = get_system_tool_secrets(action="read", tool_type="jira", service_account_type=self.service_account_type)       

            if not username or not password:
                return json.dumps({"error": "Missing Jira credentials."})
            if not password:
                return json.dumps({"error": "Missing 'jira_access' in AVASecret."})
            # 3. Process Comma-Separated Strings into Lists
            list_of_keys = [k.strip().upper() for k in issue_keys.split(",") if k.strip()]
            list_of_types = [t.strip() for t in issue_types.split(",") if t.strip()]
            try:
                for key in list_of_keys:
                    project_key_from_issue = key.split("-")
                    if project_key_from_issue and project_key != project_key_from_issue[0].upper():
                        return f"Error: Invalid issue key ({key})"
            except Exception as key_validation_err:
                logger.info(str(key_validation_err))

            # 4. Construct dynamic JQL
            if list_of_keys:
                keys_formatted = ", ".join([f'"{k}"' for k in list_of_keys])
                jql = f"key IN ({keys_formatted})"
            elif project_key:
                project_key = project_key.strip().upper()
                SAFE_TYPE_RE = re.compile(r"[A-Za-z]+(?: [A-Za-z]+)*")

                safe_types = []

                for t in list_of_types:
                    if not isinstance(t, str):
                        continue

                    t = t.strip()

                    if not SAFE_TYPE_RE.fullmatch(t):
                        continue

                    safe_types.append(f'"{t}"')

                types_formatted = ", ".join(safe_types)
                if types_formatted:
                    jql = (
                        f'project = "{project_key}" '
                        f'AND issuetype IN ({types_formatted}) '
                        f'ORDER BY created DESC'
                    )
                else:
                    jql = (
                        f'project = "{project_key}" '
                        f'ORDER BY created DESC'
                    )

            else:
                return json.dumps({
                    "error": "You must provide either 'issue_keys' or 'project_key'."
                })
            # 5. API Request Setup
            api_version = "2"
            url = f"{base_url}/rest/api/{api_version}/search"
            
            if ".atlassian.net" in base_url:
                api_version = "3"
                url = f"{base_url}/rest/api/{api_version}/search/jql"

            payload = {
                "jql": jql,
                "maxResults": max_results,
                "fields": fields_param
            }
            response = requests.get(
                url,
                params=payload,
                auth=(username, password),
                headers={"Accept": "application/json"},
                timeout=60
            )

            if response.status_code == 401:
                return json.dumps({"error": "Authentication failed (401)."})
            if response.status_code == 403:
                return json.dumps({"error": "Access forbidden (403)."})
            if response.status_code == 404:
                return json.dumps({"error": "Jira API endpoint not found (404)."})
            if not response.ok:
                return json.dumps({
                    "error": f"Jira API error {response.status_code}",
                    "details": "Upstream Jira error",
                })
 

            content_type = response.headers.get("Content-Type", "").lower()

            if "application/json" not in content_type:
                return json.dumps({"error": "Unexpected response format"})

            issues = response.json().get("issues", [])
            records: List[Dict[str, Any]] = []
            aggregated_description = ""
            aggregated_summary = ""
 
            for issue in issues[:max_results]:
                fields = issue.get("fields") or {}
                extracted_description = self._extract_description(fields.get("description"))
                aggregated_description += f"\n {extracted_description}"
                aggregated_summary += f"\n {fields.get("summary", "")}"

                fields.update({
                    "issue_key": issue.get("key", ""),
                    "description": extracted_description
                })
                if fields.get("reporter",{}).get("avatarUrls"):
                    fields["reporter"].pop("avatarUrls", {})
                if fields.get("status", {}).get("iconUrl"):
                    fields["status"].pop("iconUrl", "")
                if fields.get("priority", {}).get("iconUrl"):
                    fields["status"].pop("iconUrl", "")

                records.append(fields)

            if aggregated_description:
                guardrails_validation = validate_output(
                    tool_name="JiraFetcherRead",
                    content=aggregated_description,
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]

            if aggregated_summary:
                guardrails_validation = validate_output(
                    tool_name="JiraFetcherRead",
                    content=aggregated_summary,
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]

            return json.dumps(
                {
                    "count": len(records),
                    "records": records
                },
                indent=2
            )


        except requests.Timeout:
            return json.dumps({
                "error": "Jira request timed out"
            })

        except requests.HTTPError as e:
            status = getattr(e.response, "status_code", None)

            if status in (401, 403):
                message = "Unauthorized Jira access"
            elif status == 404:
                message = "Jira resource not found"
            else:
                message = "Jira API error"

            return json.dumps({
                "error": message
            })

        except requests.RequestException:
            return json.dumps({
                "error": "Unable to reach Jira API"
            })

        except Exception as e:
            return json.dumps({
                "error": "Unexpected error in JiraBugFetcherTool",
                "details": str(e)
            })