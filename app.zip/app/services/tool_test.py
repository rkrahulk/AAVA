import json

from fastapi import HTTPException

from app.core.secret_manager import secret_manager
from app.helpers.tool_ops import initialize_user_tool
from app.models.test_tool import TestTool


async def extract_params(payload: TestTool, Authorization: str):

    try:

        secret_manager.Authorization = Authorization

        tool_instance = initialize_user_tool(
            payload.class_name, payload.class_definition
        )

        output = tool_instance._run(**payload.inputs)

        return {
            "status": "success",
            "output": json.loads(json.dumps(output, default=str)),
        }

    except Exception as e:

        raise HTTPException(
            status_code=500, detail=f"An Error occured while testing the tool code: {e}"
        )
