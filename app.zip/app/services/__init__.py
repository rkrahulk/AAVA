from app.services.crew_controller.EventListener import EventListeners

event_listener = EventListeners()
