import logging
import os
from typing import Any

from crewai_tools import DirectoryReadTool, FileWriterTool
from crewai_tools.tools.scrape_website_tool.scrape_website_tool import ScrapeWebsiteTool
from crewai_tools.tools.serper_dev_tool.serper_dev_tool import SerperDevTool
from fastapi import HTTPException
from pydantic import BaseModel

from app.core.redis_client import redis_client
from app.helpers.db_uri import encode_db_uri
from app.helpers.redis_logs import PipelineAILogs
from app.helpers.tool_ops import add_dynamic_user_tools, create_user_tool_with_oauth
from app.tools.filereadtool import FileReadTool
from app.tools.knowledgeRagTool import KnowledgeRAGTool
from app.tools.memReadWriteTool import MemoryReaderWriterTool
from app.tools.sqltool import SQLTool
from app.tools.GitHubDocAnalysisTool import GitHubDocAnalysisTool
from app.tools.JiraFetcherRead import JiraFetcherReadTool
from app.tools.JiraFetcherReadV2 import JiraFetcherReadToolV2
from app.tools.JiraConnectorTool import JiraConnectorTool
from app.tools.JiraConnectorToolV2 import JiraConnectorToolV2
from app.tools.GithubWriterToolV2 import GithubWriterToolV2
from app.tools.GithubWriterTool import GithubWriterTool
from app.tools.S3MultiOperation import S3MultiOperation
from app.tools.TestRailReadOnlyConnectorTool import TestRailReadOnlyConnectorTool


logger = logging.getLogger(__name__)


class ToolParameter(BaseModel):
    """
    Represents a parameter for a tool, such as an API key or configuration value.
    """

    parameterName: str
    value: str | None = None


class AgentTool(BaseModel):
    """
    Represents a tool to be added to an agent, with its name and parameters.
    """

    toolName: str
    parameters: list[ToolParameter] = []


class UserTool(BaseModel):
    """
    Represents a user-defined tool, including its class name and class definition as a string.
    """

    toolClassName: str
    toolClassDef: str


class AgentEmbedding(BaseModel):
    """
    Placeholder for agent embedding configuration.
    Extend with actual fields as needed for embedding providers/models.
    """



class AgentTask(BaseModel):
    """
    Represents a task assigned to an agent, including its description and expected output.
    """

    description: str
    expectedOutput: str | None = None


class AgentData(BaseModel):
    """
    Aggregates all agent configuration data, including tools, user tools, embedding, and task.
    """

    tools: list[AgentTool]
    userTools: list[UserTool] = []
    embedding: AgentEmbedding | None = None
    task: AgentTask


class AgentToolConfigurator:
    """
    Configures and attaches tools to a CrewAI agent based on the provided agent data.
    Handles built-in, user-defined, and file system tools, and logs tool usage events.
    """

    def __init__(
        self,
        agent_data: AgentData,
        agent_model: Any,
        user_inputs: dict[str, str],
        execution_id: str,
        subfolder_path: str | None = None,
        workflow_id: str | None = None,
        tool_tokens: dict = None # HP_OBO
    ):
        self.agent_data = agent_data
        self.agent_model = agent_model
        self.user_inputs = user_inputs
        self.execution_id = execution_id
        self.redis_client = redis_client
        self.subfolder_path = subfolder_path
        self.logger = logger
        self.workflow_id = workflow_id
        self.tool_tokens = tool_tokens or {} # HP_OBO changes

    def _add_scrape_website_tool(self, tool: AgentTool):
        """
        Adds a ScrapeWebsiteTool to the agent if a website_url parameter is provided.
        Logs tool usage and raises an error if the URL is missing.
        """
        scrape_website_tool = None
        for param in tool.parameters:
            if (
                param.parameterName == "website_url"
                and param.value
                and param.value.strip()
            ):
                scrape_website_tool = ScrapeWebsiteTool(website_url=param.value)
                break
        if scrape_website_tool is None:
            PipelineAILogs().publishLogs(
                "Website URL not provided for scrape website tool.",
                "red",
                redisClient=self.redis_client,
            )
            raise HTTPException(
                status_code=500,
                detail="Website URL not provided for scrape website tool.",
            )
        logger.info("ScrapeWebsiteTool -------------------- %s", scrape_website_tool)
        self.agent_model.tools.append(scrape_website_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         scrape_website_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_memory_reader_writer_tool(self):
        """
        Adds a MemoryReaderWriterTool to the agent for persistent memory operations.
        """
        logger.info("MemoryReaderWriterTool being added to the agent")
        mem_read_write_tool = MemoryReaderWriterTool(execution_id=self.execution_id, llm_details=self.agent_data.llm)
        self.agent_model.tools.append(mem_read_write_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         mem_read_write_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_serper_dev_tool(self, tool: AgentTool):
        """
        Adds a SerperDevTool to the agent, setting the SERPER_API_KEY from parameters.
        Logs tool usage and raises an error if the API key is missing.
        """
        serper_dev_tool = SerperDevTool()
        api_key_provided = False
        for param in tool.parameters:
            if (
                param.parameterName.lower() == "serper_api_key"
                and param.value
                and param.value.strip()
            ):
                os.environ["SERPER_API_KEY"] = param.value
                api_key_provided = True
                break
        if not api_key_provided:
            PipelineAILogs().publishLogs(
                "Serper API key not provided for SerperDevTool.",
                "red",
                redisClient=self.redis_client,
            )
            raise HTTPException(
                status_code=500, detail="Serper API key not provided for SerperDevTool."
            )
        logger.info("SerperDevTool -------------------- %s", serper_dev_tool)
        self.agent_model.tools.append(serper_dev_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         serper_dev_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_file_writer_tool(self):
        """
        Adds a FileWriterTool to the agent for file output operations.
        The base directory is set to a folder named after the execution ID.
        """
        logger.info("FileWriterTool being added to the agent")
        base_dir = os.path.join(os.getcwd(), str(self.execution_id))
        file_writer_tool = FileWriterTool(base_dir=base_dir)
        self.agent_model.tools.append(file_writer_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         file_writer_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_nl2sql_tool(self, tool: AgentTool):
        """
        Adds an NL2SQL (SQLTool) to the agent if a db_uri parameter is provided.
        Encodes the DB URI and logs tool usage. Raises an error if missing.
        """
        nl2sql_tool = None
        for param in tool.parameters:
            if param.parameterName == "db_uri" and param.value and param.value.strip():
                encoded_uri = encode_db_uri(param.value)
                nl2sql_tool = SQLTool(db_uri=encoded_uri)
                break
        if nl2sql_tool is None:
            PipelineAILogs().publishLogs(
                "Database URI not provided for NL2SQL tool.",
                "red",
                redisClient=self.redis_client,
            )
            raise HTTPException(
                status_code=500, detail="Database URI not provided for NL2SQL tool."
            )
        self.agent_model.tools.append(nl2sql_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         nl2sql_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_user_defined_tools(self):
        """
        Adds user-defined tools to the agent by dynamically instantiating them from class definitions.
        Logs tool usage for each user tool.
        """
        for tool_data in self.agent_data.userTools:
            logger.debug(
                "user tool class name ------------ %s ", tool_data.toolClassName
            )
            logger.debug("user tool class def ------------ ")
            if tool_data.toolType:
                tool_handlers = {
                    'GitHubDocAnalysisTool': self._add_gitHub_doc_analysis_tool,
                    'JiraFetcherReadTool': self._add_jira_fetcher_read_tool,
                    'JiraFetcherReadToolV2': self._add_jira_fetcher_read_tool_v2,
                    'S3MultiOperation': self._add_S3_multi_operation_tool,
                    'TestRailReadOnlyConnectorTool': self._add_test_rail_readonly_connector_tool,
                    "JiraConnectorTool": self._add_jira_issue_create_tool,
                    "JiraConnectorToolV2": self._add_jira_issue_create_tool_v2,
                    "GithubWriterTool": self._add_github_writer_tool,
                    "GithubWriterToolV2": self._add_github_writer_tool_v2,
                }
                tool_handlers.get(tool_data.toolClassName)(tool_data)
            else:
                tool_instance = add_dynamic_user_tools(
                    tool_data.toolClassName, tool_data.toolClassDef
                )
                logger.debug("user tool instance created")
                self.agent_model.tools.append(tool_instance)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         tool_instance,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass

    def _add_knowledge_rag_tool(self):
        """
        Adds a KnowledgeRAGTool to the agent if embedding information is present.
        Used for retrieval-augmented generation tasks.
        """
        if self.agent_data.embedding is not None:
            
            task_description_with_user_inputs = self.agent_data.task.description

            # Replace user input placeholders in the task description
            for key, value in self.user_inputs.items():
                task_description_with_user_inputs = task_description_with_user_inputs.replace(
                    key, value
                )

            logger.debug("Agent embedding ------------ %s ", self.agent_data.embedding)
            context_tool = KnowledgeRAGTool(
                input=task_description_with_user_inputs,
                agentEmbedding=self.agent_data.embedding,
                llm_details = self.agent_data.llm,
                kwargs={"redis_client": self.redis_client},
            )
            self.agent_model.tools.append(context_tool)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         context_tool,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass


    def _add_gitHub_doc_analysis_tool(self, tool: AgentTool | None = None):
        tool_instance = GitHubDocAnalysisTool(llm_details=self.agent_data.llm, service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    def _add_jira_fetcher_read_tool(self, tool: AgentTool | None = None):
        tool_instance = JiraFetcherReadTool(llm_details=self.agent_data.llm, service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    def _add_jira_fetcher_read_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = JiraFetcherReadToolV2(llm_details=self.agent_data.llm, service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)
    
    def _add_S3_multi_operation_tool(self, tool: AgentTool | None = None):
        tool_instance = S3MultiOperation(llm_details=self.agent_data.llm)
        self.agent_model.tools.append(tool_instance)

    def _add_test_rail_readonly_connector_tool(self, tool: AgentTool | None = None):
        tool_instance = TestRailReadOnlyConnectorTool(llm_details=self.agent_data.llm)
        self.agent_model.tools.append(tool_instance)

    def _add_jira_issue_create_tool(self, tool: AgentTool | None = None):
        tool_instance = JiraConnectorTool(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    def _add_jira_issue_create_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = JiraConnectorToolV2(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)


    def _add_github_writer_tool(self, tool: AgentTool | None = None):
        tool_instance = GithubWriterTool(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    def _add_github_writer_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = GithubWriterToolV2(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)



    def setup_file_tools(self):
        """
        Adds file system tools (DirectoryReadTool, FileReadTool) to the agent if a subfolder path is provided.
        Useful for agents that need to read files or directories.
        """
        if self.subfolder_path:
            try:
                dir_tool = DirectoryReadTool(directory=str(self.subfolder_path))
                self.agent_model.tools.append(dir_tool)
                self.logger.info(
                    f"Added DirectoryReadTool for path: {self.subfolder_path}"
                )
                # try:
                #     from app.services.crew_controller.listeners import log_agent_tool_usage
                #     log_agent_tool_usage(
                #         self.agent_model,
                #         self.agent_data,
                #         self.workflow_id,
                #         self.execution_id,
                #         dir_tool,
                #         input_data=None,
                #         output_data=None
                #     )
                # except Exception:
                #     pass
            except Exception as e:
                self.logger.error(
                    f"Failed to initialize DirectoryReadTool for {self.subfolder_path}: {e}"
                )
                # Depending on requirements, this could raise an HTTPException

            file_read_tool = FileReadTool(llm_details = self.agent_data.llm)
            self.agent_model.tools.append(file_read_tool)
            self.logger.info("Added FileReadTool.")
            # try:
            #     from app.services.crew_controller.listeners import log_agent_tool_usage
            #     log_agent_tool_usage(
            #         self.agent_model,
            #         self.agent_data,
            #         self.workflow_id,
            #         self.execution_id,
            #         file_read_tool,
            #         input_data=None,
            #         output_data=None
            #     )
            # except Exception:
            #     pass

    # ====================================================== HP OBO change Begin =================================================================      
    def _setup_user_tools_with_obo(self):
        """
        Setup user tools with OBO OAuth token injection.
        Only called when CLIENT_NAME=HP.
        """
        if not self.agent_data.userTools:
            return
        
        
        logger.info(
            f"[{self.execution_id}] Setting up {len(self.agent_data.userTools)} "
            f"user tools with OBO OAuth for agent: {self.agent_data.name}"
        )
        
        access_tokens = self.tool_tokens.get('tokens', {})
        tool_to_provider = self.tool_tokens.get('tool_to_provider', {})
        
        logger.info(
            f"[{self.execution_id}] Available OAuth providers: {list(access_tokens.keys())}"
        )
        
        for user_tool in self.agent_data.userTools:
            # Get provider name for the tool
            provider_name = tool_to_provider.get(user_tool.toolId)
            
            if provider_name and provider_name in access_tokens:
                # Tool needs OAuth - inject token and cloudId
                token_info = access_tokens[provider_name]
                access_token = token_info['access_token']
                cloud_id = token_info.get('cloud_id')
                
                logger.info(
                    f"[{self.execution_id}] Creating tool '{user_tool.toolName}' (toolId={user_tool.toolId}) "
                    f"with {provider_name} OAuth (cloudId: {cloud_id})"
                )
                #user_tool.toolClassDef =  "from crewai.tools import BaseTool\nfrom pydantic import BaseModel, Field\nfrom typing import Type, Optional\nimport requests\nimport json\nimport AVASecret\nfrom AVASecret import secret_manager\n\nclass JiraIssueInput(BaseModel):\n    \"\"\"Input schema for Jira Issue Tool\"\"\"\n    project_key: str = Field(..., description=\"Jira project key (e.g., 'MP')\")\n    summary: str = Field(..., description=\"Issue summary/title\")\n    description: str = Field(\n        default=\"\",\n        description=\"Issue description in plain text (will be converted to ADF format)\"\n    )\n    issue_type: str = Field(\n        default=\"Story\",\n        description=\"Issue type (e.g., Story, Task, Bug)\"\n    )\n\nclass TestJiraTool(BaseTool):\n    \"\"\"Test Jira tool with OAuth - Creates issues via Jira REST API\"\"\"\n    \n    name: str = \"Test Jira Tool\"\n    description: str = \"Create Jira issues with OAuth authentication using Atlassian REST API\"\n    args_schema: Type[BaseModel] = JiraIssueInput\n    \n    # OAuth credentials\n    access_token: str = \"\"\n    cloud_id: str = \"\"\n    \n    def __init__(self, **data):\n        super().__init__(**data)\n        # Store in private attrs to prevent Pydantic reset\n        self._token = data.get('access_token', '')\n        self._cloud = data.get('cloud_id', '')\n        print(f\"[TOOL __init__] Stored token: {self._token[:30]}...\", flush=True)\n        print(f\"[TOOL __init__] Stored cloud: {self._cloud}\", flush=True)\n    \n    def _run(\n        self,\n        project_key: str,\n        summary: str,\n        description: str = \"\",\n        issue_type: str = \"Story\"\n    ) -> str:\n        \"\"\"Execute tool - Create Jira issue via REST API\"\"\"\n        import sys\n        \n        print(\"=\" * 60, file=sys.stdout, flush=True)\n        print(\"[TOOL _run] EXECUTING JIRA API CALL\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Token: {self._token[:30] if self._token else 'EMPTY'}...\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Cloud ID: {self._cloud}\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Project: {project_key}\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Summary: {summary}\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Issue Type: {issue_type}\", file=sys.stdout, flush=True)\n        print(\"=\" * 60, file=sys.stdout, flush=True)\n        \n        # Validate OAuth credentials\n        if not self._token:\n            return \"ERROR: No OAuth access token available!\"\n        \n        if not self._cloud:\n            return \"ERROR: No cloud ID available!\"\n        \n        # Build Jira REST API endpoint\n        api_url = f\"https://api.atlassian.com/ex/jira/{self._cloud}/rest/api/3/issue\"\n        \n        # Prepare headers with OAuth bearer token\n        headers = {\n            \"Authorization\": f\"Bearer {self._token}\",\n            \"Content-Type\": \"application/json\",\n            \"Accept\": \"application/json\"\n        }\n        \n        # Convert plain text description to ADF format\n        adf_description = {\n            \"type\": \"doc\",\n            \"version\": 1,\n            \"content\": [\n                {\n                    \"type\": \"paragraph\",\n                    \"content\": [\n                        {\n                            \"type\": \"text\",\n                            \"text\": description if description else \"Created via CrewAI\"\n                        }\n                    ]\n                }\n            ]\n        }\n        \n        # Build request payload\n        payload = {\n            \"fields\": {\n                \"project\": {\"key\": project_key},\n                \"summary\": summary,\n                \"description\": adf_description,\n                \"issuetype\": {\"name\": issue_type}\n            }\n        }\n        \n        print(f\"[TOOL _run] API URL: {api_url}\", file=sys.stdout, flush=True)\n        print(f\"[TOOL _run] Payload: {json.dumps(payload, indent=2)}\", file=sys.stdout, flush=True)\n        \n        try:\n            # Make API request\n            response = requests.post(\n                api_url,\n                headers=headers,\n                json=payload,\n                timeout=30\n            )\n            \n            print(f\"[TOOL _run] Response Status: {response.status_code}\", file=sys.stdout, flush=True)\n            print(f\"[TOOL _run] Response Body: {response.text[:500]}\", file=sys.stdout, flush=True)\n            \n            # Check response\n            if response.status_code == 201:\n                issue_data = response.json()\n                issue_key = issue_data.get(\"key\", \"UNKNOWN\")\n                issue_id = issue_data.get(\"id\", \"UNKNOWN\")\n                issue_url = issue_data.get(\"self\", \"\")\n                \n                return (\n                    f\"✓ SUCCESS! Created Jira issue:\\n\"\n                    f\"  Key: {issue_key}\\n\"\n                    f\"  ID: {issue_id}\\n\"\n                    f\"  Project: {project_key}\\n\"\n                    f\"  Summary: {summary}\\n\"\n                    f\"  Type: {issue_type}\\n\"\n                    f\"  URL: {issue_url}\"\n                )\n            else:\n                error_msg = response.text\n                return (\n                    f\"✗ FAILED to create Jira issue!\\n\"\n                    f\"  Status: {response.status_code}\\n\"\n                    f\"  Error: {error_msg}\"\n                )\n                \n        except requests.exceptions.Timeout:\n            return \"✗ ERROR: Request timed out after 30 seconds\"\n        except requests.exceptions.RequestException as e:\n            return f\"✗ ERROR: Request failed - {str(e)}\"\n        except Exception as e:\n            return f\"✗ ERROR: Unexpected error - {str(e)}\"\n"

                tool_instance = create_user_tool_with_oauth(
                    class_name=user_tool.toolClassName,
                    class_definition=user_tool.toolClassDef,
                    access_token=access_token,
                    cloud_id=cloud_id,
                    provider_name=provider_name,
                    meta=token_info.get('meta', [])
                )
            self.agent_model.tools.append(tool_instance)
            logger.info(f"[{self.execution_id}] Added tool: {user_tool.toolName}")
# ====================================================== HP OBO change End =================================================================      

    def setup_tools(self):
        """
        Configures and adds all tools to the agent model based on agent_data.
        Handles built-in tools, file system tools, user-defined tools, and knowledge RAG tools.
        """
        tool_handlers = {
            "ScrapeWebsiteTool": self._add_scrape_website_tool,
            "MemoryReaderWriterTool": lambda tool: self._add_memory_reader_writer_tool(),
            "SerperDevTool": self._add_serper_dev_tool,
            "FileWriterTool": lambda tool: self._add_file_writer_tool(),
            "NL2SQLTool": self._add_nl2sql_tool,
            'GitHubDocAnalysisTool': self._add_gitHub_doc_analysis_tool,
            'JiraFetcherReadTool': self._add_jira_fetcher_read_tool,
            'JiraFetcherReadToolV2': self._add_jira_fetcher_read_tool_v2,
            'S3MultiOperation': self._add_S3_multi_operation_tool,
            'TestRailReadOnlyConnectorTool': self._add_test_rail_readonly_connector_tool,
            "JiraConnectorTool": self._add_jira_issue_create_tool,
            "JiraConnectorToolV2": self._add_jira_issue_create_tool_v2,
            "GithubWriterTool": self._add_github_writer_tool,
            "GithubWriterToolV2": self._add_github_writer_tool_v2,
        }
        
        for tool_config in self.agent_data.tools:
            handler = tool_handlers.get(tool_config.toolClassName)
            if handler:
                handler(tool_config)
            else:
                logger.warning(f"No handler defined for tool: {tool_config.toolName}")

        if self.subfolder_path:
            self.setup_file_tools()

        if os.getenv("CLIENT_NAME", "NA").lower() == "hp" and self.tool_tokens:
            self._setup_user_tools_with_obo()
        else:
            self._add_user_defined_tools()

        self._add_knowledge_rag_tool()