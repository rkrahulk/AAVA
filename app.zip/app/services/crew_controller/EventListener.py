import logging
import uuid

from app.core.trulens import Trulens
from app.models.PipelineModel import PipelineModel
from app.models.listeners_metadata import CrewStages
from app.services.crew_controller.agent_creator import AgentCreatorConfig
from app.services.kafka_client import push_logs_to_kafka as plk


logger = logging.getLogger("EventListener")


from crewai.utilities.events import (
    CrewKickoffStartedEvent,
    CrewKickoffCompletedEvent,
    CrewKickoffFailedEvent,

    AgentExecutionStartedEvent,
    AgentExecutionCompletedEvent,
    AgentExecutionErrorEvent,

    TaskStartedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskEvaluationEvent,

    ToolUsageStartedEvent,
    ToolUsageFinishedEvent,
    ToolUsageErrorEvent,
    ToolValidateInputErrorEvent,
    ToolExecutionErrorEvent,
    ToolSelectionErrorEvent,

    # LLMGuardrailStartedEvent,
    # LLMGuardrailCompletedEvent,
    # LLMCallStartedEvent,
    # LLMCallCompletedEvent,
    # LLMCallFailedEvent,
    # LLMStreamChunkEvent,

    # MemoryQueryStartedEvent,
    # MemoryQueryCompletedEvent,
    # MemoryQueryFailedEvent,
    # MemorySaveStartedEvent,
    # MemorySaveCompletedEvent,
    # MemorySaveFailedEvent,
    # MemoryRetrievalStartedEvent,
    # MemoryRetrievalCompletedEvent,
)
from crewai.utilities.events.base_event_listener import BaseEventListener


class EventListeners(BaseEventListener):
    def __init__(self):
        self.metadata_hash = dict()
        self.plk=plk
        logger.info(f"Metadata Hash: {self.metadata_hash}")
        super().__init__()
    
    def crew_listeners_meta(self, _id: str,  payload: PipelineModel, event_type: str):
        try:
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.pipelineId,
                execution_id=payload.executionId,
                name=payload.name,
                user=payload.user,
                description=payload.description,
                user_inputs=payload.userInputs
            )
        except Exception as e:
            logger.error(
                f"Failed to create crew listener payload for event_type: {event_type}"
                f" crew id: {_id} from {payload} as: {str(e)}"
            )
            return dict()
    
    def agent_listeners_meta(self, _id: str,  payload: AgentCreatorConfig, event_type: str):
        try:
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.workflow_id,
                execution_id=payload.execution_id,
                agent_id=payload.agent_details.id,
                agent_name=payload.agent_details.name,
                agent_role=payload.agent_details.role,
            )
        except Exception as e:
            logger.error(
                f"Failed to create agent listener payload for event_type: {event_type}"
                f" agent id: {_id} from {payload} as: {str(e)}"
            )
            return dict()
    
    def task_listeners_meta(self, _id: str,  payload: AgentCreatorConfig, event_type: str):
        try:
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.workflow_id,
                execution_id=payload.execution_id,
                agent_id=payload.agent_details.id,
                agent_name=payload.agent_details.name,
                expected_output=payload.agent_details.task.expectedOutput,
                description=payload.agent_details.task.description,

            )
        except Exception as e:
            logger.error(
                f"Failed to create task listener payload for event_type: {event_type}"
                f" task id: {_id} from {payload} as: {str(e)}"
            )
            return dict()

    def setup_listeners(self, crewai_event_bus):
        @crewai_event_bus.on(CrewKickoffStartedEvent)
        def on_crew_started(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.CREW_START.value
                payload = self.metadata_hash.get(_id)
                data = self.crew_listeners_meta(_id, payload, event_type)
                data["type"] = event_type
                data["message"] =  f"[CrewAI Listener] Crew started for execution_id: {data.get('execution_id')}",
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(CrewKickoffCompletedEvent)
        def on_crew_completed(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.CREW_FINISHED.value
                payload = self.metadata_hash.get(_id)
                data = self.crew_listeners_meta(_id, payload, event_type)
                output = getattr(event, "output", None)
                raw_output = getattr(output, "raw", None) or output
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    message=  f"[CrewAI Listener] Crew Completed for execution_id: {data.get('execution_id')}",
                    output=raw_output,
                    # total_tokens=event.total_tokens,
                    type=event_type
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(CrewKickoffFailedEvent)
        def on_crew_failure(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.CREW_ERROR.value
                payload = self.metadata_hash.get(_id)
                data = self.crew_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    message=  f"[CrewAI Listener] Crew Failed for execution_id: {data.get('execution_id')}",
                    error=event.error,
                    type=event_type
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(AgentExecutionStartedEvent)
        def on_agent_start(source, event):
            try:
                agent = getattr(event, "agent", None)
                logger.error(f"agent_id: {getattr(agent, 'id')} ######### source_id: {source.id}")
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                event_type = CrewStages.AGENT_INITIALIZED.value
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent started for execution_id: {data.get('execution_id')}",
                    tools = [tool.name for tool in event.tools],
                    task_prompt = event.task_prompt,
                    user_inputs=payload.user_inputs,
                    agent_goal=payload.agent_details.goal,
                    agent_backstory=payload.agent_details.backstory,
                    agent_llm=payload.agent_details.llm,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(AgentExecutionCompletedEvent)
        def on_agent_completion(source, event):
            try:
                agent = getattr(event, "agent", None)
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                event_type = CrewStages.AGENT_FINISHED.value
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)
                task = getattr(event, "task", None)
                task_name = getattr(task, "name", None)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent finished for execution_id: {data.get('execution_id')}",
                    output=event.output,
                    task = task_name,
                )
                logger.info(data)
                self.plk(message=data)

                try:
                    Trulens(
                        agent_config=payload,
                        input = task.description, 
                        output=event.output, 
                        context=None
                    ).register_record()
                except Exception as e:
                    logger.error(
                        f"Trulens error: {str(e)}"
                        f" for execution_id: {payload.execution_id} "
                        f"and pipeline_id: {payload.workflow_id}"
                    )
                
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")


        @crewai_event_bus.on(AgentExecutionErrorEvent)
        def on_agent_failure(source, event):
            try:
                agent = getattr(event, "agent", None)
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                event_type = CrewStages.AGENT_ERROR.value
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)
                task = getattr(event, "task", None)
                task_name = getattr(task, "name", None)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent Failed for execution_id: {data.get('execution_id')}",
                    error=event.error,
                    task = task_name,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")


        @crewai_event_bus.on(TaskStartedEvent)
        def on_task_start(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.TASK_START.value
                payload = self.metadata_hash.get(_id)
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Started for execution_id: {data.get('execution_id')}",
                    context = event.context,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(TaskCompletedEvent)
        def on_task_finish(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.TASK_FINISH.value
                payload = self.metadata_hash.get(_id)
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Finished for execution_id: {data.get('execution_id')}",
                    output = event.output,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(TaskFailedEvent)
        def on_task_failure(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.TASK_FAILURE.value
                payload = self.metadata_hash.get(_id)
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Failed for execution_id: {data.get('execution_id')}",
                    error = event.error,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(TaskEvaluationEvent)
        def on_task_evaluation(source, event):
            try:
                _id = str(source.id)
                event_type = CrewStages.TASK_EVALUATION.value
                payload = self.metadata_hash.get(_id)
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Evaluation for execution_id: {data.get('execution_id')}",
                    evaluation = event.evaluation,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")



        @crewai_event_bus.on(ToolUsageStartedEvent)
        def on_tool_start(source, event):
            try:
                event_type = CrewStages.TOOL_INITIALIZED.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Tool Usage started for execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    run_attempts = event.run_attempts,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")


        @crewai_event_bus.on(ToolUsageFinishedEvent)
        def on_tool_finish(source, event):
            try:
                event_type = CrewStages.TOOL_FINISHED.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Tool Usage Finished for execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    run_attempts = event.run_attempts,
                    started_at=event.started_at.strftime("%d-%m-%Y %H:%M:%S"),
                    finished_at=event.finished_at.strftime("%d-%m-%Y %H:%M:%S"),
                    from_cache=event.from_cache,
                    output=event.output,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")


        @crewai_event_bus.on(ToolUsageErrorEvent)
        def on_tool_usage_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolUsageErrorEvent for execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(ToolValidateInputErrorEvent)
        def on_tool_input_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolValidateInputErrorEvent execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(ToolExecutionErrorEvent)
        def on_tool_execution_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolExecutionErrorEvent for execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(ToolSelectionErrorEvent)
        def on_tool_selection_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolSelectionErrorEvent for execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.plk(message=data)
            except Exception as e:
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {data.get('execution_id')} as: {str(e)}")


        # @crewai_event_bus.on(LLMGuardrailStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMGuardrailCompletedEvent)
        # def listener(source, event):
        #     pass


        # @crewai_event_bus.on(LLMCallStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMCallCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMCallFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMStreamChunkEvent)
        # def listener(source, event):
        #     pass


        # @crewai_event_bus.on(MemoryQueryStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryQueryCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryQueryFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryRetrievalStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryRetrievalCompletedEvent)
        # def listener(source, event):
        #     pass
