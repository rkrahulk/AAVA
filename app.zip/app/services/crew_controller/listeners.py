"""
CrewAI Event Listeners

This module defines listener functions for CrewAI agent and task lifecycle events.
Listeners are used for logging, error handling, and integration with external systems (e.g., Redis).
Each listener is designed to be called at specific points in the agent/task workflow.
"""

import logging
import enum
import uuid
from app.models.listeners_metadata import CrewStages
from app.core.config import settings
from app.services.kafka_client import push_logs_to_kafka as plk


logger = logging.getLogger("crewai.listeners")

def log_agent_step(push_logs_to_kafka = plk, **kwargs):
    """
    Listener for when an agent finishes a step.
    Logs the agent's id, name, role, and output.
    """
    import uuid
    try:
        step=kwargs.get('step')
        agent=kwargs.get('agent')
        execution_id=kwargs.get('execution_id')
        workflow_id=kwargs.get('workflow_id')


        agent_thought = getattr(step, "thought", "")
        agent_tool = getattr(step, "tool", "")
        agent_tool_input = getattr(step, "tool_input", "")
        agent_text = getattr(step, "text", "")
        agent_result = getattr(step, "result", "")
        agent_output = getattr(step, "output", "")

        step_message = dict(
            event_execution_id=str(uuid.uuid4()),
            pipeline_id=workflow_id,
            execution_id=execution_id,
            agent_id=agent.id,
            agent_name=agent.name,
            agent_role=agent.role,
            agent_execution_id=str(agent.id),
            message=dict(
                agent_thought=agent_thought,
                agent_tool=agent_tool,
                agent_tool_input=agent_tool_input,
                agent_text=agent_text,
                agent_result=agent_result,
                agent_output=agent_output,
            ),
            type=CrewStages.AGENT_STEP.value
        )
        logger.info(step_message)
        push_logs_to_kafka(message=step_message)
    except Exception as e:
        logger.error(
            f"Could not Log the event : {CrewStages.AGENT_STEP.value}"
            f" with execution id: {kwargs.get('execution_id')} as {str(e)}"
        )


def log_agent_error(agent, error, workflow_id, execution_id, push_logs_to_kafka = plk):

    """
    Listener for when an agent step raises an error/exception.
    Logs the agent's id, name, role, and the error message.
    """
    try:
        # agent = getattr(step, "agent", None)
        agent_id = getattr(agent, "id", "Unknown")
        agent_name = getattr(agent, "name", "Unknown")
        agent_role = getattr(agent, "role", "Unknown")
        topic = settings.workflow_topic if workflow_id else settings.agent_topic
        
        error_message = dict(
            event_execution_id=str(uuid.uuid4()),
            pipeline_id=workflow_id,
            execution_id=execution_id,
            agent_id=agent_id,
            agent_name=agent_name,
            agent_role=agent_role,
            agent_execution_id=str(agent_id),
            message = f"[CrewAI Listener] Agent (id: {agent_id}, name: {agent_name}, role: {agent_role}) encountered an error: {error}",
            type=CrewStages.AGENT_SETUP_ERROR.value
        )
        logger.info(error_message)
        push_logs_to_kafka(message=error_message)
    except Exception as e:
        logger.error(
            f"Could not Log the event : {CrewStages.AGENT_SETUP_ERROR.value}"
            f" with execution id: {execution_id} as {str(e)}"
        )



def log_pipeline_error(pipeline, agent, error, push_logs_to_kafka = plk):
    
    """
    Listener for when crew raises an error/exception.
    Logs the agent's id, name, role, and the error message.
    """
    try:
        # agent = getattr(step, "agent", None)
        workflow_id = getattr(pipeline, 'pipelineId', None)
        execution_id = getattr(pipeline, 'executionId', None)
        agent_id = getattr(agent, "id", "Unknown")
        agent_name = getattr(agent, "name", "Unknown")
        agent_role = getattr(agent, "role", "Unknown")
        topic = settings.workflow_topic if workflow_id else settings.agent_topic

        error_message = dict(
            event_execution_id=str(uuid.uuid4()),
            pipeline_id=workflow_id,
            execution_id=execution_id,
            agent_id=agent_id,
            agent_name=agent_name,
            agent_role=agent_role,
            agent_execution_id=str(agent_id),
            message = f"[CrewAI Listener] Agent (id: {agent_id}, name: {agent_name}, role: {agent_role}) encountered an error: {error}",
            type=CrewStages.PIPELINE_SETUP_ERROR.value
        )
        logger.info(error_message)
        push_logs_to_kafka(message=error_message)
    except Exception as e:
        logger.error(
            f"Could not Log the event : {CrewStages.PIPELINE_SETUP_ERROR.value}"
            f" with execution id: {execution_id} as {str(e)}"
        )


# def log_task_start(task, agent_model, agent_data, workflow_id, execution_id, push_logs_to_kafka = plk):
    
#     """
#     Listener for when a task starts.
#     Logs the agent's id, name, role, and the task description.
#     """
#     task_desc = getattr(task, "description", "Unknown")
#     agent_id = getattr(agent_data, "id", "Unknown")
#     agent_name = getattr(agent_data, "name", "Unknown")
#     agent_role = getattr(agent_data, "role", "Unknown")
#     agent_execution_id = getattr(agent_model, 'id', 'Unknown')
#     topic = settings.workflow_topic if workflow_id else settings.agent_topic

#     task_start_message = dict(
#         event_execution_id=str(uuid.uuid4()),
#         workflow_id=workflow_id,
#         execution_id=execution_id,
#         agent_id=agent_id,
#         agent_name=agent_name,
#         agent_role=agent_role,
#         agent_execution_id=str(agent_execution_id),
#         message = f"[CrewAI Listener] Task started for agent (id: {agent_id}, name: {agent_name}, role: {agent_role}, push_logs_to_kafka = plk): {task_desc}",
#         type=CrewStages.TASK_START.value
#     )
#     logger.info(task_start_message)
#     push_logs_to_kafka(message=task_start_message)


# def log_task_finish(push_logs_to_kafka = plk, **kwargs): # TODO
#     """
#     Listener for when a task finishes.
#     Logs the agent's id, name, role, task description, and result.
#     """
#     import uuid
#     try:
#         output=kwargs.get('output')
#         agent=kwargs.get('agent')
#         agent_model=kwargs.get('agent_model')
#         task_desc = kwargs.get('task_details')
#         execution_id=kwargs.get('execution_id')
#         workflow_id=kwargs.get('workflow_id')

#         agent_id = getattr(agent, "id", "Unknown")
#         agent_name = getattr(agent, "name", "Unknown")
#         agent_role = getattr(agent, "role", "Unknown")
#         agent_execution_id = getattr(agent_model, 'id', "Unknown")

#         topic = settings.workflow_topic if workflow_id else settings.agent_topic

#         task_finish_message = dict(
#             event_execution_id=str(uuid.uuid4()),
#             pipeline_id=workflow_id,
#             execution_id=execution_id,
#             agent_id=agent_id,
#             agent_name=agent_name,
#             agent_role=agent_role,
#             agent_execution_id=str(agent_execution_id),
#             message = (f"[CrewAI Listener] Task finished for agent (id: {agent_id}, "
#                     f"name: {agent_name}, role: {agent_role})."
#                     f"Task Description: {task_desc} Output: {output}"
#                     ),
#             type=CrewStages.TASK_FINISH.value
#         )
#         logger.info(task_finish_message)
#         push_logs_to_kafka(message=task_finish_message)
#     except Exception as e:
#         logger.error(
#             f"Could not Log the event : {CrewStages.TASK_FINISH.value}"
#             f" with execution id: {execution_id} as {str(e)}"
#         )


def log_llm_config_error(llm_data, agent,  error, workflow_id, execution_id, push_logs_to_kafka = plk):
    
    """
    Listener for LLM configuration errors (e.g., invalid model, missing API key).
    Logs the agent's role and the error message.
    """
    try:
        agent_id = getattr(agent, "id", "Unknown")
        agent_name = getattr(agent, "name", "Unknown")
        agent_role = getattr(agent, "role", "Unknown")
        topic = settings.workflow_topic if workflow_id else settings.agent_topic

        llm_error_message = dict(
            event_execution_id=str(uuid.uuid4()),
            pipeline_id=workflow_id,
            execution_id=execution_id,
            agent_id=agent_id,
            agent_name=agent_name,
            agent_role=agent_role,
            agent_execution_id=str(agent_id),
            llm_data=llm_data.model_dump(),
            message = f"[CrewAI Listener] LLM configuration error': {error}",
            type=CrewStages.LLM_ERROR.value
        )
        logger.info(llm_error_message)
        push_logs_to_kafka(message=llm_error_message)
    except Exception as e:
        logger.error(
            f"Could not Log the event : {CrewStages.LLM_ERROR.value}"
            f" with execution id: {execution_id} as {str(e)}"
        )

# def log_agent_init(agent_model, agent_data, workflow_id, execution_id, push_logs_to_kafka = plk):
#     """
#     Listener for agent initialization.
#     Logs the agent's id, name, and role.
#     """
#     try:
#         agent_id = getattr(agent_data, "id", "Unknown")
#         agent_name = getattr(agent_data, "name", "Unknown")
#         agent_role = getattr(agent_data, "role", "Unknown")
#         agent_execution_id = getattr(agent_model, 'id', 'Unknown')
#         topic = settings.workflow_topic if workflow_id else settings.agent_topic

#         agent_init_message = dict(
#             event_execution_id=str(uuid.uuid4()),
#             workflow_id=workflow_id,
#             execution_id=execution_id,
#             agent_id=str(agent_id),
#             agent_name=agent_name,
#             agent_role=agent_role,
#             agent_execution_id=str(str(agent_execution_id)),
#             message=f"[CrewAI Listener] Agent initialized: (id: {str(agent_id)}, name: {agent_name}, role: {agent_role})",
#             type=CrewStages.AGENT_INITIALIZED.value
#         )
#         logger.info(agent_init_message)
#         push_logs_to_kafka(message=agent_init_message)
#     except Exception as e:
#         logger.error(
#             f"Could not Log the event : {CrewStages.AGENT_INITIALIZED.value}"
#             f" with execution id: {execution_id} as {str(e)}"
#         )

# def log_agent_shutdown(agent, push_logs_to_kafka = plk):
    
#     """
#     Listener for agent shutdown/cleanup.
#     Logs the agent's id, name, and role.
#     """
#     agent_id = getattr(agent, "id", "Unknown")
#     agent_name = getattr(agent, "name", "Unknown")
#     agent_role = getattr(agent, "role", "Unknown")
#     topic = settings.workflow_topic if workflow_id else settings.agent_topic

#     agent_shutdown_message = dict(
#         event_execution_id=str(uuid.uuid4()),
#         workflow_id=None,
#         execution_id=None,
#         agent_id=agent_id,
#         agent_name=agent_name,
#         agent_role=agent_role,
#         agent_execution_id=str(agent_id),
#         message = f"[CrewAI Listener] Agent shutdown: (id: {agent_id}, name: {agent_name}, role: {agent_role})",
#         type=CrewStages.AGENT_SHUTDOWN.value
#     )
#     logger.info(agent_shutdown_message)
#     push_logs_to_kafka(message=agent_shutdown_message)

# def log_agent_tool_usage(agent_model, agent_data, workflow_id, execution_id, tool, input_data, output_data, push_logs_to_kafka = plk):
#     """
#     Listener for when an agent uses a tool.
#     Logs the agent's id, name, role, tool name, input, and output.
#     """
#     try:
#         agent_id = getattr(agent_data, "id", "Unknown")
#         agent_name = getattr(agent_data, "name", "Unknown")
#         agent_role = getattr(agent_data, "role", "Unknown")
#         agent_execution_id = getattr(agent_model, 'id', 'Unknown')
#         tool_name = getattr(tool, "toolName", str(tool))
#         topic = settings.workflow_topic if workflow_id else settings.agent_topic
        
#         agent_tool_message = dict(
#             event_execution_id=str(uuid.uuid4()),
#             workflow_id=workflow_id,
#             execution_id=execution_id,
#             agent_id=str(agent_id),
#             agent_name=agent_name,
#             agent_role=agent_role,
#             agent_execution_id=str(agent_execution_id),
#             tool_name=tool_name,
#             message = f"[CrewAI Listener] Agent (id: {str(agent_id)}, name: {agent_name}, role: {agent_role}) used tool '{tool_name}' with input: {input_data} and output: {output_data}",
#             type=CrewStages.AGENT_TOOL.value
#         )
#         logger.info(agent_tool_message)
#         push_logs_to_kafka(message=agent_tool_message)
#     # Additional listeners can be added here for other CrewAI events as needed.
#     except Exception as e:
#         logger.error(
#             f"Could not Log the event : {CrewStages.AGENT_TOOL.value}"
#             f" with execution id: {execution_id} as {str(e)}"
#         )



# def log_crew_finish(workflow_id, execution_id, push_logs_to_kafka = plk):
#     """
#     Listener for agent initialization.
#     Logs the agent's id, name, and role.
#     """
#     try:
#         agent_init_message = dict(
#             event_execution_id=str(uuid.uuid4()),
#             workflow_id=workflow_id,
#             execution_id=execution_id,
#             message=f"[CrewAI Listener] Crew Execution Finished: workflow_id: {workflow_id}, execution_id: {execution_id}",
#             type=CrewStages.CREW_FINISHED.value
#         )
#         logger.info(agent_init_message)
#         push_logs_to_kafka(message=agent_init_message)
#     except Exception as e:
#         logger.error(
#             f"Could not Log the event : {CrewStages.CREW_FINISHED.value}"
#             f" with execution id: {execution_id} as {str(e)}"
#         )