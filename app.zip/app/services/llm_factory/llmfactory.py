import logging
import os

import boto3
from botocore.exceptions import NoCredentialsError

from crewai import LLM
from fastapi import HTTPException

from app.core.config import settings

logger = logging.getLogger(__name__)

USE_BEDROCK_CREDENTIALS = settings.USE_BEDROCK_CREDENTIALS


def _assume_role_credentials(role_arn: str, region: str, session_name: str = "aava-bedrock-llm"):
    """
    Assume an AWS role and return temporary credentials for Bedrock access.
    Used when USE_BEDROCK_CREDENTIALS is false (IRSA/web-identity or instance profile).
    """
    try:
        # Avoid profile interference in containers
        if "AWS_PROFILE" in os.environ:
            os.environ.pop("AWS_PROFILE", None)

        session = boto3.Session(profile_name=None, region_name=region)
        logger.info("Assuming role %s in region %s", role_arn, region)

        sts = session.client("sts")
        identity = sts.get_caller_identity()
        logger.info(
            "Caller Identity - Account: %s, ARN: %s, UserId: %s",
            identity.get("Account"),
            identity.get("Arn"),
            identity.get("UserId"),
        )

        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName=session_name,
            DurationSeconds=3600,
        )
        logger.info("Successfully assumed role %s", role_arn)
        return response["Credentials"]
    except NoCredentialsError as e:
        logger.error("No AWS credentials available to assume role: %s", str(e))
        raise
    except Exception as e:
        logger.error("Error assuming role for Bedrock access: %s", str(e))
        raise


class LLMFactory:
    """
    Factory class for building LLM (Large Language Model) objects from configuration data.
    Supports Azure OpenAI, Amazon Bedrock, and Google Vertex AI providers.
    Handles validation, error reporting, and listener integration for LLM configuration events.
    """

    @staticmethod
    def build_llm(llm_config_data, execution_id=None, workflow_id=None):
        """
        Validates the llm_config_data and builds an LLM object for the specified provider.

        Args:
            llm_config_data (AgentLLM): The agent's LLM configuration (Pydantic model).
            langfuse_cfg (dict, optional): Optional metadata for Langfuse callbacks.

        Returns:
            LLM: Instantiated LLM object.

        Raises:
            HTTPException: If validation fails or the provider is unsupported.
        """
        try:

            logger.info("build_llm called with execution_id=%s workflow_id=%s", execution_id, workflow_id)
            logger.info("USE_BEDROCK_CREDENTIALS=%s", USE_BEDROCK_CREDENTIALS)
            logger.info("llm_config_data (raw)=%s", llm_config_data)

            aws_keys = ["aws_access_key_id", "aws_secret_access_key", "aws_session_token"]
            if USE_BEDROCK_CREDENTIALS.lower() == "false":
                logger.info("USE_BEDROCK_CREDENTIALS is false: attempting assume-role path for Bedrock")
                role_arn = settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT
                region = llm_config_data.get("aws_region_name") or settings.AWS_REGION
                logger.info("Assume-role inputs role_arn=%s region=%s", role_arn, region)
                creds = _assume_role_credentials(
                    role_arn=role_arn,
                    region=region,
                    session_name="aava-bedrock-llm",
                )
                logger.info("Assume-role success: AccessKeyId=%s SessionToken_present=%s", creds.get("AccessKeyId"), "SessionToken" in creds)
                llm_config_data["aws_access_key_id"] = creds["AccessKeyId"]
                llm_config_data["aws_secret_access_key"] = creds["SecretAccessKey"]
                llm_config_data["aws_session_token"] = creds["SessionToken"]
            else:
                logger.info("USE_BEDROCK_CREDENTIALS is true: using provided credentials in llm_config_data")
                logger.info(
                    "Provided credential keys: has_access_key=%s has_secret_key=%s has_session_token=%s",
                    bool(llm_config_data.get("aws_access_key_id")),
                    bool(llm_config_data.get("aws_secret_access_key")),
                    bool(llm_config_data.get("aws_session_token")),
                )

            llm_config_data["timeout"] = int(settings.REQUEST_TIMEOUT)
            logger.info("Final llm_config_data before LLM init: provider=%s model=%s region=%s timeout=%s",
                        llm_config_data.get("provider"), llm_config_data.get("model"),
                        llm_config_data.get("aws_region_name"), llm_config_data.get("timeout"))

            return LLM(**llm_config_data)

        except ValueError as e:  # Catches Pydantic validation errors
            logger.error(f"LLM Configuration Error: {e}. Data: {llm_config_data}")
            try:
                from app.services.crew_controller.listeners import log_llm_config_error

                log_llm_config_error(
                    llm_config_data, None, str(e), execution_id, workflow_id
                )
            except Exception as listener_exc:
                logger.warning(f"Failed to call log_llm_config_error: {listener_exc}")
            raise HTTPException(
                status_code=400, detail=f"Invalid LLM configuration: {e}"
            )

