import errno
import io
import json
import logging
import os
import re
import shutil
import stat
import time
import zipfile
from typing import Any, Dict
# from app.core.application_insights import execution_insights_decorator
from app.helpers.kb_utils import get_kb_details
from app.helpers.guardrails import GaurdRails
from crewai_tools import FileWriterTool
from fastapi import HTTPException, UploadFile, status as http_status
from langchain_core.exceptions import OutputParserException
from langfuse import Langfuse
from crewai.tasks.task_output import TaskOutput
from app.core.config import settings
from app.core.redis_client import redis_client
from app.core.secret_manager import secret_manager
from app.helpers import agent_image_utils
from app.helpers.agent_helpers import AgentPayload
from app.helpers.payload_converter import convert_payload
from app.helpers.redis_logs import PipelineAILogs
from app.helpers.workflow_history import send_execution_status
from app.models.agent import Agent
from app.models.agentDetails import AgentDetails
from app.models.AgentModel import AgentModel
from app.models.AgentRequest import AgentRequest
from app.services import event_listener
from app.services.crew_controller.agent_creator import AgentCreator, AgentCreatorConfig

adminUrl = settings.BASE_URL
logger = logging.getLogger(__name__)


def setup_langfuse_client(payload) -> Langfuse | None:
    if not settings.to_bool("LANGFUSE_ENABLED"):
        logger.info(f"LangFuse disabled — skipping setup for {payload.executionId}")
        return None

    langfuse_client = Langfuse(
        public_key=settings.LANGFUSE_PUBLIC_KEY,
        secret_key=settings.LANGFUSE_SECRET_KEY,
        host=settings.LANGFUSE_HOST,
        environment=settings.AAVA_LOGGING_ENVIRONMENT
    )

    logger.info(f"LangFuse client setup completed for {payload.executionId}")
    return langfuse_client


class AgentExecutionError(Exception):
    """Custom exception for agent execution errors."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(self.detail)


class AgentExecutor:
    """
    Manages the execution flow of a agent request.

    Encapsulates setup, payload preparation, core execution logic,
    response processing, and cleanup steps.
    """

    def __init__(
            self,
            Authorization: str,
            agent_request: AgentRequest,
            files: list[UploadFile] | None = None,
            tool_tokens: Dict[str, str] = None):  # HP_OBO

        self.Authorization: str = Authorization
        self.agent_request: AgentRequest = agent_request
        self.payload_object: AgentModel = AgentModel.model_construct()
        self.temporary_images: list[str] | None = None
        self.admin_url: str = settings.BASE_URL
        self.log_stream_enabled: bool = settings.ENABLE_LOGSTREAMING.lower() == "true"
        self.persistent_logging_enabled: bool = (
                settings.PERSISTENT_LOGGING.lower() == "true"
        )
        # Assuming redis_client is accessible (e.g., imported global instance)
        self.redis_client = redis_client
        self.files = files
        self.logger = logger

        self.tool_tokens = tool_tokens or {}  # HP_OBO

    def _prepare_payload(self):
        """Handles image processing, fetches agent JSON, and creates the AgentModel."""
        try:
            # Process images and update userInputs directly on the request object
            self.temporary_images, updated_user_inputs = (
                agent_image_utils.save_temp_images_with_rewrite_inputs(
                    self.agent_request.userInputs
                )
            )
            self.agent_request.userInputs = updated_user_inputs

            # Fetch agent definition
            agent_details = AgentPayload(
                self.agent_request.agentId,
                self.Authorization,
            )

            agent_json = agent_details.fetch()

            logger.info("Agent payload fetched")

            # Create AgentDetails object using Pydantic validation
            self.payload_object.pipeLineAgents = [
                Agent(serial=1, agent=AgentDetails(**agent_json["agentDetail"]))
            ]
            # Populate instance-specific details
            self.payload_object.userInputs = self.agent_request.userInputs
            self.payload_object.executionId = self.agent_request.executionId
            self.payload_object.user = self.agent_request.user
            secret_manager.Authorization = (
                self.Authorization
            )  # Update shared secret manager

            # ==================== HP OBO BLOCK BEGIN ====================
            # OAuth token fetching (can be enabled/disabled via flag)
            if os.getenv("CLIENT_NAME", "NA").lower() == "hp" and os.getenv("OBO_ENABLED") == True:
                self.logger.info("HP client detected - checking for user tools")

                # CHECK: Only enable OBO if agent has user tools
                user_tools = agent_json["agentDetail"].get("userTools", [])

                if not user_tools or len(user_tools) == 0:
                    self.logger.info("No user tools found in agent - skipping HP OBO flow")
                    self.tool_tokens = {'tokens': {}, 'tool_to_provider': {}}
                else:
                    self.logger.info(f"User tools detected ({len(user_tools)} tools) - enabling HP OBO flow")
                    try:
                        from app.helpers.hp_obo_tool_handler import (
                            validate_consents_and_fetch_tokens_sync,
                            ConsentMissingException,
                            ReAuthenticationRequiredException,
                            OAuthServiceException,
                            ProviderNotFoundException
                        )

                        self.logger.info("HP OBO feature enabled - validating consents")

                        self.tool_tokens = validate_consents_and_fetch_tokens_sync(
                            user_tools=user_tools,
                            authorization=self.Authorization,
                            execution_id=self.agent_request.executionId
                        )

                        self.logger.info(
                            f"Fetched tokens for providers: {list(self.tool_tokens.get('tokens', {}).keys())}")

                    except ProviderNotFoundException as e:
                        self.logger.error(f"Provider not found: {str(e)}")
                        raise AgentExecutionError(
                            status_code=404,
                            detail={
                                "error_type": "PROVIDER_NOT_FOUND",
                                "message": str(e),
                                "tool_id": e.tool_id,
                                "execution_id": self.agent_request.executionId
                            }
                        )
                    except ConsentMissingException as e:
                        self.logger.error(f"Consent missing: {str(e)}")
                        raise AgentExecutionError(
                            status_code=403,
                            detail={
                                "error_type": "CONSENT_REQUIRED",
                                "message": str(e),
                                "missing_consents": e.missing_providers,
                                "execution_id": self.agent_request.executionId
                            }
                        )


                    except ReAuthenticationRequiredException as e:
                        self.logger.error(f"Re-authentication required: {str(e)}")
                        raise AgentExecutionError(
                            status_code=401,
                            detail={
                                "error_type": "REAUTH_REQUIRED",
                                "message": str(e),
                                "expired_providers": e.expired_providers,
                                "execution_id": self.agent_request.executionId
                            }
                        )

                    except OAuthServiceException as e:
                        self.logger.error(f"OAuth service error: {str(e)}")
                        raise AgentExecutionError(
                            status_code=500,
                            detail={
                                "error_type": "OAUTH_SERVICE_ERROR",
                                "message": str(e),
                                "step": e.step,
                                "execution_id": self.agent_request.executionId
                            }
                        )
            # ==================== END HP OBO  BLOCK ====================

            logger.debug(
                f"Payload object created for execution: {self.payload_object.executionId}"
            )
            logger.debug(
                f"Agentic Memory setting: {self.payload_object.enableAgenticMemory}"
            )

        except Exception as e:
            status_code = getattr(e, "status_code", http_status.HTTP_500_INTERNAL_SERVER_ERROR)
            detail = getattr(e, "detail", str(e))
            logger.error(f"Error preparing agent payload: {e}")
            # Clean up images if they were created before the error
            self._cleanup()
            raise AgentExecutionError(
                status_code=status_code, detail=detail
            )

    async def _prepare_and_unzip_files(self, files: list[UploadFile]) -> str:
        """
        Creates a temporary subfolder and unzips uploaded files into it.
        Returns the path to the created subfolder.
        """
        self.logger.info("Current Directory: %s", os.getcwd())
        random_name = self.agent_request.executionId
        self.logger.info("Random subfolder name: %s", random_name)
        subfolder_path = os.path.join(os.getcwd(), random_name)
        self.logger.info("Subfolder path: %s", subfolder_path)

        # Create the subfolder
        os.makedirs(subfolder_path, exist_ok=True)
        os.chmod(subfolder_path, 0o777)  # Use octal for permissions

        zip_files = [file for file in files if file.filename.endswith(".zip")]

        if not zip_files:
            # Clean up the created subfolder if no zip files are found
            # import shutil # Add this import at the top of the file if not present
            # shutil.rmtree(subfolder_path) # Consider cleanup
            raise HTTPException(
                status_code=400,
                detail="Zip file not found, please upload a valid zip file",
            )

        # Process uploaded files
        for (
                file_in_list
        ) in (
                zip_files
        ):  # Renamed 'file' to 'file_in_list' to avoid conflict with 'files' parameter
            self.logger.info(f"Unzipping file: {file_in_list.filename}")

            try:
                zip_bytes = await file_in_list.read()

                # Create a subfolder for each zip with the same name as the zip file
                zip_folder_name = f"{os.path.splitext(file_in_list.filename)[0]}"
                zip_subfolder_path = os.path.join(subfolder_path, zip_folder_name)
                os.makedirs(zip_subfolder_path, exist_ok=True)
                # No need to chmod individual extracted file folders typically, parent is already set

                with zipfile.ZipFile(
                        io.BytesIO(zip_bytes), "r"
                ) as zip_ref:  # Added import for zipfile and io
                    for file_info in zip_ref.infolist():
                        filename = file_info.filename

                        # Basic check for hidden files/folders (e.g., starting with '.')
                        # and common OS-specific hidden files like __MACOSX
                        if not filename.startswith(".") and "__MACOSX" not in filename:
                            # Sanitize filename to prevent path traversal issues
                            # This is a basic sanitization, more robust solutions might be needed
                            # depending on security requirements.
                            # target_path = os.path.join(zip_subfolder_path, filename)
                            # if os.path.commonprefix((os.path.realpath(target_path), os.path.realpath(zip_subfolder_path))) != os.path.realpath(zip_subfolder_path):
                            #     self.logger.warning(f"Skipping potentially unsafe path: {filename}")
                            #     continue
                            zip_ref.extract(file_info, zip_subfolder_path)
                            self.logger.info(
                                f"Extracted: {filename} to {zip_subfolder_path}"
                            )
                        else:
                            self.logger.info(f"Skipped hidden/system file: {filename}")

            except zipfile.BadZipFile as e:
                self.logger.error(
                    f"Invalid zip file: {file_in_list.filename} - {str(e)}"
                )
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: Invalid zip file - {str(e)}",
                    "red",
                    redisClient=self.redis_client,
                )
                # shutil.rmtree(subfolder_path) # Consider cleanup
                raise HTTPException(
                    status_code=400,
                    detail=f"AAVA Agent Exception: Invalid zip file - {str(e)}",
                )

            except PermissionError as e:  # Added 'as e'
                self.logger.error(
                    f"Permission error processing file: {file_in_list.filename} - {str(e)}"
                )
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: Permission error - {str(e)}",
                    "red",
                    redisClient=self.redis_client,
                )
                # shutil.rmtree(subfolder_path) # Consider cleanup
                raise HTTPException(
                    status_code=403,
                    detail=f"AAVA Agent Exception: Permission error - {str(e)}",
                )  # 403 for permission

            except MemoryError as e:  # Added 'as e'
                self.logger.error(
                    f"Memory error processing file: {file_in_list.filename} - {str(e)}"
                )
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: Memory error - {str(e)}",
                    "red",
                    redisClient=self.redis_client,
                )
                # shutil.rmtree(subfolder_path) # Consider cleanup
                raise HTTPException(
                    status_code=500,
                    detail=f"AAVA Agent Exception: Memory error - {str(e)}",
                )  # 500 for server-side memory issues

            except Exception as e:
                self.logger.error(
                    f"Error extracting zip file: {file_in_list.filename} - {str(e)}"
                )
                # shutil.rmtree(subfolder_path) # Consider cleanup
                raise HTTPException(
                    status_code=500,
                    detail=f"AAVA Agent Exception: Error extracting zip - {str(e)}",
                )

        return subfolder_path

    def remove_readonly(self, func, path, exc):
        excvalue = exc[1]
        if func in (os.rmdir, os.remove) and excvalue.errno == errno.EACCES:

            # ensure parent directory is writeable too
            pardir = os.path.abspath(os.path.join(path, os.path.pardir))
            if not os.access(pardir, os.W_OK):
                os.chmod(pardir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

            os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 0777
            func(path)
        else:
            raise

    # async def file_uploader(self, folder_path):
    #     pipelineId = await self.get_pipelineId()
    #     file_id = zip_and_upload_folder(
    #         pipelineId=pipelineId,
    #         executionId=self.payload_object.executionId,
    #         user=self.payload_object.user,
    #         folder_path=folder_path,
    #         Authorization=self.Authorization
    #     )
    #     return file_id

    def _prepare_trace_metadata(self):
        """Prepare metadata for Langfuse tracing."""
        return {
            "agent_id": getattr(self.payload_object.pipeLineAgents[0].agent, "id", ""),
            "user_inputs": self.payload_object.userInputs,
            "execution_id": self.payload_object.executionId,
            "user": self.payload_object.user,
            "enable_memory": self.payload_object.enableAgenticMemory,
            # "subfolder_path": self.subfolder_path,
            "agent_count": len(self.payload_object.pipeLineAgents),
            "has_manager_llm": bool(self.payload_object.managerLlm),
        }

    async def execute_task(self, langfuse_client, unzipped_files_path=None):

        agent_data = self.payload_object.pipeLineAgents[0]

        creator_config = AgentCreatorConfig(
            agent_details=agent_data.agent,
            user_inputs=self.payload_object.userInputs,
            enable_memory=self.payload_object.enableAgenticMemory,
            langfuse_handler=langfuse_client,
            execution_id=self.payload_object.executionId,
            subfolder_path=unzipped_files_path,
            workflow_id=self.payload_object.executionId,  # Use executionId as workflow_id for single agent
            Authorization=self.Authorization,
            nemo_guardrails=self.payload_object.nemo_guardrails,  # Pass the NeMo guardrails flag,
            rag_enable=self.payload_object.rag_enable,  # Whether to enable RAG
            rag_mode=self.payload_object.rag_mode,  # RAG mode: STRICT or HYBRID
            tool_tokens=self.tool_tokens  # HP_OBO
        )
        agent_creator = AgentCreator(setup_config=creator_config)
        agent, task, guardrails_failed_message = await agent_creator.create_agent_and_task()
        print(f"guardrails_failed_message is {guardrails_failed_message}")

        # Handle guardrail failures
        if guardrails_failed_message:
            return str(guardrails_failed_message), "Not applicable"

        event_listener.metadata_hash[str(agent.id)] = creator_config
        event_listener.metadata_hash[str(task.id)] = creator_config

        if langfuse_client:
            with langfuse_client.start_as_current_span(
                    name=f"agent-creation-{agent_data.agent.id}") as span:  # why the span is getting created again, as already in the context?
                span.update_trace(
                    metadata={
                        "agent_role": agent_data.agent.role,
                        "agent_goal": agent_data.agent.goal
                    }
                )
                span.update_trace(
                    output={"agent_created": True,
                            "tools_count": len(getattr(agent, "tools", []))
                            }
                )

        execution_output = task.execute_sync()

        if langfuse_client:
            with langfuse_client.start_as_current_span(name="crew-agent-execution") as span:
                # Attach trace-level metadata
                span.update_trace(
                    user_id=self.payload_object.user,
                    session_id=self.payload_object.executionId,
                    tags=["agent"],
                    metadata={**self._prepare_trace_metadata()}
                )

                span.update_trace(output={"result": str(execution_output)})

        # folder_path = os.path.join(os.getcwd(), self.payload_object.executionId)
        # file_id = await self.file_uploader(folder_path) TODO

        file_id = None
        PipelineAILogs().publishLogs(
            "Pipeline Completed", "green", redisClient=redis_client
        )
        has_file_writer = any(
            isinstance(tool, FileWriterTool) for tool in getattr(agent, "tools", [])
        )

        return execution_output, (file_id if has_file_writer else "Not applicable")

    async def _execute_core_agent_with_files(
            self, files: list[UploadFile]
    ) -> tuple[Any, Any]:
        try:
            unzipped_files_path = await self._prepare_and_unzip_files(files)
            self.logger.info(f"Files prepared and unzipped at: {unzipped_files_path}")
            langfuse_client = setup_langfuse_client(self.payload_object)
            logger.debug(
                "LangFuse config setup completed in _execute_core_agent_with_files."
            )
            # Assuming CrewLogicExecutor handles its own detailed exceptions
            # executor = CrewLogicExecutor(self.payload_object, langfuse_client, self.Authorization, unzipped_files_path)
            # agent_response = await executor.execute(langfuse_client)
            agent_response = await self.execute_task(
                langfuse_client, unzipped_files_path
            )
            logger.debug("Core agent execution finished.")
            return agent_response
        except HTTPException:
            # Re-raise HTTPException to be caught by the calling run_with_files method
            raise
        except Exception as e:
            error_message = str(e)
            # Check if it's a guardrail validation error
            if "guardrail" in error_message.lower():
                specific_message = error_message.split("Last error:")[
                    -1].strip() if "Last error:" in error_message else "Response blocked by content policy"
                logger.warning(f"Guardrail blocked response: {error_message}")
                # Return a safe, user-friendly response instead of raising an error
                guardrails_response = TaskOutput(
                    description="Response blocked by content policy",
                    summary="The generated response was blocked by our content safety filters. Please rephrase your question or try a different approach.",
                    raw=str(specific_message),
                    pydantic=None,
                    json_dict=None,
                    output_format="raw",
                    agent="safety_agent"
                )
                logger.info("Returning safe fallback response due to guardrail block")
                return (guardrails_response, "Not applicable")

            # If it's not a guardrail error, raise as normal
            logger.error(f"Error in _execute_core_agent_with_files: {e}")
            raise AgentExecutionError(
                status_code=500, detail=f"Core agent execution failed: {e}"
            )

    async def _execute_core_agent(self) -> tuple[Any, Any]:
        """Executes the main agent logic using CrewLogicExecutor."""
        if not self.payload_object:
            raise AgentExecutionError(
                status_code=500,
                detail="Payload object not initialized before core execution.",
            )

        try:
            langfuse_client = setup_langfuse_client(self.payload_object)
            logger.debug("LangFuse config setup completed in _execute_core_agent.")
            # Assuming CrewLogicExecutor handles its own detailed exceptions
            # executor = CrewLogicExecutor(self.payload_object, langfuse_client, self.Authorization)
            # agent_response = await executor.execute()
            agent_response = await self.execute_task(langfuse_client)
            print(f"agent response is {agent_response}")
            logger.debug("Core agent execution finished.")
            return agent_response
        except OutputParserException as e:
            logger.error(f"Output parser error during core execution: {e}")
            raise AgentExecutionError(
                status_code=400, detail=f"Output parser error: {e}"
            )
        except HTTPException as e:
            raise e
        except Exception as e:
            error_message = str(e)
            # Check if it's a guardrail validation error
            if "guardrail validation" in error_message.lower() or "guardrail blocked" in error_message.lower():
                specific_message = error_message.split("Last error:")[
                    -1].strip() if "Last error:" in error_message else "Response blocked by content policy"
                logger.warning(f"Guardrail blocked response: {error_message}")
                # Return a safe, user-friendly response instead of raising an error
                guardrails_response = TaskOutput(
                    description="Response blocked by content policy",
                    summary="The generated response was blocked by our content safety filters. Please rephrase your question or try a different approach.",
                    raw=str(specific_message),
                    pydantic=None,
                    json_dict=None,
                    output_format="raw",
                    agent="safety_agent"
                )
                logger.info("Returning safe fallback response due to guardrail block")
                return (guardrails_response, "Not applicable")

            # If it's not a guardrail error, raise as normal
            logger.error(f"Error in _execute_core_agent: {e}")
            raise AgentExecutionError(
                status_code=500, detail=f"Core agent execution failed: {e}"
            )

    def _get_kb_context(self):

        agent_data = self.payload_object.pipeLineAgents[0]
        agent_detail = agent_data.agent
        context_data = {}
        if hasattr(agent_detail, 'embedding') and agent_detail.embedding:
            context_data = get_kb_details(agent_detail.embedding)

        return context_data

    def try_parse_json(self, mixed_str):
        """
        Attempts to extract JSON from a string that may contain extra text.
        Returns a dict if successful, otherwise returns original string.
        """
        match = re.search(r'\{.*\}', mixed_str, re.DOTALL)
        if match:
            json_str = match.group(0)
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                return mixed_str
        return mixed_str

    def _remove_sensitive_keys(self, final_response_payload: dict[str, Any]) -> dict[str, Any]:
        """
        Remove sensitive attributes from the response data to prevent exposure.

        Args:
            final_response_payload (dict): The response payload to clean

        Returns:
            dict: Cleaned response payload with sensitive data removed
        """
        try:
            # Remove sensitive fields
            final_response_payload.pop("langfuse", None)
            final_response_payload.pop("managerLlm", None)
            final_response_payload.pop("masterEmbedding", None)

            for agent in (final_response_payload.get("pipeLineAgents") or []):
                agent_data = agent.get("agent") or {}
                agent_data.pop("llm", None)
                agent_data.pop("embedding", None)

            return final_response_payload

        except Exception as e:
            logger.warning(f"Error removing sensitive keys from response: {e}")
            # Return the original payload if cleaning fails to avoid breaking the response
            return final_response_payload

    def _process_response(self, Agent_response: tuple[Any, Any]) -> dict[str, Any]:
        """Processes the agent response and formats the final output."""
        if not self.payload_object:
            raise AgentExecutionError(
                status_code=500,
                detail="Payload object not available for response processing.",
            )

        try:
            # Extract data from the assumed response structure
            response_data = Agent_response[0]
            print(f"Response data at line 625 is:{response_data}")
            file_id = Agent_response[1]  # Can be "Not applicable", None, or an ID string

            # Update payload object with results
            # Use getattr for safer access in case attributes are missing
            self.payload_object.tasksOutputs = response_data if response_data else None

            # --- START OF SURGICAL FIX ---
            # If response_data is a plain string (from Guardrail fail), assign directly to output.
            # If it is a TaskOutput object (Successful run), access the .raw property.
            if isinstance(response_data, str):
                self.payload_object.output = response_data
            else:
                self.payload_object.output = getattr(response_data, "raw", None)
            # --- END OF SURGICAL FIX ---

            # Create the base response dictionary from the updated payload object
            final_response_payload = self.payload_object.model_dump()
            print(f"final response payload at line 635 is:{final_response_payload}")

            # Add file download URL if a valid file_id is present
            if file_id and file_id != "Not applicable":
                final_response_payload[
                    "file_download_url"] = f"{settings.BASE_URL}/{settings.ADMIN_DOWNLOAD_URL}/{file_id}"
            else:
                # Ensure the key is not present if there's no valid file ID
                final_response_payload.pop("file_download_url", None)

            final_response_payload['context'] = self._get_kb_context()

            output_str = final_response_payload.get("output", "")
            if output_str:
                try:
                    final_response_payload["output"] = self.try_parse_json(output_str)
                except Exception as e:
                    logging.warning("Failed to parse output string to JSON: %s", e)

            tasks = final_response_payload.get("tasksOutputs", {})
            # Handling a case where guardrails failed and returned a plain string
            if isinstance(tasks, str):
                logger.warning("Guardrails returned string output; normalizing tasksOutputs.")
                final_response_payload["tasksOutputs"] = {"raw": tasks}
                raw_str = tasks
            else:
                raw_str = tasks.get("raw")

            if raw_str:
                try:
                    final_response_payload["tasksOutputs"]["raw"] = self.try_parse_json(raw_str)
                except Exception as e:
                    logging.warning("Failed to parse output string to JSON: %s", e)

            logger.debug(
                f"Final response payload prepared for execution: {self.agent_request.executionId}"
            )
            print(f"final response payload at line 671 is:{final_response_payload}")
            # Optional: Call save_final_workflow_history here if needed
            # save_final_workflow_history(...)

            return {"agent": self._remove_sensitive_keys(final_response_payload)}

        except AttributeError as e:
            logger.error(f"Error accessing attributes in agent response: {e}")
            raise AgentExecutionError(
                status_code=500, detail=f"Invalid agent response structure: {e}"
            )
        except Exception as e:
            logger.error(f"Error processing agent response: {e}")
            raise AgentExecutionError(
                status_code=500, detail=f"Failed to process agent response: {e}"
            )

    def _cleanup(self):
        """Cleans up resources like temporary images."""
        if self.temporary_images:
            try:
                agent_image_utils.clean_up_images(self.temporary_images)
                logger.debug("Temporary image cleanup successful.")
                self.temporary_images = None  # Clear the list after cleanup
            except Exception as e:
                # Log error but don't raise, cleanup failure might not be critical
                logger.error(f"Error during temporary image cleanup: {e}")

        # Ignore errors if folder doesn't exist
        try:
            folder_path = os.path.join(os.getcwd(), self.agent_request.executionId)
            if os.path.exists(folder_path):
                logger.info(f"Deleting subfolder: {folder_path}")
                shutil.rmtree(
                    folder_path, ignore_errors=False, onerror=self.remove_readonly
                )
        except Exception as e:
            logger.error(f"Error Deleting generated file: {e}")

    async def run(self) -> dict[str, Any]:
        """Orchestrates the agent execution steps."""
        try:
            self._prepare_payload()
            # Ensure payload object exists before proceeding
            if not self.payload_object:
                raise AgentExecutionError(
                    status_code=500, detail="Payload preparation failed silently."
                )
            agent_response = await self._execute_core_agent()
            print(f"Agent response at line no 718 is = {agent_response}")
            final_result = self._process_response(agent_response)
            print(f"final result at line no 720 is = {final_result}")
            # Send success status
            # send_execution_status(
            #     self.agent_request.executionId, "SUCCESS", self.Authorization
            # )
            return final_result
        except (AgentExecutionError, HTTPException) as e:
            status_code = (
                e.status_code if isinstance(e, HTTPException) else e.status_code
            )
            detail = e.detail if isinstance(e, HTTPException) else e.detail
            logger.error(
                f"Agent execution failed: {detail} (Status Code: {status_code})"
            )
            # Publish logs if enabled
            if self.log_stream_enabled or self.persistent_logging_enabled:
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: {detail}",
                    "red",
                    redisClient=self.redis_client,
                )
            # Send failure status
            # send_execution_status(
            #     self.agent_request.executionId, "FAILED", self.Authorization
            # )
            # Re-raise as HTTPException for FastAPI
            raise HTTPException(status_code=status_code, detail=detail)
        except Exception as e:
            # Catch any other unexpected errors
            logger.error(
                f"Unexpected error during agent execution: {e}", exc_info=True
            )  # Log traceback
            if self.log_stream_enabled or self.persistent_logging_enabled:
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: Unexpected error - {str(e)}",
                    "red",
                    redisClient=self.redis_client,
                )
            # Send failure status
            # send_execution_status(
            #     self.agent_request.executionId, "FAILED", self.Authorization
            # )
            raise HTTPException(
                status_code=500, detail=f"An unexpected error occurred: {str(e)}"
            )
        finally:
            # Cleanup is crucial, ensure it runs even if errors occur during execution
            self._cleanup()

    async def run_file(self) -> dict[str, Any]:
        """Orchestrates the agent execution steps."""
        try:
            self._prepare_payload()
            # Ensure payload object exists before proceeding
            if not self.payload_object:
                raise AgentExecutionError(
                    status_code=500, detail="Payload preparation failed silently."
                )
            agent_response = await self._execute_core_agent_with_files(files=self.files)
            final_result = self._process_response(agent_response)
            # Send success status
            # send_execution_status(
            #     self.agent_request.executionId, "SUCCESS", self.Authorization
            # )
            return final_result
        except (AgentExecutionError, HTTPException) as e:
            status_code = (
                e.status_code if isinstance(e, HTTPException) else e.status_code
            )
            detail = e.detail if isinstance(e, HTTPException) else e.detail
            logger.error(
                f"Agent execution failed: {detail} (Status Code: {status_code})"
            )
            # Publish logs if enabled
            if self.log_stream_enabled or self.persistent_logging_enabled:
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: {detail}",
                    "red",
                    redisClient=self.redis_client,
                )
            # Send failure status
            # send_execution_status(
            #     self.agent_request.executionId, "FAILED", self.Authorization
            # )
            # Re-raise as HTTPException for FastAPI
            raise HTTPException(status_code=status_code, detail=detail)
        except Exception as e:
            # Catch any other unexpected errors
            logger.error(
                f"Unexpected error during agent execution: {e}", exc_info=True
            )  # Log traceback
            if self.log_stream_enabled or self.persistent_logging_enabled:
                PipelineAILogs().publishLogs(
                    f"AAVA Agent Exception: Unexpected error - {str(e)}",
                    "red",
                    redisClient=self.redis_client,
                )
            # Send failure status
            # send_execution_status(
            #     self.agent_request.executionId, "FAILED", self.Authorization
            # )
            raise HTTPException(
                status_code=500, detail=f"An unexpected error occurred: {str(e)}"
            )
        finally:
            # Cleanup is crucial, ensure it runs even if errors occur during execution
            self._cleanup()


async def execute(Authorization: str, agentRequest: AgentRequest | None = None):
    """
        Note: agentRequest should be the last argument for the insights decorator to pick it.
    """
    if agentRequest is None:
        # Ensure agentRequest is provided
        raise HTTPException(status_code=400, detail="agentRequest is required.")

    # Instantiate the executor and run the agent
    executor = AgentExecutor(Authorization=Authorization, agent_request=agentRequest)
    result = await executor.run()
    return result


async def execute_files(
        Authorization: str, files: list[UploadFile], agentRequest: AgentRequest | None = None
):
    """
        Note: agentRequest should be the last argument for the insights decorator to pick it.
    """
    if agentRequest is None:
        raise HTTPException(status_code=400, detail="agentRequest is required.")
    executor = AgentExecutor(
        Authorization=Authorization, agent_request=agentRequest, files=files
    )
    result = await executor.run_file()
    return result


class AgentQueryExecutor:
    def __init__(self, request, Authorization, validator):
        self.request = request
        self.Authorization = Authorization
        self.validator = validator

    async def execute_query(self):
        agent_config = convert_payload(self.request, self.Authorization, self.validator)
        # Create agent and task using AgentCreator
        agent_creator = AgentCreator(agent_config)
        agent, task, guardrails_failed_message = await agent_creator.create_agent_and_task()

        if guardrails_failed_message:
            return str(guardrails_failed_message)

        # Register metadata in EventListener
        event_listener.metadata_hash[str(agent.id)] = agent_config
        event_listener.metadata_hash[str(task.id)] = agent_config

        result = task.execute_sync()
        return result