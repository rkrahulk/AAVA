import json
import logging
from app.core.config import settings
from typing import Dict, List, Optional, Callable, Any
from kafka import KafkaProducer, KafkaConsumer
from kafka.errors import KafkaError


logger = logging.getLogger('kafka.client')
class KafkaClient:
    """
    A simple Kafka client that can both produce and consume messages.
    """
    
    def __init__(self, bootstrap_servers: str=None, **config):
        self.bootstrap_servers = bootstrap_servers
        self.config = config
        self.producer = None
        self.consumer = None
        self.logger = logging.getLogger(__name__)

    def _create_producer(self) -> KafkaProducer:
        """Create and return a Kafka producer."""
        if not self.producer:
            producer_config = {
                'bootstrap_servers': self.bootstrap_servers,
                'value_serializer': lambda x: json.dumps(x).encode('utf-8'),
                'key_serializer': lambda x: x.encode('utf-8') if x else None,
                **self.config
            }
            self.producer = KafkaProducer(**producer_config)
        return self.producer
    
    def _create_consumer(self, topics: List[str], group_id: str = "agent-consumer-group") -> KafkaConsumer:
        """Create and return a Kafka consumer."""
        consumer_config = {
            'bootstrap_servers': self.bootstrap_servers,
            'group_id': group_id,
            'value_deserializer': lambda x: json.loads(x.decode('utf-8')),
            'key_deserializer': lambda x: x.decode('utf-8') if x else None,
            'auto_offset_reset': 'earliest',
            **self.config
        }
        return KafkaConsumer(*topics, **consumer_config)
    
    def produce(self, topic: str, message: Dict[str, Any], key: Optional[str] = None) -> bool:
        try:
            producer = self._create_producer()
            
            # Send message
            future = producer.send(topic, value=message, key=key)
            
            # For testing
            record_metadata = future.get(timeout=10)
            
            self.logger.info(f"Message sent to {record_metadata.topic} "
                           f"partition {record_metadata.partition} "
                           f"offset {record_metadata.offset}")
            return True
            
        except KafkaError as e:
            self.logger.error(f"Failed to send message: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
            return False
    
    def consume(self, topics: List[str], 
                group_id: str = "agent-consumer-group"):
        messages = []
        pass
    
    
    def close(self):
        """Close producer and consumer connections."""
        if self.producer:
            self.producer.close()
            self.logger.info("Producer closed")
            
        if self.consumer:
            self.consumer.close()
            self.logger.info("Consumer closed")


# Extract Kafka configuration from settings
bootstrap_servers = settings.bootstrap_server
security_protocol = settings.security_protocol
sasl_mechanism = settings.sasl_mechanism
sasl_plain_username = settings.sasl_plain_username
sasl_plain_password = settings.sasl_plain_password

# Base Kafka config (always required)
kafka_config = {
    "bootstrap_servers": bootstrap_servers,
    "acks": "all",
    "retries": 5,
    "request_timeout_ms": 30000,
    "linger_ms": 100,
}

# Conditionally add SASL settings only when needed
if "SASL" in security_protocol.upper():
    kafka_config.update({
        "security_protocol": security_protocol,
        "sasl_mechanism": sasl_mechanism,
        "sasl_plain_username": sasl_plain_username,
        "sasl_plain_password": sasl_plain_password,
    })


# Initialize Kafka client
kafka_client_ = KafkaClient(**kafka_config)


def serialize_for_json(obj):
    if isinstance(obj, dict):
        return {k: serialize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [serialize_for_json(i) for i in obj]
    elif hasattr(obj, '__dict__'):
        return serialize_for_json(obj.__dict__)
    elif isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    else:
        # fallback: convert to string
        return str(obj)


def push_logs_to_kafka(message: dict):
    """
    Wrapper to push logs to Kafka based on workflow_id and env flags.
    Only pushes if KAFKA_WORKFLOW_ENABLE or KAFKA_AGENT_ENABLE is True.
    """
    agent_id = message.get("agent_id")
    agent_enabled = settings.to_bool("kafka_agent_enabled")
    topic = settings.agent_topic

    sanitized_message = serialize_for_json(message)

    if agent_id and agent_enabled:
        logger.info(f"Pushing agent log to Kafka topic {topic}: {agent_id}")
        kafka_client_.produce(topic=topic, message=sanitized_message)
    else:
        # Do not push to Kafka
        logger.info(f"Kafka logging is disabled or missing identifiers. KAFKA_AGENT_ENABLE: {agent_enabled}")