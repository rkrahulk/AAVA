import logging

from fastapi import HTTPException
# from app.core.application_insights import track_event

logger = logging.getLogger(__name__)


async def health_check():
    logger.debug(
        "Logger enabled for ERROR= %s, WARNING= %s, NFO= %s, DEBUG= %s",
        logger.isEnabledFor(logging.ERROR),
        logger.isEnabledFor(logging.WARNING),
        logger.isEnabledFor(logging.INFO),
        logger.isEnabledFor(logging.DEBUG),
    )
    #     # Track health check event
    # track_event("Health_Check_Performed", {
    #     "service": "aava-pipeline-service",
    #     "status": "healthy"
    # })
    return {"status": "healthy"}


async def health_check_endpoint():

    try:
        return await health_check()
    except Exception as e:
        logger.error(f"Unexpected error in health check: {e}")
        raise HTTPException(
            status_code=500, detail=f"Internal server error during health check: {e}"
        )
