import chromadb
from typing import Dict, List
import pymongo
from app.core.config import settings
import logging
logger = logging.getLogger(__name__)



def get_mongodb_obj():
    if settings.MONGODB_USERNAME not in settings.MONGODB_URI:
        username = quote_plus(settings.MONGODB_USERNAME)
        password = quote_plus(settings.MONGODB_PASSWORD)
        mongo_uri = settings.MONGODB_URI.replace(
            "mongodb+srv://",
            f"mongodb+srv://{username}:{password}@"
        )
    else:
        mongo_uri = settings.MONGODB_URI
    client = pymongo.MongoClient(mongo_uri)
    return client[settings.MONGODB_DATABASE]


def retrieve_metadata(collection_name):
    db = get_mongodb_obj()
    collection = db[collection_name]
    cursor = collection.find(
        {}, 
        { 
            "_id": 0, 
            "metadata": 1 
        }
    )
    return cursor



def get_kb_details(embedding: List) -> Dict[str, Dict]:

    all_collections_details = {}
    
    if not embedding:
        return {}
    
    for emb_config in embedding:
        try:
            collection_name = getattr(emb_config, 'index_collection', None)
            if not collection_name:
                continue
            cursor = retrieve_metadata(collection_name)

            # Collect all metadata keys and sample values
            metadata_summary = list()
            for doc in cursor:
                metadata = doc.get("metadata", {}).copy()
                metadata.pop("_node_type", None)
                metadata.pop("_node_content", None)
                metadata_summary.append(metadata)
            
            # Convert sets to sorted lists (NO LIMIT)
            all_collections_details[collection_name] = metadata_summary
            
        except Exception as e:
            logger.error(f"Error getting KB details: {str(e)}")
            continue
    
    return all_collections_details



def get_kb_filenames(embedding: List) -> List[str]:
    """Get all unique filenames from knowledge base collections."""
    all_filenames = set()
    
    if not embedding:
        return []
    
    for emb_config in embedding:
        try:
            collection_name = getattr(emb_config, 'index_collection', None)
            if not collection_name:
                continue
            cursor = retrieve_metadata(collection_name)
            
            # Extract file_name from metadata
            for doc in cursor:
                metadata = doc.get("metadata", {})
                if metadata and 'file_name' in metadata:
                    all_filenames.add(metadata['file_name'])

            logger.debug(f"File names found from all KBs {all_filenames}")   
        except Exception as e:
            print(f"Error: {str(e)}")
            continue
    
    return sorted(list(all_filenames))