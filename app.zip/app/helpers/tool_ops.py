import logging

from fastapi import HTTPException , status as http_status
from typing import Optional, List

logger = logging.getLogger(__name__)


def initialize_user_tool(class_name, class_definition):
    try:
        local_namespace = {}
        exec(class_definition, local_namespace)
        tool_instance = local_namespace[class_name]()
        return tool_instance
    except Exception as e:
        logger.error(f"Error while initializing the user tool: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error initializing the user tool, there's an error in the tool code: {str(e)}",
        )


def add_dynamic_user_tools(class_name, class_definition):
    try:
        # Execute the class definition
        exec(class_definition, globals())
        # Instantiate the class
        tool_instance = globals()[class_name]()
        # Append the tool instance to the agent's tools
        logger.info(f"Dynamic user tool '{class_name}' added successfully.")
        return tool_instance
    except Exception as e:
        logger.error(f"Error adding dynamic user tool: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error adding dynamic user tool, there's an error in the tool code: {str(e)}",
        )

# ================================================= HP OBO hanges Begin ======================================================================
def create_user_tool_with_oauth(
    class_name: str,
    class_definition: str,
    access_token: str,
    cloud_id: Optional[str],
    provider_name: str,
    meta: Optional[List[dict]] = None
):
    """
    Create user tool with OAuth token and cloudId injection.
    Used only when CLIENT_NAME=HP.
    
    Args:
        class_name: Tool class name
        class_definition: Python code defining the tool class
        access_token: OAuth bearer token
        cloud_id: Cloud ID (for Jira/Atlassian, None for others)
        provider_name: Provider name (for logging)
    
    Returns:
        Instantiated tool with access_token and cloud_id injected
    """
    try:
        from crewai.tools import BaseTool
        from pydantic import BaseModel, Field
        from typing import Type
        import requests
        
        local_namespace = {
            'BaseTool': BaseTool,
            'BaseModel': BaseModel,
            'Field': Field,
            'Type': Type,
            'requests': requests
        }
        
        # Execute the class definition
        exec(class_definition, local_namespace)
        
        # Get the tool class
        tool_class = local_namespace.get(class_name)
        
        if not tool_class:
            raise ValueError(f"Tool class '{class_name}' not found in definition")
        
        # Try different injection strategies
        tool_instance = None
        
        # Strategy 1: Try passing both access_token and cloud_id in __init__
        try:
            if cloud_id:
                tool_instance = tool_class(access_token=access_token, cloud_id=cloud_id, meta=meta)
                logger.info(
                    f"Created tool '{class_name}' with {provider_name} token + cloudId "
                    f"(via __init__)"
                )
            else:
                tool_instance = tool_class(access_token=access_token,meta=meta)
                logger.info(
                    f"Created tool '{class_name}' with {provider_name} token "
                    f"(via __init__)"
                )
        except TypeError:
            # Strategy 2: Tool doesn't accept parameters, set as attributes
            tool_instance = tool_class()
            tool_instance.access_token = access_token
            if cloud_id:
                tool_instance.cloud_id = cloud_id
            if meta:
                tool_instance.meta = meta
            
        # ==================== DEBUG LOGS AFTER INJECTION ====================
        logger.debug("=" * 80)
        logger.debug(f"[AFTER INJECTION] {class_name} Instance")
        logger.debug("=" * 80)
        
        logger.debug(f"Instance of: {tool_class.__name__}")
        logger.debug("")
        logger.debug("Injected OAuth Credentials:")
        
        if hasattr(tool_instance, 'access_token'):
            token = tool_instance.access_token
            token_display = f"{token[:15]}...{token[-10:]}" if len(token) > 30 else token
            logger.debug(f"   access_token: '{token_display}'")
        else:
            logger.debug(f"  access_token: NOT FOUND")
        
        if hasattr(tool_instance, 'cloud_id'):
            logger.debug(f"  cloud_id: '{tool_instance.cloud_id}'")
        else:
            logger.debug(f"   cloud_id: NOT FOUND")
        
        logger.debug("")
        logger.debug("Tool Instance State:")
        logger.debug(f"  - name: {getattr(tool_instance, 'name', 'N/A')}")
        logger.debug(f"  - description: {getattr(tool_instance, 'description', 'N/A')}")
        
        logger.debug("")
        logger.debug("Complete Instance Attributes:")
        if hasattr(tool_instance, '__dict__'):
            for key, value in sorted(tool_instance.__dict__.items()):
                if key == 'access_token' and isinstance(value, str) and len(value) > 30:
                    value = f"{value[:15]}...{value[-10:]}"
                logger.debug(f"  - {key}: {repr(value)}")
        
        logger.debug("How _run will access credentials:")
        logger.debug("  Inside _run method:")
        logger.debug(f"    self.access_token = '{tool_instance.access_token[:15]}...'")
        if hasattr(tool_instance, 'cloud_id'):
            logger.debug(f"self.cloud_id = '{tool_instance.cloud_id}'")
        logger.debug("=" * 80)
        logger.debug(
            f"Created tool '{class_name}' with {provider_name} token + cloudId "
            f"(via attributes)"
        )
        
        return tool_instance
        
    except Exception as e:
        logger.error(f"Error creating OAuth tool '{class_name}': {str(e)}")
        raise HTTPException(
            status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating OAuth tool: {str(e)}"
        )
# ================================================= HP OBO hanges End ======================================================================