import logging
import mimetypes
import os
import zipfile
from pathlib import Path

import requests

from app.core.config import settings

logger = logging.getLogger(__name__)

CONTENT_TYPE_MAPPING = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt": "application/vnd.ms-powerpoint",
}


def get_headers(Authorization):
    return {"Content-Type": "application/json", "Authorization": Authorization}


def zip_and_upload_folder(pipelineId, executionId, user, folder_path, Authorization):

    if not os.path.exists(folder_path):

        return ""
    # upload_url = f"{settings.BASE_URL}/ava/force/workflow/history/upload-file"
    upload_url = settings.BASE_URL + settings.ADMIN_UPLOAD_URL

    zip_filename = f"{executionId}.zip"

    try:
        # Create a zip file containing the folder contents
        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, folder_path)
                    zipf.write(file_path, arcname)

        # Define the file and form data
        with open(f"{zip_filename}", "rb") as file:

            files = {"file": (f"{zip_filename}", file, "application/zip")}

            data = {
                "executionId": str(executionId),
                "pipelineId": str(pipelineId),
                "user": str(user),
            }

            headers = {"Authorization": str(Authorization)}

            # Upload the zip file to the endpoint
            response = requests.post(
                upload_url, files=files, data=data, headers=headers
            )

        # Check if the request was successful
        if response.status_code == 201:
            file_id = response.json()
            return str(file_id)
        else:
            raise Exception(
                f"File Upload failed with status code: {response.status_code}, reason: {response.reason}"
            )

    except Exception as e:
        logger.error(f"Exception while trying to create zip file : {e}")
        return None

    finally:
        # Clean up the temporary zip file
        if os.path.exists(zip_filename):
            os.remove(zip_filename)


def get_content_type(filename: str) -> str:
    # Method 1: Use mimetypes library
    detected_type = mimetypes.guess_type(filename)[0]
    if detected_type:
        return detected_type

    # Method 2: Use custom mapping
    file_ext = Path(filename).suffix.lower()
    if file_ext in CONTENT_TYPE_MAPPING:
        return CONTENT_TYPE_MAPPING[file_ext]

    # Method 3: Use fallback or default
    return "application/octet-stream"
