import logging

import httpx
from fastapi import HTTPException

from app.core.config import settings

# from app.models.agentLLM import AgentLLM

adminurlagent = settings.BASE_URL + settings.ADMIN_URL_V2_AGENT
logger = logging.getLogger(__name__)


class AgentPayload:
    def __init__(self, agentId, Authorization):
        self.agentId = agentId
        self.Authorization = Authorization

    def fetch(self):

        if not self.Authorization:
            logger.error("Access key is required")
            raise HTTPException(status_code=400, detail="Access key is required")

        logger.debug("Authorization ---------------- %s", self.Authorization)
        logger.debug("agent id ----------------- %s", self.agentId)

        params = {"agentId": self.agentId}
        logger.debug("params is ----------------- %s", params)

        headers = {
            "Authorization": self.Authorization,
            "Content-Type": "application/json",
        }
        logger.debug("headers is ----------------- %s", headers)

        from app.core.config import settings

        timeout = httpx.Timeout(
            connect=int(settings.REQUEST_TIMEOUT),
            read=int(settings.REQUEST_TIMEOUT),
            write=int(settings.REQUEST_TIMEOUT),
            pool=int(settings.REQUEST_TIMEOUT),
        )
        logger.debug("timeout is ----------------- %s", timeout)

        try:

            logger.debug("adminUrl is ----------------- %s", adminurlagent)
            if adminurlagent == None:
                raise HTTPException(
                    status_code=400,
                    detail="Environment variable ADMIN_URL is not set. Please add value to the ADMIN_URL environment variable",
                )

            adminResponse = httpx.get(
                adminurlagent, params=params, headers=headers, timeout=timeout
            )
            adminResponse.raise_for_status()

        except httpx.HTTPStatusError as e:

            logger.error("Admin api status error ----------------- %s", str(e))
            raise HTTPException(status_code=adminResponse.status_code, detail=str(e))

        except httpx.RequestError as e:
            logger.error("Admin api request error ----------------- %s", str(e))
            raise HTTPException(status_code=500, detail=str(e))

        logger.info(
            "Admin agent payload response ----------------- %s", adminResponse.json()
        )

        agentJson = adminResponse.json()

        if "agentDetail" not in agentJson:
            logger.info("Agent details not found in the response")
            raise HTTPException(
                status_code=404, detail="Agent details not found in the response"
            )

        return agentJson
