import json
import logging
import os
import time

from redis.client import Redis

from app.models.PipelineLogs.RuntimeLogs import RuntimeLogs

logger = logging.getLogger(__name__)

from app.core.pg_client import postgres_client
# from app.core.application_insights import track_dependency

logger.info("Logs is starting up")


class PipelineAILogs:

    progress: str = "STARTED"
    executionId: str | None = None
    pipelineId: int | None = None
    sender: str | None = None

    def push_logs_to_database(self, execution_id, logs_json):
        if not postgres_client:
            return
        connection = postgres_client.get_connection()

        start_time = time.perf_counter()
        error_detail = None

        try:
            with connection.cursor() as cursor:
                sql = "INSERT INTO core.workflow_execution_logs (executionid, logs) VALUES (%s, %s)"
                cursor.execute(sql, (execution_id, logs_json))
            connection.commit()
            logger.info(
                f"Logs for execution ID {execution_id} successfully pushed to the database."
            )
        except Exception as e:
            connection.rollback()
            logger.info(f"Error pushing logs to database: {str(e)}")
            error_detail = str(e)

        finally:
            postgres_client.release_connection(conn=connection)
            logger.info("Released connection")
            duration_ms = (time.perf_counter() - start_time) * 1000
            properties = {
                "dependency_category": "database",
                "operation": "insert_logs",
                "table": "core.workflow_execution_logs",
            }
            if error_detail:
                properties["error"] = error_detail
            # track_dependency(
            #     name="PostgreSQL core.workflow_execution_logs",
            #     dependency_type="SQL",
            #     target=os.getenv("DB_URL", "postgres"),
            #     data="INSERT core.workflow_execution_logs",
            #     duration=duration_ms,
            #     success=error_detail is None,
            #     result_code="200" if error_detail is None else "EXCEPTION",
            #     properties=properties,
            # )

    def publishLogs(
        self, logs: str, color: str | None = None, redisClient: Redis = None
    ):

        try:
            logStream = os.getenv("ENABLE_LOGSTREAMING")
            persistent_logging = os.getenv("PERSISTENT_LOGGING")
            
            if redisClient:

                self.progress = "IN PROGRESS"
                if (
                    "AAVA Pipeline Logs Completed" in logs
                    or "AAVA Pipeline Exception:" in logs
                ):
                    self.progress = "FINISHED"
                elif color is not None and color == "red":
                    self.progress = "EXCEPTION"
                if logStream == "True":

                    log_entry = RuntimeLogs(
                        progress=self.progress,
                        content=logs,
                        color=color,
                        sender=self.sender,
                        executionId=self.executionId,
                    )

                    log_entry_json = json.dumps(log_entry.model_dump())

                    logger.info("---------------- Redis Publisher ---------------- ")
                    logger.info("Execution Id is ---------------- %s", self.executionId)
                    logger.info("Pipeline Id is ---------------- %s", self.pipelineId)
                    logger.info("Color is ---------------- %s", color)
                    logger.info("Content is ---------------- %s", logs)

                    try:

                        publish_start = time.perf_counter()
                        publish_error: Exception | None = None

                        try:
                            redisClient.publish(self.executionId, log_entry_json)
                        except Exception as e:  # noqa: BLE001
                            publish_error = e
                            raise
                        finally:
                            duration_ms = (time.perf_counter() - publish_start) * 1000
                            properties = {
                                "dependency_category": "cache",
                                "operation": "publish",
                                "channel": self.executionId,
                            }
                            if publish_error:
                                properties["error"] = str(publish_error)
                            # track_dependency(
                            #     name="Redis Publish",
                            #     dependency_type="Cache",
                            #     target=os.getenv("REDIS_HOST", "redis"),
                            #     data=f"channel:{self.executionId}",
                            #     duration=duration_ms,
                            #     success=publish_error is None,
                            #     result_code="200" if publish_error is None else "EXCEPTION",
                            #     properties=properties,
                            # )

                        logger.info(
                            "--------------Published the topic------------ %s",
                            log_entry_json,
                        )

                    except Exception as e:

                        logger.error(f"Could not connect to Redis:{e}")


            if persistent_logging == "True":

                log_entry = RuntimeLogs(
                    progress=self.progress,
                    content=logs,
                    color=color,
                    sender=self.sender,
                    executionId=self.executionId,
                )

                log_entry_json = json.dumps(log_entry.model_dump())

                try:

                    self.push_logs_to_database(self.executionId, log_entry_json)

                    logger.info(
                        "--------------Published the topic------------ %s",
                        log_entry_json,
                    )

                except Exception as e:

                    logger.error(f"Could not connect to PostGres:{e}")

        except Exception as e:
            logger.error(f"Error in publishLogs: {str(e)}")
