import logging
import os
import boto3
import certifi
from botocore.exceptions import NoCredentialsError
from app.core.config import settings
from fastapi import HTTPException
import pymongo
from langchain_mongodb import MongoDBAtlasVectorSearch

logger = logging.getLogger(__name__)
USE_BEDROCK_CREDENTIALS = settings.USE_BEDROCK_CREDENTIALS


class MongoDBService:
    """Singleton MongoDB vector adapter supporting both Legacy and Boto3 IAM Auth."""

    _client: pymongo.MongoClient | None = None  # Singleton Mongo client

    def __init__(self):
        self.logger = logger

    def _assume_role_credentials(self, role_arn: str, region: str, session_name: str = "aava-mongodb-vector"):
        """Assume AWS role and return temporary credentials."""
        try:
            if "AWS_PROFILE" in os.environ:
                os.environ.pop("AWS_PROFILE", None)

            session = boto3.Session(profile_name=None, region_name=region)
            sts = session.client("sts")

            identity = sts.get_caller_identity()
            logger.info(
                "Caller Identity - Account: %s, ARN: %s, UserId: %s",
                identity.get("Account"),
                identity.get("Arn"),
                identity.get("UserId"),
            )

            response = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName=session_name,
                DurationSeconds=3600,
            )

            logger.info("Successfully assumed role %s", role_arn)
            return response["Credentials"]

        except NoCredentialsError as e:
            logger.error("No AWS credentials available to assume role: %s", str(e))
            raise

        except Exception as e:
            self.logger.error(f"Unable to assume role: {str(e)}")
            raise HTTPException(detail=str(e), status_code=500)

    def connect(self, agentEmbedding) -> pymongo.MongoClient:
        """
        Singleton MongoDB connection.
        """

        # 🔹 Return existing client if already created
        if MongoDBService._client is not None:
            logger.info("Reusing existing MongoDB client (singleton).")
            return MongoDBService._client

        try:
            mongodb_uri = settings.MONGODB_URI

            if not settings.to_bool("MONGO_IAM_AUTH_ENABLED"):
                self.logger.info("Standard/Legacy Auth detected.")

                mongo_uri = mongodb_uri.replace(
                    "mongodb+srv://",
                    f"mongodb+srv://{settings.MONGODB_USERNAME}:{settings.MONGODB_PASSWORD}@"
                ) if settings.MONGODB_USERNAME not in mongodb_uri else mongodb_uri

                logger.info("MongoDB URI prepared.")

                MongoDBService._client = pymongo.MongoClient(mongo_uri)

            else:
                logger.info("IAM Auth detected for MongoDB.")
                logger.info("USE_BEDROCK_CREDENTIALS=%s", USE_BEDROCK_CREDENTIALS)

                if USE_BEDROCK_CREDENTIALS.lower() == "false":

                    role_arn = settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT
                    region = agentEmbedding.embedding_aws_region or settings.AWS_REGION

                    creds = self._assume_role_credentials(
                        role_arn=role_arn,
                        region=region,
                        session_name="aava-mongodb-vector",
                    )

                    MongoDBService._client = pymongo.MongoClient(
                        mongodb_uri,
                        authMechanism="MONGODB-AWS",
                        username=creds["AccessKeyId"],
                        password=creds["SecretAccessKey"],
                        authMechanismProperties={
                            "AWS_SESSION_TOKEN": creds["SessionToken"]
                        },
                        tls=True,
                        tlsCAFile=certifi.where(),
                        retryWrites=True,
                        serverSelectionTimeoutMS=300000
                    )

                else:
                    MongoDBService._client = pymongo.MongoClient(
                        mongodb_uri,
                        authMechanism="MONGODB-AWS",
                        username=agentEmbedding.embedding_aws_key,
                        password=agentEmbedding.embedding_aws_secret_key,
                        tls=True,
                        tlsCAFile=certifi.where(),
                        retryWrites=True,
                        serverSelectionTimeoutMS=300000
                    )

            logger.info("MongoDB client initialized (singleton).")

            return MongoDBService._client

        except Exception as e:
            self.logger.error(f"Failed to connect to MongoDB: {str(e)}")
            raise HTTPException(detail=str(e), status_code=500)

    def initialize_store(self, agentEmbedding, embedding_fn) -> MongoDBAtlasVectorSearch:
        """Initialize MongoDB vector store."""
        try:
            client = self.connect(agentEmbedding)

            mongo_collection = client[settings.MONGODB_DATABASE][agentEmbedding.index_collection]

            store = MongoDBAtlasVectorSearch(
                collection=mongo_collection,
                embedding=embedding_fn,
                index_name=settings.MONGODB_INDEX,
            )

            logger.info("MongoDB vector store initialized.")

            return store, client

        except Exception as e:
            self.logger.error(f"MongoDB initialization error: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))