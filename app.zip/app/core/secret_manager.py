"""
Secret manager singleton for pipeline-core microservice.

Implements a singleton pattern for managing secrets (e.g., access keys) within the service.
"""


class SecretManager:
    """
    Singleton secret manager for storing and accessing secrets.

    Ensures only one instance is created per process.
    Use the Authorization attribute to store/retrieve the current access key.
    """

    _instance = None

    def __new__(cls):
        # Singleton pattern: only one instance per process
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            # Attribute to store the access key or other secrets
            cls._instance.Authorization = ""
        return cls._instance

    def __init__(self):
        pass


# Global singleton instance for use throughout the service
secret_manager = SecretManager()
