"""
core package for pipeline-core microservice.

This package contains configuration, logging, database, and utility modules for the pipeline-core service.
"""
