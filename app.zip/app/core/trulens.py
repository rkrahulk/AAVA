from fastapi import HTTPException
import logging
import requests
from app.core.config import settings


logger = logging.getLogger(__name__)

class Trulens:

    def __init__(
            self,
            agent_config: dict,
            input: str,
            output: str, 
            context: list
        ):
        try:
            self.agent_config = agent_config
            self.output = output
            self.input = input
            self.context = context
            self.agent_data = self.agent_config.agent_details
        except Exception as e:
            logger.error(f"Failed in Trulens evaluator initialization: {str(e)}")

    def get_provider_config(self, llm_data):
        if "azure" in llm_data.get("model"):
            provider_config = {
                "provider_llm": "AzureOpenAI",
                "llm_deployment_name": llm_data["model"].split("/")[-1],
                "api_key": llm_data["api_key"],
                "azure_endpoint": llm_data["base_url"],
                "llm_api_version": llm_data["api_version"]
            }
        elif "bedrock" in llm_data.get('model'):
            provider_config = {
                "provider_llm": "AmazonBedrock",
                "modelid": llm_data["model"].split("/")[-1],
                "region": llm_data["aws_region_name"],
                "access_key": llm_data["aws_access_key_id"],
                "secret_key": llm_data["aws_secret_access_key"]
            }

        return provider_config

    def prepare_payload(self):
        
        llm_data = self.agent_data.llm
        payload = {
            "use_case": "AGENT",
            "app_version": f"{self.agent_data.name}",
            "input": self.input,
            "output": self.output,
            "context": ""
        }
        provider_config = self.get_provider_config(llm_data)
        payload.update(**provider_config)

        return payload

    def register_record(self):
        if settings.to_bool("TRULENS_ENABLED"):
            try:
                headers = dict()
                payload = self.prepare_payload()
                response = requests.post(
                    settings.TRULENS_URL, 
                    headers=headers, 
                    json=payload
                )
                if response.status_code>=400:
                    raise HTTPException(
                        detail=response.content, 
                        status_code=response.status_code
                    )

            except Exception as e:
                    logger.error(
                        f"Trulens error: {response.content} ",
                        f"for agent id: {self.agent_data.id} ",
                        f"and agent name: {self.agent_data.name} ",
                        f"and execution_id: {self.agent_config.execution_id}"
                        f"as: {str(e)}"
                    )


