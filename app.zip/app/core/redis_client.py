"""
Redis client singleton for pipeline-core microservice.

Implements a singleton Redis client with retry and SSL support.
Configuration is loaded from environment variables via the config module.
"""

import base64
import binascii
import logging

import redis
from redis.backoff import ExponentialBackoff
from redis.exceptions import ConnectionError, TimeoutError
from redis.retry import Retry

from app.core.config import settings as config

logger = logging.getLogger(__name__)


class RedisClientSingleton:
    """
    Singleton Redis client with retry and SSL support.
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        # Singleton pattern: only one instance per process
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize(*args, **kwargs)
        return cls._instance

    def _initialize(self):
        """
        Initialize the Redis client using config values.
        """
        logger.info("---------------- Redis Configuration ---------------- ")

        redis_host = config.REDIS_HOST
        redis_port = config.REDIS_PORT
        redis_password = config.REDIS_PASSWORD
        sslValue = config.REDIS_SSL

        # ---------------------------------------------------------
        # FIX: Robust Password Decoding
        # ---------------------------------------------------------
        decoded_password = None
        if redis_password:
            try:
                # Try to decode assuming it is Base64
                decoded_password = base64.b64decode(redis_password).decode("utf-8")
            except (binascii.Error, UnicodeDecodeError, ValueError):
                # If decoding fails, assume it is Plain Text and use as is
                decoded_password = redis_password
        else:
            decoded_password = None

        # Convert SSL value to boolean
        sslBool = str(sslValue).lower() == "true"

        logger.info("REDIS sslValue is %s and sslBool is %s", sslValue, sslBool)

        try:
            self.redisClient = redis.StrictRedis(
                host=redis_host,
                port=int(redis_port),# if redis_port else 6379,
                password=decoded_password,
                ssl=sslBool,
                decode_responses=True,
                retry=Retry(ExponentialBackoff(cap=10, base=1), 7),
                retry_on_error=[ConnectionError, TimeoutError],
                health_check_interval=1,
            )

        except redis.ConnectionError as e:
            if hasattr(self, 'redisClient') and self.redisClient:
                self.redisClient.close()
                logger.info("Closed Redis connection.")
            logger.error(f"Could not connect to Redis: {e}")
            raise Exception(f"Could not connect to Redis: {e}")

    def get_client(self):
        return self.redisClient


logger.debug("Redis client being initialized")

# Instantiate the client only if log streaming is enabled
redis_client_singleton = (
    RedisClientSingleton() if config.ENABLE_LOGSTREAMING == "True" else None
)

redis_client = redis_client_singleton.get_client() if redis_client_singleton else None