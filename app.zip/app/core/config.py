"""
Unified configuration management for pipeline-core.

- All configuration is loaded from environment variables (.env file) or a configuration service.
- No hardcoded values: defaults should be set in .env, not in code.
- If CONFIG_SERVICE_URL is set, config is fetched from the remote service and overrides .env values.
- If CONFIG_REFRESH_ENABLED is true, config is periodically refreshed from the config service.
- This pattern should be used in all microservices for unified config management.

See .env.example for all available variables and documentation.
"""

import logging
import os
import threading
import time

import dotenv
import httpx
from pydantic_settings import BaseSettings
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict

dotenv.load_dotenv(override=True)  # Load .env file, allowing environment variables to override

logger = logging.getLogger("pipeline-core.config")


# def _log_with_correlation(log_callable, *args, **kwargs):
#     """Ensure configuration logs carry an operation/request ID for telemetry correlation."""
#     import uuid

#     try:
#         from app.core.application_insights import (  # Local import to avoid circular dependency
#             get_current_operation_id,
#             operation_context,
#             push_operation_context,
#             pop_operation_context,
#         )

#         if get_current_operation_id():
#             log_callable(*args, **kwargs)
#             return

#         with operation_context():
#             log_callable(*args, **kwargs)
#             return

#     except Exception:  # noqa: BLE001
#         op_id = uuid.uuid4().hex
#         req_id = f"|{op_id}.{uuid.uuid4().hex[:16]}."
#         tokens = None
#         try:
#             from app.core.application_insights import push_operation_context, pop_operation_context  # type: ignore  # noqa: F811

#             tokens = push_operation_context(op_id, req_id)
#         except Exception:  # noqa: BLE001
#             tokens = None

#         extra = kwargs.setdefault("extra", {})
#         custom = extra.setdefault("custom_dimensions", {})
#         custom.setdefault("operation_id", op_id)
#         custom.setdefault("request_id", req_id)

#         try:
#             log_callable(*args, **kwargs)
#         finally:
#             if tokens is not None:
#                 try:
#                     pop_operation_context(tokens)
#                 except Exception:  # noqa: BLE001
#                     pass


class Settings(BaseSettings):
    """
    Settings class for pipeline-core microservice.
    """
    BASE_URL:str = ""
    BASE_PLATFORM_URL:str = ""
    REDIS_HOST: str = ""
    REDIS_PORT: str = ""
    REDIS_PASSWORD: str = ""
    DB_URL: str = ""
    DB_USER: str = ""
    DB_PASSWORD: str = ""
    ADMIN_URL: str = ""
    ENABLE_LOGSTREAMING: str = ""
    PERSISTENT_LOGGING: str = ""
    USE_BEDROCK_CREDENTIALS: str = "True"
    USE_SYSTEM_PROMPT: str = "True"

    # Read as string from env
    ENABLED_PROVIDERS: str = "" # TODO

    # Optional: URL of a configuration service
    APP_CONFIG_URL: Optional[str] = "https://hci-prd-ai.aava.ai/appconfig/api/v1/config/multi-app?applications=aava-core-platform-agent-service" 
    COMMON_CONFIG_URL: Optional[str] = "https://hci-prd-ai.aava.ai/appconfig/api/v1/config/multi-app?applications=aava-core-platform-common-config"

    # Optional: Enable config refresh (true/false)
    CONFIG_REFRESH_ENABLED: bool = False
    

    # Optional: Config refresh interval in seconds (default: 300)
    CONFIG_REFRESH_INTERVAL: int = 300

    # AdminURL for V2
    ADMIN_URL_V2_AGENT: str = ""

    SECRETS_URL: str = ""
    REDIS_SSL: str = ""
    LOG_LEVEL: str = ""
    LANGFUSE_PUBLIC_KEY: str = ""
    LANGFUSE_SECRET_KEY: str = ""
    LANGFUSE_HOST: str = ""
    INSTRUCTIONS_URL: str = ""
    TIKA_URL: str = ""
    REQUEST_TIMEOUT: int = (
        1000  # Timeout for outbound HTTP requests in seconds (recommended: 10-30)
    )
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


    AAVA_CORE_ENABLED: bool = False

    # Logging Configuration
    AAVA_LOGGING_ENABLED: bool = False
    AAVA_LOGGING_APP_NAME: str = "aava-agent-service"
    AAVA_LOGGING_ENVIRONMENT: str = ""
    AAVA_LOGGING_JSON_FORMAT: bool = False
    AAVA_LOGGING_CONSOLE_ENABLED: bool = False
    AAVA_LOGGING_FILE_ENABLED: bool = False
    AAVA_LOGGING_FILE_PATH: str = ""
    AAVA_LOGGING_ASPECT_ENABLED: bool = False
    AAVA_LOGGING_PERFORMANCE_ENABLED: bool = False
    AAVA_LOGGING_PERFORMANCE_SLOW_THRESHOLD: int = 1000
    AAVA_LOGGING_PERFORMANCE_LOG_DATABASE_OPERATIONS: bool = False
    AAVA_LOGGING_PERFORMANCE_LOG_METHOD_EXECUTIONS: bool = False
    # JWT Security Configuration
    AAVA_SECURITY_JWT_ENABLED: bool = False
    # Endpoints that don't require JWT (comma-separated patterns)
    LIBRARY_ENDPOINT_EXCEPTIONS: str = ""
    APP_CONFIG_SERVICE_URL: str = ""

    # Listeners Logs
    BOOTSTRAP_SERVER: str = ""
    SECURITY_PROTOCOL: str = ""
    SASL_MECHANISHM: str = ""
    SASL_PLAIN_USERNAME: str = ""
    SASL_PLAIN_PASSWORD: str = ""
    AGENT_TOPIC: str = ""
    KAFKA_AGENT_ENABLED: str = ""

    CORS_ALLOWED_ORIGINS: str = ""

    GUARDRAILS_URL: str = ""

    ADMIN_DOWNLOAD_URL: str = ""
    ADMIN_UPLOAD_URL: str = ""
    LANGFUSE_ENABLED: str = ""
    TRULENS_ENABLED: str = ""
    TRULENS_URL: str = ""

    # Azure Application Insights Configuration
    APPLICATIONINSIGHTS_CONNECTION_STRING: str = ""
    APPLICATIONINSIGHTS_ENABLED: bool = False
    APPLICATIONINSIGHTS_INSTRUMENTATIONKEY: str = ""  # Fallback for legacy setup
    APPLICATIONINSIGHTS_SAMPLE_RATE: float = 1.0
    APPLICATIONINSIGHTS_DISABLE_TELEMETRY: bool = False
    APPLICATIONINSIGHTS_LOG_LEVEL: str = "INFO"

     # AWS IAM Authentication
    IAM_DB_HOST: str = ""
    IAM_DB_PORT: int = 5432
    DB_NAME: str = ""
    IAM_DB_USER: str = ""
    AWS_REGION: str = ""
    IAM_TOKEN_REFRESH_INTERVAL:int = 13

    # SYSTEM GUARDRAILS
    SYSTEM_GUARDRAILS_ENABLED: bool = False 

    # ==================== HP OBO SETTINGS ====================
    OBO_API_BASE_URL: str = ""  # Base URL for Java OAuth service

    IAM_AUTH_ENABLED: str = "False"

    MONGODB_URI: str = ""
    MONGODB_DATABASE: str = ""
    MONGODB_COLLECTION: str = ""
    MONGODB_INDEX: str = ""

    MONGODB_HOST: str = ""
    MONGODB_PORT: str = ""
    MONGODB_USERNAME: str = ""
    MONGODB_PASSWORD: str = ""
    MONGODB_AUTH_SOURCE: str = ""

    AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT: str = ""

    # Tools - Base urls allow lists
    GITHUB_BASE_URL: str = ""
    JIRA_BASE_URL: str = ""
    TEST_RAIL_READONLY_CONNECTOR_BASE_URL: str = ""

    # Tools output System guardrails validation
    GITHUB_GUARDRAIL_VALIDATION_ENABLED: bool = False
    JIRA_GUARDRAIL_VALIDATION_ENABLED: bool = False
    KNOWLEDGE_RAG_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    S3_MULTI_OPERATION_GUARDRAIL_VALIDATION_ENABLED: bool = False
    IMAGE_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    FILE_READ_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    MEMREADWRITE_GUARDRAIL_VALIDATION_ENABLED: bool = False
    TESTRAILREADCONNECTOR_GUARDRAIL_VALIDATION_ENABLED:bool = False

    # Environment Name
    ENVIRONMENT_NAME: str = ""

    @property
    def obo_api_base_url(self) -> str:
        """Get OBO API base URL from environment or config"""
        return os.environ.get("OBO_API_BASE_URL") or self.OBO_API_BASE_URL
    
    # ==================== END OBO SETTINGS ====================

    @property
    def enabled_providers(self) -> list[str]:
        enabled = os.environ.get("ENABLED_PROVIDERS") or self.ENABLED_PROVIDERS
        if enabled:
            return [p.strip().lower() for p in enabled.split(",") if p.strip()]
        return []

    @property
    def azure_provider_url(self) -> str:
        return os.environ.get("AZURE_PROVIDER_URL") or self.AZURE_PROVIDER_URL

    @property
    def google_provider_url(self) -> str:
        return os.environ.get("GOOGLE_PROVIDER_URL") or self.GOOGLE_PROVIDER_URL

    @property
    def bedrock_provider_url(self) -> str:
        return os.environ.get("BEDROCK_PROVIDER_URL") or self.BEDROCK_PROVIDER_URL

    @property
    def azure_provider_files_url(self) -> str:
        return (
            os.environ.get("AZURE_PROVIDER_FILES_URL") or self.AZURE_PROVIDER_FILES_URL
        )

    @property
    def google_provider_files_url(self) -> str:
        return (
            os.environ.get("GOOGLE_PROVIDER_FILES_URL")
            or self.GOOGLE_PROVIDER_FILES_URL
        )

    @property
    def bedrock_provider_files_url(self) -> str:
        return (
            os.environ.get("BEDROCK_PROVIDER_FILES_URL")
            or self.BEDROCK_PROVIDER_FILES_URL
        )

    @property
    def azure_agent_url(self) -> str:
        return os.environ.get("AZURE_AGENT_URL") or self.AZURE_AGENT_URL

    @property
    def google_agent_url(self) -> str:
        return os.environ.get("GOOGLE_AGENT_URL") or self.GOOGLE_AGENT_URL

    @property
    def bedrock_agent_url(self) -> str:
        return os.environ.get("BEDROCK_AGENT_URL") or self.BEDROCK_AGENT_URL

    @property
    def azure_agent_files_url(self) -> str:
        return os.environ.get("AZURE_AGENT_FILES_URL") or self.AZURE_AGENT_FILES_URL

    @property
    def google_agent_files_url(self) -> str:
        return os.environ.get("GOOGLE_AGENT_FILES_URL") or self.GOOGLE_AGENT_FILES_URL

    @property
    def bedrock_agent_files_url(self) -> str:
        return os.environ.get("BEDROCK_AGENT_FILES_URL") or self.BEDROCK_AGENT_FILES_URL

    @property
    def bootstrap_server(self) -> str:
        return os.environ.get("BOOTSTRAP_SERVER") or self.BOOTSTRAP_SERVER

    @property
    def security_protocol(self) -> str:
        return os.environ.get("SECURITY_PROTOCOL") or self.SECURITY_PROTOCOL

    @property
    def sasl_mechanism(self) -> str:
        return os.environ.get("SASL_MECHANISHM") or self.SASL_MECHANISHM

    @property
    def sasl_plain_username(self) -> str:
        return os.environ.get("SASL_PLAIN_USERNAME") or self.SASL_PLAIN_USERNAME

    @property
    def sasl_plain_password(self) -> str:
        return os.environ.get("SASL_PLAIN_PASSWORD") or self.SASL_PLAIN_PASSWORD

    @property
    def agent_topic(self) -> str:
        return os.environ.get("AGENT_TOPIC") or self.AGENT_TOPIC

    @property
    def kafka_agent_enabled(self) -> str:
        return os.environ.get("KAFKA_AGENT_ENABLED") or self.KAFKA_AGENT_ENABLED

    def _fetch_config_from_url(self, url: str, config_type: str) -> tuple[bool, str, dict]:
        """
        Fetch configuration from a remote URL.
        
        Args:
            url: The configuration service URL
            config_type: Type of config being loaded (for logging: "common" or "app-specific")
            
        Returns:
            Tuple of (success, message, config_dict)
        """
        try:
            resp = httpx.get(url, timeout=5)
            resp.raise_for_status()
            remote_config = resp.json()
            
            loaded_configs = {}
            loaded_keys = 0
            skipped_keys = 0

            for item in remote_config:
                key = item.get("configKey")
                value = item.get("configValue")

                if not key:
                    continue

                if hasattr(self, key):
                    loaded_configs[key] = value
                    loaded_keys += 1
                else:
                    # _log_with_correlation(
                    #     logger.warning,
                    #     f'Settings object has no field "{key}" — skipping.'
                    # )
                    skipped_keys += 1

            message = f"Loaded {loaded_keys} {config_type} config(s) from {url}"
            if skipped_keys > 0:
                message += f" (skipped {skipped_keys} unknown keys)"
            
            logger.info(message)
            return True, message, loaded_configs
            
        except Exception as e:
            error_msg = f"Failed to load {config_type} config from {url}: {e}"
            logger.warning(f"Warning: {error_msg}")
            return False, error_msg, {}

    def load_remote_config(self):
        """
        Load configuration from remote services in priority order:
        1. First load COMMON_CONFIG_URL (if set) - shared/common configurations
        2. Then load APP_CONFIG_URL (if set) - app-specific configurations that override common
        
        Only known settings (attributes defined in the class) will be loaded.
        Unknown keys are logged and skipped.
        """
        
        total_loaded = 0
        messages = []
        
        # Step 1: Load common config first
        #common_url = self.COMMON_CONFIG_URL or os.environ.get("COMMON_CONFIG_URL")
        common_url = self.COMMON_CONFIG_URL
        common_configs = {}
        
        if common_url:
            success, message, common_configs = self._fetch_config_from_url(common_url, "common")
            messages.append(message)
            total_loaded += len(common_configs)
        
        # Step 2: Load app-specific config (will override common if keys overlap)
        #app_url = self.APP_CONFIG_URL or os.environ.get("APP_CONFIG_URL")
        app_url = self.APP_CONFIG_URL
        app_configs = {}
        
        if app_url:
            success, message, app_configs = self._fetch_config_from_url(app_url, "app-specific")
            messages.append(message)
            total_loaded += len(app_configs)
        
        # Step 3: Apply configurations in priority order (common first, then app-specific)
        # This ensures app-specific configs overwrite common configs
        all_configs = {**common_configs, **app_configs}
        
        overridden_keys = set(common_configs.keys()) & set(app_configs.keys())
        if overridden_keys:
            logger.info(f"App-specific config overriding {len(overridden_keys)} common config(s): {', '.join(overridden_keys)}")
        
        # Apply all configs to settings and environment
        for key, value in all_configs.items():
            setattr(self, key, value)
            os.environ[key] = str(value)
        
        # Summary logging
        if common_url or app_url:
            logger.info(f"Configuration loading complete: {total_loaded} total config(s) loaded")
            return True, " | ".join(messages)
        else:
            logger.info("No remote config URLs configured, using local .env settings only")
            return False, "No remote config URLs configured"

    def to_bool(self, key):
        value = getattr(self, key, False)
        return str(value).strip().lower() in ("true", "1", "yes")

    def start_config_refresh(self):
        """
        If CONFIG_REFRESH_ENABLED is true, start a background thread to periodically refresh config.
        """
        self.CONFIG_REFRESH_ENABLED = self.to_bool("CONFIG_REFRESH_ENABLED")

        if self.CONFIG_REFRESH_ENABLED:

            def refresh_loop():
                while True:
                    self.load_remote_config()
                    time.sleep(int(self.CONFIG_REFRESH_INTERVAL))

            thread = threading.Thread(target=refresh_loop, daemon=True)
            thread.start()


# Usage in main.py:
settings = Settings()
logger.info(
    f"Loaded REQUEST_TIMEOUT from environment/config: {int(settings.REQUEST_TIMEOUT)}"
)
settings.load_remote_config()


# Commented
#settings.start_config_refresh()
# Use settings.FIELD_NAME to access config values throughout your application.
 