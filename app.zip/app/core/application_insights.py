"""
Production Azure Application Insights integration for AAVA Agent Service.

This module provides comprehensive telemetry tracking including:
- Request telemetry with proper operation IDs
- Dependency tracking for external services
- Custom events and metrics
- Exception tracking
- Application Map support
"""

import inspect
import logging
import os
import uuid
from contextlib import contextmanager
from contextvars import ContextVar, Token
from functools import wraps
import time
from typing import Optional, Dict, Any, Tuple, Union
from urllib.parse import urlparse
import requests
from datetime import datetime

logger = logging.getLogger(__name__)

_current_operation_id: ContextVar[Optional[str]] = ContextVar("current_operation_id", default=None)
_current_request_id: ContextVar[Optional[str]] = ContextVar("current_request_id", default=None)
_HTTPX_PATCHED = False


def push_operation_context(operation_id: str, request_id: Optional[str] = None) -> Tuple[Optional[Token], Optional[Token]]:
    op_token = _current_operation_id.set(operation_id)
    req_token = None
    if request_id is not None:
        req_token = _current_request_id.set(request_id)
    return op_token, req_token


def pop_operation_context(tokens: Tuple[Optional[Token], Optional[Token]]) -> None:
    op_token, req_token = tokens
    if op_token is not None:
        _current_operation_id.reset(op_token)
    if req_token is not None:
        _current_request_id.reset(req_token)


def get_current_operation_id() -> Optional[str]:
    return _current_operation_id.get()


def get_current_request_id() -> Optional[str]:
    return _current_request_id.get()


def generate_operation_id() -> str:
    """Generate a 32-character hexadecimal operation identifier."""
    return uuid.uuid4().hex


def generate_request_id(operation_id: str) -> str:
    """Generate a request identifier using the Application Insights format."""
    span_suffix = uuid.uuid4().hex[:16]
    return f"|{operation_id}.{span_suffix}."


@contextmanager
def operation_context(
    operation_id: Optional[str] = None,
    request_id: Optional[str] = None
):
    """Context manager that pushes/pops correlation identifiers."""
    op_id = operation_id or generate_operation_id()
    req_id = request_id or generate_request_id(op_id)
    tokens = push_operation_context(op_id, req_id)
    try:
        yield {"operation_id": op_id, "request_id": req_id}
    finally:
        pop_operation_context(tokens)

# Import Azure Application Insights components
try:
    from opencensus.ext.azure.log_exporter import AzureLogHandler
    from opencensus.ext.azure.trace_exporter import AzureExporter
    from opencensus.trace.tracer import Tracer
    from opencensus.trace.samplers import ProbabilitySampler
    from opencensus.trace import config_integration
    from opencensus.trace.span import SpanKind
    from opencensus.trace.attributes_helper import COMMON_ATTRIBUTES
    from opencensus.trace.status import Status
    try:
        from opencensus.trace.status import StatusCanonicalCode
    except ImportError:
        # Fallback for newer OpenCensus versions
        class StatusCanonicalCode:
            OK = 0
            UNKNOWN = 2
    try:
        from opencensus.ext.requests import RequestsIntegration
    except ImportError:
        # RequestsIntegration might not be available in some versions
        RequestsIntegration = None
    OPENCENSUS_AVAILABLE = True
    logger.info("✅ OpenCensus Azure components available")
except ImportError as e:
    OPENCENSUS_AVAILABLE = False
    logger.error("❌ OpenCensus Azure components not available: %s", str(e))

class ResilientAzureExporter(AzureExporter):
    """Azure exporter that suppresses noisy telemetry transport errors."""

    def export(self, data):  # type: ignore[override]
        try:
            return super().export(data)
        except requests.exceptions.ReadTimeout:
            logger.warning("Telemetry export timed out talking to Azure Monitor")
            return 0
        except requests.exceptions.RequestException as exc:
            logger.warning("Telemetry export request failed: %s", exc)
            return 0
        except TimeoutError:
            logger.warning("Telemetry export hit socket timeout")
            return 0
        except Exception as exc:  # noqa: BLE001
            logger.error("Unexpected telemetry export failure: %s", exc)
            return 0


class ApplicationInsights:
    """Production Application Insights client for AAVA Agent Service."""
    
    def __init__(self, connection_string: str, service_name: str = "aava-core-platform-agent-service"):
        """
        Initialize Application Insights with production configuration.
        
        Args:
            connection_string: Azure Application Insights connection string
            service_name: Service name for cloud role identification
        """
        self.connection_string = connection_string
        self.service_name = service_name
        self.enabled = bool(connection_string) and OPENCENSUS_AVAILABLE
        
        # Initialize components
        self.tracer: Optional[Tracer] = None
        self.log_handler: Optional[AzureLogHandler] = None
        self._instance_name: Optional[str] = None
        
        if self.enabled:
            self._initialize()
        else:
            logger.warning("⚠️ Application Insights disabled - missing connection string or OpenCensus")
    
    def _initialize(self):
        """Initialize Application Insights components."""
        try:
            # Configure trace exporter
            exporter = ResilientAzureExporter(
                connection_string=self.connection_string,
                timeout=10.0
            )

            # Force set cloud role name and instance
            self._instance_name = self._get_instance_name()

            def _apply_role_tags(envelope):
                envelope.tags['ai.cloud.role'] = self.service_name
                envelope.tags['ai.cloud.roleInstance'] = self._instance_name or self.service_name

            exporter.add_telemetry_processor(_apply_role_tags)
            
            # Set up tracer with appropriate sampling
            sampler = ProbabilitySampler(rate=1.0)  # 100% sampling for production monitoring
            self.tracer = Tracer(exporter=exporter, sampler=sampler)
            
            # Set up logging handler
            self.log_handler = AzureLogHandler(
                connection_string=self.connection_string,
                timeout=10.0
            )
            
            # Configure custom properties for all telemetry
            self.log_handler.add_telemetry_processor(self._add_custom_properties)
            
            # Add handler to root logger
            root_logger = logging.getLogger()
            if not any(isinstance(h, AzureLogHandler) for h in root_logger.handlers):
                root_logger.addHandler(self.log_handler)
            
            # Configure integrations if available
            try:
                config_integration.trace_integrations(['requests'])
            except Exception:  # noqa: BLE001
                # Integration may not be available
                pass

            _instrument_httpx_clients()
            
            logger.info("🚀 Application Insights initialized for service: %s", self.service_name)
            
            # Log the instance name for verification
            instance_name = self._instance_name or self._get_instance_name()
            self._instance_name = instance_name
            logger.info("📋 Application Insights instance name: %s", instance_name)
            
            # Send initialization telemetry
            self._send_startup_telemetry()
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to initialize Application Insights: %s", e)
            self.enabled = False

    def _get_instance_name(self):
        """Generate a meaningful instance name for the service."""
        # Try different approaches to get a meaningful instance name
        
        # 1. Use Kubernetes pod name if available
        pod_name = os.getenv('POD_NAME')
        if pod_name:
            return f"{self.service_name}-{pod_name}"
        
        # 2. Use container ID/hostname
        hostname = os.getenv('HOSTNAME', 'unknown')
        
        # 3. Add environment context if available
        environment = os.getenv('ENVIRONMENT', os.getenv('ENV', 'local'))
        
        # 4. Include deployment info if available
        deployment = os.getenv('DEPLOYMENT_NAME', '')
        
        # Build instance name with available information
        parts = [self.service_name]
        
        if environment and environment != 'local':
            parts.append(environment)
        
        if deployment:
            parts.append(deployment)
        
        # Always include hostname/container ID for uniqueness
        if hostname != 'unknown':
            # Use short container ID (first 8 characters) for readability
            short_hostname = hostname[:8] if len(hostname) > 8 else hostname
            parts.append(short_hostname)
        
        return '-'.join(parts)

    def _add_custom_properties(self, envelope):
        """Add custom properties to all telemetry items and override conflicting values."""
        instance_name = self._instance_name or self._get_instance_name()
        self._instance_name = instance_name

        # Ensure cloud role tags are authoritative
        envelope.tags['ai.cloud.role'] = self.service_name
        envelope.tags['ai.cloud.roleInstance'] = instance_name
        envelope.tags['ai.application.ver'] = os.getenv('APP_VERSION', '1.0.0')
        envelope.tags['ai.device.type'] = 'Container'

        operation_identifier: Optional[str] = None
        parent_identifier: Optional[str] = None

        if hasattr(envelope, 'data') and hasattr(envelope.data, 'baseData'):
            base_data = envelope.data.baseData

            properties_dict: Dict[str, Any] = {}
            if hasattr(base_data, 'properties'):
                raw_properties = getattr(base_data, 'properties')
                if isinstance(raw_properties, dict):
                    properties_dict = raw_properties
                elif raw_properties:
                    properties_dict = dict(raw_properties)
                else:
                    properties_dict = {}

                current_op = _current_operation_id.get()
                current_req = _current_request_id.get()
                if current_op and 'operation_id' not in properties_dict:
                    properties_dict['operation_id'] = current_op
                if current_req:
                    properties_dict.setdefault('request_id', current_req)
                    properties_dict.setdefault('parent_id', current_req)

                base_data.properties = properties_dict

                # Surface explicit operation identifiers if present
                operation_from_props = properties_dict.get('operation_id')
                parent_from_props = properties_dict.get('parent_id') or properties_dict.get('operation_parent_id')
                request_from_props = properties_dict.get('request_id') or properties_dict.get('dependency_id')

                if operation_from_props:
                    operation_identifier = str(operation_from_props)
                    if not envelope.tags.get('ai.operation.id'):
                        envelope.tags['ai.operation.id'] = operation_identifier

                if parent_from_props:
                    parent_identifier = str(parent_from_props)
                    if not envelope.tags.get('ai.operation.parentId'):
                        envelope.tags['ai.operation.parentId'] = parent_identifier

                if request_from_props and hasattr(base_data, 'id'):
                    base_data.id = str(request_from_props)

                # Clean up problematic property keys and values that confuse App Insights
                problematic_keys = ['__main__.py', 'main.py', '__main__']
                for key in list(properties_dict.keys()):
                    if any(prob in str(key) for prob in problematic_keys):
                        base_data.properties[key] = f"OVERRIDDEN-{self.service_name}"
                        logger.debug("🔧 Override: Replaced problematic property key: %s", key)

                for key, value in list(properties_dict.items()):
                    if isinstance(value, str) and ('__main__' in value or value.endswith('.py')):
                        base_data.properties[key] = f"{self.service_name}-{key}"
                        logger.debug("🔧 Override: Fixed property %s from '%s' to '%s'", key, value, base_data.properties[key])

            if hasattr(base_data, 'name') and base_data.name:
                if '__main__' in str(base_data.name) or 'main.py' in str(base_data.name):
                    base_data.name = f"{self.service_name}-operation"
                    logger.debug("🔧 Override: Fixed operation name from __main__ reference")

            if hasattr(base_data, 'id'):
                existing_id = getattr(base_data, 'id', None)
                if existing_id:
                    cleaned = str(existing_id).strip('|')
                    if cleaned and cleaned.strip('0.'):
                        inferred = cleaned.split('.', 1)[0]
                        if inferred and inferred.strip('0'):
                            operation_identifier = operation_identifier or inferred
                if not existing_id or not str(existing_id).strip('|0.'):
                    # Generate a deterministic request ID when missing so AI doesn't fall back to zeros
                    if operation_identifier:
                        span_suffix = uuid.uuid4().hex[:16]
                        base_data.id = f"|{operation_identifier}.{span_suffix}."

        # Final guard to ensure instance and operation identifiers are present
        envelope.tags['ai.cloud.role'] = self.service_name
        envelope.tags['ai.cloud.roleInstance'] = instance_name

        if not envelope.tags.get('ai.operation.id'):
            base_data = getattr(envelope.data, 'baseData', None)
            base_id = getattr(base_data, 'id', None)
            if base_id:
                cleaned = str(base_id).strip('|')
                if cleaned and cleaned.strip('0.'):
                    envelope.tags['ai.operation.id'] = cleaned.split('.', 1)[0]

        if not envelope.tags.get('ai.operation.id'):
            fallback_operation = (
                operation_identifier
                or _current_operation_id.get()
                or properties_dict.get('operation_id')
                if 'properties_dict' in locals()
                else None
            )
            fallback_operation = fallback_operation or generate_operation_id()
            envelope.tags['ai.operation.id'] = fallback_operation

            base_data = getattr(envelope.data, 'baseData', None)
            if hasattr(base_data, 'id'):
                base_request_id = getattr(base_data, 'id', None)
                if not base_request_id or not str(base_request_id).strip('|0.'):
                    generated_request_id = generate_request_id(fallback_operation)
                    base_data.id = generated_request_id
                    if hasattr(base_data, 'properties'):
                        base_props = getattr(base_data, 'properties')
                        if isinstance(base_props, dict):
                            base_props.setdefault('request_id', generated_request_id)
                        elif base_props is not None:
                            mutable_props = dict(base_props)
                            mutable_props.setdefault('request_id', generated_request_id)
                            base_data.properties = mutable_props

        if parent_identifier and not envelope.tags.get('ai.operation.parentId'):
            envelope.tags['ai.operation.parentId'] = parent_identifier

        logger.debug("🏷️ Applied telemetry tags - Role: %s, Instance: %s", self.service_name, instance_name)
        return True

    def _send_startup_telemetry(self):
        """Send startup telemetry to establish service in Application Insights."""
        try:
            with operation_context() as ctx:
                self.track_event(
                    name="ServiceStartup",
                    properties={
                        "service": self.service_name,
                        "version": os.getenv("APP_VERSION", "1.0.0"),
                        "environment": os.getenv("ENVIRONMENT", "development"),
                        "startup_time": datetime.utcnow().isoformat(),
                        "operation_id": ctx["operation_id"],
                        "request_id": ctx["request_id"]
                    }
                )
            logger.info("✅ Startup telemetry sent to Application Insights")
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to send startup telemetry: %s", e)

    def track_event(
        self, 
        name: str, 
        properties: Optional[Dict[str, Any]] = None, 
        measurements: Optional[Dict[str, float]] = None
    ):
        """
        Track custom event telemetry.
        
        Args:
            name: Event name
            properties: Event properties
            measurements: Event measurements
        """
        if not self.enabled:
            return
        
        try:
            # Log custom event
            extra = {
                'custom_dimensions': {
                    'event_name': name,
                    'service': self.service_name,
                    **(properties or {})
                }
            }
            
            if measurements:
                extra['custom_dimensions'].update({f"measurement_{k}": v for k, v in measurements.items()})

            current_operation = get_current_operation_id()
            current_request = get_current_request_id()
            if current_operation:
                extra['custom_dimensions'].setdefault('operation_id', current_operation)
            if current_request:
                extra['custom_dimensions'].setdefault('request_id', current_request)
            
            logger.info("Custom event: %s", name, extra=extra)
            logger.debug("📝 Event tracked: %s", name)
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to track event: %s", e)

    def track_exception(
        self, 
        exception: Exception, 
        properties: Optional[Dict[str, Any]] = None
    ):
        """
        Track exception telemetry.
        
        Args:
            exception: Exception to track
            properties: Additional properties
        """
        if not self.enabled:
            return
        
        try:
            extra = {
                'custom_dimensions': {
                    'exception_type': type(exception).__name__,
                    'service': self.service_name,
                    **(properties or {})
                }
            }

            current_operation = get_current_operation_id()
            current_request = get_current_request_id()
            if current_operation:
                extra['custom_dimensions'].setdefault('operation_id', current_operation)
            if current_request:
                extra['custom_dimensions'].setdefault('request_id', current_request)
            
            logger.exception("Exception tracked: %s", exception, extra=extra)
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to track exception: %s", e)

    def track_metric(
        self, 
        name: str, 
        value: float, 
        properties: Optional[Dict[str, Any]] = None
    ):
        """
        Track metric telemetry.
        
        Args:
            name: Metric name
            value: Metric value
            properties: Additional properties
        """
        if not self.enabled:
            return
        
        try:
            extra = {
                'custom_dimensions': {
                    'metric_name': name,
                    'metric_value': value,
                    'service': self.service_name,
                    **(properties or {})
                }
            }

            current_operation = get_current_operation_id()
            current_request = get_current_request_id()
            if current_operation:
                extra['custom_dimensions'].setdefault('operation_id', current_operation)
            if current_request:
                extra['custom_dimensions'].setdefault('request_id', current_request)
            
            logger.info("Metric: %s = %s", name, value, extra=extra)
            logger.debug("📈 Metric tracked: %s = %s", name, value)
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to track metric: %s", e)

    def track_request(
        self, 
        name: str, 
        url: str, 
        method: str = "GET",
        duration: float = 0.0, 
        response_code: int = 200, 
        success: bool = True,
        properties: Optional[Dict[str, Any]] = None,
        operation_id: Optional[str] = None
    ):
        """
        Track HTTP request telemetry.
        
        Args:
            name: Request name/endpoint
            url: Request URL
            method: HTTP method
            duration: Request duration in milliseconds
            response_code: HTTP response code
            success: Whether request was successful
            properties: Additional properties
            operation_id: Operation ID for correlation
        """
        if not self.enabled or not self.tracer:
            return
        
        try:
            operation_id = operation_id or str(uuid.uuid4()).replace('-', '')
            properties = dict(properties) if properties else {}
            properties.setdefault('operation_id', operation_id)
            properties.setdefault('service', self.service_name)

            request_id: Optional[str] = None
            span_id: Optional[str] = None

            with self.tracer.span(name=f"{method} {name}") as span:
                span.span_kind = SpanKind.SERVER

                if hasattr(span, "span_context") and getattr(span.span_context, "trace_id", None) is not None:
                    try:
                        span.span_context.trace_id = operation_id
                    except (AttributeError, TypeError):
                        span.add_attribute("ai.operation.id", operation_id)
                else:
                    ctx = getattr(span, "context", None)
                    if ctx is not None and getattr(ctx, "trace_id", None) is not None:
                        try:
                            ctx.trace_id = operation_id
                        except (AttributeError, TypeError):
                            span.add_attribute("ai.operation.id", operation_id)
                    else:
                        span.add_attribute("ai.operation.id", operation_id)

                span_id = getattr(span, "span_id", None)
                if span_id:
                    request_id = f"|{operation_id}.{span_id}."
                    properties.setdefault('request_id', request_id)
                
                # Set span attributes
                span.add_attribute("http.method", method)
                span.add_attribute("http.url", url)
                span.add_attribute("http.status_code", response_code)
                span.add_attribute("http.duration_ms", float(duration))
                span.add_attribute("operation.id", operation_id)
                span.add_attribute("ai.operation.id", operation_id)
                
                # Add custom properties
                for key, value in properties.items():
                    span.add_attribute(f"custom.{key}", str(value))
                
                # Set span status
                if success and 200 <= response_code < 400:
                    span.set_status(Status(StatusCanonicalCode.OK))
                else:
                    span.set_status(Status(StatusCanonicalCode.UNKNOWN))

            op_token = _current_operation_id.set(operation_id)
            req_token = _current_request_id.set(request_id)
            try:
                logger.debug("📊 Request tracked: %s %s - %s", method, name, response_code)
            finally:
                _current_operation_id.reset(op_token)
                _current_request_id.reset(req_token)

            return {"operation_id": operation_id, "request_id": request_id}
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to track request: %s", e)
    
    def track_dependency(
        self, 
        name: str, 
        dependency_type: str, 
        target: str,
        data: str = "",
        duration: float = 0.0, 
        success: bool = True,
        result_code: Union[str, int] = "200",
        properties: Optional[Dict[str, Any]] = None,
        operation_id: Optional[str] = None
    ):
        """
        Track dependency call telemetry.
        
        Args:
            name: Dependency name
            dependency_type: Type of dependency (HTTP, SQL, etc.)
            target: Target server/service
            data: Additional data (SQL command, URL, etc.)
            duration: Call duration in milliseconds
            success: Whether call was successful
            result_code: Result code
            properties: Additional properties
            operation_id: Operation ID for correlation
        """
        if not self.enabled or not self.tracer:
            return
        
        try:
            operation_id = operation_id or _current_operation_id.get() or str(uuid.uuid4()).replace('-', '')
            parent_id = properties.get('parent_id') if properties else None
            parent_id = parent_id or _current_request_id.get()
            properties = dict(properties) if properties else {}
            properties.setdefault('operation_id', operation_id)
            if parent_id:
                properties.setdefault('parent_id', parent_id)
            properties.setdefault('service', self.service_name)
            properties.setdefault('dependency_type', dependency_type)

            dependency_id: Optional[str] = None
            span_id: Optional[str] = None

            with self.tracer.span(name=f"{dependency_type} {name}") as span:
                span.span_kind = SpanKind.CLIENT

                if hasattr(span, "span_context") and getattr(span.span_context, "trace_id", None) is not None:
                    try:
                        span.span_context.trace_id = operation_id
                    except (AttributeError, TypeError):
                        span.add_attribute("ai.operation.id", operation_id)
                else:
                    ctx = getattr(span, "context", None)
                    if ctx is not None and getattr(ctx, "trace_id", None) is not None:
                        try:
                            ctx.trace_id = operation_id
                        except (AttributeError, TypeError):
                            span.add_attribute("ai.operation.id", operation_id)
                    else:
                        span.add_attribute("ai.operation.id", operation_id)

                span_id = getattr(span, "span_id", None)
                if span_id:
                    dependency_id = f"|{operation_id}.{span_id}."
                    properties.setdefault('dependency_id', dependency_id)
                
                # Set span attributes
                span.add_attribute("dependency.type", dependency_type)
                span.add_attribute("dependency.target", target)
                span.add_attribute("dependency.data", data)
                span.add_attribute("dependency.resultCode", str(result_code))
                span.add_attribute("dependency.duration_ms", float(duration))
                span.add_attribute("operation.id", operation_id)
                span.add_attribute("ai.operation.id", operation_id)

                # Populate HTTP-specific attributes
                if dependency_type.upper() == "HTTP":
                    http_method = properties.get("http_method") or properties.get("method") or "GET"
                    span.add_attribute("component", "http")
                    span.add_attribute("http.method", http_method)
                    span.add_attribute("http.url", target)
                    if data:
                        span.add_attribute("http.path", data)                
                
                # Add custom properties
                for key, value in properties.items():
                    span.add_attribute(f"custom.{key}", str(value))
                
                # Set span status
                if success:
                    span.set_status(Status(StatusCanonicalCode.OK))
                else:
                    span.set_status(Status(StatusCanonicalCode.UNKNOWN))
            logger.debug("🔗 Dependency tracked: %s -> %s", dependency_type, target)
            
        except Exception as e:  # noqa: BLE001
            logger.error("❌ Failed to track dependency: %s", e)


def _instrument_httpx_clients() -> None:
    global _HTTPX_PATCHED
    if _HTTPX_PATCHED:
        return

    try:
        import httpx  # type: ignore
    except ImportError:
        logger.debug("httpx not available for instrumentation")
        return

    original_client_request = httpx.Client.request
    original_async_request = getattr(httpx.AsyncClient, "request", None)

    def _record(method, url, start_time, response, error):
        app_insights = get_application_insights()
        if not app_insights or not app_insights.enabled:
            return

        duration = (time.perf_counter() - start_time) * 1000
        parsed = urlparse(str(url))
        target_host = parsed.netloc or parsed.path or str(url)
        path = parsed.path or "/"
        success = error is None and response is not None and getattr(response, "status_code", 500) < 400
        result_code = getattr(response, "status_code", None)
        if result_code is None:
            result_code = getattr(error, "status_code", "EXCEPTION") if error else "0"

        properties = {
            "http_method": method,
            "dependency_source": "httpx",
        }
        if parsed.scheme:
            properties["scheme"] = parsed.scheme
        if parsed.query:
            properties["query"] = "present"

        target = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme and parsed.netloc else str(url)
        app_insights.track_dependency(
            name=f"{method} {target_host}",
            dependency_type="HTTP",
            target=target,
            data=path,
            duration=duration,
            success=success,
            result_code=result_code,
            properties=properties,
        )

    def instrumented_request(self, method, url, *args, **kwargs):
        start_time = time.perf_counter()
        response = None
        error = None
        try:
            response = original_client_request(self, method, url, *args, **kwargs)
            return response
        except Exception as exc:  # noqa: BLE001
            error = exc
            raise
        finally:
            try:
                _record(method, url, start_time, response, error)
            except Exception:  # noqa: BLE001
                logger.debug("Failed recording httpx dependency", exc_info=True)

    httpx.Client.request = instrumented_request  # type: ignore[assignment]
    if original_async_request is not None:

        async def instrumented_async_request(self, method, url, *args, **kwargs):
            start_time = time.perf_counter()
            response = None
            error = None
            try:
                response = await original_async_request(self, method, url, *args, **kwargs)
                return response
            except Exception as exc:  # noqa: BLE001
                error = exc
                raise
            finally:
                try:
                    _record(method, url, start_time, response, error)
                except Exception:  # noqa: BLE001
                    logger.debug("Failed recording httpx dependency (async)", exc_info=True)

        httpx.AsyncClient.request = instrumented_async_request  # type: ignore[assignment]

    _HTTPX_PATCHED = True
    logger.info("🌐 httpx instrumentation enabled for Application Insights")


# Global Application Insights instance
_app_insights: Optional[ApplicationInsights] = None

def get_application_insights() -> Optional[ApplicationInsights]:
    """Get the global Application Insights instance."""
    return _app_insights

def initialize_application_insights(connection_string: str, service_name: str = "aava-core-platform-agent-service") -> ApplicationInsights:
    """
    Initialize the global Application Insights instance.
    
    Args:
        connection_string: Azure Application Insights connection string
        service_name: Service name for cloud role identification
    
    Returns:
        ApplicationInsights instance
    """
    global _app_insights  # noqa: PLW0603
    _app_insights = ApplicationInsights(connection_string, service_name)
    return _app_insights

# Utility functions for backward compatibility
def track_event(name: str, properties: Optional[Dict[str, Any]] = None, measurements: Optional[Dict[str, float]] = None):
    """Track custom event - utility function."""
    app_insights = get_application_insights()
    if app_insights and hasattr(app_insights, "track_event"):
        app_insights.track_event(name, properties, measurements)
    else:
        logger.debug("track_event skipped — Application Insights client unavailable")

def track_exception(exception: Exception, properties: Optional[Dict[str, Any]] = None):
    """Track exception - utility function."""
    app_insights = get_application_insights()
    if app_insights and hasattr(app_insights, "track_exception"):
        app_insights.track_exception(exception, properties)
    else:
        logger.debug("track_exception skipped — Application Insights client unavailable")

def track_metric(name: str, value: float, properties: Optional[Dict[str, Any]] = None):
    """Track metric - utility function."""
    app_insights = get_application_insights()
    if app_insights and hasattr(app_insights, "track_metric"):
        app_insights.track_metric(name, value, properties)
    else:
        logger.debug("track_metric skipped — Application Insights client unavailable")

def track_dependency(name: str, dependency_type: str, target: str, data: str = "", duration: float = 0.0, success: bool = True, result_code: Union[str, int] = "200", properties: Optional[Dict[str, Any]] = None):
    """Track dependency - utility function."""
    app_insights = get_application_insights()
    if app_insights and hasattr(app_insights, "track_dependency"):
        app_insights.track_dependency(name, dependency_type, target, data, duration, success, result_code, properties)
    else:
        logger.debug("track_dependency skipped — Application Insights client unavailable")

def track_request(name: str, url: str, method: str = "GET", duration: float = 0.0, response_code: int = 200, success: bool = True, properties: Optional[Dict[str, Any]] = None):
    """Track request - utility function."""
    app_insights = get_application_insights()
    if app_insights and hasattr(app_insights, "track_request"):
        app_insights.track_request(name, url, method, duration, response_code, success, properties)
    else:
        logger.debug("track_request skipped — Application Insights client unavailable")

def get_insights_logger(name: str):
    """Get a logger configured for Application Insights."""
    return logging.getLogger(name)


def execution_insights_decorator(func):
    is_coroutine = inspect.iscoroutinefunction(func)

    def _extract_agent_request(args, kwargs):
        if "agentRequest" in kwargs:
            return kwargs["agentRequest"]
        return args[-1] if args else None

    def _build_agent_data(agent_request, context_ids):
        def _string_or_fallback(value, fallback="unknown"):
            return str(value) if value not in (None, "") else fallback

        return {
            "agent_id": _string_or_fallback(getattr(agent_request, "agentId", None)),
            "execution_id": _string_or_fallback(getattr(agent_request, "executionId", None)),
            "user": _string_or_fallback(getattr(agent_request, "user", None)),
            "service": "agent_ai",
            "operation_id": context_ids.get("operation_id"),
            "request_id": context_ids.get("request_id"),
        }

    async def _async_wrapper(*args, **kwargs):
        agent_request = _extract_agent_request(args, kwargs)
        if agent_request is None:
            return await func(*args, **kwargs)

        operation_id = str(getattr(agent_request, "executionId", "")) or generate_operation_id()
        request_id = generate_request_id(operation_id)
        start_time = time.perf_counter()

        with operation_context(operation_id, request_id) as ctx:
            agent_data = _build_agent_data(agent_request, ctx)
            track_event("Agent_Execution_Started", agent_data)
            try:
                result = await func(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001
                execution_time = (time.perf_counter() - start_time) * 1000
                detail = getattr(exc, "detail", str(exc))
                status_code = getattr(exc, "status_code", 500)
                track_exception(
                    exc,
                    {
                        **agent_data,
                        "status_code": str(status_code),
                    },
                )
                track_event(
                    "Agent_Execution_Failed",
                    {
                        **agent_data,
                        "error_detail": detail,
                        "status_code": str(status_code),
                        "status": "FAILED",
                    },
                    {"execution_time_ms": execution_time},
                )
                track_metric(
                    "Agent_execution_duration",
                    execution_time,
                    {"agent_id": agent_data["agent_id"], "status": "FAILED"},
                )
                raise

            execution_time = (time.perf_counter() - start_time) * 1000
            track_event(
                "Agent_Execution_Completed",
                {**agent_data, "status": "SUCCESS"},
                {"execution_time_ms": execution_time},
            )
            track_metric(
                "Agent_execution_duration",
                execution_time,
                {"agent_id": agent_data["agent_id"], "status": "SUCCESS"},
            )
            return result

    def _sync_wrapper(*args, **kwargs):
        agent_request = _extract_agent_request(args, kwargs)
        if agent_request is None:
            return func(*args, **kwargs)

        operation_id = str(getattr(agent_request, "executionId", "")) or generate_operation_id()
        request_id = generate_request_id(operation_id)
        start_time = time.perf_counter()

        with operation_context(operation_id, request_id) as ctx:
            agent_data = _build_agent_data(agent_request, ctx)
            track_event("Agent_Execution_Started", agent_data)
            try:
                result = func(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001
                execution_time = (time.perf_counter() - start_time) * 1000
                detail = getattr(exc, "detail", str(exc))
                status_code = getattr(exc, "status_code", 500)
                track_exception(
                    exc,
                    {
                        **agent_data,
                        "status_code": str(status_code),
                    },
                )
                track_event(
                    "Agent_Execution_Failed",
                    {
                        **agent_data,
                        "error_detail": detail,
                        "status_code": str(status_code),
                        "status": "FAILED",
                    },
                    {"execution_time_ms": execution_time},
                )
                track_metric(
                    "Agent_execution_duration",
                    execution_time,
                    {"agent_id": agent_data["agent_id"], "status": "FAILED"},
                )
                raise

            execution_time = (time.perf_counter() - start_time) * 1000
            track_event(
                "Agent_Execution_Completed",
                {**agent_data, "status": "SUCCESS"},
                {"execution_time_ms": execution_time},
            )
            track_metric(
                "Agent_execution_duration",
                execution_time,
                {"agent_id": agent_data["agent_id"], "status": "SUCCESS"},
            )
            return result

    wrapper = _async_wrapper if is_coroutine else _sync_wrapper
    return wraps(func)(wrapper)