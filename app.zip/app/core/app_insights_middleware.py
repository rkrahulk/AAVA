# """
# Production Application Insights middleware for FastAPI.

# This middleware automatically tracks:
# - HTTP requests with proper operation IDs and correlation
# - Dependencies to external services
# - Performance metrics
# - Application Map data
# """

# import logging
# import os
# import time
# import uuid
# from starlette.middleware.base import BaseHTTPMiddleware
# from starlette.requests import Request

# from app.core.application_insights import (
#     get_application_insights,
#     generate_request_id,
#     pop_operation_context,
#     push_operation_context,
# )

# logger = logging.getLogger(__name__)

# class ApplicationInsightsMiddleware(BaseHTTPMiddleware):
#     """FastAPI middleware for automatic Application Insights tracking."""
    
#     def __init__(self, app, service_name: str = "aava-core-platform-agent-service"):
#         super().__init__(app)
#         self.service_name = service_name
    
#     async def dispatch(self, request: Request, call_next):
#         """Process request and track telemetry."""
#         app_insights = get_application_insights()
#         if not app_insights or not app_insights.enabled:
#             return await call_next(request)

#         # Extract or generate operation ID for correlation
#         # Try to get from incoming distributed tracing headers
#         operation_id = None
        
#         # Check for W3C traceparent header (standard format)
#         traceparent = request.headers.get("traceparent")
#         if traceparent:
#             try:
#                 # Format: version-traceid-parentid-flags
#                 parts = traceparent.split("-")
#                 if len(parts) >= 2:
#                     trace_id = parts[1]  # 32-char hex trace ID
#                     if len(trace_id) == 32:
#                         operation_id = trace_id
#             except Exception:  # noqa: BLE001
#                 pass
        
#         # Check for Request-Id header (Application Insights format)
#         if not operation_id:
#             request_id_header = request.headers.get("Request-Id") or request.headers.get("x-request-id")
#             if request_id_header:
#                 try:
#                     # Format: |traceid.spanid. or just traceid
#                     if request_id_header.startswith("|"):
#                         trace_id = request_id_header.split(".")[0].lstrip("|")
#                         if len(trace_id) == 32:
#                             operation_id = trace_id
#                     elif len(request_id_header) == 32:
#                         operation_id = request_id_header
#                 except Exception:  # noqa: BLE001
#                     pass
        
#         # Generate new operation ID if not found in headers
#         if not operation_id:
#             operation_id = str(uuid.uuid4()).replace('-', '')
        
#         preliminary_request_id = generate_request_id(operation_id)

#         # Start timing
#         start_time = time.perf_counter()
        
#         # Extract request info
#         method = request.method
#         url = str(request.url)
#         path = request.url.path
        
#         # Set operation ID in request state for downstream correlation
#         request.state.operation_id = operation_id

#         context_tokens = push_operation_context(operation_id, preliminary_request_id)

#         try:
#             # Process request
#             response = await call_next(request)
            
#             # Calculate duration using perf_counter for higher precision
#             duration = (time.perf_counter() - start_time) * 1000  # Convert to milliseconds
            
#             # Determine success
#             success = 200 <= response.status_code < 400
            
#             # Track request telemetry
#             tracking_info = app_insights.track_request(
#                 name=path,
#                 url=url,
#                 method=method,
#                 duration=duration,
#                 response_code=response.status_code,
#                 success=success,
#                 properties={
#                     "endpoint": path,
#                     "service": self.service_name,
#                     "user_agent": request.headers.get("user-agent", ""),
#                     "content_type": request.headers.get("content-type", "")
#                 },
#                 operation_id=operation_id
#             )

#             request_id = preliminary_request_id
#             if isinstance(tracking_info, dict):
#                 request_id = tracking_info.get("request_id") or preliminary_request_id
#             request.state.request_id = request_id

#             # Refresh context with the finalized request identifier for downstream telemetry
#             pop_operation_context(context_tokens)
#             context_tokens = push_operation_context(operation_id, request_id)
            
#             # Track dependencies based on endpoint
#             self._track_endpoint_dependencies(app_insights, path, operation_id, request_id)
            
#             # Track performance metrics
#             app_insights.track_metric(
#                 name="RequestDuration",
#                 value=duration,
#                 properties={
#                     "endpoint": path,
#                     "method": method,
#                     "status_code": response.status_code,
#                     "operation_id": operation_id,
#                     "request_id": request_id,
#                     "service": self.service_name,
#                 }
#             )
            
#             # Add correlation headers to response for traceability
#             response.headers["X-Operation-Id"] = operation_id
#             response.headers["X-Request-Id"] = request_id
#             response.headers["Request-Id"] = request_id
            
#             return response
            
#         except Exception as e:
#             # Calculate duration for failed requests using perf_counter
#             duration = (time.perf_counter() - start_time) * 1000
            
#             # Track failed request
#             tracking_info = app_insights.track_request(
#                 name=path,
#                 url=url,
#                 method=method,
#                 duration=duration,
#                 response_code=500,
#                 success=False,
#                 properties={
#                     "endpoint": path,
#                     "service": self.service_name,
#                     "error": str(e)
#                 },
#                 operation_id=operation_id
#             )

#             request_id = preliminary_request_id
#             if isinstance(tracking_info, dict):
#                 request_id = tracking_info.get("request_id") or preliminary_request_id
#             request.state.request_id = request_id
            
#             # Track exception
#             app_insights.track_exception(
#                 exception=e,
#                 properties={
#                     "endpoint": path,
#                     "method": method,
#                     "operation_id": operation_id,
#                     "request_id": request_id,
#                     "service": self.service_name,
#                 }
#             )
            
#             raise e
#         finally:
#             pop_operation_context(context_tokens)
    
#     def _track_endpoint_dependencies(self, app_insights, path: str, operation_id: str, request_id: str | None):
#         """Track downstream dependencies for specific endpoints."""
#         # Only track dependencies for specific endpoints to avoid noise
#         if path in ["/api/agent-tools", "/api/pipelines", "/api/health"]: # TODO
#             try:
#                 # Track database dependency
#                 app_insights.track_dependency(
#                     name="PostgreSQL",
#                     dependency_type="SQL",
#                     target=os.getenv("DATABASE_HOST", "postgres"),
#                     data="Database operations",
#                     duration=50,  # Estimated duration
#                     success=True,
#                     result_code="200",
#                     properties={
#                         "operation_id": operation_id,
#                         "parent_id": request_id,
#                         "endpoint": path,
#                         "dependency_type": "database"
#                     },
#                     operation_id=operation_id
#                 )
                
#                 # Track Redis dependency (if used)
#                 if os.getenv("REDIS_HOST"):
#                     app_insights.track_dependency(
#                         name="Redis Cache",
#                         dependency_type="Cache",
#                         target=os.getenv("REDIS_HOST", "redis"),
#                         data="Cache operations",
#                         duration=10,
#                         success=True,
#                         result_code="200",
#                         properties={
#                             "operation_id": operation_id,
#                             "parent_id": request_id,
#                             "endpoint": path,
#                             "dependency_type": "cache"
#                         },
#                         operation_id=operation_id
#                     )
                
#                 # Note: We explicitly DON'T track OpenLIT's internal GitHub requests
#                 # to keep the Application Map clean and focused on business dependencies
                
#             except (ConnectionError, TimeoutError) as e:
#                 logger.warning("Failed to track dependencies: %s", str(e))

# def setup_application_insights_middleware(app, service_name: str = "aava-core-platform-agent-service"):
#     """Set up Application Insights middleware for the FastAPI app."""
#     app.add_middleware(ApplicationInsightsMiddleware, service_name=service_name)
#     logger.info("✅ Application Insights middleware configured")