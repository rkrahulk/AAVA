import functools
import logging

from fastapi import HTTPException

logger = logging.getLogger(__name__)


def handle_agent_creation_exceptions(func):
    """
    Decorator for agent creation functions.
    Catches and logs known exceptions, publishes logs to Redis, and raises HTTPException with appropriate status codes.
    Also triggers CrewAI listeners for LLM config and agent errors.
    """
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            return await func(self, *args, **kwargs)
        
        except Exception as err:
            agent = getattr(err, "agent", "Unknown")
            detail = str(err.__class__.__name__)+" "+str(getattr(err, "detail", str(e)))
            execution_id = str(getattr(err, "execution_id", "Unknown"))
            status_code = str(getattr(err, "status_code", 500))

            logger.error(f"{detail} (agent creation context): {str((err, execution_id))}")

            self.pipeline_ai_logs.publishLogs(
                f"AAVA Agent Exception: {detail} - {str((err, execution_id))}",
                "red",
                redisClient=self.redis_client,
            )

            try:
                from app.services.crew_controller.listeners import log_agent_error
                log_agent_error(agent, err, None, execution_id)
            except Exception:
                pass

            raise HTTPException(
                status_code=status_code,
                detail=detail,
            )
    return wrapper
