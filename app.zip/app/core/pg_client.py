"""
PostgreSQL client for pipeline-core microservice.

Backward-compatible version:
- Supports LEGACY username/password DB connection (existing functionality)
- Adds IAM Authentication for Amazon RDS PostgreSQL
- Falls back to legacy DB if IAM fails
"""

import psycopg2
from psycopg2 import pool
import logging
import urllib.parse
import time
import threading
import boto3
import os
from app.core.config import settings as config

logger = logging.getLogger(__name__)

# SAFEGUARD: ENSURE CONFIG IS LOADED
if (config.APP_CONFIG_URL or config.COMMON_CONFIG_URL) and not config.DB_USER:
    try:
        config.load_remote_config()
    except Exception as e:
        logger.warning(f"pg_client attempted to load remote config but failed: {e}")

class PostgresClient:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialize()
        return cls._instance

    # INITIALIZATION
    def _initialize(self):
        raw_url = config.DB_URL or ""
        self.dbname = config.DB_NAME or ""

        # Robust URL Parsing
        parse_target = raw_url
        if "://" not in parse_target and not parse_target.startswith("//"):
            parse_target = f"//{parse_target}"

        try:
            parsed = urllib.parse.urlparse(parse_target)
            self.db_url = parsed.netloc if parsed.netloc else raw_url

            if not self.dbname and parsed.path:
                self.dbname = parsed.path.lstrip("/")

            extracted_host = parsed.hostname or self.db_url.split(':')[0]
            extracted_port = parsed.port or 5432
        except Exception:
            self.db_url = raw_url.strip("/")
            extracted_host = self.db_url
            extracted_port = 5432

        self.db_username = config.DB_USER
        self.db_password = config.DB_PASSWORD

        # IAM settings
        self.iam_user = config.IAM_DB_USER
        self.region = config.AWS_REGION
        self.db_host = config.IAM_DB_HOST or extracted_host
        self.db_port = config.IAM_DB_PORT or extracted_port
        self.IAM_TOKEN_REFRESH_INTERVAL = config.IAM_TOKEN_REFRESH_INTERVAL

        # Internal IAM state
        self._token = None
        self._token_lock = threading.Lock()
        self._stop_scheduler = threading.Event()
        self.connection_pool = None

        # Mode Check
        is_iam_mode = os.getenv("CLIENT_NAME", "NA").lower() == "hp"

        if is_iam_mode:
            logger.info(f"IAM authentication enabled. Target IAM User: {self.iam_user}")
            try:
                self._generate_iam_token()
                self._start_token_scheduler()
            except Exception as e:
                logger.error(f"IAM initialization failed: {e}")
                logger.warning("Falling back to legacy DB")
                self._initialize_legacy_pool()
        else:
            logger.info("IAM disabled — using legacy DB")
            self._initialize_legacy_pool()

    # LEGACY CONNECTION POOL
    def _initialize_legacy_pool(self):
        try:
            if not all([self.db_url, self.db_username, self.db_password]):
                raise ValueError("Missing legacy DB environment variables")

            encoded_password = urllib.parse.quote_plus(self.db_password)
            dsn = f"postgresql://{self.db_username}:{encoded_password}@{self.db_url}/{self.dbname}"

            logger.info(f"DEBUG: Initializing Legacy Pool for Host='{self.db_url}'")
            self.connection_pool = pool.SimpleConnectionPool(1, 10, dsn=dsn)
            logger.info("Legacy PostgreSQL pool initialized")
        except Exception as e:
            logger.error(f"Error initializing legacy PostgreSQL pool: {e}")
            raise e

    # IAM TOKEN
    def _generate_iam_token(self):
        with self._token_lock:
            try:
                client = boto3.client("rds", region_name=self.region)
                token = client.generate_db_auth_token(
                    DBHostname=self.db_host,
                    Port=self.db_port,
                    DBUsername=self.iam_user,
                )
                if not token:
                    raise ValueError("AWS RDS returned an empty auth token.")

                self._token = token
                logger.debug("IAM token refreshed")
            except Exception as e:
                logger.error(f"Failed to generate IAM token: {e}")
                raise e

    def _start_token_scheduler(self):
        def refresh_loop():
            interval_seconds = self.IAM_TOKEN_REFRESH_INTERVAL * 60
            while not self._stop_scheduler.is_set():
                time.sleep(interval_seconds)
                if self._stop_scheduler.is_set():
                    break
                try:
                    self._generate_iam_token()
                except Exception as e:
                    logger.error(f"Background IAM token refresh failed: {e}")

        t = threading.Thread(target=refresh_loop, daemon=True)
        t.start()
        logger.info("IAM token auto-refresh background thread started")

    # GET CONNECTION
    def get_connection(self):
        # Check Mode dynamically or via stored state
        if os.getenv("CLIENT_NAME", "NA").lower() == "hp":
            try:
                token_to_use = self._token
                if not token_to_use:
                    self._generate_iam_token()
                    token_to_use = self._token

                conn = psycopg2.connect(
                    host=self.db_host,
                    port=self.db_port,
                    user=self.iam_user,
                    password=token_to_use,
                    sslmode="require",
                    dbname=self.dbname,
                    connect_timeout=10,
                )
                return conn
            except Exception as e:
                logger.warning(f"IAM database auth failed: {e}")
                logger.warning("Falling back to legacy DB during connection")
                if not self.connection_pool:
                    self._initialize_legacy_pool()

        if self.connection_pool:
            return self.connection_pool.getconn()

        raise RuntimeError("No valid database connection available")

    # RELEASE CONNECTION
    def release_connection(self, conn):
        if self.connection_pool:
            try:
                self.connection_pool.putconn(conn)
            except Exception:
                conn.close()
        else:
            try:
                conn.close()
            except Exception:
                pass

    # SHUTDOWN
    def close_all_connections(self):
        self._stop_scheduler.set()
        if self.connection_pool:
            self.connection_pool.closeall()


# Instantiate only if persistent logging enabled
postgres_client = None
if config.PERSISTENT_LOGGING and config.PERSISTENT_LOGGING.lower() == "true":
    postgres_client = PostgresClient()