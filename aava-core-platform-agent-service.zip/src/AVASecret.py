import requests
import json
import logging
import boto3

from app.core.secret_manager import secret_manager
from app.core.config import settings, secrets_manager, mask_secret
from app.core.mongodb_client import assume_role_credentials
from aava.exception.custom.validation_exception import ValidationException

logger = logging.getLogger(__name__)


def _get_secret_via_aava_secrets(secret_key):
    logger.info(f"[AAVA_SECRETS] Lookup started for key: {secret_key}")

    if not secrets_manager:
        logger.warning("[AAVA_SECRETS] secrets_manager not initialized")
        return None

    standardized_key = secret_key.replace("_", "-")
    names_to_try = [
        secret_key,
        standardized_key,
        secret_key.lower(),
        standardized_key.lower()
    ]

    for name in names_to_try:
        try:
            logger.debug(f"[AAVA_SECRETS] Checking existence for: {name}")

            if secrets_manager.secret_exists(name):
                secret = secrets_manager.get_secret(name)
                logger.info(
                    f"[AAVA_SECRETS] Secret found for key={name}, value={mask_secret(secret)}"
                )
                return secret

        except Exception as e:
            logger.exception(f"[AAVA_SECRETS] Error while checking {name}: {e}")

    logger.warning(f"[AAVA_SECRETS] No secret found for key: {secret_key}")
    return None


def get_secret(secret_name):
    logger.info(f"[AWS_SECRETS] Fetching secret: {secret_name}")

    try:
        boto_client = get_session_client()
        logger.debug("[AWS_SECRETS] boto3 client created successfully")

        response = boto_client.get_secret_value(SecretId=secret_name)

        secret_string = response.get("SecretString")
        if secret_string:
            try:
                secret_dict = json.loads(secret_string)
                # If you expect a key inside the secret JSON
                logger.info("json_loaded")
                return secret_dict.get(secret_name)
            except json.JSONDecodeError:
                logger.info("json_not_loaded")
                # If the secret is just a plain string, not JSON
                return secret_string
        return None

    except Exception as e:
        logger.exception(f"[AWS_SECRETS] Failed to get secret: {secret_name}")
        raise Exception(
            f"Failed to get secret name - {secret_name} and error: {e}"
        )

def get_session_client():
    logger.info("[AWS_SESSION] Creating assumed role session client")

    creds = assume_role_credentials(
        role_arn=settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT,
        region=settings.AWS_REGION,
        session_name="pipeline-secrets-session"
    )

    logger.debug("[AWS_SESSION] Temporary credentials obtained")

    return boto3.client(
        "secretsmanager",
        region_name=settings.AWS_REGION,
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"]
    )


def getValue(secret_key):
    logger.info(f"[SECRET_FLOW] getValue called for key: {secret_key}")

    # Step 1: Try AAVA secrets (currently commented in your code)
    # secret = _get_secret_via_aava_secrets(secret_key)

    secret = None  # placeholder for now

    if secret:
        logger.info(f"[SECRET_FLOW] Secret resolved via AAVA secrets: {secret_key}")
        return secret

    logger.info(f"[SECRET_FLOW] Falling back to AWS Secrets Manager for: {secret_key}")

    secret = get_secret(secret_key)

    if secret:
        logger.info(f"[SECRET_FLOW] Secret successfully retrieved from AWS: {secret_key}")
        return secret

    logger.error(f"[SECRET_FLOW] Secret not found in any source: {secret_key}")

    raise ValidationException(f"Secret '{secret_key}' not found via any provider")