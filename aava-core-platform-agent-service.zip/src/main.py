import logging
import uvicorn
import gc
import sys
import asyncio
from contextlib import suppress

from fastapi import FastAPI

from app.core.config import settings
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from app.core.config import settings, exception_handler, setup_jwt_middleware, setup_logging_middleware

from app.dependencies import get_postgres_client, get_redis_client
from app.routes import router
from app.routes_v2 import v2_router

# 2. IMPORT APP MODULES (Now safe to import)
from app.routes import router
from app.dependencies import get_redis_client, get_postgres_client, get_mongodb_client
from aava.logging.aspect import setup_logging_middleware
from aava.security.jwt import setup_jwt_middleware
from aava.exception.handler import exception_handler

from app.core.mongodb_client import AsyncMongoDBClient


# 1. CONFIGURE LOGGING FIRST
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)  # Force output to stdout
    ],
    force=True  # Override any existing logging config
)
logger = logging.getLogger(__name__)


# Timeout middleware to prevent hanging requests
# Note: Gunicorn timeout is 600s, but application-level timeouts should be shorter
# to allow graceful error handling before Gunicorn kills the worker
class TimeoutMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        try:
            # Application-level timeout (shorter than Gunicorn's 600s)
            # Agent execution: 540s (9 min) - leaves 60s for cleanup before Gunicorn timeout
            # Other endpoints: 60s (1 min) - reasonable for API operations
            timeout = 60 if (request.url.path.startswith("/agent/v1/health") or request.url.path.startswith("/agent/v1/config-refresh")) else 1000
            return await asyncio.wait_for(call_next(request), timeout=timeout)
        except asyncio.TimeoutError:
            logger.error(f"Request timeout after {timeout}s: {request.url.path}")
            return JSONResponse(
                status_code=504,
                content={"detail": f"Request timeout - operation took longer than {timeout}s"}
            )


def lifespan(_app: FastAPI):
    """
    Application lifespan handler for FastAPI.
    Manages startup and shutdown with Gunicorn compatibility.
    
    Gunicorn settings (from Dockerfile):
    - graceful-timeout: 120s for clean shutdown
    - workers: 1 (single worker, async via UvicornWorker)
    - keep-alive: 75s for connection reuse
    """
    # Startup
    logger.info("Starting up application...")


async def lifespan(app: FastAPI):

    redis_client = get_redis_client()
    postgres_client = get_postgres_client()
    logger.info("Application startup complete")

    try:
        mongodb_client = get_mongodb_client()
    except Exception as e:
        logger.error(f"MongoDB client initialization failed at startup (non-fatal): {e}")
        mongodb_client = None

    logger.info("EventListener auto-registered via BaseEventListener.__init__() on import")

    logger.info("Lifespan initialization complete - app ready to start")

    yield

    # Graceful shutdown (must complete within 120s per Gunicorn config)
    logger.info("Shutting down gracefully (120s grace period)...")
    shutdown_start = asyncio.get_event_loop().time()
    
    try:
        # Close Redis client
        if settings.ENABLE_LOGSTREAMING if settings else False:
            if redis_client:
                with suppress(Exception):
                    redis_client.close()
                    logger.info("Redis client closed")

        # Close PostgreSQL connections
        if settings.PERSISTENT_LOGGING if settings else False:
            if postgres_client:
                with suppress(Exception):
                    postgres_client.close_all_connections()
                    logger.info("PostgreSQL connections closed")
        
        # Close HTTP client connections
        with suppress(Exception):
            from app.core.http_client import HTTPClientSingleton
            HTTPClientSingleton.close_all()
            logger.info("HTTP client connections closed")
        
        # Clean up EventListener memory
        with suppress(Exception):
            from app.services.crew_controller.EventListener import EventListeners
            # Clear any remaining execution states
            if hasattr(EventListeners, '_instance'):
                listener = EventListeners._instance
                if listener:
                    listener.metadata_hash.clear()
                    listener.agent_spans.clear()
                    listener.tool_spans.clear()
                    listener._run_state.clear()
                    logger.info("EventListener memory cleared")
        
        # Clean up temporary file manager
        with suppress(Exception):
            from app.helpers.temp_file_manager import TempFileManager
            TempFileManager.cleanup_all()
            logger.info("Temporary files cleaned up")
        
        # Force garbage collection to free memory
        gc.collect()
        logger.info(f"Garbage collection completed, freed {gc.collect()} objects")
        
        # Log memory usage before shutdown
        if hasattr(sys, 'getsizeof'):
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            logger.info(f"Memory usage at shutdown: RSS={memory_info.rss / 1024 / 1024:.2f}MB, VMS={memory_info.vms / 1024 / 1024:.2f}MB")
        
        shutdown_duration = asyncio.get_event_loop().time() - shutdown_start
        logger.info(f"Graceful shutdown completed in {shutdown_duration:.2f}s")
    except Exception as e:
        logger.error(f"Error during shutdown: {e}", exc_info=True)
        # Final cleanup attempt
        gc.collect()

    if mongodb_client:
        mongodb_client.close()


logger.info('API is starting up')

app = FastAPI(
    title="AAVA Core Platform Agent Service",
    description="Microservice for managing AI Agents, Tools, and their configurations. Acts as the central registry for agent behaviors and tool definitions used by the orchestration layer.",
    version=getattr(settings, 'SERVICE_VERSION', '1.0.0'),
    timeout=int(settings.REQUEST_TIMEOUT),
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
    openapi_url=None
)


# Add timeout middleware
app.add_middleware(TimeoutMiddleware)


def custom_openapi():
    """
    Custom OpenAPI schema generator that:
    1. Defines JWT Bearer authentication scheme
    2. Applies authentication globally to all endpoints
    3. Excludes health check endpoints from authentication requirement
    """
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Define JWT Bearer authentication scheme
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter your JWT token in the format: `<token>`"
        }
    }
    
    # Apply security to all endpoints except health checks
    # Health endpoints should be accessible without authentication
    public_paths = ["/health", "/health/ui"]
    
    for path, path_item in openapi_schema.get("paths", {}).items():
        # Check if this path should be public (no authentication)
        is_public = any(path.endswith(public_path) for public_path in public_paths)
        
        for method, operation in path_item.items():
            if method in ["get", "post", "put", "patch", "delete", "options", "head"]:
                if is_public:
                    # Explicitly mark as no security required
                    operation["security"] = []
                else:
                    # Require JWT Bearer authentication
                    operation["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ALLOWED_ORIGINS if settings else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



app.include_router(router, prefix="/agent/v1")
app.include_router(v2_router, prefix="/agent/v2")


setup_jwt_middleware(app)
setup_logging_middleware(app)
app.add_exception_handler(Exception, exception_handler(app))

if __name__ == "__main__":
    uvicorn.run(app=app)
