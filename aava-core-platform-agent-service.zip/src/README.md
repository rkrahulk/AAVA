# AAVA Core Platform Agent Service

AAVA Core Platform Agent Service is a backend microservice designed to orchestrate, execute, and monitor AI agent workflows using CrewAI, LLMs, and a modular tool system. It provides robust event tracking, error handling, and extensibility for building complex, multi-agent systems in enterprise environments.

---

> **Project Documentation & Codebase Comments**
>
> - All core service files (CrewAI agent creation, tool configuration, LLM factory, event listeners, and exception decorators) are now fully documented with clear comments and docstrings.
> - See `app/services/crew_controller/agent_creator.py`, `app/services/crew_controller/setup_agent_tools.py`, `app/services/crew_controller/listeners.py`, `app/services/crew_controller/exception_decorator.py`, and `app/services/llm_factory/llmfactory.py` for in-depth code explanations.
> - This documentation will help new contributors and maintainers quickly understand the architecture, event flow, and extensibility points for CrewAI integration.

---

## Table of Contents

- [Features](#features)
- [Architecture Overview](#architecture-overview)
- [CrewAI Listener Integration](#crewai-listener-integration)
- [Getting Started](#getting-started)
- [Configuration](#configuration)
- [Build and Test](#build-and-test)
- [Contribute](#contribute)
- [License](#license)

---

## Features

- **CrewAI Agent Orchestration:** Create, configure, and execute agents and tasks using CrewAI.
- **LLM Integration:** Supports Azure OpenAI, Amazon Bedrock, Google Vertex AI, and more.
- **Dynamic Tool System:** Register and use built-in and user-defined tools (file, SQL, web scraping, memory, RAG, etc).
- **Event Listeners:** Comprehensive observability for agent lifecycle, tool usage, LLM config, and errors.
- **Agent Workflow Execution:** Run multi-agent pipelines with step callbacks, logging, and error handling.
- **Extensible:** Easily add new tools, listeners, and agent types.

---

## Architecture Overview

- **FastAPI** backend exposing REST endpoints for pipeline and agent execution.
- **CrewAI** for agent, task, and crew abstractions.
- **LLM Factory** for dynamic LLM instantiation and validation.
- **Tool System** for modular, pluggable agent tools.
- **Event Listeners** for logging and monitoring agent/task/tool/LLM events.
- **Redis** for logging, caching, and workflow state.
- **Pydantic** for data validation and configuration schemas.

---

## CrewAI Listener Integration

This project includes comprehensive CrewAI listener integration for observability and event tracking across all major agent, tool, LLM, and workflow events.

### Listener Coverage

- **Agent Initialization:** Logs when an agent is instantiated.
- **Tool Registration:** Logs when a tool is added to an agent.
- **Task Start:** Logs when a CrewAI Task is created.
- **Agent Step Events:** Logs agent step completions and step outputs to Redis.
- **LLM Configuration Errors:** Logs errors during LLM configuration and validation.
- **Agent Errors:** Logs agent-related errors and exceptions during creation and execution.

### Extensibility

The listener system is designed to be extensible. Developers can add new listeners for additional CrewAI or workflow events by updating `app/services/crew_controller/listeners.py` and invoking them at the appropriate locations in the codebase.

---

## Getting Started

### Prerequisites

- Python 3.10+
- pip
- Redis server (for logging and caching)
- Access to supported LLM providers (Azure OpenAI, Amazon Bedrock, Google Vertex AI, etc.)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://ascendionava@dev.azure.com/ascendionava/AAVA/_git/aava-core-platform-agent-service
   cd aava-core-platform-agent-service
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment variables:**
   - Copy `env.example` to `.env` and fill in required values (API keys, Redis, etc).

4. **Start Redis server** (if not already running):
   ```bash
   redis-server
   ```

5. **Run the service:**
   ```bash
   python main.py
   ```

---

## Configuration

- **Environment Variables:** See `env.example` for all required and optional environment variables.
- **LLM Credentials:** Place LLM provider credentials in `genai-platform-creds.json` or as environment variables.
- **Pipeline/Agent Configuration:** Use the provided Pydantic models in `app/models/` to define agents, tools, and pipelines.

---

## Build and Test

### Build

No explicit build step is required. Ensure all dependencies are installed.

### Test

- **Unit Tests:** (Add your test instructions here if available)
- **Manual Testing:** Use the FastAPI endpoints to trigger agent and pipeline execution.

---

## Contribute

Contributions are welcome! To contribute:

1. Fork the repository.
2. Create a new branch for your feature or bugfix.
3. Make your changes and add tests as appropriate.
4. Submit a pull request describing your changes.

---

## License

[Specify your license here, e.g., MIT, Apache 2.0, etc.]

---

## References

- [CrewAI Documentation](https://github.com/joaomdmoura/crewAI)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Redis Documentation](https://redis.io/)
