"""
HTTP client singleton for efficient connection pooling.

Provides a reusable HTTP client with connection pooling to reduce
overhead from repeated connection establishment.
"""

import logging
import httpx

logger = logging.getLogger(__name__)


class HTTPClientSingleton:
    """
    Singleton HTTP client with connection pooling.
    
    Ensures only one HTTP client is created per process,
    reusing connections for better performance.
    """
    
    _client = None
    _async_client = None
    
    @classmethod
    def get_client(cls) -> httpx.Client:
        """
        Get or create the synchronous HTTP client instance.
        
        Returns:
            httpx.Client: Configured HTTP client with connection pooling
        """
        if cls._client is None:
            cls._client = httpx.Client(
                limits=httpx.Limits(
                    max_keepalive_connections=20,
                    max_connections=100,
                    keepalive_expiry=30
                ),
                timeout=httpx.Timeout(30.0),
                follow_redirects=True
            )
            logger.info(
                "HTTP client initialized with connection pooling: "
                "max_keepalive=20, max_connections=100"
            )
        return cls._client
    
    @classmethod
    def get_async_client(cls) -> httpx.AsyncClient:
        """
        Get or create the asynchronous HTTP client instance.
        
        Returns:
            httpx.AsyncClient: Configured async HTTP client with connection pooling
        """
        if cls._async_client is None:
            cls._async_client = httpx.AsyncClient(
                limits=httpx.Limits(
                    max_keepalive_connections=20,
                    max_connections=100,
                    keepalive_expiry=30
                ),
                timeout=httpx.Timeout(30.0),
                follow_redirects=True
            )
            logger.info(
                "Async HTTP client initialized with connection pooling: "
                "max_keepalive=20, max_connections=100"
            )
        return cls._async_client
    
    @classmethod
    def close_all(cls):
        """Close all HTTP clients."""
        if cls._client:
            cls._client.close()
            cls._client = None
            logger.info("HTTP client closed")
        if cls._async_client:
            import asyncio
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(cls._async_client.aclose())
                else:
                    loop.run_until_complete(cls._async_client.aclose())
            except Exception:
                pass
            cls._async_client = None
            logger.info("Async HTTP client closed")
