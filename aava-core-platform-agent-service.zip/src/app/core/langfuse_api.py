"""
Custom Langfuse API Integration (Agent Service)
Adapted from pipeline-service by: Saravanan Ramalingam

Purpose: Direct Langfuse API integration bypassing SDK callbacks
- Create traces via POST /api/public/traces
- Create/update observations via POST /api/public/ingestion
- Create scores via POST /api/public/scores
- No PATCH to /traces (unsupported in v3)
"""

import httpx
import logging
import base64
import json
import os
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
from app.core.config import load_remote_config, settings

logger = logging.getLogger(__name__)


def _iso_z(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


class LangfuseAPI:
    def __init__(self):
        host = getattr(settings, "LANGFUSE_HOST", "") or os.environ.get("LANGFUSE_HOST", "")
        self.api_base = host.rstrip('/') if host else ""
        self.public_key = getattr(settings, "LANGFUSE_PUBLIC_KEY", "") or os.environ.get("LANGFUSE_PUBLIC_KEY", "")
        self.secret_key = getattr(settings, "LANGFUSE_SECRET_KEY", "") or os.environ.get("LANGFUSE_SECRET_KEY", "")
        # Always enable for unified behavior
        self.enabled = True
        # Get environment from ConfigMap via LANGFUSE_ENV (default: "dev")
        self.environment = getattr(settings, "LANGFUSE_ENV", "dev") or os.environ.get("LANGFUSE_ENV", "dev") or "dev"
        logger.info(f"[Custom Langfuse][agent] Integration enabled (env={self.environment})")
        if not (self.api_base and self.public_key and self.secret_key):
            try:
                logger.info("[Custom Langfuse][agent] LANGFUSE_* missing; attempting AppConfig reload...")
                load_remote_config()
            except Exception as e:
                logger.warning(f"[Custom Langfuse][agent] AppConfig reload failed: {e}")
            # re-read after reload
            host = getattr(settings, "LANGFUSE_HOST", "") or os.environ.get("LANGFUSE_HOST", "")
            self.api_base = host.rstrip('/') if host else ""
            self.public_key = getattr(settings, "LANGFUSE_PUBLIC_KEY", "") or os.environ.get("LANGFUSE_PUBLIC_KEY", "")
            self.secret_key = getattr(settings, "LANGFUSE_SECRET_KEY", "") or os.environ.get("LANGFUSE_SECRET_KEY", "")
            logger.info(f"[Custom Langfuse][agent] Langfuse host {'set' if self.api_base else 'missing'} after reload")
        self._model_map = self._load_model_map()
        self._pricing = self._load_pricing()
        # Load server-side pricing configured in Langfuse (if any)
        try:
            self._refresh_pricing_from_langfuse()
        except Exception as e:
            logger.warning(f"[Custom Langfuse][agent] Failed to refresh pricing from Langfuse: {e}")
        self._excluded_patterns = self._load_exclusions()
        # Map span_id -> trace_id to ensure correct updates without brittle string parsing
        self._span_trace = {}
        try:
            self._ensure_langfuse_models()
        except Exception as e:
            logger.warning(f"[Custom Langfuse][agent] Failed to ensure model definitions: {e}")

    def _load_model_map(self) -> Dict[str, str]:
        try:
            mapping = {
                # OpenAI family
                "gpt-4o": "openai/gpt-4o",
                "gpt-4o-mini": "openai/gpt-4o-mini",
                "gpt-4-turbo": "openai/gpt-4-turbo",
                "gpt-4.1": "openai/gpt-4.1",
                "o1": "openai/o1",
                "o1-mini": "openai/o1-mini",
                "o3": "openai/o3",
                # Azure aliases
                "azure/gpt-4.1": "openai/gpt-4.1",
                "azure/gpt-4.1-2025-04-14": "openai/gpt-4.1",
                "azure/gpt-4o": "openai/gpt-4o",
                "azure/gpt-4o-mini": "openai/gpt-4o-mini",
                # Anthropic
                "claude-3-5-sonnet": "anthropic/claude-3.5-sonnet",
                "claude-3-5-haiku": "anthropic/claude-3.5-haiku",
                "claude-3-5-opus": "anthropic/claude-3.5-opus",
                "anthropic.claude-3-5-sonnet": "anthropic/claude-3.5-sonnet",
                "anthropic.claude-3-5-haiku": "anthropic/claude-3.5-haiku",
                # Google
                "gemini-1.5-pro": "google/gemini-1.5-pro",
                "gemini-1.5-flash": "google/gemini-1.5-flash",
            }
            return {k.lower(): v for k, v in mapping.items()}
        except Exception:
            return {}

    def _load_pricing(self) -> Dict[str, Dict[str, float]]:
        """Load default pricing, allow override via LANGFUSE_PRICING_JSON in env or settings."""
        defaults = {
            "openai/gpt-4o": {"input_per_1k": 0.005, "output_per_1k": 0.015},
            "openai/gpt-4o-mini": {"input_per_1k": 0.003, "output_per_1k": 0.006},
            "openai/gpt-4-turbo": {"input_per_1k": 0.01, "output_per_1k": 0.03},
            "openai/gpt-4.1": {"input_per_1k": 0.0, "output_per_1k": 0.0},
            "openai/o1": {"input_per_1k": 0.015, "output_per_1k": 0.06},
            "openai/o1-mini": {"input_per_1k": 0.005, "output_per_1k": 0.015},
            "openai/o3": {"input_per_1k": 0.025, "output_per_1k": 0.075},
            "anthropic/claude-3.5-sonnet": {"input_per_1k": 0.003, "output_per_1k": 0.015},
            "anthropic/claude-3.5-haiku": {"input_per_1k": 0.0008, "output_per_1k": 0.004},
            "google/gemini-1.5-pro": {"input_per_1k": 0.0035, "output_per_1k": 0.0105},
            "google/gemini-1.5-flash": {"input_per_1k": 0.00035, "output_per_1k": 0.00105},
        }
        try:
            raw = getattr(settings, "LANGFUSE_PRICING_JSON", None) or os.environ.get("LANGFUSE_PRICING_JSON", None)
            if raw:
                try:
                    override = json.loads(raw)
                    # normalize keys to lowercase for matching, but keep original form for display
                    normalized = {}
                    for k, v in (override.items() if isinstance(override, dict) else []):
                        if isinstance(v, dict):
                            normalized[k.lower()] = {"input_per_1k": float(v.get("input_per_1k", v.get("inputPrice", 0.0))), "output_per_1k": float(v.get("output_per_1k", v.get("outputPrice", 0.0)))}
                    # merge: overrides take precedence
                    for k, v in normalized.items():
                        defaults[k] = v
                    logger.info(f"[Custom Langfuse][agent] Loaded pricing overrides for {len(normalized)} models")
                except Exception as e:
                    logger.warning(f"[Custom Langfuse][agent] Failed to parse LANGFUSE_PRICING_JSON: {e}")
            return defaults
        except Exception:
            return defaults

    def _refresh_pricing_from_langfuse(self):
        """Fetch model pricing from Langfuse Models API and merge into local pricing map.
        This allows central pricing configuration in Langfuse UI to drive cost computation here.
        """
        try:
            res = self._make_request("models", method="GET")
            if isinstance(res, dict) and "data" in res and isinstance(res["data"], list):
                models = res["data"]
            else:
                models = res if isinstance(res, list) else []
            updated = 0
            for m in models:
                try:
                    name = (m.get("modelName") or m.get("name") or "").strip()
                    if not name:
                        continue
                    ip = float(m.get("inputPrice", 0.0) or 0.0)
                    op = float(m.get("outputPrice", 0.0) or 0.0)
                    if ip > 0.0 or op > 0.0:
                        self._pricing[name.lower()] = {"input_per_1k": ip, "output_per_1k": op}
                        updated += 1
                except Exception:
                    continue
            if updated:
                logger.info(f"[Custom Langfuse][agent] Refreshed pricing from Langfuse for {updated} models")
        except Exception as e:
            logger.warning(f"[Custom Langfuse][agent] Could not fetch models pricing from Langfuse: {e}")

    def _load_exclusions(self) -> List[str]:
        pats: List[str] = []
        try:
            raw = getattr(settings, "LANGFUSE_EXCLUDED_URL_PATTERNS", "") or ""
            if raw:
                pats.extend([p.strip().lower() for p in raw.split(",") if p.strip()])
        except Exception:
            pass
        for key in ("APP_CONFIG_API_URL", "COMMON_CONFIG_API_URL", "ADMIN_API_URL", "ADMIN_API_URL_V2_AGENT"):
            try:
                url = getattr(settings, key, "") or ""
                if url:
                    pats.append(url.lower())
            except Exception:
                pass
        pats.extend(["appconfig", "config-service", "/config", "/app-config", "/application/config", "admin/", "/workflow/history", "instructions"])
        dedup: List[str] = []
        for p in pats:
            if p and p not in dedup:
                dedup.append(p)
        return dedup

    def _is_excluded(self, name: Optional[str] = None, input_data: Any = None, metadata: Optional[Dict[str, Any]] = None) -> bool:
        pats = getattr(self, "_excluded_patterns", []) or []
        if not pats:
            return False
        def textify(obj: Any) -> str:
            try:
                if obj is None:
                    return ""
                if isinstance(obj, str):
                    return obj
                if isinstance(obj, (dict, list)):
                    return json.dumps(obj, ensure_ascii=False)
                return str(obj)
            except Exception:
                return str(obj)
        blob = (textify(name) + "\n" + textify(input_data) + "\n" + textify(metadata)).lower()
        for p in pats:
            if p and p in blob:
                logger.info(f"[Custom Langfuse][agent] Skipping logging due to excluded pattern '{p}'")
                return True
        return False

    def _make_request(self, endpoint: str, method: str = "POST", data: Dict = None) -> Optional[Dict]:
        if not self.enabled:
            return None
        try:
            if not self.api_base or not self.public_key or not self.secret_key:
                logger.warning("[Custom Langfuse][agent] Missing Langfuse configuration; skipping API call")
                return None
            url = f"{self.api_base}/api/public/{endpoint}"
            auth_base64 = base64.b64encode(f"{self.public_key}:{self.secret_key}".encode("utf-8")).decode("utf-8")
            headers = {"Authorization": f"Basic {auth_base64}", "Content-Type": "application/json"}
            
            # FIX: Use HTTPClientSingleton for connection pooling (3x faster)
            from app.core.http_client import HTTPClientSingleton
            client = HTTPClientSingleton.get_client()
            
            # Reduced timeout from 10s to 5s for faster failure detection
            if method == "POST":
                resp = client.post(url, json=data, headers=headers, timeout=5.0)
            elif method == "GET":
                resp = client.get(url, headers=headers, timeout=5.0)
            else:
                logger.warning(f"[Custom Langfuse][agent] Unsupported method '{method}', defaulting to POST")
                resp = client.post(url, json=data, headers=headers, timeout=5.0)
            
            logger.info(f"[Custom Langfuse][agent] API Response Status: {resp.status_code} for {method} {endpoint}")
            if resp.status_code >= 400:
                logger.error(f"[Custom Langfuse][agent] API Error Response: {resp.text}")
            resp.raise_for_status()
            if resp.content and len(resp.content) > 0:
                return resp.json()
            return {"ok": True, "status": resp.status_code}
        except httpx.TimeoutException:
            logger.warning(f"[Custom Langfuse][agent] API request timed out after 5s: {method} {endpoint}")
            return None
        except httpx.HTTPStatusError as e:
            logger.error(f"[Custom Langfuse][agent] HTTP error: {method} {endpoint} - {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response text: {e.response.text}")
            return None
        except Exception as e:
            logger.error(f"[Custom Langfuse][agent] Unexpected error: {str(e)}")
            return None

    def _ensure_langfuse_models(self):
        try:
            for model_name, prices in self._pricing.items():
                base = model_name.split("/", 1)[1] if "/" in model_name else model_name
                def esc(s: str) -> str:
                    return s.replace(".", "\\.")
                alias = {model_name, esc(base), f"azure(?:/|-|:)?{esc(base)}"}
                if model_name.startswith("openai/"):
                    alias.add(f"openai(?:/|-|:)?{esc(base)}")
                if model_name.startswith("google/"):
                    alias.add(f"google(?:/|-|:)?{esc(base)}")
                if model_name.startswith("anthropic/"):
                    alias.add(f"anthropic\\.{esc(base.replace('.', '-'))}")
                match_pattern = f"(?i)^(?:{'|'.join(sorted(alias))})$"
                body = {"modelName": model_name, "matchPattern": match_pattern, "unit": "TOKENS"}
                # Always set a non-zero price so Langfuse UI can compute/display cost. Use baseline if unknown.
                baseline_input = 0.005
                baseline_output = 0.015
                ip = float(prices.get("input_per_1k", 0.0)) if isinstance(prices, dict) else 0.0
                op = float(prices.get("output_per_1k", 0.0)) if isinstance(prices, dict) else 0.0
                body["inputPrice"] = ip if ip > 0 else baseline_input
                body["outputPrice"] = op if op > 0 else baseline_output
                self._make_request("models", method="POST", data=body)
        except Exception as e:
            logger.warning(f"[Custom Langfuse][agent] Model upsert failed: {e}")

    def map_model_name(self, raw_model: Optional[str]) -> Optional[str]:
        if not raw_model:
            return None
        m = raw_model.strip()
        k = m.lower()
        if k in self._model_map:
            return self._model_map[k]
        for prefix in ("azure-", "azure/", "azure:", "openai:", "openai-", "openai/", "bedrock:", "bedrock/", "google-", "google/", "google:"):
            if k.startswith(prefix):
                k = k[len(prefix):]
                m = m[len(prefix):]
        return m

    def compute_cost(self, prompt_tokens: int, completion_tokens: int, model: Optional[str]) -> float:
        """Compute cost using mapped model pricing. Falls back to baseline if model pricing unknown."""
        baseline_input = 0.005
        baseline_output = 0.015
        
        if not model:
            logger.warning(f"[Custom Langfuse][agent] No model provided; using baseline pricing for {prompt_tokens} prompt + {completion_tokens} completion tokens")
            cost = (prompt_tokens/1000.0)*baseline_input + (completion_tokens/1000.0)*baseline_output
            return round(cost, 6)
        mapped = self.map_model_name(model)
        prices = self._pricing.get(mapped.lower() if mapped else "")
        baseline_input = 0.005
        baseline_output = 0.015
        if not prices:
            # Try live refresh from Langfuse so we use centrally configured prices
            try:
                self._refresh_pricing_from_langfuse()
                prices = self._pricing.get(mapped.lower() if mapped else "")
            except Exception:
                pass
        if not prices:
            cost = (prompt_tokens/1000.0)*baseline_input + (completion_tokens/1000.0)*baseline_output
            logger.info(f"[Custom Langfuse][agent] Using baseline pricing for model '{model}' mapped '{mapped}': ${cost:.6f}")
            return round(cost, 6)
        ip = float(prices.get("input_per_1k", 0.0))
        op = float(prices.get("output_per_1k", 0.0))
        if ip <= 0.0 and op <= 0.0:
            cost = (prompt_tokens/1000.0)*baseline_input + (completion_tokens/1000.0)*baseline_output
            logger.info(f"[Custom Langfuse][agent] Model '{mapped}' has zero pricing; using baseline: ${cost:.6f}")
            return round(cost, 6)
        cost = (prompt_tokens/1000.0)*ip + (completion_tokens/1000.0)*op
        return round(cost, 6)

    def create_trace(self, agent_name: str, execution_id: str, input_data: Any = None, metadata: Dict[str, Any] = None, user_id: str = None, tags: List[str] = None, version: str = None, release: str = None, public: bool = False) -> Optional[str]:
        """Create trace - NO root observation for single agent (unlike pipeline service with crews)"""
        if not self.enabled:
            return None
        trace_data = {
            "id": execution_id,
            "name": f"{agent_name} - Execution",
            "sessionId": agent_name,
            "timestamp": _iso_z(datetime.now(timezone.utc)),
            "metadata": metadata or {},
            "public": public,
            "environment": self.environment,
            "userId": user_id or (metadata.get("user", "system") if metadata else "system"),
        }
        if input_data:
            trace_data["input"] = input_data
        if tags:
            trace_data["tags"] = tags
        
        # For single agent execution, only create the trace - NO root observation
        # EventListener will create agent/task/tool observations directly under trace
        create_res = self._make_request("traces", method="POST", data=trace_data)
        if create_res:
            logger.info(f"[Custom Langfuse][agent] Created trace for single agent: {agent_name} (ID: {execution_id})")
            return execution_id
        else:
            logger.error(f"[Custom Langfuse][agent] Failed to create trace")
            return None

    def create_span(self, trace_id: str, name: str, span_type: str = "GENERATION", parent_span_id: Optional[str] = None, metadata: Dict[str, Any] = None, input_data: Any = None, model: str = None, model_parameters: Dict[str, Any] = None, version: str = None, level: str = "DEFAULT", start_time: Optional[datetime] = None) -> Optional[Dict[str, Any]]:
        if not self.enabled:
            return None
        if self._is_excluded(name=name, input_data=input_data, metadata=metadata):
            return None
        span_id = f"{trace_id}_{name.replace(' ', '_')}_{int(datetime.now(timezone.utc).timestamp() * 1000)}"
        if start_time is None:
            start_time = datetime.now(timezone.utc)
        if not hasattr(self, "_span_types"):
            self._span_types = {}
        self._span_types[span_id] = span_type
        # Track owning trace for this span for reliable updates
        if not hasattr(self, "_span_trace"):
            self._span_trace = {}
        self._span_trace[span_id] = trace_id
        body = {
            "id": span_id,
            "traceId": trace_id,
            "name": name,
            "startTime": _iso_z(start_time),
            "metadata": metadata or {},
            "level": level,
            "environment": self.environment,
            "type": span_type if span_type in ("GENERATION", "SPAN") else "SPAN",
        }
        if parent_span_id:
            body["parentObservationId"] = parent_span_id
        if input_data is not None:
            body["input"] = input_data if isinstance(input_data, (str, dict)) else str(input_data)
        if version:
            body["version"] = version
        if span_type == "GENERATION":
            if model:
                mapped = self.map_model_name(model)
                body["model"] = mapped or model
                meta = body.get("metadata") or {}
                meta["modelOriginal"] = model
                if mapped:
                    meta["modelMapped"] = mapped
                body["metadata"] = meta
            if model_parameters:
                body["modelParameters"] = model_parameters
            body["completionStartTime"] = _iso_z(start_time)
        event_type = "generation-create" if span_type == "GENERATION" else "observation-create"
        ingestion_payload = {
            "batch": [{
                "id": f"{span_id}_create",
                "timestamp": _iso_z(datetime.now(timezone.utc)),
                "type": event_type,
                "body": body,
            }],
            "metadata": {"sdk_integration": "custom-python", "sdk_name": "aava-agent-service"}
        }
        res = self._make_request("ingestion", method="POST", data=ingestion_payload)
        if res:
            logger.info(f"[Custom Langfuse][agent] Created span: {name} (ID: {span_id}, type: {span_type})")
            return {"span_id": span_id, "start_time": start_time}
        return None

    def end_span(self, span_id: str, output_data: Any = None, tokens: int = 0, prompt_tokens: int = 0, completion_tokens: int = 0, cost: float = 0.0, level: str = "DEFAULT", start_time: Optional[datetime] = None, end_time: Optional[datetime] = None, update_timing: bool = True, model: Optional[str] = None):
        if not self.enabled:
            return
        if end_time is None:
            end_time = datetime.now(timezone.utc)
        if start_time and start_time.tzinfo is None:
            start_time = start_time.replace(tzinfo=timezone.utc)
        trace_id_hint = getattr(self, "_span_trace", {}).get(span_id)
        body = {"id": span_id, "level": level, "environment": self.environment, "type": "GENERATION" if getattr(self, "_span_types", {}).get(span_id) == "GENERATION" else "SPAN"}
        if trace_id_hint:
            body["traceId"] = trace_id_hint
        if update_timing:
            body["endTime"] = _iso_z(end_time)
        if getattr(self, "_span_types", {}).get(span_id) == "GENERATION" and start_time:
            body["completionStartTime"] = _iso_z(start_time)
        if output_data is not None:
            if isinstance(output_data, dict):
                out_str = json.dumps(output_data, ensure_ascii=False)
            else:
                out_str = output_data if isinstance(output_data, str) else str(output_data)
            body["output"] = out_str
            if getattr(self, "_span_types", {}).get(span_id) == "GENERATION":
                body["completion"] = out_str
        if tokens > 0:
            body["usage"] = {"promptTokens": prompt_tokens, "completionTokens": completion_tokens, "totalTokens": tokens}
        if getattr(self, "_span_types", {}).get(span_id) == "GENERATION" and model:
            mapped = self.map_model_name(model)
            body["model"] = mapped or model
            # Preserve original/mapped in metadata for debugging
            meta = body.get("metadata") or {}
            meta["modelOriginal"] = model
            if mapped:
                meta["modelMapped"] = mapped
            body["metadata"] = meta
        # Calculate/patch cost if missing
        if (not cost or cost == 0.0) and (tokens and tokens > 0):
            try:
                model_name = body.get("model")
                cost = float(self.compute_cost(prompt_tokens, completion_tokens, model_name)) if model_name else 0.0
            except Exception:
                cost = 0.0
        # Match pipeline service format: use costDetails and cost
        input_cost = (prompt_tokens / tokens * cost) if tokens > 0 else 0.0
        output_cost = (completion_tokens / tokens * cost) if tokens > 0 else 0.0
        body["costDetails"] = {
            "input": round(input_cost, 6),
            "output": round(output_cost, 6),
            "total": round(cost, 6)
        }
        body["cost"] = round(cost, 6)
        # Ensure observation type in body for updates
        body["type"] = "GENERATION" if getattr(self, "_span_types", {}).get(span_id) == "GENERATION" else "SPAN"
        # Use generation/observation update based on span type (Langfuse v3)
        is_gen = getattr(self, "_span_types", {}).get(span_id) == "GENERATION"
        event_type = "generation-update" if is_gen else "observation-update"
        ingestion_payload = {
            "batch": [{
                "id": f"{span_id}_update_{int(datetime.now(timezone.utc).timestamp() * 1000)}",
                "timestamp": _iso_z(datetime.now(timezone.utc)),
                "type": event_type,
                "body": body,
            }],
            "metadata": {"sdk_integration": "custom-python", "sdk_name": "aava-agent-service"}
        }
        self._make_request("ingestion", method="POST", data=ingestion_payload)

    def update_trace(self, trace_id: str, total_tokens: int = 0, prompt_tokens: int = 0, completion_tokens: int = 0, total_cost: float = 0.0, output_data: Any = None, end_time: Optional[datetime] = None, model: Optional[str] = None, model_parameters: Optional[Dict[str, Any]] = None):
        """Update trace with usage data using ingestion API (Langfuse v3 approach)
        Additionally sets model on the final generation so Langfuse can compute/display costs/tokens reliably in UI.
        """
        if not self.enabled:
            return
        
        try:
            # Smart output extraction
            def _normalize_output(data: Any):
                if data is None:
                    return "No output generated"
                if isinstance(data, str):
                    return data.strip() if data.strip() else "Empty output"
                if isinstance(data, dict):
                    for key in ["output", "result", "answer", "response", "text", "content", "message", "final_answer"]:
                        if key in data:
                            value = data[key]
                            if value is not None and str(value).strip():
                                return _normalize_output(value)
                    if data:
                        output_parts = []
                        for key, value in data.items():
                            if value is not None:
                                clean_key = key.strip("()").strip()
                                value_str = str(value).strip()
                                if clean_key and value_str:
                                    output_parts.append(f"{clean_key}: {value_str}")
                        if output_parts:
                            return "\n".join(output_parts)
                    try:
                        json_output = json.dumps(data, ensure_ascii=False, indent=2)
                        return json_output if json_output and json_output != "{}" else "Empty dict output"
                    except:
                        return "Dict output (serialization failed)"
                result = str(data)
                return result if result.strip() else "Empty output"
            
            # Create/update final generation observation
            final_obs_id = f"{trace_id}_final_generation"
            now_utc = datetime.now(timezone.utc)
            now_iso = _iso_z(now_utc)
            now_ms = int(now_utc.timestamp() * 1000)
            
            trace_end_time = _iso_z(end_time) if end_time else now_iso
            
            # Create final generation
            generation_create_body = {
                "id": final_obs_id,
                "traceId": trace_id,
                "name": "Final Output",
                "startTime": trace_end_time,
                "endTime": trace_end_time,
                "environment": self.environment,
                "type": "GENERATION",
            }
            if model:
                mapped = self.map_model_name(model)
                generation_create_body["model"] = mapped or model
                # Preserve original and mapped model names for troubleshooting
                generation_create_body.setdefault("metadata", {})
                generation_create_body["metadata"].update({"modelOriginal": model})
                if mapped:
                    generation_create_body["metadata"]["modelMapped"] = mapped
            if model_parameters:
                generation_create_body["modelParameters"] = model_parameters
            
            generation_create_event = {
                "id": f"{final_obs_id}_create_{now_ms}",
                "timestamp": now_iso,
                "type": "generation-create",
                "body": generation_create_body
            }
            
            # Update with aggregated data
            generation_update_body = {
                "id": final_obs_id,
                "traceId": trace_id,
                "output": _normalize_output(output_data),
                "endTime": trace_end_time,
                "environment": self.environment,
                "type": "GENERATION",
            }
            if model:
                mapped = self.map_model_name(model)
                generation_update_body["model"] = mapped or model
            if total_tokens > 0:
                generation_update_body["usage"] = {
                    "promptTokens": prompt_tokens,
                    "completionTokens": completion_tokens,
                    "totalTokens": total_tokens
                }
                generation_update_body["usageDetails"] = {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens
                }
            
            # Calculate/patch cost if missing or zero
            if (not total_cost or total_cost == 0.0) and (total_tokens and total_tokens > 0):
                try:
                    model_name = generation_update_body.get("model")
                    total_cost = float(self.compute_cost(prompt_tokens, completion_tokens, model_name)) if model_name else 0.0
                except Exception:
                    total_cost = 0.0
            # Match pipeline service format: use costDetails and cost
            input_cost = (prompt_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
            output_cost = (completion_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
            generation_update_body["costDetails"] = {
                "input": round(input_cost, 6),
                "output": round(output_cost, 6),
                "total": round(total_cost, 6)
            }
            generation_update_body["cost"] = round(total_cost, 6)
            
            generation_update_event = {
                "id": f"{final_obs_id}_update_{now_ms}",
                "timestamp": now_iso,
                "type": "generation-update",
                "body": generation_update_body
            }
            
            ingestion_payload = {
                "batch": [generation_create_event, generation_update_event],
                "metadata": {"sdk_integration": "custom-python", "sdk_name": "aava-agent-service"}
            }
            
            result = self._make_request("ingestion", method="POST", data=ingestion_payload)
            if result:
                logger.info(f"[Custom Langfuse][agent] Updated trace {trace_id} (tokens: {total_tokens}, cost: ${total_cost:.4f}, model={model})")
            else:
                logger.error(f"[Custom Langfuse][agent] Failed to update trace {trace_id}")
                
        except Exception as e:
            logger.error(f"[Custom Langfuse][agent] Failed to update trace: {e}")

    def create_score(self, trace_id: str, name: str, value: float | bool, observation_id: str = None, comment: str = None, data_type: str = "NUMERIC"):
        if not self.enabled:
            return
        # Coerce value type based on data_type to fit Langfuse expectations
        if data_type == "BOOLEAN":
            # Use integer 1/0 for boolean scores (Langfuse API expects 1 or 0, not True/False or 1.0/0.0)
            coerced_value = 1 if bool(value) else 0
        else:
            try:
                coerced_value = float(value)
            except Exception:
                coerced_value = 0.0
        payload = {"traceId": trace_id, "name": name, "value": coerced_value, "dataType": data_type, "environment": self.environment}
        if observation_id:
            payload["observationId"] = observation_id
        if comment:
            payload["comment"] = comment
        self._make_request("scores", method="POST", data=payload)


_langfuse_api_instance = None

def get_langfuse_api() -> LangfuseAPI:
    global _langfuse_api_instance
    if settings.CUSTOM_LANGFUSE_ENABLED :
        if _langfuse_api_instance is None:
            _langfuse_api_instance = LangfuseAPI()
        return _langfuse_api_instance
