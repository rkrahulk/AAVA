"""
Unified configuration management for pipeline-core.

- All configuration is loaded from environment variables (.env file) or a configuration service.
- No hardcoded values: defaults should be set in .env, not in code.
- If CONFIG_SERVICE_API_URL is set, config is fetched from the remote service and overrides .env values.
- If CONFIG_REFRESH_ENABLED is true, config is periodically refreshed from the config service.
- This pattern should be used in all microservices for unified config management.

See .env.example for all available variables and documentation.
"""

import logging
import os, json
import threading
import time

import dotenv
import httpx
from typing import Optional
from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings

from contextvars import ContextVar
from logging import Filter, LogRecord

execution_id_var: ContextVar[str] = ContextVar('execution_id', default=None)

dotenv.load_dotenv()

logger = logging.getLogger("__name__")

def mask_secret(secret: Optional[str]) -> str:
    """Mask sensitive information in logs: show first 2 and last 2 characters."""
    if not secret:
        return "****"
    s = str(secret)
    if len(s) <= 4:
        return "*" * len(s)
    return f"{s[:2]}{'*' * (len(s) - 4)}{s[-2:]}"

def should_mask(key: str) -> bool:
    """Check if a configuration key should be masked in logs."""
    mask_keywords = {"PASSWORD", "SECRET", "KEY", "TOKEN", "AUTH", "CREDENTIAL"}
    return any(keyword in key.upper() for keyword in mask_keywords)

try:
    from aava_secrets import create_secrets_manager_from_env
    secrets_manager = create_secrets_manager_from_env(True)
except Exception as e:
    secrets_manager = None
    logger.warning(f"Could not initialize aava_secrets manager: {e}")

def fetch_password_secret(password_field: str, current_value: Optional[str] = None) -> Optional[str]:
    """Retrieve password from aava_secrets if available, checking multiple naming conventions."""
    if not secrets_manager:
        return current_value

    standardized_key = password_field.replace("_", "-")
    names_to_try = [
        password_field,                # Original: REDIS_PASSWORD
        standardized_key,              # Hyphenated: REDIS-PASSWORD
        password_field.lower(),       # Lowercase: redis_password
        standardized_key.lower()      # Lowercase hyphenated: redis-password
    ]

    for name in names_to_try:
        try:
            if secrets_manager.secret_exists(name):
                secret = secrets_manager.get_secret(name)
                logger.info(f"Found secret for {name}: {mask_secret(secret)}")
                return secret
        except Exception:
            continue
        
    logger.info(f"Could not find secret value for {password_field}")
    return current_value

settings = None
common_config_message = ""
app_config_message = ""
_default_message = ""
config_setup_completed = False

config_metadata = dict(
    COMMON_CONFIG_API_URL=(True, "Successfully Loaded Common Config", os.environ.get("COMMON_CONFIG_API_URL")),
    APP_CONFIG_PLATFORM_URL=(True, "Successfully Loaded App Config", os.environ.get("APP_CONFIG_PLATFORM_URL"))
)

class ExecutionIdMessageFilter(Filter):
    """
    Filter that modifies the log message to include execution_id.
    This appends to msg before formatting happens.
    """
    def filter(self, record: LogRecord) -> bool:
        exec_id = execution_id_var.get()
        if exec_id:
            record.msg = f"[{exec_id}] {record.msg}"
        return True
 
def add_execution_id_filter():
    logger = logging.getLogger()

    for handler in logger.handlers:
        handler.addFilter(ExecutionIdMessageFilter())
        print(f"✓ Added ExecutionIdMessageFilter to handler: {handler}")

def fetch_config_from_url(url: str, config_type: str) -> dict:
    """
    Fetch configuration from a remote URL with proper operation context.
    Args:
        url: The configuration service URL
        config_type: Type of config being loaded (for logging: "common" or "app-specific")
    Returns:
        dict: Dictionary of configuration key-value pairs
    Raises:
        Exception: If the HTTP request fails or returns an error status
    """
    try:
        resp = httpx.get(url, timeout=5)
        if resp.status_code >= 400:
            raise Exception(f"Failed to load config for the service as: {resp.content}")
        remote_config = resp.json()
        loaded_configs = {}
        for item in remote_config:
            key = item.get("configKey")
            value = item.get("configValue")
            if key:
                loaded_configs[key] = value
        return loaded_configs
        
    except Exception as e:
        raise e.__class__(f"Load failed for {config_type} as: {str(e)}")


def load_remote_config() -> None:
    """
    Load configuration from remote services in priority order.
    
    1. First load COMMON_CONFIG_API_URL (if set) - shared/common configurations
    2. Then load APP_CONFIG_API_URL (if set) - app-specific configurations that override common
    All configurations are loaded into environment variables.
    Raises:
        Exception: If required config URLs are not set in environment
    """
    global common_config_message
    global app_config_message
    global config_metadata

    for _type, metadata in config_metadata.items():
        url = metadata[-1]
        try:
            if not url:
                raise Exception(f"{_type} url not set in the environment")
            configs = fetch_config_from_url(url, _type)
            for key, value in configs.items():
                os.environ[key] = str(value)
                display_value = mask_secret(str(value)) if should_mask(key) else value
                message = f"{key}: {display_value}\n"
                if _type == "COMMON_CONFIG_API_URL":
                    common_config_message += f"COMMON CONFIG - {message}"
                else:
                    app_config_message += f"APP CONFIG - {message}"
        except Exception as e:
            config_metadata[_type] = (False, "Failed to load config as: " + str(e), url)


class PlatformSettings(BaseModel):
    BASE_API_URL: str = Field(
        description="Base URL for the primary platform service API"
    )
    ADMIN_API_URL_V2_AGENT: str = Field(
        default="/agents/execute",
        description="Admin API v2 endpoint URL for agent management operations"
    )
    API_AGENT_EXECUTION_STATUS: str = Field(
        default="/agents/execute/status",
        description="service endpoint for updating agent execution status"
    )
    API_AGENT_ADMIN_URL: str = Field(
        default="/agents/execute/output",
        description="service endpoint to update the final agent execution output"
    )
    API_AGENT_LOGS_ENDPOINT: Optional[str] = Field(
        default="/agents/execute/logs",
        description="service endpoint to update the final agent execution output"
    )
    AGENT_LOGS_BASIC_AUTH: Optional[str] = Field(
        default="YWRtaW46YWRtaW4xMjM=",
        description="Basic authentication for workflow logs endpoint (optional)"
    )
    TIKA_API_URL: str = Field(
        default="/tika/api/documents/process",
        description="Apache Tika service endpoint for document parsing and text extraction"
    )
    GUARDRAILS_PLATFORM_URL: str = Field(
        default="/guardrails/v1/validate",
        description="Guardrails service endpoint for content validation and safety checks"
    )
    ADMIN_DOWNLOAD_API_URL: Optional[str] = Field(
        default="workflows/history/download-file",
        description="Admin service endpoint for file download operations (optional)"
    )
    ADMIN_UPLOAD_API_URL: Optional[str] = Field(
        default="workflows/history/upload-file",
        description="Admin service endpoint for file upload operations (optional)"
    )

    MODELS_USES_OPENAI_RESPONSE_API: Optional[str] = Field(
        default="",
        description="Models which uses (openai/responses) api"
    )


class RedisSettings(BaseModel):
    REDIS_HOST: Optional[str] = Field(
        None,
        description="Redis server hostname or IP address"
    )
    REDIS_PORT: Optional[str] = Field(
        None,
        description="Redis server port number (typically 6379)"
    )
    REDIS_PASSWORD: Optional[str] = Field(
        None,
        description="Redis authentication password for secure connections"
    )
    REDIS_SSL: Optional[str] = Field(
        None,
        description="Enable SSL/TLS for Redis connections (true/false)"
    )
    ENABLE_LOGSTREAM: Optional[bool] = Field(
        default=False,
        description="Enable Redis-based log streaming functionality"
    )

    @model_validator(mode="after")
    def validate_redis(self):
        """Validate Redis settings when log streaming is enabled."""
        self.REDIS_PASSWORD = fetch_password_secret("REDIS_PASSWORD", self.REDIS_PASSWORD)
        if self.ENABLE_LOGSTREAM:
            if not all([
                self.REDIS_HOST,
                self.REDIS_PASSWORD,
                self.REDIS_PORT,
            ]):
                raise Exception("❌ Redis configurations missing for enabled logstream")
        return self


class DatabaseSettings(BaseModel):
    DB_URL: Optional[str] = Field(
        default="", 
        description="Database connection URL (e.g., postgresql://host:port/dbname)"
    )
    DB_USER: Optional[str] = Field(
        default="", 
        description="Database username for authentication"
    )
    DB_PASSWORD: Optional[str] = Field(
        default="", 
        description="Database password for authentication"
    )


class LangfuseSettings(BaseModel):
    LANGFUSE_PUBLIC_KEY: Optional[str] = Field(
        default="", 
        description="Langfuse public API key for authentication"
    )
    LANGFUSE_SECRET_KEY: Optional[str] = Field(
        default="", 
        description="Langfuse secret API key for authentication"
    )
    LANGFUSE_HOST: Optional[str] = Field(
        default="", 
        description="Langfuse server URL (e.g., https://cloud.langfuse.com)"
    )
    LANGFUSE_ENV: Optional[str] = Field(
        default="dev", 
        description="Langfuse environment label (dev, staging, prod)"
    )
    LANGFUSE_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable Langfuse tracing for LLM observability"
    )
    CUSTOM_LANGFUSE_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable custom Langfuse implementation with additional features"
    )    
    LANGFUSE_OTEL_EXPORT_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable custom Langfuse implementation with additional features"
    )

    @model_validator(mode="after")
    def validate_langfuse(self):
        """Validate Langfuse credentials when tracing is enabled."""
        self.LANGFUSE_PUBLIC_KEY = fetch_password_secret("LANGFUSE_PUBLIC_KEY", self.LANGFUSE_PUBLIC_KEY)
        self.LANGFUSE_SECRET_KEY = fetch_password_secret("LANGFUSE_SECRET_KEY", self.LANGFUSE_SECRET_KEY)
        
        if self.LANGFUSE_ENABLED or self.CUSTOM_LANGFUSE_ENABLED or self.LANGFUSE_OTEL_EXPORT_ENABLED:
            if not all([
                self.LANGFUSE_PUBLIC_KEY,
                self.LANGFUSE_HOST,
                self.LANGFUSE_SECRET_KEY
            ]):
                raise Exception("❌ Langfuse configurations missing for Langfuse enabled")
        return self


class KafkaSettings(BaseModel):
    BOOTSTRAP_SERVER: Optional[str] = Field(
        default="", 
        description="Kafka broker address (e.g., localhost:9092 or kafka.example.com:9093)"
    )
    SECURITY_PROTOCOL: Optional[str] = Field(
        default="", 
        description="Kafka security protocol (PLAINTEXT, SASL_SSL, SASL_PLAINTEXT, SSL)"
    )
    SASL_MECHANISHM: Optional[str] = Field(
        default="", 
        description="SASL authentication mechanism (PLAIN, SCRAM-SHA-256, SCRAM-SHA-512)"
    )
    SASL_PLAIN_USERNAME: Optional[str] = Field(
        default="", 
        description="SASL username for Kafka authentication"
    )
    SASL_PLAIN_PASSWORD: Optional[str] = Field(
        default="", 
        description="SASL password for Kafka authentication"
    )
    AGENT_TOPIC: Optional[str] = Field(
        default="", 
        description="Kafka topic name for agent event messages"
    )
    KAFKA_AGENT_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable Kafka-based agent event streaming"
    )

    @model_validator(mode="after")
    def validate_kafka(self):
        """Validate Kafka settings when agent streaming is enabled."""
        self.SASL_PLAIN_PASSWORD = fetch_password_secret("SASL_PLAIN_PASSWORD", self.SASL_PLAIN_PASSWORD)
        if self.KAFKA_AGENT_ENABLED:
            if not all([
                self.BOOTSTRAP_SERVER,
                self.SECURITY_PROTOCOL,
                self.AGENT_TOPIC
            ]):
                raise Exception("❌ Kafka configurations missing for Kafka enabled")
        return self


class TrulensSettings(BaseModel):
    TRULENS_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable TruLens for LLM evaluation and monitoring"
    )
    TRULENS_PLATFORM_URL: Optional[str] = Field(
        default="", 
        description="TruLens service endpoint URL for evaluation requests"
    )

    @model_validator(mode="after")
    def validate_trulens(self):
        """Validate TruLens URL when TruLens is enabled."""
        if self.TRULENS_ENABLED and not self.TRULENS_PLATFORM_URL:
            raise Exception("❌ TruLens URL missing for TruLens enabled")
        return self

class RAGSettings(BaseModel):
    RAG_API_URL: Optional[str] = Field(
        default="https://aava-dev.avateam.io/agents/rag/query-hybrid", 
        description="RAG API endpoint URL for knowledge retrieval"
    )

class StarterPackageSettings(BaseModel):
    AAVA_CORE_ENABLED: Optional[bool] = Field(
        default=True, 
        description="Enable AAVA Python Starter functionality"
    )
    AAVA_LOGGING_ENABLED: Optional[bool] = Field(
        default=True, 
        description="Enable AAVA logging and configuration in Starter Package"
    )
    AAVA_LOGGING_APP_NAME: Optional[str] = Field(
        default="aava-core-platform-guardrails-service", 
        description="Application name identifier for log entries"
    )
    AAVA_LOGGING_ENVIRONMENT: Optional[str] = Field(
        default="LOCAL", 
        description="Deployment environment (LOCAL, DEV, STAGING, PROD)"
    )
    AAVA_LOGGING_JSON_FORMAT: Optional[bool] = Field(
        default=True, 
        description="Output logs in JSON format for structured logging"
    )
    AAVA_LOGGING_CONSOLE_ENABLED: Optional[bool] = Field(
        default=True, 
        description="Enable logging output to console/stdout"
    )
    AAVA_LOGGING_FILE_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable logging output to file"
    )
    AAVA_LOGGING_FILE_PATH: Optional[str] = Field(
        default="logs/app.log", 
        description="File path for log output when file logging is enabled"
    )
    AAVA_LOGGING_ASPECT_ENABLED: Optional[bool] = Field(
        default=True, 
        description="Enable aspect-oriented programming (AOP) for automatic logging decorators"
    )

    # Performance Logging
    AAVA_LOGGING_PERFORMANCE_ENABLED: Optional[bool] = Field(
        default=True, 
        description="Enable performance monitoring and logging"
    )
    AAVA_LOGGING_PERFORMANCE_SLOW_THRESHOLD: Optional[int] = Field(
        default=1000, 
        ge=0, 
        description="Threshold in milliseconds for flagging slow operations"
    )
    AAVA_LOGGING_PERFORMANCE_LOG_DATABASE_OPERATIONS: Optional[bool] = Field(
        default=True, 
        description="Log performance metrics for database queries and operations"
    )
    AAVA_LOGGING_PERFORMANCE_LOG_METHOD_EXECUTIONS: Optional[bool] = Field(
        default=True, 
        description="Log performance metrics for method/function executions"
    )

    # JWT Security
    AAVA_SECURITY_JWT_ENABLED: Optional[bool] = Field(
        default=False, 
        description="Enable JWT-based authentication and authorization"
    )
    LIBRARY_ENDPOINT_EXCEPTIONS: Optional[str] = Field(
        default="health,docs,openapi,rapidoc,openapi.json", 
        description="Comma-separated list of endpoint paths exempt from JWT authentication"
    )


class MCPSettings(BaseModel):
    MCP_CONFIG_API_URL: Optional[str] = Field(default="", description="Common Configuration for MCP")
    MCP_ENABLED: Optional[bool] = Field(default=False, description="MCP Flag")
    MCP_SERVER_API_URL: Optional[str] = Field(default="", description="MCP Server URI")
    MCP_TIMEOUT: Optional[int] = Field(default=1000, description="MCP Server Timeout")

    @model_validator(mode="after")
    def validate_mcp(self):
        if self.MCP_CONFIG_API_URL:
            mcp_status_response = httpx.get(url=self.MCP_CONFIG_API_URL)
            logger.info("mcp_status_response MCP",mcp_status_response)
            if mcp_status_response.status_code == 200:
                for config in mcp_status_response.json():
                    if config.get("configKey") == "aava.mcp.enable":
                        logger.info("enabling MCP test",config)
                        self.MCP_ENABLED = str(config.get("configValue")).lower() in ("true", 1, "yes")
        if self.MCP_ENABLED and not self.MCP_SERVER_API_URL:
            raise Exception("❌ MCP SERVER API URL configuration missing")
    
        return self

class Settings(
        BaseSettings,
        PlatformSettings,
        RedisSettings,
        DatabaseSettings,
        LangfuseSettings,
        StarterPackageSettings,
        KafkaSettings,
        TrulensSettings,
        MCPSettings,
        RAGSettings
    ):
    """Settings class for pipeline-core microservice."""

    class Config:
        env_file = "/app/.env"
        extra = "ignore"

    ENABLE_LOGSTREAMING: bool = Field(
        default=False,
        description="Enable log streaming functionality"
    )
    PERSISTENT_LOGGING: bool = Field(
        default=False,
        description="Enable persistent logging to storage"
    )

    AAVA_LOG_SOURCE_TYPE: str = Field(
        default="kafka",
        description="Enable persistent logging to storage"
    )
    USE_BEDROCK_CREDENTIALS: bool = Field(
        default=False,
        description="Use AWS Bedrock credentials for authentication"
    )
    USE_SYSTEM_PROMPT: bool = Field(
        default=True,
        description="Use system prompt in LLM interactions"
    )
    CONFIG_REFRESH_ENABLED: bool = Field(
        default=False,
        description="Enable automatic configuration refresh from remote sources"
    )
    CONFIG_REFRESH_INTERVAL: int = Field(
        default=300,
        ge=60,
        description="Configuration refresh interval in seconds (minimum 60)"
    )
    LOG_LEVEL: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)"
    )
    REQUEST_TIMEOUT: int = Field(
        default=1000,
        description="HTTP request timeout in milliseconds"
    )
    CORS_ALLOWED_ORIGINS: str = Field(
        default="*",
        description="Comma-separated list of allowed CORS origins"
    )

    # ==================== ADDED CONFIG BLOCK ====================

    # AWS IAM Authentication
    IAM_DB_HOST: str = ""
    IAM_DB_PORT: int = 5432
    DB_NAME: str = ""
    IAM_DB_USER: str = ""
    AWS_REGION: str = ""
    IAM_TOKEN_REFRESH_INTERVAL: int = 13

    # SYSTEM GUARDRAILS
    SYSTEM_GUARDRAILS_ENABLED: bool = False 

    # ==================== HP OBO SETTINGS ====================
    OBO_API_BASE_URL: str = ""

    IAM_AUTH_ENABLED: str = "False"

    MONGODB_URI: str = ""
    MONGODB_DATABASE: str = ""
    MONGODB_COLLECTION: str = ""
    MONGODB_INDEX: str = ""

    MONGODB_HOST: str = ""
    MONGODB_PORT: str = ""
    MONGODB_USERNAME: str = ""
    MONGODB_PASSWORD: str = ""
    MONGODB_AUTH_SOURCE: str = ""

    AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT: str = ""

    # Tools - Base URLs allow lists
    GITHUB_BASE_URL: str = ""
    JIRA_BASE_URL: str = ""
    TEST_RAIL_CONNECTOR_BASE_URL: str = ""

    # Tools output System guardrails validation
    GITHUB_GUARDRAIL_VALIDATION_ENABLED: bool = False
    JIRA_GUARDRAIL_VALIDATION_ENABLED: bool = False
    KNOWLEDGE_RAG_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    IMAGE_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    FILE_READ_TOOL_GUARDRAIL_VALIDATION_ENABLED: bool = False
    MEMREADWRITE_GUARDRAIL_VALIDATION_ENABLED: bool = False
    TESTRAIL_CONNECTOR_GUARDRAIL_VALIDATION_ENABLED: bool = False

    # Environment Name
    ENVIRONMENT_NAME: str = ""

    # SIMILARITY SEARCH CONFIG
    K_FACTOR: int = 4
    OVERSAMPLING_FACTOR: int = 2

    RETRY_KB_COUNT: str = "3"

    CONNECT_TIMEOUT_MS: str = "45000"
    SOCKET_TIMEOUT_MS: str = "120000"
    SERVER_SELECTION_TIMEOUT_MS: str = "30000"
    WAIT_QUEUE_TIMEOUT_MS: str = "30000"
    MAX_IDLE_TIME_MS: str = "60000"
    MIN_POOL_SIZE: str = "10"
    MAX_POOL_SIZE: str = "200"
    TLS_ALLOW_INVALID_CERTIFICATES: str = "False"

    # ==================== END ADDED CONFIG ====================

    def start_config_refresh(self):
        if self.CONFIG_REFRESH_ENABLED:
            def refresh_loop():
                while True:
                    try:
                        load_remote_config()
                    except Exception as e:
                        logger.error(f"❌Config refresh failed: {str(e)}")
                    time.sleep(self.CONFIG_REFRESH_INTERVAL)

            thread = threading.Thread(target=refresh_loop, daemon=True)
            thread.start()
            logger.info(f"Config refresh enabled (interval: {self.CONFIG_REFRESH_INTERVAL}s)")

    @property
    def obo_api_base_url(self) -> str:
        """Get OBO API base URL from environment or config"""
        return os.environ.get("OBO_API_BASE_URL") or self.OBO_API_BASE_URL

    def to_bool(self, key):
        value = getattr(self, key, False)
        return str(value).strip().lower() in ("true", "1", "yes")
    
    @model_validator(mode="after")
    def validate_settings(self):
        if self.AAVA_LOG_SOURCE_TYPE=="db":
            self.PERSISTENT_LOGGING = True
        
        return self


def export_default_to_env(config: Settings) -> None:
    """
    Export default configuration values to environment variables.
    Only sets values that are not already present in the environment.
    Args:
        config: Settings instance containing default values
    """
    global _default_message
    
    for key, value in config.model_dump().items():
        if not os.environ.get(key):
            os.environ[key] = str(value)
            display_value = mask_secret(str(value)) if should_mask(key) else value
            _default_message += f"DEFAULT - {key}: {display_value}\n"

def bootstrap_settings(force=False):
    global settings
    global common_config_message
    global app_config_message
    global _default_message
    global config_setup_completed
    if force:
        settings = None
        common_config_message = ""
        app_config_message = ""
        _default_message = ""
        config_setup_completed = False
    if not settings:
        try:
            load_remote_config()
            settings = Settings()
            settings.start_config_refresh()
            export_default_to_env(settings)

        except Exception as e:
            logger.error(f"❌Failure in Config Initialization: {str(e)}")

bootstrap_settings()

# Initialize Starter Package
from aava.logging.aspect import setup_logging_middleware
from aava.security.jwt import setup_jwt_middleware
from aava.exception.handler import exception_handler

add_execution_id_filter()

def log_config_operation():
    # Log configuration status
    messages = []
    global config_setup_completed
    if not config_setup_completed:
        for key, value in config_metadata.items():
            if value[0]:
                logger.info(f"✅ {value}")
            else:
                logger.error(f"❌ {value}")
            messages.append(value)

        logger.info(f"Common Configs Loaded: {common_config_message}")
        logger.info(f"App Configs Loaded: {app_config_message}")
        logger.info(f"Default Configs: {_default_message}")
        config_setup_completed = True
    return messages

log_config_operation()

