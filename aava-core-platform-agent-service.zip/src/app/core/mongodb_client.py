import logging
import os
import asyncio
import threading
import boto3
import certifi
from pymongo import AsyncMongoClient, MongoClient

from botocore.exceptions import NoCredentialsError
from fastapi import HTTPException

from app.core.config import settings, Settings

logger = logging.getLogger(__name__)
config = Settings()

USE_BEDROCK_CREDENTIALS = settings.USE_BEDROCK_CREDENTIALS


# ---------------------------------------------------------------------------
# Standalone credential helper — synchronous, safe to call from any context
# ---------------------------------------------------------------------------

def assume_role_credentials(
    role_arn: str,
    region: str = None,
    session_name: str = "aava-session",
) -> dict:
    """Assume an AWS IAM role and return temporary credentials dict.

    Accepts optional region and session_name so callers (e.g. Bedrock embedding
    in knowledgeRagTool) can pass their own values without monkeypatching env vars.
    """
    try:
        if "AWS_PROFILE" in os.environ:
            os.environ.pop("AWS_PROFILE", None)

        session = boto3.Session(profile_name=None, region_name=region)
        logger.info("Assuming role %s in region %s", role_arn, region)

        sts = session.client("sts")
        identity = sts.get_caller_identity()
        logger.info(
            "Caller Identity - Account: %s, ARN: %s, UserId: %s",
            identity.get("Account"),
            identity.get("Arn"),
            identity.get("UserId"),
        )

        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName=session_name,
            DurationSeconds=3600,
        )
        logger.info("Successfully assumed role %s", role_arn)
        return response["Credentials"]

    except NoCredentialsError as e:
        logger.error(f"No AWS credentials: {str(e)}")
        raise


# ---------------------------------------------------------------------------
# Async MongoDB client — for use in async FastAPI endpoints ONLY
# ---------------------------------------------------------------------------

class AsyncMongoDBClient:
    """Async Singleton MongoDB client.

    Use ONLY from async def code running on the event loop (FastAPI endpoints,
    lifespan handlers).  Do NOT call from sync code or worker threads — use
    get_sync_mongo_client() instead.
    """

    _instance = None
    # Lazy: created inside get_instance() so it always binds to the running loop.
    _lock: asyncio.Lock = None

    def __init__(self):
        self.mongoDBClient = None

    @classmethod
    async def get_instance(cls):
        if cls._lock is None:
            cls._lock = asyncio.Lock()
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    await cls._instance._initialize()
        return cls._instance

    async def _initialize(self):
        try:
            logger.info("Initializing Async MongoDB client...")
            self.mongoDBClient = await self._create_client()
            logger.info("MongoDB async client connected")
        except Exception as e:
            logger.error("MongoDB async init failed (non-fatal): %s", e)
            self.mongoDBClient = None

    def _assume_role_credentials(self, role_arn: str) -> dict:
        """Backward-compatible wrapper — delegates to module-level assume_role_credentials()."""
        return assume_role_credentials(role_arn)

    async def _create_client(self) -> AsyncMongoClient:
        mongodb_uri = settings.MONGODB_URI

        common_kwargs = dict(
            tls=True,
            tlsCAFile=certifi.where(),
            retryWrites=True,
            maxPoolSize=100,
            minPoolSize=10,
            maxIdleTimeMS=30000,
            waitQueueTimeoutMS=10000,
            serverSelectionTimeoutMS=30000,
            tlsAllowInvalidCertificates=True,
            connectTimeoutMS=45000,
            socketTimeoutMS=90000,
        )

        if not settings.to_bool("MONGO_IAM_AUTH_ENABLED"):
            logger.info("Async MongoDB: using standard auth")
            return AsyncMongoClient(mongodb_uri, **common_kwargs)

        logger.info("Async MongoDB: using IAM auth")

        if not USE_BEDROCK_CREDENTIALS:
            creds = assume_role_credentials(settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT)
            return AsyncMongoClient(
                mongodb_uri,
                authMechanism="MONGODB-AWS",
                username=creds["AccessKeyId"],
                password=creds["SecretAccessKey"],
                authMechanismProperties={
                    "AWS_SESSION_TOKEN": creds["SessionToken"]
                },
                **common_kwargs
            )

        return AsyncMongoClient(
            mongodb_uri,
            authMechanism="MONGODB-AWS",
            username=os.getenv("AWS_ACCESS_KEY_ID"),
            password=os.getenv("AWS_SECRET_ACCESS_KEY"),
            **common_kwargs
        )

    def get_client(self):
        return self.mongoDBClient

    async def close(self):
        try:
            if self.mongoDBClient:
                self.mongoDBClient.close()
                logger.info("MongoDB connection closed")
        except Exception as e:
            logger.error(f"Error closing MongoDB: {str(e)}")


# ---------------------------------------------------------------------------
# Sync MongoDB client — for use in sync/threaded contexts
#
# crew.kickoff() runs inside asyncio.to_thread() — a worker thread with NO
# event loop.  Any code invoked during crew execution (BaseTool._run(),
# kb_utils, EventListener callbacks) must use this sync client, not the async
# one above.
# ---------------------------------------------------------------------------

_sync_client: MongoClient = None
_sync_lock = threading.Lock()


def get_sync_mongo_client() -> MongoClient:
    """Return a thread-safe sync MongoClient singleton.

    Safe to call from any thread including asyncio.to_thread() workers.
    Uses double-checked locking so the client is only created once.
    Returns None if MongoDB is unavailable — callers must handle None.
    """
    global _sync_client
    if _sync_client is None:
        with _sync_lock:
            if _sync_client is None:
                try:
                    _sync_client = _create_sync_client()
                except Exception as e:
                    logger.error("Sync MongoDB client creation failed (non-fatal): %s", e)
                    return None
    return _sync_client


def reset_sync_mongo_client() -> None:
    """Reset the sync MongoClient singleton.

    Call this after a connection error (e.g. SSL reset, ServerSelectionTimeout)
    so the next call to get_sync_mongo_client() creates a fresh client with a
    clean connection pool instead of reusing broken connections.
    """
    global _sync_client
    with _sync_lock:
        if _sync_client is not None:
            try:
                _sync_client.close()
            except Exception:
                pass
            _sync_client = None
            logger.info("Sync MongoDB client reset — will reconnect on next request")


def _create_sync_client() -> MongoClient:
    mongodb_uri = settings.MONGODB_URI

    common_kwargs = dict(
        tls=True,
        tlsCAFile=certifi.where(),
        retryWrites=True,
        maxPoolSize=int(settings.MAX_POOL_SIZE),
        minPoolSize=int(settings.MIN_POOL_SIZE),
        maxIdleTimeMS=int(settings.MAX_IDLE_TIME_MS),
        waitQueueTimeoutMS=int(settings.WAIT_QUEUE_TIMEOUT_MS),
        serverSelectionTimeoutMS=int(settings.SERVER_SELECTION_TIMEOUT_MS),
        tlsAllowInvalidCertificates=bool(settings.TLS_ALLOW_INVALID_CERTIFICATES),
        connectTimeoutMS=int(settings.CONNECT_TIMEOUT_MS),
        socketTimeoutMS=int(settings.SOCKET_TIMEOUT_MS)
    )

    if not settings.to_bool("MONGO_IAM_AUTH_ENABLED"):
        logger.info("Sync MongoDB: using standard auth")
        return MongoClient(mongodb_uri, **common_kwargs)

    logger.info("Sync MongoDB: using IAM auth")

    if not USE_BEDROCK_CREDENTIALS:
        creds = assume_role_credentials(settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT)
        return MongoClient(
            mongodb_uri,
            authMechanism="MONGODB-AWS",
            username=creds["AccessKeyId"],
            password=creds["SecretAccessKey"],
            authMechanismProperties={"AWS_SESSION_TOKEN": creds["SessionToken"]},
            **common_kwargs
        )

    return MongoClient(
        mongodb_uri,
        authMechanism="MONGODB-AWS",
        username=os.getenv("AWS_ACCESS_KEY_ID"),
        password=os.getenv("AWS_SECRET_ACCESS_KEY"),
        **common_kwargs
    )
