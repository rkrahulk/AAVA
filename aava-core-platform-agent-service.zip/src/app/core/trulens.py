import logging
import requests
from concurrent.futures import ThreadPoolExecutor
from app.core.config import settings


logger = logging.getLogger(__name__)

# Thread pool for TruLens async calls (max 20 concurrent threads)
_trulens_executor = ThreadPoolExecutor(max_workers=20, thread_name_prefix="TruLens")

class Trulens:

    def __init__(
            self,
            _input: str,
            output: str, 
            kb_context: str = "",
            agent_config: dict = None
        ):
        self._input = _input
        self.output = output
        self.kb_context = kb_context
        self.agent_config = agent_config
        self.enabled = settings.TRULENS_ENABLED and agent_config is not None
        
        logger.info(f"[TruLens] Init - TRULENS_ENABLED={settings.TRULENS_ENABLED}, has_config={agent_config is not None}, enabled={self.enabled}")


    @staticmethod
    def _is_kb_tool(tool_name: str, tool_class: str = "") -> bool:
        """Check if tool is a KB/RAG tool by matching the tool name or class."""
        if "Knowledge Base Answer Retrieval" in (tool_name or ""):
            return True
        # Fallback: check for class name   #Checking tool:class=CrewStructuredTool
        if "KnowledgeRAGTool" in (tool_class or ""):
            return True
        return False

    def get_provider_config(self, llm_data):
        """Extract LLM provider configuration."""
        try:
            if "azure" in llm_data.get("model", "").lower():
                return {
                    "provider_llm": "AzureOpenAI",
                    "llm_deployment_name": llm_data["model"].split("/")[-1],
                    "api_key": llm_data["api_key"],
                    "azure_endpoint": llm_data["base_url"],
                    "llm_api_version": llm_data["api_version"]
                }
            elif "bedrock" in llm_data.get("model", "").lower():
                return {
                    "provider_llm": "AmazonBedrock",
                    "modelid": llm_data["model"].split("/")[-1],
                    "region": llm_data["aws_region_name"],
                    "access_key": llm_data["aws_access_key_id"],
                    "secret_key": llm_data["aws_secret_access_key"]
                }
            
            return {}
        except KeyError as e:
            raise ValueError(f"[TruLens] Missing required LLM configuration field: {e}")

    def prepare_payload(self):
        """Prepare TruLens payload with input, output, context and critical IDs."""
        agent_data = self.agent_config.agent_details if self.agent_config else None
        llm_data = agent_data.llm if agent_data else {}
    
        # For agent service, use agent name as the app version
        agent_name = agent_data.name if agent_data else "Unknown Agent"
        app_version = agent_name
        
        payload = {
            "use_case": "AGENT",
            "app_version": app_version,
            "execution_id": getattr(self.agent_config, 'execution_id', None),
            "workflow_id": getattr(self.agent_config, 'workflow_id', None),
            "agent_id": agent_data.id if agent_data and hasattr(agent_data, 'id') else None,
            "agent_name": agent_name,
            "input": self._input or "",
            "output": self.output or "",
            "context": self.kb_context or ""
        }
        
        if llm_data:
            provider_config = self.get_provider_config(llm_data)
            payload.update(**provider_config)
        return payload

    def register_record(self):
        """Send TruLens record asynchronously using thread pool."""
        if not self.enabled:
            logger.info("[TruLens] Disabled - skipping")
            return
        
        # Submit task to thread pool (fire-and-forget)
        _trulens_executor.submit(self._send_to_trulens)
        logger.info(f"[TruLens] Submitted to evaluation (KB: {len(self.kb_context)} chars)")
    
    def _send_to_trulens(self):
        """Send payload to TruLens (runs in background thread)."""
        try:
            logger.info("[TruLens] Thread executing, preparing payload...")
            payload = self.prepare_payload()
            logger.info(f"[TruLens] Sending to {settings.TRULENS_PLATFORM_URL}")
            
            response = requests.post(
                settings.TRULENS_PLATFORM_URL,
                json=payload,
                timeout=5
            )
            
            if response.status_code >= 400:
                logger.error(f"[TruLens] Failed - HTTP {response.status_code}")
            else:
                logger.info(f"[TruLens] Sent - {payload.get('agent_name')} (exec: {payload.get('execution_id')})")
        except Exception as e:
            logger.error(f"[TruLens] Error: {str(e)}", exc_info=True)