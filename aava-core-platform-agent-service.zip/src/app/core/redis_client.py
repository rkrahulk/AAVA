"""
Redis client singleton for pipeline-core microservice.

Implements a singleton Redis client with retry and SSL support.
Configuration is loaded from environment variables via the config module.
"""

import base64
import binascii
import logging

import redis
from redis.backoff import ExponentialBackoff
from redis.exceptions import ConnectionError, TimeoutError
from redis.retry import Retry

from app.core.config import settings as config

# Instantiate the config object from Settings
logger = logging.getLogger(__name__)


class RedisClientSingleton:
    """
    Singleton Redis client with retry, SSL support, and automatic reconnection.

    Ensures only one Redis client is created per process.
    Use get_client() to access the Redis client.
    Includes health checks and reconnection logic.
    """

    _instance = None
    _decoded_password = None  # Cache decoded password

    def __new__(cls, *args, **kwargs):
        # Singleton pattern: only one instance per process
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize(*args, **kwargs)
        return cls._instance

    def _initialize(self):
        """
        Initialize the Redis client using config values.
        Caches decoded password for efficiency.
        """
        logger.info("---------------- Redis Configuration ---------------- ")

        redis_host = config.REDIS_HOST
        redis_port = config.REDIS_PORT
        redis_password = config.REDIS_PASSWORD
        sslValue = config.REDIS_SSL

                # ---------------------------------------------------------
        # FIX: Robust Password Decoding
        # ---------------------------------------------------------
        decoded_password = None
        if redis_password:
            try:
                # Try to decode assuming it is Base64
                decoded_password = base64.b64decode(redis_password).decode("utf-8")
            except (binascii.Error, UnicodeDecodeError, ValueError):
                # If decoding fails, assume it is Plain Text and use as is
                decoded_password = redis_password
        else:
            decoded_password = None

        # Convert SSL value to boolean
        sslBool = sslValue.lower() == "true"
        logger.info(
            "REDIS sslValue is %s and sslBool is %s and type is %s",
            sslValue,
            sslBool,
            type(sslBool),
        )

        try:
            # Create the Redis client with retry and SSL support
            self.redisClient = redis.StrictRedis(
                host=redis_host,
                port=int(redis_port),
                password=self._decoded_password,
                ssl=sslBool,  # SSL is required for Azure Cache for Redis
                decode_responses=True,  # Decode responses as UTF-8 strings
                retry=Retry(ExponentialBackoff(cap=10, base=1), 7),
                retry_on_error=[ConnectionError, TimeoutError],
                health_check_interval=30,  # Health check every 30 seconds
            )
            
            # Test connection
            self.redisClient.ping()
            logger.info("Redis client initialized and connection verified")

        except redis.ConnectionError as e:
            logger.error(f"Could not connect to Redis: {e}")
            # Don't set client to None, keep instance for retry
            self.redisClient = None
            # Will retry on next get_client() call

    def health_check(self) -> bool:
        """
        Perform health check on Redis connection.
        
        Returns:
            bool: True if connection is healthy, False otherwise
        """
        try:
            if self.redisClient:
                self.redisClient.ping()
                return True
            return False
        except Exception as e:
            logger.warning(f"Redis health check failed: {e}")
            return False

    def reconnect(self):
        """
        Attempt to reconnect to Redis.
        """
        try:
            logger.info("Attempting to reconnect to Redis...")
            if self.redisClient:
                try:
                    self.redisClient.close()
                except Exception:
                    pass
            
            # Reinitialize
            self._initialize()
            
            if self.redisClient and self.health_check():
                logger.info("Redis reconnection successful")
                return True
            else:
                logger.error("Redis reconnection failed")
                return False
        except Exception as e:
            logger.error(f"Redis reconnection error: {e}")
            return False

    def get_client(self):
        """
        Get the Redis client instance with automatic reconnection.
        
        Returns:
            Redis client or None if connection failed
        """
        # Check health and reconnect if needed
        if not self.health_check():
            logger.warning("Redis connection unhealthy, attempting reconnection...")
            if not self.reconnect():
                logger.error("Redis reconnection failed, returning None")
                return None
        
        return self.redisClient
    
    def close(self):
        """Close the Redis client connection."""
        if self.redisClient:
            try:
                self.redisClient.close()
                logger.info("Redis connection closed")
            except Exception as e:
                logger.error(f"Error closing Redis connection: {e}")
            finally:
                self.redisClient = None


logger.debug("Redis client being initialized")

# Instantiate the client only if log streaming is enabled
redis_client_singleton = (
    RedisClientSingleton() if config and config.ENABLE_LOGSTREAMING else False
)

redis_client = redis_client_singleton.get_client() if redis_client_singleton else None
