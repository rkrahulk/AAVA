"""
PostgreSQL client for pipeline-core microservice.

Supports:
- AWS IAM authentication (for HP / secure environments)
- Legacy username/password connection pooling
- Automatic fallback from IAM → legacy
"""

import logging
import urllib.parse
import threading
import time
import os

import psycopg2
from psycopg2 import pool
import boto3

from app.core.config import settings as config

logger = logging.getLogger(__name__)


class PostgresClient:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    # ==================== INITIALIZATION ====================
    def _initialize(self):
        raw_url = config.DB_URL or ""
        self.dbname = config.DB_NAME or ""

        # Robust URL parsing
        parse_target = raw_url
        if "://" not in parse_target and not parse_target.startswith("//"):
            parse_target = f"//{parse_target}"

        try:
            parsed = urllib.parse.urlparse(parse_target)
            self.db_url = parsed.netloc if parsed.netloc else raw_url

            if not self.dbname and parsed.path:
                self.dbname = parsed.path.lstrip("/")

            extracted_host = parsed.hostname or self.db_url.split(':')[0]
            extracted_port = parsed.port or 5432
        except Exception:
            self.db_url = raw_url.strip("/")
            extracted_host = self.db_url
            extracted_port = 5432

        # Standard credentials
        self.db_username = config.DB_USER
        self.db_password = config.DB_PASSWORD

        # IAM settings
        self.iam_user = config.IAM_DB_USER
        self.region = config.AWS_REGION
        self.db_host = config.IAM_DB_HOST or extracted_host
        self.db_port = config.IAM_DB_PORT or extracted_port
        self.token_refresh_interval = config.IAM_TOKEN_REFRESH_INTERVAL

        # Internal state
        self._token = None
        self._token_lock = threading.Lock()
        self._stop_scheduler = threading.Event()
        self.connection_pool = None

        # Mode detection
        self.is_iam_mode = os.getenv("CLIENT_NAME", "NA").lower() == "hp"

        if self.is_iam_mode:
            logger.info(f"IAM authentication enabled. IAM User: {self.iam_user}")
            try:
                self._generate_iam_token()
                self._start_token_scheduler()
            except Exception as e:
                logger.error(f"IAM init failed: {e}")
                logger.warning("Falling back to legacy DB")
                self._initialize_legacy_pool()
        else:
            logger.info("IAM disabled — using legacy DB")
            self._initialize_legacy_pool()

    # ==================== LEGACY POOL ====================
    def _initialize_legacy_pool(self):
        try:
            if not all([self.db_url, self.db_username, self.db_password]):
                raise ValueError("Missing legacy DB configuration")

            encoded_password = urllib.parse.quote_plus(self.db_password)

            dsn = f"postgresql://{self.db_username}:{encoded_password}@{self.db_url}/{self.dbname}"

            self.connection_pool = pool.ThreadedConnectionPool(
                minconn=2,
                maxconn=50,
                dsn=dsn,
                connect_timeout=10,
                options="-c statement_timeout=30000"
            )

            logger.info("Legacy PostgreSQL pool initialized (2–50 connections)")

        except Exception as e:
            logger.error(f"Legacy DB pool init failed: {e}")
            raise

    # ==================== IAM TOKEN ====================
    def _generate_iam_token(self):
        with self._token_lock:
            try:
                client = boto3.client("rds", region_name=self.region)

                token = client.generate_db_auth_token(
                    DBHostname=self.db_host,
                    Port=self.db_port,
                    DBUsername=self.iam_user,
                )

                if not token:
                    raise ValueError("Empty IAM token received")

                self._token = token
                logger.debug("IAM token refreshed")

            except Exception as e:
                logger.error(f"IAM token generation failed: {e}")
                raise

    def _start_token_scheduler(self):
        def refresh_loop():
            interval = self.token_refresh_interval * 60
            while not self._stop_scheduler.is_set():
                time.sleep(interval)
                if self._stop_scheduler.is_set():
                    break
                try:
                    self._generate_iam_token()
                except Exception as e:
                    logger.error(f"IAM token refresh failed: {e}")

        thread = threading.Thread(target=refresh_loop, daemon=True)
        thread.start()
        logger.info("IAM token auto-refresh thread started")

    # ==================== GET CONNECTION ====================
    def get_connection(self):
        # IAM Mode
        if self.is_iam_mode:
            try:
                if not self._token:
                    self._generate_iam_token()

                return psycopg2.connect(
                    host=self.db_host,
                    port=self.db_port,
                    user=self.iam_user,
                    password=self._token,
                    dbname=self.dbname,
                    sslmode="require",
                    connect_timeout=10,
                )

            except Exception as e:
                logger.warning(f"IAM connection failed: {e}")
                logger.warning("Falling back to legacy DB")

                if not self.connection_pool:
                    self._initialize_legacy_pool()

        # Legacy pool
        if self.connection_pool:
            try:
                return self.connection_pool.getconn()
            except pool.PoolError as e:
                logger.error(f"Connection pool exhausted: {e}")
                raise

        raise RuntimeError("No database connection available")

    # ==================== RELEASE CONNECTION ====================
    def release_connection(self, conn):
        if not conn:
            return

        try:
            if self.connection_pool:
                self.connection_pool.putconn(conn)
            else:
                conn.close()  # IAM connection
        except Exception as e:
            logger.warning(f"Error releasing connection: {e}")

    # ==================== CLEANUP ====================
    def close_all_connections(self):
        self._stop_scheduler.set()

        if self.connection_pool:
            self.connection_pool.closeall()
            logger.info("All PostgreSQL connections closed")

        logger.info("Postgres client shutdown complete")


# Instantiate only if needed
postgres_client = None
# if config.PERSISTENT_LOGGING:
#     postgres_client = PostgresClient()