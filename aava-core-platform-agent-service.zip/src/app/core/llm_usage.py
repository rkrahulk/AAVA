"""
Lightweight LLM usage capture for CrewAI/LiteLLM calls.

Goal:
- Capture prompt/completion/total tokens, model, and cost from LiteLLM callbacks
- Aggregate by execution_id so EventListener/agent.py can reliably update Langfuse
- Provide safe no-op behavior when LiteLLM is not present or callback signature changes

Usage:
- Call set_current_execution_id(execution_id) before invoking task execution
- The OpenTelemetry initialization will register the liteLLM_usage_callback if LiteLLM is installed
- After execution, call get_aggregated_usage(execution_id) to retrieve totals
"""
from __future__ import annotations
import threading
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass, field

# Thread-local storage for the current execution ID context
_context = threading.local()


@dataclass
class UsageTotals:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0
    model: Optional[str] = None
    # Latest raw usage blobs for debugging
    raw_usages: list[dict] = field(default_factory=list)


# Global aggregator: execution_id -> UsageTotals
_USAGE_STORE: Dict[str, UsageTotals] = {}


def set_current_execution_id(execution_id: Optional[str]):
    """Set the current execution id in thread-local context."""
    setattr(_context, "execution_id", execution_id)


def get_current_execution_id() -> Optional[str]:
    return getattr(_context, "execution_id", None)


def _ensure_entry(execution_id: str) -> UsageTotals:
    if execution_id not in _USAGE_STORE:
        _USAGE_STORE[execution_id] = UsageTotals()
    return _USAGE_STORE[execution_id]


def record_usage(execution_id: str, prompt_tokens: int, completion_tokens: int, total_tokens: int, cost: float, model: Optional[str], raw: Optional[dict] = None):
    entry = _ensure_entry(execution_id)
    # Aggregate totals (sum across multiple calls)
    entry.prompt_tokens += int(prompt_tokens or 0)
    entry.completion_tokens += int(completion_tokens or 0)
    entry.total_tokens += int(total_tokens or 0)
    entry.cost += float(cost or 0.0)
    if model and not entry.model:
        entry.model = model
    if raw:
        entry.raw_usages.append(raw)


def get_aggregated_usage(execution_id: str) -> Tuple[int, int, int, float, Optional[str]]:
    entry = _USAGE_STORE.get(execution_id)
    if not entry:
        return 0, 0, 0, 0.0, None
    return entry.total_tokens, entry.prompt_tokens, entry.completion_tokens, round(entry.cost, 6), entry.model


def clear_usage(execution_id: str):
    _USAGE_STORE.pop(execution_id, None)


# --------------- LiteLLM callback integration ---------------

def _extract_from_response(response_obj: Any) -> tuple[int, int, int, float, Optional[str], dict]:
    """Best-effort extraction of usage and model from a LiteLLM response object."""
    prompt = completion = total = 0
    cost = 0.0
    model = None
    raw: dict = {}

    try:
        # Try OpenAI-style usage first
        usage = None
        if isinstance(response_obj, dict):
            usage = response_obj.get("usage") or response_obj.get("token_usage")
            model = response_obj.get("model") or response_obj.get("model_name")
            raw = response_obj
        else:
            usage = getattr(response_obj, "usage", None) or getattr(response_obj, "token_usage", None)
            model = getattr(response_obj, "model", None) or getattr(response_obj, "model_name", None)
            try:
                raw = response_obj.__dict__  # type: ignore
            except Exception:
                raw = {}
        if usage:
            if isinstance(usage, dict):
                prompt = int(usage.get("prompt_tokens") or usage.get("promptTokens") or 0)
                completion = int(usage.get("completion_tokens") or usage.get("completionTokens") or 0)
                total = int(usage.get("total_tokens") or usage.get("totalTokens") or (prompt + completion))
                cost = float(usage.get("cost") or 0.0)
            else:
                prompt = int(getattr(usage, "prompt_tokens", getattr(usage, "promptTokens", 0)) or 0)
                completion = int(getattr(usage, "completion_tokens", getattr(usage, "completionTokens", 0)) or 0)
                total = int(getattr(usage, "total_tokens", getattr(usage, "totalTokens", prompt + completion)) or (prompt + completion))
                cost = float(getattr(usage, "cost", 0.0) or 0.0)
    except Exception:
        pass

    return total, prompt, completion, cost, model, raw


def litellm_usage_callback(*args, **kwargs):
    """
    LiteLLM success/failure callback that records usage to the global store using the current execution id context.
    Signature intentionally flexible to be compatible with LiteLLM callback invocation.
    """
    try:
        # LiteLLM typically passes response as the first positional arg or as kwarg 'response'
        response_obj = None
        if args:
            # search for response-like object in args
            for a in args:
                if a is not None:
                    response_obj = a
                    break
        if kwargs and response_obj is None:
            response_obj = kwargs.get("response") or kwargs.get("resp") or kwargs.get("result")

        total, prompt, completion, cost, model, raw = _extract_from_response(response_obj)

        exec_id = get_current_execution_id()
        if exec_id and (total > 0 or prompt > 0 or completion > 0 or cost > 0.0):
            record_usage(exec_id, prompt, completion, total, cost, model, raw)
    except Exception:
        # Swallow exceptions to avoid impacting LLM calls
        pass
