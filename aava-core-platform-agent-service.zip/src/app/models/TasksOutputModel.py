from typing import Optional
from pydantic import BaseModel, Field


class TasksOutputModel(BaseModel):
    description: Optional[str] = Field(
        default="",
        description="Detailed description of what the task did or processed."
    )
    summary: Optional[str] = Field(
        default="",
        description="Concise summary of the task outcome."
    )
    expected_output: Optional[str] = Field(
        default="",
        description="The output that was anticipated or required from the task."
    )
    raw: str | dict = Field(
        default="",
        description="The raw output data, often in structured format (e.g., JSON)."
    )
