
from typing import Optional

from pydantic import BaseModel, Field

from .AgentTools import AgentTools, AgentUserTools


class AgentRequest(BaseModel):
    agentId: Optional[int] | None = Field(
        None,
        description="Unique identifier for the agent to be executed."
        )
    executionId: str = Field(
        description="Optional execution ID for tracking the pipeline run."
    )
    userInputs: dict[str, str] = Field(
        description="Key-value inputs provided by the user."
    )
    user: str = Field(description="Username initiating the request.")
    tools: list[AgentTools] = Field(
        [], description="List of pre-defined tools available for the agent."
    )
    userTools: list[AgentUserTools] | None = Field(
        [], description="List of user-defined tools for the agent."
    )
    agent: Optional[dict] | None = Field(
        {},
        description="Validated Payload For Agent"
    )

    class Config:
        title = "AgentRequest"
        json_schema_extra = {
            "example": {
                "agentId": 123, # can be none if agent is there
                "executionId": "exec_20240729_001",
                "userInputs": {"region": "US", "type": "summary"},
                "user": "johndoe",
                "tools": [{"toolId": 1, "toolName": "ExampleTool", "parameters": []}],
                "userTools": [
                    {
                        "toolId": 2,
                        "toolName": "UserTool",
                        "toolClassName": "CustomToolClass",
                        "toolClassDef": "class CustomToolClass: pass",
                    }
                ],
                "agent": {"agent_id":123,"other_data":"other"}
            }
        }
