from pydantic import BaseModel
from typing import List


class ConfigResponse(BaseModel):
    message: List[str]