import uuid
import enum
from pydantic import BaseModel

class CrewStages(enum.Enum):
    # CREW_START="PIPELINE_START"
    # CREW_FINISHED="CREW_FINISHED"
    # CREW_ERROR="CREW_ERROR"
    PIPELINE_SETUP_ERROR="PIPELINE_ERROR"
    
    AGENT_INITIALIZED="AGENT_INITIALIZED"
    AGENT_FINISHED="AGENT_FINISHED"
    AGENT_ERROR="AGENT_ERROR"
    AGENT_SETUP_ERROR="AGENT_SETUP_ERROR"

    TASK_START="TASK_START"
    TASK_FINISH="TASK_FINISH"
    TASK_FAILURE="TASK_FAILURE"
    TASK_EVALUATION="TASK_EVALUATION"

    TOOL_INITIALIZED="TOOL_INITIALIZED"
    TOOL_FINISHED="TOOL_FINISHED"
    TOOL_ERROR="TOOL_ERROR"


    LLM_ERROR="LLM_ERROR"

    AGENT_STEP="AGENT_STEP"

    LLM_GUARDRAILS_INITIALIZED="LLM_GUARDRAILS_INITIALIZED"
    LLM_GUARDRAILS_FINISHED="LLM_GUARDRAILS_FINISHED"
    LLM_STARTED="LLM_STARTED"
    LLM_FINISHED="LLM_FINISHED"
    LLM_FAILED="LLM_FAILED"
    LLM_STREAM_CHUNK="LLM_STREAM_CHUNK"


class ListenerMetadata(BaseModel):
    execution_id: str
    workflow_id: str = ""
    event_execution_id: str = str(uuid.uuid4())
    agent_id: str = ""
    agent_name: str = ""
    agent_role: str = ""
    agent_execution_id: str = ""
    message: str
    type: CrewStages = ""
