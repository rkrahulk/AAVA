from pydantic import BaseModel

class TestToolResponse(BaseModel):
    status: str
    output: str