
from typing import Optional
from pydantic import BaseModel

class GuardrailsModel(BaseModel):
    colang_content: str
    yaml_content: str
    llm: dict
    collection_config: Optional[dict] = {}