
from pydantic import BaseModel, Field


class AgentEmbedding(BaseModel):
    # Azure embedding config
    embedding_model: str | None = Field(
        None, description="Azure embedding model name."
    )
    embedding_deployment_name: str | None = Field(
        None, description="Deployment name used in Azure."
    )
    embedding_api_version: str | None = Field(
        None, description="Azure API version for the embedding model."
    )
    embedding_api_key: str | None = Field(
        None, description="API key for Azure embedding access."
    )
    embedding_azure_endpoint: str | None = Field(
        None, description="Azure OpenAI endpoint."
    )

    # Amazon embedding config
    embedding_aws_key: str | None = Field(
        None, description="AWS access key for embedding."
    )
    embedding_aws_secret_key: str | None = Field(
        None, description="AWS secret key for embedding."
    )
    embedding_aws_region: str | None = Field(
        None, description="AWS region for embedding service."
    )
    embedding_model_id: str | None = Field(
        None, description="Amazon Bedrock embedding model ID."
    )


    # Chroma DB config
    aiEngine: str = Field(None, description="Vector engine name (e.g., chromadb).")
    chroma_end_point: str = Field(None, description="ChromaDB endpoint URL.")
    chroma_port: str = Field(None, description="ChromaDB service port.")
    index_collection: str = Field(
        None, description="Name of the index or collection used in Chroma."
    )
    topK: int = Field(4, description="Number of top similar documents to retrieve.")
    vector_store_type: str = Field(
        "chroma", description="Type of vector store (e.g., chroma, qdrant)."
    )
    vector_store_end_point: str = Field(
        None, description="Vector store endpoint URL."
    )
    vector_store_port: str = Field(
        None, description="Vector store service port."
    )
    mongodb_uri: str | None = Field(None, description="MongoDB URI.")
    mongodb_database: str | None = Field(None, description="MongoDB database name.")
    mongodb_collection: str | None = Field(None, description="MongoDB collection name.")
    mongodb_index: str | None = Field(None, description="MongoDB index name.")
