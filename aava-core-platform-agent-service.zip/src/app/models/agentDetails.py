
from pydantic import BaseModel, Field
from typing import Optional


from .agentEmbedding import AgentEmbedding
from .AgentTools import AgentTools, AgentUserTools

# from .agentLLM import AgentLLM
from .taskDetails import TaskDetails


class AgentDetails(BaseModel):

    id: int = Field(description="Unique identifier for the agent.")  #

    name: str | None = Field(None, description="Name of the agent.")  #

    role: str | None = Field(None, description="The role this agent plays.")  #

    goal: str | None = Field(
        None, description="The objective or mission assigned to the agent."
    )  #

    backstory: str | None = Field(
        None, description="Background information or personality for the agent."
    )  #

    verbose: bool | None = Field(
        True, description="If true, the agent provides detailed logs and responses."
    )  #

    allowDelegation: bool | None = Field(
        False,
        description="If true, the agent is allowed to delegate tasks to other agents.",
    )  #

    maxIter: int | None = Field(
        25, description="Maximum number of iterations the agent can perform."
    )

    maxRpm: int | None = Field(
        None, description="Maximum requests per minute allowed for the agent."
    )

    maxExecutionTime: int | None = Field(
        None, description="Maximum execution time (in seconds) allowed for this agent."
    )

    task: TaskDetails = Field(
        ..., description="Details of the task assigned to the agent."
    )  #

    # llm: AgentLLM = Field(..., description="LLM configuration used by the agent.")
    llm: dict = Field(..., description="LLM configuration used by the agent.")  #

    modelDetails: dict = Field(..., description="LLM configuration used by the agent.")  #

    embedding: list[AgentEmbedding] | None = Field(
        [], description="List of embeddings used by the agent."
    )  # in azure

    tools: list[AgentTools] = Field(
        [], description="List of tools available to the agent."
    )  #

    allowCodeExecution: bool | None = Field(
        True, description="If true, the agent can execute code."
    )  #

    isSafeCodeExecution: bool | None = Field(
        True, description="If true, the agent uses a secure sandbox for code execution."
    )  #

    userTools: list[AgentUserTools] | None = Field(
        [], description="Custom tools provided by the user for the agent."
    )  #

    useSystemPrompt: bool | None = Field(
        None,
        description="If true, the agent uses a system prompt for better context handling.",
    )  #

    colang_content: str | None = Field(
        None, description="CoLang content for NeMo Guardrails, if any."
    )

    yaml_content: str | None = Field(
        None, description="YAML content for NeMo Guardrails, if any."
    )

    nemo_guardrails: Optional[bool] = Field(False, description="Indicates if NeMo Guardrails are enabled for this agent.")


