import logging
from typing import Any, Optional

from pydantic import BaseModel, model_serializer
from app.models.AgentModel import AgentModel

logger = logging.getLogger(__name__)

class FinalAgentResponse(AgentModel):
    context: Optional[dict] = None

# Only AgentResponse (the response model) changes
class AgentResponse(BaseModel):
    agent: FinalAgentResponse
    
    model_config = {"extra": "allow"}
    
    @model_serializer(mode='wrap')
    def serialize_without_sensitive(self, serializer, info):
        """Remove sensitive fields during serialization only"""
        data = serializer(self)
        if not isinstance(data, dict):
            return data
        try:
            agent_data = data.get("agent", {})
            for key in ["langfuse", "managerLlm", "masterEmbedding"]:
                agent_data.pop(key, None)
            if "agent" in agent_data and isinstance(agent_data["agent"], dict):
                agent = agent_data["agent"]
                for key in ["llm", "embedding"]:
                    agent.pop(key, None)
            return data
        except Exception as e:
            logger.warning(f"Error removing sensitive keys: {e}")
            return data

