
from pydantic import BaseModel, Field

from app.core.config import settings


class LangFuse(BaseModel):
    langfuseHost: str | None = Field(
        settings.LANGFUSE_HOST if settings else None, description="The host URL for Langfuse server."
    )
    langfusePublicKey: str | None = Field(
        settings.LANGFUSE_PUBLIC_KEY if settings else None, description="The public API key for Langfuse."
    )
    langfuseSecretKey: str | None = Field(
        settings.LANGFUSE_SECRET_KEY if settings else None, description="The secret API key for Langfuse."
    )
