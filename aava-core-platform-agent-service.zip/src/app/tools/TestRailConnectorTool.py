import base64
import json
import logging
from typing import Any, Type, Literal, List, Optional, Dict

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime

from pydantic import BaseModel, Field, model_validator
from crewai.tools import BaseTool

import AVASecret
from app.core.config import settings
from app.tools.tool_output_validation import validate_output

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------

class TestRailDefaults:
    TEMPLATE_ID = 1
    TYPE_ID = 6
    PRIORITY_ID = 2
    REQUEST_TIMEOUT = 30
    MAX_RETRIES = 3
    BACKOFF_FACTOR = 0.5


class TestRailError(Exception):
    pass


# ---------------------------------------------------------------------------
# SCHEMA
# ---------------------------------------------------------------------------

class TestStepSchema(BaseModel):
    Step_ID: int
    Step_Desc: str
    Expected_Result: str
    Test_Data: Optional[Any] = None


class MasterConnectorInput(BaseModel):

    operation: Literal[
        "fetch_cases",
        "get_case",
        "add_case",
        "update_case",
        "create_section",
        "bulk_create",
        "fetch_cases_by_project",
        "fetch_results_with_defects",
        "fetch_all_defects_for_case",
        "fetch_cases_hierarchy"
    ]

    base_url: str

    project_id: Optional[int] = None
    suite_id: Optional[int] = None
    section_id: Optional[int] = None

    case_id: Optional[int] = None
    case_ids: Optional[List[int]] = None

    testCaseId: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    IssueId: Optional[str] = None

    testSteps: List[TestStepSchema] = Field(default_factory=list)
    steps: Optional[List[str]] = None
    expected_result: Optional[List[str]] = None

    feasibility_score: Optional[float] = None
    automation_feasibility: Optional[Literal["Yes", "No", "May Be"]] = None
    estimate: Optional[str] = None
    milestone_id: Optional[int] = None
    refs: Optional[str] = None
    preconds: Optional[str] = None
    steps_text: Optional[str] = None
    expected_result_text: Optional[str] = None
    mission: Optional[str] = None
    goals: Optional[str] = None

    section_name: Optional[str] = None

    testcases_json: Optional[str] = None

    range: Optional[str] = None  # NEW: "start-end"
    parent_section_id: Optional[int] = None
    created_after: Optional[str] = ""
    created_before: Optional[str] = ""

    run_id: Optional[int] = None
    include_results: Optional[bool] = True

    @model_validator(mode="after")
    def validate_fields(self):
        op = self.operation

        if op == "fetch_cases":
            if not all([self.project_id, self.suite_id, self.section_id]):
                raise ValueError("fetch_cases requires project_id, suite_id, section_id")

        if op == "get_case":
            if not self.case_id and not self.case_ids:
                raise ValueError("get_case requires case_id or case_ids")

        if op == "add_case":
            if not self.section_id:
                raise ValueError("add_case requires section_id")

        if op == "update_case":
            if not self.case_id and not self.testCaseId:
                raise ValueError("update_case requires case_id or testCaseId")

        if op == "create_section":
            if not all([self.project_id, self.section_name]):
                raise ValueError("create_section requires project_id, suite_id, section_name")

        if op == "bulk_create":
            if not self.section_id or not self.testcases_json:
                raise ValueError("bulk_create requires section_id and testcases_json")

        if op == "fetch_cases_by_project":
            if not self.project_id:
                raise ValueError("fetch_cases_by_project requires project_id")

        if op == "fetch_results_with_defects":
            if not self.project_id and not self.run_id:
                raise ValueError("fetch_results_with_defects requires run_id or project_id")

        if op == "fetch_all_defects_for_case":
            if not self.project_id or not self.case_id:
                raise ValueError("fetch_all_defects_for_case requires project_id and case_id")

        return self


# ---------------------------------------------------------------------------
# TOOL
# ---------------------------------------------------------------------------

class TestRailConnectorTool(BaseTool):
    def _get_suite_map(self, session, base_url, project_id):
        """Fetch all suites for a project and return a map of id to name."""
        try:
            data = self._request(session, "GET", self._api(base_url, f"get_suites/{project_id}"))
            suites =  data.get("suites", []) if isinstance(data, dict) else data
            suites_with_name = {suite["id"]: suite["name"] for suite in suites}
            logger.info(f"suites: {suites_with_name}")
            return suites_with_name
            
        except Exception as e:
            logger.info(f"suites: {e}")
            return {}

    def _get_user_map(self, session, base_url):
        """Fetch all users and return a map of id to name."""
        try:
            data = self._request(session, "GET", self._api(base_url, "get_users"))
            users = data.get("users", []) if isinstance(data, dict) else data
            return {user["id"]: user["name"] for user in users}
        except Exception as e:
            logger.error(str(e))
            return {}

    def _get_type_map(self, session, base_url):
        """Fetch all case types and return a map of id to name."""
        try:
            data = self._request(session, "GET", self._api(base_url, "get_case_types"))
            return {t["id"]: t["name"] for t in data}
        except Exception:
            return {}

    name: str = "TestRail connector Tool"
    description: str = "Unified TestRail tool with AVASecret + Guardrails support."
    args_schema: Type[BaseModel] = MasterConnectorInput
    llm_details: dict | None = None

    # ------------------------------------------------------------------
    # ENTRY
    # ------------------------------------------------------------------

    def _run(self, **kwargs) -> Any:
        params = MasterConnectorInput(**kwargs)

        base_url = params.base_url.strip().rstrip("/")

        # ✅ Base URL allowlist validation
        allowed_base_urls = {
            url.strip().rstrip("/")
            for url in settings.TEST_RAIL_CONNECTOR_BASE_URL.replace(" ", "").split(",")
        }

        if base_url not in allowed_base_urls:
            return {"status": "error", "message": f"Base URL {base_url} not allowed"}

        # Fetch credentials from AVASecret
        username = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_test_rail_global")
        api_key = AVASecret.getValue(f"{settings.ENVIRONMENT_NAME}_test_rail_access")

        if not username or not api_key:
            return {"status": "error", "message": "Missing TestRail credentials from AVASecret"}

        session = self._build_session(username, api_key)

        dispatch = {
            "fetch_cases": self._fetch_cases,
            "get_case": self._get_case,
            "add_case": self._add_case,
            "update_case": self._update_case,
            "create_section": self._create_section,
            "bulk_create": self._bulk_create,
            "fetch_cases_by_project": self._fetch_cases_by_project,
            "fetch_results_with_defects": self._fetch_results_with_defects,
            "fetch_all_defects_for_case": self._fetch_all_defects_for_case,
            "fetch_cases_hierarchy": self._fetch_cases_hierarchy
        }

        try:
            return dispatch[params.operation](params, session, base_url)
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ------------------------------------------------------------------
    # SESSION
    # ------------------------------------------------------------------

    def _build_session(self, username, api_key):
        token = base64.b64encode(f"{username}:{api_key}".encode()).decode()

        session = requests.Session()
        session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Basic {token}",
        })

        retry = Retry(
            total=TestRailDefaults.MAX_RETRIES,
            backoff_factor=TestRailDefaults.BACKOFF_FACTOR,
            status_forcelist=[429, 500, 502, 503, 504],
        )

        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)

        return session

    def _api(self, base_url, endpoint):
        return f"{base_url}/index.php?/api/v2/{endpoint}"

    def _request(self, session, method, url, **kwargs):
        resp = session.request(method, url, timeout=30, **kwargs)
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # READ OPS (WITH GUARDRAILS)
    # ------------------------------------------------------------------

    def _apply_guardrails(self, data: Any):
        if not data:
            return data

        validation = validate_output(
            tool_name="TestRailConnectorTool",
            content=json.dumps(data),
            llm_details=self.llm_details
        )

        if not validation.get("success"):
            return validation.get("result")

        return data

    def _get_case(self, params, session, base_url):
        ids = params.case_ids or []
        if params.case_id:
            ids.append(params.case_id)

        automation_map = self._get_automation_status_map(session, base_url)
        field_maps = self._get_all_custom_field_maps(session, base_url)
        results = []
        for cid in ids:
            case = self._request(session, "GET", self._api(base_url, f"get_case/{cid}"))
            case = self._map_automation_status(case, automation_map)
            case = self._map_all_dropdown_fields(case, field_maps)
            results.append(case)

        return self._apply_guardrails({"status": "success", "cases": results})

    def _fetch_cases(self, params, session, base_url):

        start, end = self._parse_range(params.range)
        all_cases = []
        logger.info(f"__START__: {start}")
        date_filter = self._build_date_filter(params)
        # If no range → keep default behavior (single call)
        if not start:
            url = self._api(
                base_url,
                f"get_cases/{params.project_id}&suite_id={params.suite_id}&section_id={params.section_id}{date_filter}"
            )

            data = self._request(session, "GET", url)
            raw = data.get("cases", data) if isinstance(data, dict) else data
            all_cases = raw

        else:
            # Fetch ONLY required range using pagination
            logger.info(f"___START_END__: {start}_{end}")
            calls = self._build_pagination(start, end)

            logger.info(f"__calls__: {calls}")

            for offset, limit in calls:
                logger.info(f"__offset__:{offset} | {limit}")
                url = self._api(
                    base_url,
                    f"get_cases/{params.project_id}"
                    f"&suite_id={params.suite_id}"
                    f"&section_id={params.section_id}"
                    f"&offset={offset}&limit={limit}"
                    f"{date_filter}"
                )

                data = self._request(session, "GET", url)
                batch = data.get("cases", data) if isinstance(data, dict) else data

                if not batch:
                    break

                all_cases.extend(batch)

        raw = all_cases
        formatted = []
        priority_map = self._get_priority_map(session, base_url)
        automation_map = self._get_automation_status_map(session, base_url)
        field_maps = self._get_all_custom_field_maps(session, base_url)
        suite_map = self._get_suite_map(session, base_url, params.project_id)
        user_map = self._get_user_map(session, base_url)
        type_map = self._get_type_map(session, base_url)

        for case in raw:
            steps_sep = case.get("custom_steps_separated", [])
            if steps_sep:
                steps = [
                    {
                        "Step_ID": i + 1,
                        "Step_Desc": s.get("content"),
                        "Expected_Result": s.get("expected")
                    }
                    for i, s in enumerate(steps_sep)
                ]
            else:
                steps_lines = (case.get("custom_steps") or "").split("\n")
                exp_lines = (case.get("custom_expected") or "").split("\n")
                steps = [
                    {
                        "Step_ID": i + 1,
                        "Step_Desc": steps_lines[i] if i < len(steps_lines) else "",
                        "Expected_Result": exp_lines[i] if i < len(exp_lines) else ""
                    }
                    for i in range(len(steps_lines))
                ]
            pid = case.get("priority_id")
            suite_id = case.get("suite_id")
            created_by = case.get("created_by")
            updated_by = case.get("updated_by")
            type_id = case.get("type_id")

            case.update({
                "steps": steps,
                "priority": {"id": pid, "name": priority_map.get(pid, "unknown")},
                "suite": {"id": suite_id, "name": suite_map.get(suite_id, "unknown")} if suite_id else None,
                "created_by": {"id": created_by, "name": user_map.get(created_by, str(created_by))} if created_by else None,
                "updated_by": {"id": updated_by, "name": user_map.get(updated_by, str(updated_by))} if updated_by else None,
                "type": {"id": type_id, "name": type_map.get(type_id, str(type_id))} if type_id else None
            })

            case.pop("priority_id", None)
            case.pop("suite_id", None)
            case.pop("type_id", None)
            case = self._map_automation_status(case, automation_map)
            case = self._map_all_dropdown_fields(case, field_maps)
            formatted.append(case)

        return self._apply_guardrails({"status": "success", "cases": formatted})

    # ------------------------------------------------------------------
    # WRITE OPS
    # ------------------------------------------------------------------

    def _add_case(self, params, session, base_url):

        steps = []

        if params.testSteps:
            for step in params.testSteps:
                steps.append({
                    "content": step.Step_Desc,
                    "expected": step.Expected_Result
                })
        elif params.steps and params.expected_result:
            steps = [
                {"content": s, "expected": e}
                for s, e in zip(params.steps, params.expected_result)
            ]

        payload = {
            "title": params.title or f"Test Case {params.testCaseId}",
            "template_id": TestRailDefaults.TEMPLATE_ID,
            "type_id": TestRailDefaults.TYPE_ID,
            "priority_id": TestRailDefaults.PRIORITY_ID,
            "refs": params.IssueId,
            "custom_preconds": params.description,
            "custom_steps_separated": steps
        }

        res = self._request(
            session,
            "POST",
            self._api(base_url, f"add_case/{params.section_id}"),
            json=payload
        )

        return {
            "status": "success",
            "case_id": res.get("id"),
            "url": f"{base_url}/index.php?/cases/view/{res.get('id')}"
        }

    def _update_case(self, params, session, base_url):

        case_id = params.case_id or self._resolve_case_id(
            params.testCaseId,
            params.project_id,
            params.suite_id,
            session,
            base_url
        )

        payload: Dict = {}

        if params.steps and params.expected_result:
            payload["custom_steps_separated"] = [
                {"content": s, "expected": e}
                for s, e in zip(params.steps, params.expected_result)
            ]

        res = self._request(
            session,
            "POST",
            self._api(base_url, f"update_case/{case_id}"),
            json=payload
        )

        return {"status": "success", "updated_case": res}

    def _create_section(self, params, session, base_url):

        payload = {
            "name": params.section_name
        }

        if params.suite_id:
            payload.update({"suite_id": params.suite_id})

        # Add this
        if params.parent_section_id:
            payload["parent_id"] = params.parent_section_id

        res = self._request(
            session,
            "POST",
            self._api(base_url, f"add_section/{params.project_id}"),
            json=payload
        )

        return {
            "status": "success",
            "section": res,
            "is_subsection": bool(params.parent_section_id)
        }

    def _bulk_create(self, params, session, base_url):

        data = json.loads(params.testcases_json)
        testcases = data.get("testcases", [])

        results = []
        success = 0

        for tc in testcases:
            try:
                steps = [
                    {
                        "content": s.get("Enriched_step"),
                        "expected": s.get("expected_result")
                    }
                    for s in tc.get("Enriched_step", [])
                ]

                payload = {
                    "title": tc.get("title"),
                    "custom_steps_separated": steps
                }

                # Add optional fields if provided
                if tc.get("priority_id"):
                    payload["priority_id"] = tc["priority_id"]
                if tc.get("type_id"):
                    payload["type_id"] = tc["type_id"]
                if tc.get("refs"):
                    payload["refs"] = tc["refs"]
                if tc.get("milestone_id"):
                    payload["milestone_id"] = tc["milestone_id"]
                if tc.get("estimate"):
                    payload["estimate"] = tc["estimate"]
                if tc.get("custom_preconds"):
                    payload["custom_preconds"] = tc["custom_preconds"]
                if tc.get("custom_automationstatus"):
                    payload["custom_automationstatus"] = tc["custom_automationstatus"]

                res = self._request(
                    session,
                    "POST",
                    self._api(base_url, f"add_case/{params.section_id}"),
                    json=payload
                )

                success += 1
                results.append({"title": tc.get("title"), "id": res.get("id")})

            except Exception as e:
                results.append({"title": tc.get("title"), "error": str(e)})

        return {
            "status": "success",
            "total": len(testcases),
            "created": success,
            "details": results
        }


    def _fetch_cases_by_project(self, params, session, base_url):
        """
        Fetch all test cases across a project, optionally supporting a range.
        - If `params.range` is provided, fetch only that slice.
        - Otherwise, fetch all cases (paginated internally by TestRail).
        """

        project_id = params.project_id
        priority_map = self._get_priority_map(session, base_url)
        automation_map = self._get_automation_status_map(session, base_url)
        field_maps = self._get_all_custom_field_maps(session, base_url)
        suite_map = self._get_suite_map(session, base_url, project_id)
        user_map = self._get_user_map(session, base_url)
        type_map = self._get_type_map(session, base_url)
        date_filter = self._build_date_filter(params)

        # Determine offset and limit from range
        if getattr(params, "range", None):
            try:
                start_str, end_str = params.range.replace(" ", "").split("-")
                start = int(start_str)
                end = int(end_str)
                if start < 1 or end < start:
                    raise ValueError("Invalid range provided")
                limit = end - start + 1
                offset = start - 1  # TestRail offset is 0-based
            except Exception as e:
                return {"status": "error", "message": f"Invalid range format: {str(e)}"}
        else:
            # Default: fetch all in batches of 250
            limit = 250
            offset = 0

        all_results = []

        while True:
            try:
                # Construct project-level get_cases URL with limit & offset
                url = self._api(
                    base_url,
                    f"get_cases/{project_id}&limit={limit}&offset={offset}{date_filter}"
                )
                data = self._request(session, "GET", url)
                batch = data.get("cases", data) if isinstance(data, dict) else data

                if not batch:
                    break

                for case in batch:
                    steps_sep = case.get("custom_steps_separated", [])
                    if steps_sep:
                        steps = [
                            {"step": s.get("content"), "expected": s.get("expected")}
                            for s in steps_sep
                        ]
                    else:
                        steps = []

                    suite_id = case.get("suite_id")
                    created_by = case.get("created_by")
                    updated_by = case.get("updated_by")
                    type_id = case.get("type_id")

                    case = self._map_automation_status(case, automation_map)
                    case = self._map_all_dropdown_fields(case, field_maps)

                    all_results.append({
                        "id": case.get("id"),
                        "title": case.get("title"),
                        "suite": {"id": suite_id, "name": suite_map.get(suite_id, "unknown")} if suite_id else None,
                        "section_id": case.get("section_id"),
                        "priority": priority_map.get(case.get("priority_id", ""), "unknown"),
                        "type": {"id": type_id, "name": type_map.get(type_id, str(type_id))} if type_id else None,
                        "custom_automationstatus": case.get("custom_automationstatus", ""),
                        "created_by": {"id": created_by, "name": user_map.get(created_by, str(created_by))} if created_by else None,
                        "updated_by": {"id": updated_by, "name": user_map.get(updated_by, str(updated_by))} if updated_by else None,
                        "steps": steps,
                        "custom_fields": {k: v for k, v in case.items() if k.startswith("custom_") and k not in ["custom_steps", "custom_expected", "custom_steps_separated"]}
                    })

                # If range is specified, we only need one batch
                if getattr(params, "range", None):
                    break

                # If less than limit returned → done
                if len(batch) < limit:
                    break

                # Move to next batch
                offset += len(batch)

            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429:
                    return {"status": "error", "message": "Rate limit exceeded. Retry later."}
                return {"status": "error", "message": f"HTTP error: {str(e)}"}

            except requests.exceptions.RequestException as e:
                return {"status": "error", "message": f"Request failed: {str(e)}"}

            except Exception as e:
                logger.exception("Unexpected error in fetch_cases_by_project")
                return {"status": "error", "message": "Unexpected error occurred"}

        return self._apply_guardrails({
            "status": "success",
            "total_cases": len(all_results),
            "cases": all_results
        })


    # ------------------------------------------------------------------
    # HELPERS
    # ------------------------------------------------------------------

    def _resolve_case_id(self, test_case_id, project_id, suite_id, session, base_url):

        data = self._request(
            session,
            "GET",
            self._api(base_url, f"get_cases/{project_id}&suite_id={suite_id}")
        )

        raw = data.get("cases", data)

        for case in raw:
            if case.get("custom_test_case_id", "").upper() == test_case_id.upper():
                return case["id"]

        raise TestRailError(f"Test case {test_case_id} not found")

    def _get_priority_map(self, session, base_url):
        data = self._request(
            session,
            "GET",
            self._api(base_url, "get_priorities")
        )

        return {p["id"]: p["name"] for p in data}


    # ------------------------------------------------------------------
    # RANGE + PAGINATION HELPERS
    # ------------------------------------------------------------------

    def _parse_range(self, range_str: Optional[str]):
        if not range_str:
            return None, None

        try:
            start, end = map(int, range_str.split("-"))
        except Exception:
            raise ValueError(f"Invalid range format '{range_str}'. Use 'start-end'")

        if start < 1:
            raise ValueError("Range start must be >= 1")

        if start > end:
            raise ValueError("Range start cannot be greater than end")

        return start, end


    def _build_pagination(self, start: int, end: int, max_limit: int = 250):
        logger.info(f"build__pagination__start__{start}__{end}")

        calls = []

        start_index = start - 1
        remaining = end - start + 1
        offset = start_index

        while remaining > 0:
            batch_limit = min(max_limit, remaining)
            calls.append((offset, batch_limit))
            offset += batch_limit
            remaining -= batch_limit

        return calls

    def _get_all_custom_field_maps(self, session, base_url):
        """
        Build a comprehensive mapping for ALL dropdown custom fields.
        Returns a dict: {field_name: {id: value, ...}, ...}
        """
        field_maps = {}
        
        try:
            data = self._request(
                session,
                "GET",
                self._api(base_url, "get_case_fields")
            )

            for field in data:
                field_name = field.get("system_name") or field.get("name")
                

                # Try to extract options from configs
                for config in field.get("configs", []):
                    options = config.get("options", {}).get("items")
                    if options:
                        mapping = {}
                        try:
                            for item in options.split("\n"):
                                if item.strip():
                                    key, value = item.split(",", 1)
                                    mapping[int(key)] = value.strip()

                            if mapping:
                                field_maps[field_name] = mapping
                        except Exception as e:
                            logger.warning(f"Failed to parse options for field {field_name}: {str(e)}")
                            continue
                        break
        except Exception as e:
            logger.error(f"Error fetching custom field maps: {str(e)}")
        
        return field_maps

    def _map_all_dropdown_fields(self, case: dict, field_maps: dict):
        """
        Apply all dropdown field mappings to a case.
        Handles both single-value and multi-value dropdown fields.
        """
        for field_name, mapping in field_maps.items():
            field_value = case.get(field_name)
            
            if field_value is None:
                continue
            
            # Handle single value (int or string ID)
            if isinstance(field_value, (int, str)):
                try:
                    field_id = int(field_value) if isinstance(field_value, str) else field_value
                    case[field_name] = mapping.get(field_id, str(field_value))
                except (ValueError, TypeError):
                    pass
            
            # Handle multi-value (list of IDs)
            elif isinstance(field_value, list):
                mapped_values = []
                for item_id in field_value:
                    try:
                        item_id_int = int(item_id) if isinstance(item_id, str) else item_id
                        mapped_values.append(mapping.get(item_id_int, str(item_id)))
                    except (ValueError, TypeError):
                        mapped_values.append(str(item_id))
                case[field_name] = mapped_values
        
        return case

    def _map_automation_status(self, case: dict, status_map: dict):
        # Single value
        status_id = case.get("custom_automationstatus")
        if status_id is not None:
            case["custom_automationstatus"] = status_map.get(status_id, str(status_id))

        # Multi value
        status_list = case.get("custom_automation_statusess")
        if status_list:
            case["custom_automation_statusess"] = [
                status_map.get(sid, str(sid)) for sid in status_list
            ]

        return case


    def _get_automation_status_map(self, session, base_url):
        data = self._request(
            session,
            "GET",
            self._api(base_url, "get_case_fields")
        )

        for field in data:
            if field.get("system_name") == "custom_automationstatus":
                for config in field.get("configs", []):
                    options = config.get("options", {}).get("items")
                    if options:
                        mapping = {}
                        for item in options.split("\n"):
                            key, value = item.split(",", 1)
                            mapping[int(key)] = value.strip()
                        return mapping

        return {}


    def _build_date_filter(self, params):
        filters = ""

        if params.created_after:
            created_after_int = self._to_timestamp(params.created_after)
            filters += f"&created_after={created_after_int}"

        if params.created_before:
            created_before_int = self._to_timestamp(params.created_before)
            filters += f"&created_before={created_before_int}"

        return filters

    def _to_timestamp(self, date_str):
        return int(datetime.strptime(date_str, "%Y-%m-%d").timestamp())


    def _fetch_results_with_defects(self, params, session, base_url):
        run_id = params.run_id
        # If run_id not given → pick latest run
        if not run_id:
            runs = self._request(
                session,
                "GET",
                self._api(base_url, f"get_runs/{params.project_id}")
            )
            if not runs:
                return {"status": "error", "message": "No runs found"}
            run_id = runs[0]["id"]  # latest run

        # Step 1: Get tests in run
        tests = self._request(
            session,
            "GET",
            self._api(base_url, f"get_tests/{run_id}")
        )

        results_output = []

        for test in tests.get("tests", []) if isinstance(tests, dict) else tests:

            test_id = test.get("id")
            case_id = test.get("case_id")

            # Step 2: Get results for test
            results = self._request(
                session,
                "GET",
                self._api(base_url, f"get_results/{test_id}")
            )

            results =  results.get("results", []) if isinstance(results, dict) else results

            if not results:
                continue

            latest = results[0]  # latest result

            status_id = latest.get("status_id")

            results_output.append({
                "case_id": case_id,
                "test_id": test_id,
                "status_id": status_id,
                "status": self._map_status(status_id),
                "comment": latest.get("comment"),
                "defects": self._extract_defects(latest),
                "elapsed": latest.get("elapsed"),
                "created_on": latest.get("created_on")
            })

        return self._apply_guardrails({
            "status": "success",
            "run_id": run_id,
            "results": results_output
        })

    def _map_status(self, status_id: int):
        mapping = {
            1: "Passed",
            2: "Blocked",
            3: "Untested",
            4: "Retest",
            5: "Failed"
        }
        return mapping.get(status_id, "Unknown")

    def _extract_defects(self, obj: dict):
        refs = obj.get("defects") or obj.get("refs") or ""
        if not refs:
            return []
        return [r.strip() for r in refs.split(",") if r.strip()]


    def _fetch_all_defects_for_case(self, params, session, base_url):
        project_id = params.project_id
        case_id = params.case_id

        all_defects = set()
        runs_with_case = []

        # Step 1: Get all runs
        runs = self._request(
            session,
            "GET",
            self._api(base_url, f"get_runs/{project_id}")
        )

        if not runs:
            return {"status": "error", "message": "No runs found"}

        runs_list = runs.get("runs", []) if isinstance(runs, dict) else runs

        for run in runs_list:
            run_id = run.get("id")

            try:
                # Step 2: Get tests in run
                tests = self._request(
                    session,
                    "GET",
                    self._api(base_url, f"get_tests/{run_id}")
                )
            except Exception:
                continue

            tests_list = tests.get("tests", []) if isinstance(tests, dict) else tests

            # Step 3: Check if case exists in this run
            matching_tests = [t for t in tests_list if t.get("case_id") == case_id]

            if not matching_tests:
                continue

            runs_with_case.append(run_id)

            # Step 4: Fetch results for the case in this run
            try:
                results = self._request(
                    session,
                    "GET",
                    self._api(base_url, f"get_results_for_case/{run_id}/{case_id}")
                )
            except Exception:
                continue

            results_list = results.get("results", []) if isinstance(results, dict) else results

            for result in results_list:
                defects = self._extract_defects(result)
                for d in defects:
                    all_defects.add(d)

        return self._apply_guardrails({
            "case_id": case_id,
            "project_id": project_id,
            "total_runs_scanned": len(runs_list),
            "runs_with_case": runs_with_case,
            "defects": list(all_defects)
        })

    def _fetch_cases_hierarchy(self, params, session, base_url):
        """
        Fetch cases across section + subsections.

        Supports:
        - range="1-50" → returns slice
        - range=None → returns ALL cases
        """

        if not all([params.project_id, params.suite_id, params.section_id]):
            return {
                "status": "error",
                "message": "project_id, suite_id, section_id required"
            }

        # ----------------------------
        # Parse range (optional)
        # ----------------------------
        start, end = self._parse_range(params.range) if params.range else (None, None)

        # ----------------------------
        # Get section hierarchy
        # ----------------------------
        sections = self._get_sections(session, base_url, params.project_id, params.suite_id)

        all_section_ids = [params.section_id]
        all_section_ids += self._get_all_subsections(sections, params.section_id)

        # ----------------------------
        # Fetch + paginate
        # ----------------------------
        results = []
        global_index = 0

        date_filter = self._build_date_filter(params)

        for sid in all_section_ids:

            offset = 0
            limit = 250

            while True:
                url = self._api(
                    base_url,
                    f"get_cases/{params.project_id}"
                    f"&suite_id={params.suite_id}"
                    f"&section_id={sid}"
                    f"&offset={offset}&limit={limit}"
                    f"{date_filter}"
                )

                data = self._request(session, "GET", url)
                batch = data.get("cases", data) if isinstance(data, dict) else data

                if not batch:
                    break

                batch = sorted(batch, key=lambda x: x.get("id"))

                for case in batch:
                    global_index += 1

                    # ----------------------------
                    # RANGE FILTER (optional)
                    # ----------------------------
                    if start and end:
                        if start <= global_index <= end:
                            results.append(case)

                        if global_index >= end:
                            return self._apply_guardrails({
                                "status": "success",
                                "range": params.range,
                                "returned": len(results),
                                "cases": results
                            })

                    else:
                        # NO RANGE → collect everything
                        results.append(case)

                if len(batch) < limit:
                    break

                offset += len(batch)

        return self._apply_guardrails({
            "status": "success",
            "range": params.range,
            "returned": len(results),
            "cases": results
        })

    def _get_sections(self, session, base_url, project_id, suite_id=None):
        """
        Fetch all sections for a project (and suite if provided).
        """
        endpoint = f"get_sections/{project_id}"

        if suite_id:
            endpoint += f"&suite_id={suite_id}"

        data = self._request(session, "GET", self._api(base_url, endpoint))

        return data.get("sections", data) if isinstance(data, dict) else data

    def _get_all_subsections(self, sections, parent_id):
        """
        Recursively collect all child section IDs for a given parent section.
        """
        result = []

        def dfs(pid):
            for s in sections:
                if s.get("parent_id") == pid:
                    sid = s.get("id")
                    result.append(sid)
                    dfs(sid)

        dfs(parent_id)
        return result