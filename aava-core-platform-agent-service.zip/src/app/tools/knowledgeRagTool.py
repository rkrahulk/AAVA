import logging
from typing import Any
import httpx
from crewai.tools.base_tool import BaseTool
from pydantic import BaseModel, Field
from app.core.config import settings
from app.core.redis_client import redis_client
from app.helpers.redis_logs import PipelineAILogs

logger = logging.getLogger(__name__)

class KnowledgeRAGToolSchema(BaseModel):
    """Input for KnowledgeRAGTool."""
    question: str = Field(..., description="The question to search for in the knowledge base.")

class KnowledgeRAGTool(BaseTool):
    name: str = "Knowledge Base Answer Retrieval"
    description: str = (
        "A tool to retrieve comprehensive answers from the knowledge base. "
        "Input should be a clear and specific question."
    )
    args_schema: type[BaseModel] = KnowledgeRAGToolSchema
    agent_id: Any = None
    auth_token: str | None = None

    def __init__(
        self,
        **kwargs,
    ):
        # Handle the case where 'input' might be passed but we don't use it anymore
        kwargs.pop('input', None)
        
        # Extract kwargs that might be passed from AgentToolConfigurator
        extra_kwargs = kwargs.pop('kwargs', {})
        if not redis_client and 'redis_client' in extra_kwargs:
            # This is just to satisfy the old interface if needed
            self._redis_client = extra_kwargs['redis_client']
        
        super().__init__(**kwargs)

    def _run(
        self,
        question: str,
        **kwargs: Any,
    ) -> Any:
        try:
            logger.info("Knowledge Base Search question: %s", question)
            
            # Prepare the payload for the RAG API
            agent_id_to_use = str(self.agent_id)
            
            payload = {
                "question": question,
                "agentId": agent_id_to_use,
                "topK": 5,
                "similarityThreshold": 0.1,
                # "featureConfig": {
                #     "rerankingEnabled": True
                # }
            }
            
            headers = {
                "Content-Type": "application/json"
            }
            
            headers["Authorization"] = self.auth_token

            url = settings.RAG_API_URL
            
            logger.info("Calling RAG API: %s with agentId: %s", url, agent_id_to_use)
            
            with httpx.Client(timeout=60.0) as client:
                response = client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                result = response.json()
            
            if result.get("status") == "SUCCESS":
                data = result.get("data", {})
                answer = data.get("answer", "No answer found.")

                # Extract chunkContent from sources
                sources = data.get("sources", [])
                chunks = []

                for src in sources:
                    # handle multiple possible structures safely
                    chunk = (
                        src.get("chunkContent")
                        or src.get("content")
                        or src.get("text")
                        or src.get("metadata", {}).get("chunkContent")
                    )
                    if chunk:
                        chunks.append(chunk)

                logger.info("RAG API Success")


                # Return answer + KB context (matches AAVA 1.0 behavior)
                if chunks:
                    response = (
                        "This is your answer : \n"
                        + answer
                        + "\n\n--- Source Context ---\n"
                        + "\n\n".join(chunks)
                    )
                    return response
                return answer

            else:
                error_msg = f"RAG API returned status: {result.get('status')}"
                logger.error(error_msg)
                return f"Error retrieving answer: {error_msg}"

        except Exception as e:
            logger.error("Knowledge Base Tool error: %s", str(e))
            return f"An error occurred while calling the knowledge base: {str(e)}"
