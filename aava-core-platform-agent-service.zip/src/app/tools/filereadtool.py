# from tika import parser
import logging
from io import BytesIO
from typing import Any

import httpx
import pandas as pd
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.core.config import settings
from app.helpers.file_utils import get_content_type
from app.core.secret_manager import secret_manager
from app.helpers.guardrails import GuardRails
from app.tools.tool_output_validation import validate_output

logger = logging.getLogger(__name__)


class FileReadToolSchema(BaseModel):
    """Input for FileReadTool."""

    file_path: str = Field(..., description="Mandatory file full path to read the file")


class FileReadTool(BaseTool):
    """A tool for reading file contents.

    This tool inherits its schema handling from BaseTool to avoid recursive schema
    definition issues. The args_schema is set to FileReadToolSchema which defines
    the required file_path parameter. The schema should not be overridden in the
    constructor as it would break the inheritance chain and cause infinite loops.

    The tool supports two ways of specifying the file path:
    1. At construction time via the file_path parameter
    2. At runtime via the file_path parameter in the tool's input

    Args:
        file_path (Optional[str]): Path to the file to be read. If provided,
            this becomes the default file path for the tool.
        **kwargs: Additional keyword arguments passed to BaseTool.

    Example:
        >>> tool = FileReadTool(file_path="/path/to/file.txt")
        >>> content = tool.run()  # Reads /path/to/file.txt
        >>> content = tool.run(file_path="/path/to/other.txt")  # Reads other.txt
    """

    name: str = "Read a file's content"
    description: str = (
        "A tool that reads the content of a file. To use this tool, provide a 'file_path' parameter with the path to the file you want to read."
    )
    llm_details: dict | None = None 
    args_schema: type[BaseModel] = FileReadToolSchema
    file_path: str | None = None
    auth_token: str | None = None

    def parse_with_tika(self, file_path):
        try:
            tika_url = settings.BASE_API_URL + settings.TIKA_API_URL
            with open(file_path, "rb") as file:
                file_content = file.read()

            file_stream = BytesIO(file_content)
            content_type = get_content_type(filename=file_path)
            files = [("file", (file_path, file_stream, content_type))]
            headers = {
                "Authorization": self.auth_token,
                "Accept": "application/json",
            }
            resp = httpx.post(
                url=tika_url, 
                timeout=int(settings.REQUEST_TIMEOUT),
                files=files, 
                headers=headers
            )
            resp.raise_for_status()
            logger.info(f"File Content Fetched: {resp.json()['extractedText']}")
            return resp.json()["extractedText"]
        except Exception as e:
            if logger:
                logger.error(f"Tika error: {str(e)}")
            raise e.__class__(" - " + "tika parse error " + str(e)) from e


    def __init__(self, file_path: str | None = None, **kwargs: Any) -> None:
        """Initialize the FileReadTool.

        Args:
            file_path (Optional[str]): Path to the file to be read. If provided,
                this becomes the default file path for the tool.
            **kwargs: Additional keyword arguments passed to BaseTool.
        """
        if file_path is not None:
            kwargs["description"] = (
                f"A tool that reads file content. The default file is {file_path}, but you can provide a different 'file_path' parameter to read another file."
            )

        super().__init__(**kwargs)
        self.file_path = file_path

    def _run(
        self,
        **kwargs: Any,
    ) -> str:
        file_path = kwargs.get("file_path", self.file_path)
        if file_path is None:
            return "Error: No file path provided. Please provide a file path either in the constructor or as an argument."

        try:
            content = ""
            if file_path.endswith(".xlsx"):
                logger.debug(f"Reading Excel file at {file_path}")
                content = pd.read_excel(file_path).to_string(index=False)
            else:
                # content = parser.from_file(file_path)['content']
                content = self.parse_with_tika(file_path)
                logger.debug(f"File content parsed from {file_path}: {content}")
            if content:
                guardrails_validation = validate_output(
                    tool_name="filereadtool",
                    content=content,
                    llm_details=self.llm_details,
                    file_path=file_path
                )

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]
            
            return content

        except FileNotFoundError:
            return f"Error: File not found at path: {file_path}"
        except PermissionError:
            return f"Error: Permission denied when trying to read file: {file_path}"
        except Exception as e:
            return f"Error: Failed to read file {file_path}. {str(e)}"
