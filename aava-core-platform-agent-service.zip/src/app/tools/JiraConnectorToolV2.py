import os
import json
import csv
import requests
import logging
from typing import Optional, Dict, List
from concurrent.futures import ThreadPoolExecutor, as_completed

from pydantic import BaseModel, Field
from crewai.tools import BaseTool

from app.core.config import settings
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

logger = logging.getLogger(__name__)

class JiraConnectorSchema(BaseModel):

    base_url: str = Field(..., description="Jira base domain")

    operation: str = Field(
        ...,
        description="Operation type: create_issue / modify_issue / update_status / add_comment / bulk_create"
    )

    issue_key: Optional[str] = None
    project_key: Optional[str] = None
    summary: Optional[str] = None
    description: Optional[str] = None
    issue_type: Optional[str] = None

    priority: Optional[str] = None
    assignee: Optional[str] = None
    status: Optional[str] = None
    story_points: Optional[int] = None
    parent_ticket: Optional[str] = None

    custom_fields: Optional[Dict[str, str]] = {}

    csv_file_path: Optional[str] = None

    adf_type: Optional[str] = "paragraph"
    code_language: Optional[str] = "json"
    comment_text: Optional[str] = None
    file_path: Optional[str] = None
    inward_issue_key: Optional[str] = None
    outward_issue_key: Optional[str] = None
    link_type: Optional[str] = Field(None, description="Jira issue link type (e.g., Blocks, Relates)")
    test_scenarios: Optional[List[Dict]] = Field(None, description="List of test scenarios as dictionaries")
    parent_issue_key: Optional[str] = Field(None, description="Parent Jira issue key (e.g., 'HPX-123')")

    check_duplicate: bool = Field(
        False,
        description=(
            "If True, checks for an existing issue with the same project, "
            "issue type, summary (and parent if provided) before creating. "
            "Applies to: create_issue, bulk_create, create_subtask_with_scenarios."
        )
    )


class JiraConnectorToolV2(BaseTool):

    name: str = "JiraConnectorToolV2"

    description: str = """
    Jira connector tool supporting multiple operations.

    Supported operations:
    - create_issue
    - modify_issue
    - update_status
    - add_comment
    - bulk_create
    - link_issue
    - upload_file
    - create_subtask_with_scenarios
    """

    service_account_type: str
    args_schema: type = JiraConnectorSchema

    MAX_THREADS: int = 5

    # -----------------------------------------------------
    # API VERSION DETECTION
    # -----------------------------------------------------

    def _get_api_info(self, base_url):

        if ".atlassian.net" in base_url:
            return "3", f"{base_url}/rest/api/3"

        return "2", f"{base_url}/rest/api/2"

    # -----------------------------------------------------
    # FIELD DISCOVERY
    # -----------------------------------------------------

    def _get_all_fields(self, api_url, headers, auth):

        url = f"{api_url}/field"

        if ".atlassian.net" in api_url:
            url = f"{api_url}/field?expand=custom"

        res = requests.get(
            url,
            headers=headers,
            auth=auth,
            timeout=60
        )
        print("response for fields")

        res.raise_for_status()

        return res.json()

    # -----------------------------------------------------
    # STORY POINT FIELD DETECTION
    # -----------------------------------------------------

    def _get_story_point_field(self, api_url, headers, auth):

        fields = self._get_all_fields(api_url, headers, auth)

        for f in fields:
            if "story point" in f["name"].lower():
                return f["id"]

        return None

    # -----------------------------------------------------
    # CUSTOM FIELD RESOLUTION
    # -----------------------------------------------------

    def _resolve_custom_fields(self, custom_fields, api_url, headers, auth):

        fields = self._get_all_fields(api_url, headers, auth)

        name_to_id = {
            f["name"].lower(): f["id"]
            for f in fields
        }
        print("name_id")
        print(name_to_id)

        resolved = {}

        if custom_fields.get("story_points"):
            for display_name, field_id in name_to_id.items():
                if "story" in display_name.lower():
                    resolved[field_id] = custom_fields.get("story_points")
            custom_fields.pop("story_points", "")


        for display_name, value in custom_fields.items():

            field_id = name_to_id.get(display_name.lower())

            if not field_id:
                raise Exception(f"Custom field '{display_name}' not found")

            resolved[field_id] = value

        return resolved

    # -----------------------------------------------------
    # ADF BUILDER
    # -----------------------------------------------------

    def _build_adf_doc(self, text: str, adf_type="paragraph", language="json"):

        if adf_type == "codeBlock":

            node = {
                "type": "codeBlock",
                "attrs": {"language": language},
                "content": [{"type": "text", "text": text}]
            }

        else:

            node = {
                "type": "paragraph",
                "content": [{"type": "text", "text": text}]
            }

        return {
            "version": 1,
            "type": "doc",
            "content": [node]
        }

    # -----------------------------------------------------
    # CSV READER
    # -----------------------------------------------------

    def _read_csv(self, csv_path):

        if not os.path.exists(csv_path):
            raise Exception(f"CSV file not found: {csv_path}")

        rows = []

        with open(csv_path, newline="", encoding="utf-8") as f:

            reader = csv.DictReader(f)

            for row in reader:

                ticket = {
                    k.strip().lower(): v.strip()
                    for k, v in row.items()
                    if v and v.strip()
                }

                rows.append(ticket)

        if not rows:
            raise Exception("CSV file is empty")

        return rows

    # -----------------------------------------------------
    # DUPLICATE DETECTION HELPERS
    # -----------------------------------------------------

    def _search_issues(self, api_url, headers, auth, jql):
        """Search Jira issues via JQL, returns list of issue dicts."""
        res = requests.post(
            f"{api_url}/search/jql",   # works for v3 (Cloud)
            headers=headers,
            auth=auth,
            json={"jql": jql, "maxResults": 50, "fields": ["summary", "parent", "status"]},
            timeout=60
        )
        if not res.ok:
            # Fallback for v2 (Server/DC)
            res = requests.get(
                f"{api_url}/search",
                headers=headers,
                auth=auth,
                params={"jql": jql, "maxResults": 50, "fields": "summary,parent,status"},
                timeout=60
            )
        res.raise_for_status()
        return res.json().get("issues", [])

    def _find_existing_issue(self, api_url, headers, auth, project_key, summary, issue_type, parent_key=None):
        """
        Returns existing issue key if a matching issue is found, else None.
        Matches on: project, issuetype, summary (case-insensitive), and optionally parent.

        JQL uses ~ (contains) for initial filtering, then Python does an exact
        case-insensitive comparison to eliminate fuzzy false positives.
        """
        safe_summary = summary.replace('"', '\\"')
        jql = (
            f'project = "{project_key}" '
            f'AND issuetype = "{issue_type}" '
            f'AND summary ~ "{safe_summary}"'
        )
        if parent_key:
            jql += f' AND parent = "{parent_key}"'

        issues = self._search_issues(api_url, headers, auth, jql)

        for issue in issues:
            existing_summary = (issue.get("fields", {}).get("summary") or "").strip().lower()
            if existing_summary == summary.strip().lower():
                return issue["key"]  # exact match found

        return None

    # -----------------------------------------------------
    # BULK ISSUE CREATION
    # -----------------------------------------------------

    def _bulk_create_from_csv(self, args, api_url, headers, auth, ver):

        rows = self._read_csv(args.csv_file_path)

        story_point_field = self._get_story_point_field(api_url, headers, auth)

        results = []

        def create_ticket(row):

            try:
                # --- DUPLICATE CHECK (only when opted in) ---
                if args.check_duplicate:
                    existing_key = self._find_existing_issue(
                        api_url, headers, auth,
                        project_key=args.project_key,
                        summary=row["summary"],
                        issue_type=row.get("issuetype"),
                        parent_key=row.get("parent")
                    )
                    if existing_key:
                        return {
                            "status": "already_exists",
                            "issue_key": existing_key,
                            "url": f"{args.base_url}/browse/{existing_key}"
                        }

                payload = {
                    "fields": {
                        "project": {"key": args.project_key},
                        "summary": row["summary"],
                        "issuetype": {"name": row.get("issuetype")}
                    }
                }

                if row.get("description"):

                    payload["fields"]["description"] = (
                        self._build_adf_doc(row["description"])
                        if ver == "3"
                        else row["description"]
                    )

                if row.get("priority"):
                    payload["fields"]["priority"] = {"name": row["priority"]}

                if row.get("assignee"):

                    if ver == "3":
                        payload["fields"]["assignee"] = {"accountId": row["assignee"]}
                    else:
                        payload["fields"]["assignee"] = {"name": row["assignee"]}

                print("story points details:", row.get("story_points"), story_point_field)

                if row.get("story_points") and story_point_field:
                    payload["fields"][story_point_field] = float(row["story_points"])

                if row.get("parent"):
                    payload["fields"]["parent"] = {"key": row["parent"]}

                res = requests.post(
                    f"{api_url}/issue",
                    json=payload,
                    headers=headers,
                    auth=auth,
                    timeout=60
                )

                res.raise_for_status()

                issue_key = res.json()["key"]

                return {
                    "status": "success",
                    "issue_key": issue_key,
                    "url": f"{args.base_url}/browse/{issue_key}"
                }

            except Exception as e:

                return {
                    "status": "failed",
                    "error": str(e),
                    "row": row
                }

        with ThreadPoolExecutor(max_workers=self.MAX_THREADS) as executor:

            futures = [executor.submit(create_ticket, row) for row in rows[:3]]

            for future in as_completed(futures):
                results.append(future.result())

        success = [r for r in results if r["status"] == "success"]
        skipped = [r for r in results if r["status"] == "already_exists"]
        failed  = [r for r in results if r["status"] == "failed"]

        return {
            "total_rows": len(rows),
            "tickets_created": len(success),
            "tickets_skipped": len(skipped),
            "tickets_failed": len(failed),
            "created_tickets": [s["url"] for s in success],
            "skipped_tickets": [s["url"] for s in skipped],
            "failed_rows": failed
        }

    # -----------------------------------------------------
    # MAIN TOOL LOGIC
    # -----------------------------------------------------

    def _run(self, **kwargs):

        args = JiraConnectorSchema(**kwargs)

        base_url = args.base_url.strip().rstrip("/")

        allowed_base_urls = {
            url.strip().rstrip("/")
            for url in settings.JIRA_BASE_URL.replace(" ", "").split(",")
        }

        if not is_valid_base_url(base_url, allowed_base_urls):
            return f"Invalid Jira base URL: {base_url}"

        username, password = get_system_tool_secrets(
            action="write",
            tool_type="jira",
            service_account_type=self.service_account_type
        )

        auth = (username, password)

        ver, api_url = self._get_api_info(base_url)

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        operation = args.operation.lower().strip()

        # -------------------------------------------------
        # BULK CREATE
        # -------------------------------------------------

        if operation == "bulk_create":

            if not args.csv_file_path:
                return "csv_file_path required"

            if not args.project_key:
                return "project_key required"

            return self._bulk_create_from_csv(
                args,
                api_url,
                headers,
                auth,
                ver
            )

        # -------------------------------------------------
        # CREATE ISSUE
        # -------------------------------------------------

        if operation == "create_issue":

            # --- DUPLICATE CHECK (only when opted in) ---
            if args.check_duplicate:
                existing_key = self._find_existing_issue(
                    api_url, headers, auth,
                    project_key=args.project_key,
                    summary=args.summary,
                    issue_type=args.issue_type,
                    parent_key=args.parent_issue_key
                )
                if existing_key:
                    return {
                        "status": "already_exists",
                        "issue_key": existing_key,
                        "url": f"{base_url}/browse/{existing_key}"
                    }

            payload = {
                "fields": {
                    "project": {"key": args.project_key},
                    "summary": args.summary,
                    "issuetype": {"name": args.issue_type}
                }
            }


            final_issue_type = args.issue_type
            if args.parent_issue_key:
                resolved_type = self._resolve_subtask_type(api_url, auth, args.project_key)
                if resolved_type:
                    final_issue_type = resolved_type 

            if args.parent_issue_key:
                payload["fields"]["parent"] = {"key": args.parent_issue_key}


            if args.description:

                payload["fields"]["description"] = (
                    self._build_adf_doc(args.description)
                    if ver == "3"
                    else args.description
                )
            
            if args.priority:
                payload["fields"]["priority"] = {
                    "name": args.priority
                }

            if args.assignee:
                if ver == "2":
                    payload["fields"]["assignee"] = {
                        "name": args.assignee
                    }
                else:
                    payload["fields"]["assignee"] = {
                        "accountId": args.assignee
                    }

            if args.story_points or args.custom_fields:
                custom_fields = args.custom_fields or {}
                if args.story_points:
                    custom_fields.update({
                        "story_points": args.story_points
                    })
                
                payload.get("fields", {}).update(
                    self._resolve_custom_fields(custom_fields, api_url=api_url, headers=headers, auth=auth)
                )
            res = requests.post(
                f"{api_url}/issue",
                json=payload,
                headers=headers,
                auth=auth,
                timeout=60
            )

            res.raise_for_status()

            return f"{base_url}/browse/{res.json()['key']}"


        if operation in ("update issue", "modify issue", "update", "modify ticket", "modify_issue", "modify jira ticket"):
            if not args.issue_key:
                return "Error: Issue key is required for modifying a ticket."
            
            if not args.project_key.lower() in args.issue_key.lower():
                return "Error: Issue key and Project Key is not matching."

            payload = {"fields": {}}
            if args.summary:
                payload["fields"]["summary"] = args.summary
            if args.description:
                payload["fields"]["description"] = (
                    self._build_adf_doc(args.description, args.adf_type, args.code_language) 
                    if ver == "3" else args.description
                )

            if args.priority:
                payload["fields"]["priority"] = {
                    "name": args.priority
                }

            if args.assignee:
                if ver == "2":
                    payload["fields"]["assignee"] = {
                        "name": args.assignee
                    }
                else:
                    payload["fields"]["assignee"] = {
                        "accountId": args.assignee
                    }

            if args.issue_type:
                payload["fields"]["issuetype"] = {
                    "name": args.issue_type
                }

            if args.story_points or args.custom_fields:
                custom_fields = args.custom_fields or {}
                if args.story_points:
                    custom_fields.update({
                        "story_points": args.story_points
                    })
                
                payload.get("fields", {}).update(
                    self._resolve_custom_fields(custom_fields, api_url=api_url, headers=headers, auth=auth)
                )

            res = requests.put(f"{api_url}/issue/{args.issue_key}", json=payload, headers=headers, auth=auth)
            res.raise_for_status()

            return f"{base_url}/browse/{args.issue_key}"


        # -------------------------------------------------
        # ADD COMMENT
        # -------------------------------------------------

        if operation == "add_comment":

            comment_body = (
                self._build_adf_doc(args.comment_text)
                if ver == "3"
                else args.comment_text
            )

            res = requests.post(
                f"{api_url}/issue/{args.issue_key}/comment",
                json={"body": comment_body},
                headers=headers,
                auth=auth,
                timeout=60
            )

            res.raise_for_status()

            return f"{base_url}/browse/{args.issue_key}"


        if operation == "link_issue":
            payload = {"type": {"name": args.link_type}, "inwardIssue": {"key": args.inward_issue_key}, "outwardIssue": {"key": args.outward_issue_key}}

            # Use dynamic api_url (handles both Cloud v3 and Server v2)
            # issueLink endpoint is the same path in both v2 and v3
            res = requests.post(f"{api_url}/issueLink", json=payload, headers=headers, auth=auth, timeout=60)
            res.raise_for_status()
            return f"{base_url}/browse/{args.outward_issue_key}"

        if operation == "upload_file":
            file_headers = {"Accept": "application/json", "X-Atlassian-Token": "nocheck"}
            with open(args.file_path, "rb") as f:
                files = {"file": (os.path.basename(args.file_path), f)}
                res = requests.post(f"{base_url}/rest/api/2/issue/{args.issue_key}/attachments", files=files, headers=file_headers, auth=auth)
                res.raise_for_status()
                attachments = res.json()
                attachment_info = [{"attachment_id": att["id"], "filename": att["filename"]} for att in attachments]
                return {"issue_url": f"{base_url}/browse/{args.issue_key}", "attachments": attachment_info}
        


        if operation in ("update_status", "change_status", "status", "update status", "change status"):
            if args.status:
                transitions_url = f"{api_url}/issue/{args.issue_key}/transitions"

                t_response = requests.get(
                    transitions_url,
                    auth=auth,
                    headers=headers,
                    timeout=60
                )

                transitions = t_response.json().get("transitions", [])

                target_status = args.status.strip().lower()

                transition_id = next(
                    (t["id"] for t in transitions
                    if t["to"]["name"].strip().lower() == target_status),
                    None
                )

                if not transition_id:
                    return json.dumps({
                        "error": f"Status '{args.status}' not available for transition."
                    })

                tr_response = requests.post(
                    transitions_url,
                    json={"transition": {"id": transition_id}},
                    auth=auth,
                    headers=headers,
                    timeout=60
                )

                if not tr_response.ok:
                    logger.info("jira write: status update failed")
                    logger.info(tr_response.text)
                    return json.dumps({
                        "error": "Other fields are updated but status transition failed",
                        "details": tr_response.text
                    })
                
                return f"{base_url}/browse/{args.issue_key}"
            else:
                return "Error: status is missing."


        if operation == "create_subtask_with_scenarios":
            return self._create_subtask_with_scenarios(
                args,
                api_url,
                headers,
                auth,
                base_url
            )

        return f"Unsupported operation: {operation}"

    def _create_subtask_with_scenarios(self, args, api_url, headers, auth, base_url):

        parent_issue_key = args.parent_issue_key
        test_scenarios = args.test_scenarios

        # -----------------------------------
        # VALIDATIONS
        # -----------------------------------
        if not parent_issue_key or "-" not in parent_issue_key:
            return f"❌ Invalid parent_issue_key: {parent_issue_key}"

        if not test_scenarios:
            return "❌ test_scenarios required"

        # -----------------------------------
        # HANDLE STRING INPUT (IMPORTANT FIX)
        # -----------------------------------
        if isinstance(test_scenarios, str):
            try:
                test_scenarios = json.loads(test_scenarios)
            except Exception:
                return "❌ test_scenarios must be valid JSON string"

        if not isinstance(test_scenarios, list):
            return "❌ test_scenarios must be a list"

        project_key = parent_issue_key.split("-")[0]

        # -----------------------------------
        # RESOLVE SUBTASK TYPE
        # (needed before duplicate check so subtask_type is defined)
        # -----------------------------------
        subtask_type = self._resolve_subtask_type(api_url, auth, project_key)

        # -----------------------------------
        # DUPLICATE CHECK (only when opted in)
        # Placed here after all required variables
        # (project_key, subtask_type, test_scenarios)
        # are fully defined
        # -----------------------------------
        if args.check_duplicate:
            subtask_summary = f"Batch Test Scenarios ({len(test_scenarios)} items)"
            existing_key = self._find_existing_issue(
                api_url, headers, auth,
                project_key=project_key,
                summary=subtask_summary,
                issue_type=subtask_type,
                parent_key=parent_issue_key
            )
            if existing_key:
                return f"⚠️ Subtask already exists: {base_url}/browse/{existing_key}"

        # -----------------------------------
        # STEP 1: FETCH PARENT ISSUE
        # -----------------------------------
        delivery_team_value = None

        try:
            parent_res = requests.get(
                f"{api_url}/issue/{parent_issue_key}",
                headers=headers,
                auth=auth,
                timeout=60
            )

            if not parent_res.ok:
                return f"❌ Failed to fetch parent issue: {parent_res.text}"

            parent_fields = parent_res.json().get("fields", {})

            # OPTIONAL FIELD (SAFE)
            if "customfield_21600" in parent_fields:
                field = parent_fields.get("customfield_21600")
                if field:
                    delivery_team_value = field.get("value") or field.get("name")

        except Exception as e:
            return f"❌ Exception fetching parent issue: {str(e)}"

        # -----------------------------------
        # STEP 2: FORMAT SCENARIOS
        # -----------------------------------
        description_text = self._format_scenarios(test_scenarios)

        # ✅ FIX: Jira v2 vs v3 compatibility
        description_payload = (
            self._build_adf_doc(description_text)
            if "rest/api/3" in api_url
            else description_text
        )

        # -----------------------------------
        # STEP 3: BUILD PAYLOAD
        # -----------------------------------
        payload = {
            "fields": {
                "project": {"key": project_key},
                "parent": {"key": parent_issue_key},
                "summary": f"Batch Test Scenarios ({len(test_scenarios)} items)",
                "description": description_payload,
                "issuetype": {"name": subtask_type}
            }
        }

        # OPTIONAL CUSTOM FIELD
        if delivery_team_value:
            payload["fields"]["customfield_21600"] = {
                "value": delivery_team_value
            }

        # -----------------------------------
        # DEBUG LOG (VERY IMPORTANT)
        # -----------------------------------
        print("\n🚀 FINAL PAYLOAD:")
        print(json.dumps(payload, indent=2))

        # -----------------------------------
        # STEP 4: CREATE SUBTASK
        # -----------------------------------
        try:
            res = requests.post(
                f"{api_url}/issue",
                json=payload,
                headers=headers,
                auth=auth,
                timeout=60
            )

            # -----------------------------------
            # RETRY WITHOUT CUSTOM FIELD
            # -----------------------------------
            if res.status_code >= 400 and delivery_team_value:
                print("⚠️ Retrying without customfield_21600")

                payload["fields"].pop("customfield_21600", None)

                res = requests.post(
                    f"{api_url}/issue",
                    json=payload,
                    headers=headers,
                    auth=auth,
                    timeout=60
                )

            # -----------------------------------
            # HANDLE ERROR PROPERLY
            # -----------------------------------
            if not res.ok:
                print("❌ JIRA ERROR RESPONSE:")
                print(res.text)
                return f"❌ Subtask creation failed: {res.text}"

            issue_key = res.json().get("key")

            return f"✅ Subtask created: {base_url}/browse/{issue_key}"

        except Exception as e:
            return f"❌ Exception during subtask creation: {str(e)}"


    def _format_scenarios(self, scenarios):

        parts = []

        for i, scenario in enumerate(scenarios, 1):
            lines = [f"*{k}:* {v}" for k, v in scenario.items()]

            parts.append(
                f"h3. Scenario {i}\n" + "\n".join(lines)
            )

        return "\n\n----\n\n".join(parts)

    def _resolve_subtask_type(self, api_url, auth, project_key):
        """
        Smart Feature: Different Jira projects might rename 'Sub-task' to 'Subtask', 'Sub Task', etc.
        This queries the specific project to find the exact internal name expected by the API.
        """
        try:
            res = requests.get(f"{api_url}/project/{project_key}", auth=auth)
            if res.status_code == 200:
                issue_types = res.json().get("issueTypes", [])
                for itype in issue_types:
                    # Check the boolean flag 'subtask' rather than relying on string matching
                    if itype.get("subtask") is True:
                        return itype.get("name")
        except Exception as e:
            print("Subtask type fetch failed:", str(e))

        return "Sub-task"  # fallback
