import logging
from typing import Any

from crewai.tools import BaseTool
from pydantic import BaseModel

from app.core.redis_client import redis_client
from app.helpers.redis_logs import PipelineAILogs
from app.tools.tool_output_validation import validate_output

logger = logging.getLogger(__name__)


class FixedMemoryReaderWriterTool(BaseModel):
    """Input for MemoryReaderWriterTool."""


class MemoryReaderWriterToolSchema(FixedMemoryReaderWriterTool):
    """Input for MemoryReaderWriterTool."""


class MemoryReaderWriterTool(BaseTool):
    name: str = "Memory Reader Writer Tool"
    description: str = (
        "Reads the content of a specified file containing the previous agent's outputs"
        "and returns it as a string. The content of the file readed will be used as context to execute the current task."
    )
    llm_details: dict | None = None
    args_schema: type[BaseModel] = MemoryReaderWriterToolSchema
    execution_id: str | None = None

    def __init__(
        self,
        execution_id: str | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if execution_id is not None:
            self.execution_id = execution_id

    def _run(
        self,
        **kwargs: Any,
    ) -> Any:
        key = self.execution_id + "_memory"

        logger.info(f"Attempting to read memory from Redis with execution_id: {key}")
        # PipelineAILogs().publishLogs(
        #     f"Attempting to read memory from Redis with execution_id: {key}",
        #     "green",
        #     redisClient=redis_client,
        # )

        if redis_client.exists(key):
            content = redis_client.get(key)
            # PipelineAILogs().publishLogs(
            #     f"Successfully retrieved memory contents for execution_id {key}. Contents: \n{content}",
            #     "green",
            #     redisClient=redis_client,
            # )
            logger.info(
                f"Successfully retrieved memory contents for execution_id {key}. Contents:\n{content}"
            )

            if content:
                guardrails_validation = validate_output(
                    tool_name="memReadWriteTool",
                    content=content,
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]    

        else:
            content = "None"
            # PipelineAILogs().publishLogs(
            #     f"No memory contents found for execution_id {key}.",
            #     "green",
            #     redisClient=redis_client,
            # )
            logger.warning(f"No memory contents found for execution_id {key}.")
        return content
