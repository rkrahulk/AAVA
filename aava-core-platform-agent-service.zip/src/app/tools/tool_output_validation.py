import logging
from app.core.secret_manager import secret_manager
from app.helpers.guardrails import GuardRails
from app.core.config import settings

logger = logging.getLogger(__name__)

def validate_output(tool_name, content, llm_details, file_path="") -> dict:
    validation_response = {
        "result": "Guardrails validation passed",
        "success": True
    }

    is_output_validation_enabled = {
        "filereadtool": settings.to_bool("FILE_READ_TOOL_GUARDRAIL_VALIDATION_ENABLED"),
        "image_tool": settings.to_bool("IMAGE_TOOL_GUARDRAIL_VALIDATION_ENABLED"),
        "knowledgeragtool": settings.to_bool("KNOWLEDGE_RAG_TOOL_GUARDRAIL_VALIDATION_ENABLED"),
        "GithubDocAnalysisTool": settings.to_bool("GITHUB_GUARDRAIL_VALIDATION_ENABLED"),
        "S3MultiOperation": settings.to_bool("S3_MULTI_OPERATION_GUARDRAIL_VALIDATION_ENABLED"),
        "JiraFetcherRead": settings.to_bool("JIRA_GUARDRAIL_VALIDATION_ENABLED"),
        "memReadWriteTool": settings.to_bool("MEMREADWRITE_GUARDRAIL_VALIDATION_ENABLED"),
        "TestRailConnectorTool": settings.to_bool("TESTRAIL_CONNECTOR_GUARDRAIL_VALIDATION_ENABLED"),
        "GithubReadCloud": settings.to_bool("GithubReadCloud_VALIDATION_ENABLED")
    }

    if content and settings.to_bool("SYSTEM_GUARDRAILS_ENABLED") and is_output_validation_enabled[tool_name]:
        try:
            guardrails_instance = GuardRails(
                Authorization=secret_manager.Authorization,
                request_payload={"content":content, 'llm': llm_details},
                _type="agent_run"
            )
            is_validation_success, validation_result = guardrails_instance.system_validation()
            if not is_validation_success:
                logger.info(f"Guardrails blocked {tool_name}")
                logger.info(f"response from guardrails -> {validation_result} and output -> {content}")
                if tool_name == "filereadtool":
                    result = f"Error: Suspicious instructions found in files so it is blocked by guardrails. this is the guardrails response {validation_result} and file {file_path}"
                elif tool_name == "image_tool":
                    result = f"Error: Suspicious instructions found in the image so it is blocked by guardrails. this is the guardrails response {validation_result}"
                else:
                    result = f"Error: Suspicious instructions found in {tool_name} output so it is blocked by guardrails. this is the guardrails response {validation_result}"
                validation_response.update({
                    "result": result,
                    "success":False
                })
        except Exception as guardrail_exception:
            logger.info(f"Guardrails validation failed for {tool_name} output details - {content}")
            logger.error(f"Error occured during guardrail validation: {str(guardrail_exception)}")
            validation_response.update({
                "result":f"Error: {tool_name} validation failed",
                "success": False
            })
    else:
        validation_response.update({
            "result": f"Guardrails validation is skipped due to config variable"
        })
    return validation_response
