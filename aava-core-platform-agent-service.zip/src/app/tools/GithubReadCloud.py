import re
import json
import base64
import logging
import requests

from typing import Type, Optional
from pydantic import BaseModel, Field
from crewai.tools import BaseTool

import AVASecret
from app.core.config import settings
from app.tools.tool_output_validation import validate_output
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

logger = logging.getLogger(__name__)


def is_valid_github_name(name: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9_.-]*[A-Za-z0-9])?", name))


class GitHubReadCloudSchema(BaseModel):

    base_url: str = Field(
        ...,
        description="GitHub base URL. Example: https://api.github.com"
    )

    repo_owner: str = Field(
        ...,
        description="GitHub repository owner or organization name"
    )

    repo_name: str = Field(
        ...,
        description="GitHub repository name"
    )

    branch: str = Field(
        default="main",
        description="Branch name of the repository. Example: main or master"
    )

    file_paths: str = Field(
        "",
        description=(
            "Optional. Comma separated list of file paths to read from the repository. "
            "Example: auto_scripts/AddNumbers.java,auto_scripts/add_numbers.go"
            "If provided, ONLY these files will be read."
        )
    )

    folder_path: str = Field(
        "",
        description=(
            "Optional. Folder path inside the repository to read recursively. "
            "Example: src/utils or docs/api. "
            "If provided, all files inside this folder will be returned."
        )
    )

    pull_request_number: Optional[int] = Field(
        default=None,
        description=(
            "Optional. Pull request number to fetch. "
        )
    )


class GithubReadCloud(BaseTool):

    name: str = "github_files_reader"

    description: str = (
        "Reads source code files from a GitHub repository. "
        "Modes supported: "
        "1. Entire repository if no file_paths or folder_path provided. "
        "2. Specific files if file_paths is provided. "
        "3. Specific folder if folder_path is provided."
    )

    args_schema: Type[BaseModel] = GitHubReadCloudSchema

    llm_details: dict | None = None
    tool_name: str = "GithubReadCloud"

    username: str = "" 
    access_token: str = ""
    cloud_id: Optional[str] = ""
    meta: Optional[list[dict]] = []

    def _run(self, *args, **kwargs) -> str:

        try:

            # ------------------------------
            # Normalize CrewAI arguments
            # ------------------------------
            params = {}

            if args and isinstance(args[0], dict):
                params = args[0]

            params.update(kwargs)

            base_url = str(params.get("base_url", "")).strip().rstrip("/")
            repo_owner = str(params.get("repo_owner", "")).strip()
            repo_name = str(params.get("repo_name", "")).strip()
            branch = str(params.get("branch", "main")).strip()

            file_paths_str = str(params.get("file_paths", "")).strip()
            folder_path = str(params.get("folder_path", "")).strip()

            pull_request_number = (
                params.get("pull_request_number")
                or params.get("pullRequestNumber")
                or params.get("pr_number")
            )

            if not pull_request_number and args:
                try:
                    raw_str = str(args)
                    import re
                    match = re.search(r"'pull_request_number':\s*'?(\\d+)'?", raw_str)
                    if match:
                        pull_request_number = match.group(1)
                except Exception:
                    pass

            # Normalize
            if isinstance(pull_request_number, str):
                pull_request_number = pull_request_number.strip()
                if pull_request_number == "":
                    pull_request_number = None

            file_paths = [fp.strip() for fp in file_paths_str.split(",") if fp.strip()]

            logger.info(f"GitHub Tool Params: {params}")

            # ------------------------------
            # Validate Base URL
            # ------------------------------
            allowed_base_urls = {
                url.strip().rstrip("/")
                for url in settings.GITHUB_BASE_URL.replace(" ", "").split(",")
            }

            if not is_valid_base_url(base_url, allowed_base_urls):
                return f"Invalid GitHub base URL: {base_url}"

            # ------------------------------
            # Get GitHub Token
            # ------------------------------

            username, access_token = "", ""

            if not self.access_token:
                return "Error: GitHub Access Token missing."

            if not is_valid_github_name(repo_owner) or not is_valid_github_name(repo_name):
                return "Error: Invalid repository owner or name."

            # ------------------------------
            # GitHub API base
            # ------------------------------
            if "api.github.com" in base_url:
                github_api_base = "https://api.github.com"
            elif base_url.endswith("/api/v3"):
                github_api_base = base_url
            else:
                github_api_base = f"{base_url}/api/v3"

            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Accept": "application/vnd.github.v3+json"
            }

            # ------------------------------
            # Check repo access
            # ------------------------------
            repo_check = requests.get(
                f"{github_api_base}/repos/{repo_owner}/{repo_name}",
                headers=headers,
                timeout=10
            )

            if repo_check.status_code == 401:
                return "Invalid GitHub token"

            if repo_check.status_code == 404:
                return "Repository not found or access denied"

            if repo_check.status_code == 403:
                return f"Error: this project_id (repo: {repo_name}) must be added in service account list."

            repo_check.raise_for_status()

            # ------------------------------
            # PR mode
            # ------------------------------
            if pull_request_number is not None and str(pull_request_number).strip() != "":
                file_paths = []
                folder_path = ""

                try:
                    pull_request_number = int(pull_request_number)
                except (TypeError, ValueError):
                    return "Error: pull_request_number must be a valid integer."

                if not (1 <= pull_request_number <= 999_999):
                    return "Error: pull_request_number must be between 1 and 999,999."

                pr_headers = {
                    "Authorization": f"Bearer {self.access_token}",
                    "Accept": "application/vnd.github+json"
                }

                pr_res = requests.get(
                    f"{github_api_base}/repos/{repo_owner}/{repo_name}/pulls/{pull_request_number}",
                    headers=pr_headers,
                    timeout=30
                )

                if pr_res.status_code == 404:
                    return "Pull request not found."

                pr_res.raise_for_status()

                pr_data = pr_res.json()

                base_sha = pr_data.get("base", {}).get("sha")
                head_sha = pr_data.get("head", {}).get("sha")

                raw_files = []
                page = 1

                while page <= 100:

                    files_res = requests.get(
                        f"{github_api_base}/repos/{repo_owner}/{repo_name}/pulls/{pull_request_number}/files",
                        headers=pr_headers,
                        params={"per_page": 100, "page": page},
                        timeout=30
                    )

                    files_res.raise_for_status()

                    batch = files_res.json()

                    if not batch:
                        break

                    raw_files.extend(batch)

                    if len(raw_files) >= 300:
                        break

                    if len(batch) < 100:
                        break

                    page += 1

                changed_files = []

                for f in raw_files:

                    path = f.get("filename", "")
                    status = f.get("status", "")

                    if any(path.lower().endswith(ext) for ext in [
                        ".png", ".jpg", ".jpeg", ".gif",
                        ".pdf", ".zip", ".exe", ".bin"
                    ]):
                        continue

                    base_content = None
                    head_content = None

                    if status in {"modified", "removed"} and base_sha:

                        base_res = requests.get(
                            f"{github_api_base}/repos/{repo_owner}/{repo_name}/contents/{path}",
                            headers=pr_headers,
                            params={"ref": base_sha},
                            timeout=30
                        )

                        if base_res.status_code == 200:
                            base_json = base_res.json()
                            if "content" in base_json:
                                base_content = base64.b64decode(
                                    base_json["content"]
                                ).decode("utf-8", errors="replace")

                    if status in {"modified", "added"} and head_sha:

                        head_res = requests.get(
                            f"{github_api_base}/repos/{repo_owner}/{repo_name}/contents/{path}",
                            headers=pr_headers,
                            params={"ref": head_sha},
                            timeout=15
                        )

                        if head_res.status_code == 200:
                            head_json = head_res.json()
                            if "content" in head_json:
                                head_content = base64.b64decode(
                                    head_json["content"]
                                ).decode("utf-8", errors="replace")

                    changed_files.append({
                        "file_path": path,
                        "status": status,
                        "previous_path": f.get("previous_filename"),
                        "additions": f.get("additions"),
                        "deletions": f.get("deletions"),
                        "base_content": base_content,
                        "head_content": head_content
                    })

                if not changed_files:
                    return "Error: No readable changed files found in this pull request."

                repo_content_response = json.dumps({
                    "repository": repo_name,
                    "pr_number": pull_request_number,
                    "title": pr_data.get("title"),
                    "author": pr_data.get("user", {}).get("login"),
                    "base_ref": pr_data.get("base", {}).get("ref"),
                    "head_ref": pr_data.get("head", {}).get("ref"),
                    "base_sha": base_sha,
                    "head_sha": head_sha,
                    "changed_files": changed_files,
                    "files_processed": len(changed_files),
                    "url_source": f"{base_url}/{repo_owner}/{repo_name}/pull/{pull_request_number}"
                })

                guardrails_validation = validate_output(
                    tool_name="GithubReadCloud",
                    content=repo_content_response,
                    llm_details=self.llm_details
                )

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]

                return repo_content_response

            # ------------------------------
            # Fetch repository tree
            # ------------------------------
            tree_url = f"{github_api_base}/repos/{repo_owner}/{repo_name}/git/trees/{branch}?recursive=1"

            tree_res = requests.get(tree_url, headers=headers, timeout=60)

            if tree_res.status_code == 404:
                return "Branch not found."

            tree_res.raise_for_status()

            repo_tree = tree_res.json().get("tree", [])

            MAX_FILES = 200
            MAX_BLOB_SIZE = 500000

            files_to_read = []

            # ------------------------------
            # Determine Mode
            # ------------------------------
            mode = "repo"
            requested_files = set()

            if file_paths:
                mode = "files"
                requested_files = set(file_paths)

            elif folder_path:
                mode = "folder"
                folder_path = folder_path.rstrip("/") + "/"

            logger.info(f"GitHub Reader Mode: {mode}")

            # ------------------------------
            # Select files
            # ------------------------------
            for item in repo_tree:

                if item.get("type") != "blob":
                    continue

                path = item.get("path", "")
                size = item.get("size", 0)

                if size > MAX_BLOB_SIZE:
                    continue

                if mode == "files":
                    if path not in requested_files:
                        continue

                elif mode == "folder":
                    if not path.startswith(folder_path):
                        continue

                files_to_read.append(item)

                if len(files_to_read) >= MAX_FILES:
                    break

            # ------------------------------
            # Read file contents
            # ------------------------------
            aggregated_data = []

            for item in files_to_read:

                file_path = item["path"]

                if any(file_path.lower().endswith(ext) for ext in [
                    ".png", ".jpg", ".jpeg", ".gif",
                    ".pdf", ".zip", ".exe", ".bin"
                ]):
                    continue

                file_url = f"{github_api_base}/repos/{repo_owner}/{repo_name}/contents/{file_path}?ref={branch}"

                file_res = requests.get(file_url, headers=headers, timeout=15)

                if file_res.status_code != 200:
                    continue

                f_json = file_res.json()

                if "content" not in f_json:
                    continue

                decoded = base64.b64decode(
                    f_json["content"]
                ).decode("utf-8", errors="replace")

                aggregated_data.append({
                    "file_path": file_path,
                    "file_content": decoded
                })

            if not aggregated_data:
                return "Error: Requested files not found."

            repo_content_response = json.dumps({
                "repository": repo_name,
                "branch": branch,
                "content": aggregated_data,
                "files_processed": len(aggregated_data),
                "url_source": f"{base_url}/{repo_owner}/{repo_name}"
            })

            guardrails_validation = validate_output(
                tool_name="GithubReadCloud",
                content=repo_content_response,
                llm_details=self.llm_details
            )

            if not guardrails_validation.get("success"):
                return guardrails_validation["result"]

            return repo_content_response

        except requests.Timeout:
            logger.error("GitHub API timeout", exc_info=True)
            return "Error: GitHub API request timed out."

        except Exception as e:
            logger.error(f"Unexpected Tool Error: {type(e).__name__}", exc_info=True)
            return "Error: Unexpected error occurred."