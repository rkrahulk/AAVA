import requests
import json
import datetime
import base64
import logging
from typing import List, Dict, Any, Type, Optional
from pydantic import BaseModel
from crewai.tools import BaseTool

from app.core.config import settings
from app.tools.tool_output_validation import validate_output
from app.tools.tool_helpers import is_valid_base_url, get_system_tool_secrets

logger = logging.getLogger(__name__)


# =========================================================
# Schema
# =========================================================
class JiraReaderSchema(BaseModel):
    base_url: str
    operation: str

    jql: Optional[str] = None

    # Filters
    project_key: Optional[str] = None
    issue_keys: Optional[str] = None
    issue_types: Optional[str] = None
    status: Optional[str] = None
    assignee: Optional[str] = None
    created_after: Optional[str] = None
    created_before: Optional[str] = None

    # Specific operations
    issue_key: Optional[str] = None
    attachment_id: Optional[str] = None

    max_results: Optional[int] = 20
    include_acceptance_criteria: Optional[bool] = True
    fields_to_fetch: Optional[str] = ""


# =========================================================
# Tool
# =========================================================
class JiraFetcherReadToolV2(BaseTool):

    name: str = "JiraFetcherReadToolV2"
    description: str = (
        "Universal Jira reader tool. Supports retrieving issues, single issue, comments, "
        "history, and downloading attachments, and full parent hierarchy. Supports both structured filters and raw JQL."
    )

    args_schema: Type[BaseModel] = JiraReaderSchema
    service_account_type: str

    # =========================================================
    # REQUEST (v3 → v2 fallback)
    # =========================================================
    def _request(self, base_url, path, auth, params=None, stream=False):
        url_v3 = f"{base_url}/rest/api/3{path}"
        url_v2 = f"{base_url}/rest/api/2{path}"

        try:
            res = requests.get(url_v3, auth=auth, params=params, timeout=15, stream=stream)
            if res.status_code < 400:
                return res
        except Exception:
            pass

        if params and "fields" in params:
            fields = params["fields"]

            if isinstance(fields, str) and "," in fields:
                params["fields"] = fields.strip().strip(",").lower()

        try:
            res = requests.get(url_v2, auth=auth, params=params, timeout=60, stream=stream)
            return res
        except Exception as e:
            raise Exception(f"Both v3 and v2 requests failed: {str(e)}")

    # =========================================================
    # TEXT PARSER (ADF SAFE)
    # =========================================================
    def _extract_text(self, data):
        if not data:
            return ""

        if isinstance(data, str):
            return data.strip()

        texts = []

        def walk(node):
            if isinstance(node, dict):
                if "text" in node:
                    texts.append(node["text"])
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for i in node:
                    walk(i)

        walk(data)
        return "\n".join(texts)

    # =========================================================
    # JQL BUILDER
    # =========================================================
    def _build_jql(self, args: JiraReaderSchema) -> str:

        clauses = []

        if args.jql:
            clauses.append(f"({args.jql.strip()})")

        if args.project_key:
            clauses.append(f'project = "{args.project_key}"')

        if args.issue_keys:
            keys = args.issue_keys.strip().replace(" ", "")
            clauses.append(f'key in ({keys})')

        if args.issue_types:
            types = args.issue_types.strip().replace(" ", "")
            clauses.append(f'issuetype in ({types})')

        if args.status:
            status = args.status.strip().replace(" ", "")
            clauses.append(f'status in ({status})')

        if args.assignee:
            clauses.append(f'assignee = "{args.assignee}"')

        if args.created_after:
            clauses.append(f'created >= "{args.created_after}"')

        if args.created_before:
            clauses.append(f'created <= "{args.created_before}"')

        return " AND ".join(clauses) if clauses else "ORDER BY created DESC"



    def _get_ac_field(self, base_url, auth):
        try:
            res = self._request(base_url, "/field", auth)

            if res.status_code != 200:
                return None

            for field in res.json():
                name = field.get("name", "").lower()

                # flexible matching
                if any(k in name for k in ["acceptance", "criteria", "ac"]):
                    return field.get("id")  # customfield_xxxxx

        except Exception:
            pass

        return None


    def _extract_ac(self, issue, ac_field):
        if not ac_field:
            return None

        return self._extract_text(issue.get("fields", {}).get(ac_field))


    # =========================================================
    # OPERATIONS
    # =========================================================
    def _get_issues(self, base_url, auth, args):

        fields_to_fetch = ",".join([
                            "summary",
                            "description",
                            "status",
                            "resolution",
                            "reporter",
                            "assignee",
                            "components",
                            "created",
                            "resolutiondate",
                            "priority",
                            "issuetype"
                        ])


        jql = self._build_jql(args)
        path =  "/search/jql" if ".atlassian.net" in base_url else "/search"

        if args.fields_to_fetch:
            fields_to_fetch = self._resolve_custom_fields(args.fields_to_fetch, base_url, auth)

        res = self._request(
            base_url,
            path,
            auth,
            params={
                "jql": jql,
                "maxResults": min(args.max_results, 50),
                "fields": fields_to_fetch
            }
        )

        if res.status_code != 200:
            return {
                "error": "JQL query failed",
                "details": res.text
            }

        data = res.json()
        ac_field = self._get_ac_field(base_url, auth) 

        for issue in data.get("issues", []):
            if args.include_acceptance_criteria:          
                issue["acceptance_criteria"] = self._extract_ac(issue, ac_field)

            created = issue.get("fields", {}).get("created")
            issue["issue_age"] = self._calculate_issue_age(created)


        # guardrails_validation = validate_output(
        #                             "JiraFetcherRead", 
        #                             json.dumps(data), 
        #                             llm_details=self.llm_details
        #                             )

        # if not guardrails_validation.get("success"):
        #     return guardrails_validation["result"]

        return data


    def _get_issue(self, base_url, auth, issue_key, args):

        fields_to_fetch = ",".join([
                            "summary",
                            "description",
                            "status",
                            "resolution",
                            "reporter",
                            "assignee",
                            "components",
                            "created",
                            "resolutiondate",
                            "priority",
                            "issuetype"
                        ])
        
        fields_to_fetch = args.fields_to_fetch or fields_to_fetch

        if not issue_key:
            return {"error": "issue_key is required"}

        if args.fields_to_fetch:
            fields_to_fetch = self._resolve_custom_fields(args.fields_to_fetch, base_url, auth)

        res = self._request(base_url, f"/issue/{issue_key}?fields={fields_to_fetch}", auth)

        if res.status_code != 200:
            return {"error": res.text}

        data = res.json()

        if args.include_acceptance_criteria:
            ac_field = self._get_ac_field(base_url, auth)
            data["acceptance_criteria"] = self._extract_ac(data, ac_field)

        # guardrails_validation = validate_output(
        #                             "JiraFetcherRead", 
        #                             json.dumps(data), 
        #                             llm_details=self.llm_details
        #                             )

        # if not guardrails_validation.get("success"):
        #     return guardrails_validation["result"]

        return data


    def _get_comments(self, base_url, auth, issue_key):

        if not issue_key:
            return {"error": "issue_key is required"}

        res = self._request(base_url, f"/issue/{issue_key}/comment", auth)

        if res.status_code != 200:
            return {"error": res.text}

        return {
            "issue_key": issue_key,
            "comments": [
                {
                    "author": c.get("author", {}).get("displayName"),
                    "comment": self._extract_text(c.get("body"))
                }
                for c in res.json().get("comments", [])
            ]
        }

    def _get_history(self, base_url, auth, issue_key):

        if not issue_key:
            return {"error": "issue_key is required"}

        res = self._request(
            base_url,
            f"/issue/{issue_key}",
            auth,
            params={"expand": "changelog"}
        )

        if res.status_code != 200:
            return {"error": res.text}

        histories = res.json().get("changelog", {}).get("histories", [])

        changes = []
        for h in histories:
            for item in h.get("items", []):
                changes.append({
                    "field": item.get("field"),
                    "from": item.get("fromString"),
                    "to": item.get("toString")
                })

        return {
            "issue_key": issue_key,
            "changes": changes
        }

    def _download_attachments(self, base_url, auth, issue_key):

        res = self._request(base_url, f"/issue/{issue_key}", auth)

        if res.status_code != 200:
            return {"error": res.text}

        attachments = res.json().get("fields", {}).get("attachment", [])

        results = []

        for att in attachments:
            att_id = att.get("id")

            file_res = self._request(
                base_url,
                f"/attachment/content/{att_id}",
                auth,
                stream=True
            )

            MAX_SIZE = 500_000  # ~500KB

            if len(file_res.content) > MAX_SIZE:
                return {
                    "error": "File too large to return as base64",
                    "suggestion": "Use download URL instead"
                }

            if file_res.status_code == 200:
                results.append({
                    "type": "raw_attachment",
                    "file_name": att.get("filename"),
                    "attachment_id": att_id,
                    "content_base64": base64.b64encode(file_res.content).decode()
                })
            else:
                results.append({
                    "file_name": att.get("filename"),
                    "error": file_res.text
                })

        return {
            "issue_key": issue_key,
            "attachments": results
        }

    # =========================================================
    # MAIN
    # =========================================================
    def _run(self, **kwargs):

        args = JiraReaderSchema(**kwargs)
        base_url = args.base_url.rstrip("/")

        # Validate URL
        allowed_urls = {
            u.strip().rstrip("/")
            for u in settings.JIRA_BASE_URL.replace(" ", "").split(",")
        }

        if not is_valid_base_url(base_url, allowed_urls):
            return json.dumps({"error": "Invalid Jira URL"})

        # Auth
        username, password = get_system_tool_secrets(
            action="read",
            tool_type="jira",
            service_account_type=self.service_account_type
        )

        auth = (username, password)

        try:

            if args.operation == "retrieve_issues":
                result = self._get_issues(base_url, auth, args)

            elif args.operation == "retrieve_issue":
                result = self._get_issue(base_url, auth, args.issue_key, args)

            elif args.operation == "retrieve_comments":
                result = self._get_comments(base_url, auth, args.issue_key)

            elif args.operation == "retrieve_history":
                result = self._get_history(base_url, auth, args.issue_key)

            elif args.operation == "download_attachments":
                if not args.issue_key:
                    return {"message": "issue_key is required to fetch the attachments"}
                result = self._download_attachments(base_url, auth, args.issue_key)

            elif args.operation == "retrieve_issue_hierarchy":
                result = self._get_issue_hierarchy(base_url, auth, args.issue_key)

            else:
                result = {"error": "Unknown operation"}

            return json.dumps(result, indent=2)

        except Exception as e:
            logger.exception("Jira tool error")
            return json.dumps({
                "error": "Something went wrong",
                "details": str(e)
            })

    # -----------------------------------------------------
    # CUSTOM FIELD RESOLUTION
    # -----------------------------------------------------

    def _resolve_custom_fields(self, custom_fields, base_url, auth):
        api_url = base_url + "/rest/api/3/" if ".atlassian.net" in base_url else base_url + "/rest/api/2/"
        fields = self._get_all_fields(api_url, auth)

        name_to_id = {
            f["name"].lower().strip().replace(" ", ""): f["id"]
            for f in fields
        }
        resolved = ""

        for display_name in custom_fields.strip().split(","):

            field_id = name_to_id.get(display_name.lower().strip().replace(" ", ""))

            if not field_id:
                logger.info(f"Custom field '{display_name}' not found")
                continue

            resolved += f"{field_id},"

        return resolved


    def _get_all_fields(self, api_url, auth):
        url = f"{api_url}field"

        if ".atlassian.net" in api_url:
            url = f"{api_url}field?expand=custom"

        res = requests.get(
            url,
            auth=auth,
            timeout=60
        )
        res.raise_for_status()
        return res.json()

    def _calculate_issue_age(self, created_str: str) -> Optional[str]:
        if not created_str:
            return None

        try:
            # Example format: 2024-01-01T10:00:00.000+0000
            created_dt = datetime.datetime.strptime(created_str, "%Y-%m-%dT%H:%M:%S.%f%z")

            now = datetime.datetime.now(datetime.timezone.utc)

            delta = now - created_dt

            days = delta.days

            return f"{days} days"
        except Exception as e:
            logger.warning(f"Failed to parse created date: {created_str}, error: {e}")
            return None


    def _get_issue_hierarchy(self, base_url, auth, issue_key):

        if not issue_key:
            return {"error": "issue_key is required"}

        hierarchy: List[Dict[str, Any]] = []
        current_issue_key = issue_key

        while True:

            res = self._request(base_url, f"/issue/{current_issue_key}", auth)

            if res.status_code != 200:
                return {"error": res.text}

            issue = res.json()
            fields = issue.get("fields", {})

            description_raw = fields.get("description")

            description_text = (
                self._extract_text(description_raw)
                if isinstance(description_raw, (dict, list))
                else description_raw
            )

            issue_data: Dict[str, Any] = {
                "level": None,
                "Hierarchy_Level": fields.get("issuetype", {}).get("name"),
                "Issue Id": issue.get("id"),
                "Issue Key": issue.get("key"),
                "Summary": fields.get("summary"),

                "Description_Raw": description_text,
                "Description_Text": description_text,

                "Status": fields.get("status", {}).get("name"),
                "Priority": fields.get("priority", {}).get("name"),

                "Assignee": (
                    fields.get("assignee", {}).get("displayName")
                    if fields.get("assignee") else None
                ),

                "Reporter": (
                    fields.get("reporter", {}).get("displayName")
                    if fields.get("reporter") else None
                ),

                "Due Date": fields.get("duedate"),

                "Created": fields.get("created"),
                "Issue Age": self._calculate_issue_age(fields.get("created")),

                "Comments": self._get_comments(base_url, auth, issue.get("key")).get("comments", [])
            }

            hierarchy.append(issue_data)

            parent = fields.get("parent")
            if not parent:
                break

            current_issue_key = parent.get("key")

        # Normalize order → ROOT → LEAF
        hierarchy.reverse()

        for idx, item in enumerate(hierarchy):
            item["level"] = idx

        return {
            "status": "SUCCESS",
            "hierarchy_type": "BOTTOM_UP",
            "starting_issue_key": issue_key,
            "data": hierarchy
        }