import base64
import imghdr
import logging
from pathlib import Path

from crewai import LLM
from crewai.tools import BaseTool
from pydantic import BaseModel, PrivateAttr, field_validator
from app.tools.tool_output_validation import validate_output
from pydantic import Field

logger = logging.getLogger(__name__)

class ImagePromptSchema(BaseModel):
    """Input for Vision Tool."""

    image_path_url: str = Field(..., description="Image path or public URL")

    @field_validator("image_path_url")
    def validate_image_path_url(cls, v: str) -> str:
        if v.startswith("http"):
            return v

        path = Path(v)
        if not path.exists():
            raise ValueError(f"Image file does not exist: {v}")

        # Validate supported formats
        valid_extensions = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
        if path.suffix.lower() not in valid_extensions:
            raise ValueError(
                f"Unsupported image format. Supported formats: {valid_extensions}"
            )

        return v


class Imagetool(BaseTool):
    """Tool for analyzing images using vision models.

    Args:
        llm: Optional LLM instance to use
        model: Model identifier to use if no LLM is provided
    """

    name: str = "Vision Tool"
    description: str = (
        "This tool takes image path and public url as a input and give the description of the image"
    )
    llm_details: dict | None = None
    args_schema: type[BaseModel] = ImagePromptSchema

    _model: str = PrivateAttr(default="gpt-4o-mini")
    _llm: LLM | None = PrivateAttr(default=None)

    def __init__(self, llm: LLM | None = None, model: str = "gpt-4o-mini", **kwargs):
        """Initialize the vision tool.

        Args:
            llm: Optional LLM instance to use
            model: Model identifier to use if no LLM is provided
            **kwargs: Additional arguments for the base tool
        """
        super().__init__(**kwargs)
        self._model = model
        self._llm = llm

    @property
    def model(self) -> str:
        """Get the current model identifier."""
        return self._model

    @model.setter
    def model(self, value: str) -> None:
        """Set the model identifier and reset LLM if it was auto-created."""
        self._model = value
        if self._llm is not None and self._llm._model != value:
            self._llm = None

    @property
    def llm(self) -> LLM:
        """Get the LLM instance, creating one if needed."""
        if self._llm is None:
            self._llm = LLM(model=self._model, stop=["STOP", "END"])
        return self._llm

    def _run(self, **kwargs) -> str:
        try:
            image_path_url = kwargs.get("image_path_url")
            if not image_path_url:
                return "Image Path or URL is required."

            ImagePromptSchema(image_path_url=image_path_url)

            if image_path_url.startswith("http"):
                image_data = image_path_url
            else:
                try:
                    base64_image, mime_type = self._encode_image_with_mime(image_path_url)
                    image_data = f"data:{mime_type};base64,{base64_image}"
                except Exception as e:
                    return f"Error processing image: {str(e)}"
            if 'codex' in str(self.llm.model).lower():
                text_content = {"type": "input_text", "text": "What's in this image?"}
                image_content = {"type": "input_image", "image_url": image_data}

                message_content = [text_content, image_content]
            else:
                text_content = {"type": "text", "text": "What's in this image?"}
                image_content = {"type": "image_url", "image_url": {"url": image_data}}
                message_content = [text_content, image_content]

            response = self.llm.call(
                messages=[
                    {
                        "role": "user",
                        "content": message_content,
                    },
                ],
            )
            if response:
                guardrails_validation = validate_output(
                    tool_name="image_tool",
                    content=response,
                    llm_details=self.llm_details
                )
                logger.info(f"guardrails validation result {guardrails_validation.get('success')}")

                if not guardrails_validation.get("success"):
                    return guardrails_validation["result"]

            return response
        except Exception as e:
            return f"An error occurred: {str(e)}"

    def _encode_image_with_mime(self, image_path: str) -> tuple[str, str]:
        """Encode an image file as base64.

        Args:
            image_path: Path to the image file

        Returns:
            Base64-encoded image data
        """
        with open(image_path, "rb") as image_file:
            image_bytes = image_file.read()

        detected = imghdr.what(None, h=image_bytes)

        mime_map = {
            "jpeg": "image/jpeg",
            "png": "image/png",
            "gif": "image/gif",
            "webp": "image/webp",
        }

        if detected not in mime_map:
            raise ValueError(f"Unsupported or undetectable image format: {detected}")

        base64_image = base64.b64encode(image_bytes).decode("utf-8")
        return base64_image, mime_map[detected]