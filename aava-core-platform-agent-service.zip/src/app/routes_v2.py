import json
import logging
from typing import Annotated

from crewai import TaskOutput
from fastapi import APIRouter, Body, Form, Header, UploadFile

from app.core.config import settings, bootstrap_settings, log_config_operation, execution_id_var
from app.models.ConfigResponse import ConfigResponse
from app.models.AgentRequest import AgentRequest
from app.models.AgentResponse import AgentResponse
from app.models.healthResponse import HealthResponse

from app.services.agent_ai import AgentExecutor
from app.services.health_check import health_check
from aava.exception.custom.validation_exception import ValidationException
from aava.exception.custom.business_exception import BusinessException
from aava.exception.custom.system_exception import SystemException
from aava.exception.custom.data_not_found_exception import DataNotFoundException
from aava.exception.constants.error_codes import ErrorCodes
from pydantic import ValidationError


logger = logging.getLogger(__name__)

v2_router = APIRouter()


@v2_router.get("/health", response_model=HealthResponse, summary="🏥 Health Check",
    description="""
    **Comprehensive health check endpoint** that provides deailted information about:
    """,
    response_description="Detailed health check information",
    tags=["Health & Monitoring"])

async def health_check_endpoint():
    try:
        return await health_check()
    except Exception as e:
        logger.error(f"Unexpected error in health check: {e}")
        raise SystemException(f"Internal server error during health check: {e}")



@v2_router.post("/config-refresh",response_model=ConfigResponse, summary="🔄 Refresh Configuration",
    description="""
    **Reload configuration from remote config service.**
    
    This endpoint triggers a refresh of application configuration from the configured
    remote config service (Azure App Configuration, etc.).
    """,
    tags=["Configuration"])

async def config_refresh_endpoint():
    try:
        bootstrap_settings(force=True)
        messages = log_config_operation()
        return {"message": messages}
    except Exception as e:
        logger.error(f"Unexpected error in Config Refresh: {e}")
        raise SystemException(f"Internal server error during Config Refresh:: {e}")

@v2_router.post(
    "/run",
    response_model=AgentResponse,
    summary="🤖 Execute Agent",
    description="""
    **Execute an AI agent** through the Agent Service.
    
    This endpoint processes requests through the configured AI agent framework:
    * Validates agent configuration and parameters
    * Executes agent with tools and context
    * Manages conversation state and memory
    * Returns agent response and execution metadata""",
    tags=["Agent Execution"]
)
async def execute_agent_endpoint(
    Authorization: Annotated[str | None, Header()] = None,
    agentRequest: AgentRequest = Body(...),
):
    try:
        if not (agentRequest.agent and agentRequest.agent.get("id")):
            raise ValidationException(error_code=ErrorCodes.VALIDATION_ERROR,
                message="Please Send Valid AgentId")
        execution_id_var.set(agentRequest.executionId)
        agentRequest.agentId = agentRequest.agent.get("id")
        executor = AgentExecutor(Authorization=Authorization, agent_request=agentRequest)
        return await executor.run()
    except RuntimeError as e:
        raise SystemException(
                error_code=ErrorCodes.SYSTEM_ERROR,
                message=f"{str(e)}"
            )
    except ValueError as e:
            raise ValidationException(
                error_code=ErrorCodes.VALIDATION_ERROR,
                message=f"{str(e)}"
            )
    except Exception as e:
        logger.error(f"Error in agent execution endpoint: {e}")
        raise e.__class__(" - " + "agent execution endpoint error " + str(e)) from e



@v2_router.post(
    "/run-files",
    response_model=AgentResponse,
    summary="🤖📁 Execute Agent with Files",
    description="""
    **Execute AI agent with file attachments** for document-aware interactions.
    
    Enables agents to process and reason about files:
    * Document analysis and Q&A
    * Image understanding and description
    * Code review and analysis
    * Multi-file context reasoning""",
    tags=["Agent Execution"]
)
async def execute_agent_files_endpoint(
    executionId: Annotated[str, Form()],
    Authorization: Annotated[str | None, Header()] = None,
    files: list[UploadFile] = None,
    userInputs: Annotated[str, Form()] = None,  # JSON string
    user: Annotated[str, Form()] = None,
    tools: Annotated[str | None, Form()] = "[]",  # JSON string
    userTools: Annotated[str | None, Form()] = "[]",  # JSON string
    agent: Annotated[str, Form()] = "{}",  # JSON 
):
    try:
        agent=json.loads(agent)
        if not agent.get("id"):
            raise ValidationException(error_code=ErrorCodes.VALIDATION_ERROR,
                message="Please Send Valid AgentId")
        agentId = agent.get("id")
        execution_id_var.set(executionId)  
        request_data = AgentRequest(
            agentId=int(agentId),
            executionId=executionId,
            userInputs=json.loads(userInputs),
            user=user,
            tools=json.loads(tools),
            userTools=json.loads(userTools),
            agent=agent,
        )
        executor = AgentExecutor(Authorization=Authorization, files=files, agent_request=request_data)
        return await executor.run()
    except RuntimeError as e:
        raise SystemException(
                error_code=ErrorCodes.SYSTEM_ERROR,
                message=f"{str(e)}"
            )
    except ValueError as e:
            raise ValidationException(
                error_code=ErrorCodes.VALIDATION_ERROR,
                message=f"{str(e)}"
            )
    except Exception as e:
        logger.error(f"Error in agent with files execution endpoint: {e}")
        raise e.__class__(" - " + "agent files endpoint error " + str(e)) from e
