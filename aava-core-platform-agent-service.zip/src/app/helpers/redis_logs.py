import httpx
import json
import logging
import os
import time

from app.core.redis_client import redis_client
from redis.client import Redis

from app.models.PipelineLogs.RuntimeLogs import RuntimeLogs

logger = logging.getLogger(__name__)

from app.core.config import settings, execution_id_var
from app.core.pg_client import postgres_client


logger.info("Logs is starting up")


class PipelineAILogs:

    progress: str = "STARTED"
    executionId: str | None = execution_id_var.get()
    agentId: int | None = None
    sender: str | None = None

    def push_logs_to_database(self,execution_id, logs_json):

        try:
            if not settings or not settings.BASE_API_URL or not settings.API_AGENT_LOGS_ENDPOINT:
                logger.warning(f"⚠️ Agent logs for execution '{execution_id}' not saved: Service not configured. Please set BASE_URL and WF_LOGS_ENDPOINT environment variables.")
                return
            url = settings.BASE_API_URL + settings.API_AGENT_LOGS_ENDPOINT
            headers = dict(Authorization=f"Basic {settings.AGENT_LOGS_BASIC_AUTH}", **{"Content-Type": "application/json"})            
            body = dict(executionId=execution_id, logs=logs_json)
            response = httpx.post(url=url, json=body, headers=headers)
            if response.status_code>=400:
                raise Exception(response.content)
            logger.info(f"Logs for execution ID {execution_id} successfully pushed to agent endpoint. Status: {response.status_code}")
        except Exception as e:
            logger.info(f"Error pushing logs to database: {str(e)}")
            logger.info("Released connection")

    def publishLogs(
        self, logs: str, color: str | None = None, redisClient: Redis = redis_client
    ):
        
        self.progress = "IN PROGRESS"
        if (
            "agent completed" in logs.lower()
            or "aava agent exception:" in logs.lower()
        ):
            self.progress = "FINISHED"
        elif color is not None and color == "red":
            self.progress = "EXCEPTION"

        try:
            if redisClient:
                if settings.ENABLE_LOGSTREAMING:

                    log_entry = RuntimeLogs(
                        progress=self.progress,
                        content=logs,
                        color=color,
                        sender=self.sender,
                        executionId=self.executionId,
                    )

                    log_entry_json = json.dumps(log_entry.model_dump())

                    logger.info("---------------- Redis Publisher ---------------- ")
                    logger.info("Execution Id is ---------------- %s", self.executionId)
                    logger.info("Agent Id is ---------------- %s", self.pipelineId)
                    logger.info("Color is ---------------- %s", color)
                    logger.info("Content is ---------------- %s", logs)

                    try:

                        try:
                            redisClient.publish(self.executionId, log_entry_json)
                        except Exception as e:  # noqa: BLE001
                            raise

                        logger.info(
                            "--------------Published the topic------------ %s",
                            log_entry_json,
                        )

                    except Exception as e:

                        logger.error(f"Could not connect to Redis:{e}")


            if settings.PERSISTENT_LOGGING:

                log_entry = RuntimeLogs(
                    progress=self.progress,
                    content=logs,
                    color=color,
                    sender=self.sender,
                    executionId=self.executionId,
                )

                log_entry_json = json.dumps(log_entry.model_dump())

                try:

                    self.push_logs_to_database(self.executionId, log_entry_json)

                    logger.info(
                        "--------------Published the topic------------ %s",
                        log_entry_json,
                    )

                except Exception as e:

                    logger.error(f"Could not connect to PostGres:{e}")

        except Exception as e:
            logger.error(f"Error in publishLogs: {str(e)}")
