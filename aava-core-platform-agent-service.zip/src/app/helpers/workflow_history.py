# # TODO required in agents?

# import copy
# import json
# import logging

# import httpx

# from app.core.config import settings

# logger = logging.getLogger(__name__)

# # Set default instruction URL if not already set
# # if "INSTRUCTIONS_URL" not in os.environ:
# #     os.environ["INSTRUCTIONS_URL"] = "https://avaplus-internal.avateam.io/v1/api/instructions"


# def save_initial_workflow_history(
#     pipelineId, executionId, user, md_requests, adminUrl, Authorization
# ):
#     try:
#         data = {
#             "pipelineId": pipelineId,
#             "executionId": executionId,
#             "record": {"user": user, "request": json.dumps(md_requests)},
#         }
#         response = httpx.post(adminUrl, headers=get_headers(Authorization), json=data)
#         logger.info(f"save initial workflow history response : {response}")
#     except Exception as e:
#         logger.error(f"Error in save_initial_workflow_history: {e}")


# def save_payload_workflow_history(
#     pipelineId, executionId, fullpayload, adminUrl, Authorization
# ):
#     try:
#         data = {
#             "pipelineId": pipelineId,
#             "executionId": executionId,
#             "record": {"full_payload": json.dumps(fullpayload)},
#         }
#         response = httpx.post(adminUrl, headers=get_headers(Authorization), json=data)
#         logger.info(f"save full payload workflow history response : {response}")
#     except Exception as e:
#         logger.error(f"Error in save_payload_workflow_history: {e}")


# def mask_response(response: dict):

#     if response.get("masterEmbedding"):
#         response["masterEmbedding"] = "*******"

#     if response.get("managerLlm"):
#         response["managerLlm"] = "*******"

#     for agent in response["pipeLineAgents"]:
#         if agent.get("agent", {}).get("llm", {}):
#             agent["agent"]["llm"] = "*******"
#         if agent.get("agent", {}).get("embedding", {}):
#             agent["agent"]["embedding"] = "*******"

#     if response.get("langfuse"):
#         response["langfuse"] = "*******"

#     return response


# def get_headers(Authorization):
#     return {"Content-Type": "application/json", "Authorization": Authorization}


# def save_final_workflow_history(
#     pipelineId, executionId, pipeline_response, finalResponse, adminUrl, Authorization
# ):
#     try:
#         # {"pipeline": final_response_payload}
#         payload_object = copy.deepcopy(finalResponse["pipeline"])
#         _ = payload_object.pop("file_download_url", None)
#         masked_response = mask_response(payload_object)
#         crew_output, upload_file_id = pipeline_response

#         data = {
#             "pipelineId": pipelineId,
#             "executionId": executionId,
#             "record": {
#                 "response": json.dumps(masked_response),
#                 "total_tokens": crew_output.token_usage.total_tokens,
#                 "prompt_tokens": crew_output.token_usage.prompt_tokens,
#                 "cached_prompt_tokens": crew_output.token_usage.cached_prompt_tokens,
#                 "completion_tokens": crew_output.token_usage.completion_tokens,
#                 "successful_requests": crew_output.token_usage.successful_requests,
#                 "upload_file_id": upload_file_id,
#             },
#         }

#         response = httpx.post(adminUrl, headers=get_headers(Authorization), json=data)

#         logger.info(f"save final workflow history response : {response}")

#     except Exception as e:
#         logger.error(f"Error in save_final_workflow_history: {e}")


# def send_execution_status(execution_id: str, status: str, Authorization: str):
#     try:
#         instruction_url = settings.BASE_API_URL + settings.INSTRUCTIONS_API_URL
#         if not instruction_url:
#             logger.error("INSTRUCTIONS_API_URL environment variable not set")
#             return False

#         status_url = f"{instruction_url}/workflow-executions/{execution_id}/status"
#         data = {"status": status}
#         response = httpx.post(status_url, headers=get_headers(Authorization), json=data)

#         if response.status_code != 200:
#             logger.error(
#                 f"Failed to send execution status. Status code: {response.status_code}"
#             )
#             return False

#         return True
#     except Exception as e:
#         logger.error(
#             f"Error sending execution status for execution_id {execution_id}: {e}"
#         )
#         return False
