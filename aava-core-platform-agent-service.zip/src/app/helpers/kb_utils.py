from typing import Dict, List
from app.core.config import settings
import logging
logger = logging.getLogger(__name__)

from app.core.mongodb_client import get_sync_mongo_client


# ---------------------------------------------------------------------------
# Async helper — use only from async def endpoints/handlers
# ---------------------------------------------------------------------------

async def get_mongodb_obj():
    client = get_sync_mongo_client()
    return client[settings.MONGODB_DATABASE]


# ---------------------------------------------------------------------------
# Sync helper — use from sync contexts: CrewAI tools, threads, EventListeners
# ---------------------------------------------------------------------------

def _get_sync_db():
    """Return the sync MongoDB database object."""
    return get_sync_mongo_client()[settings.MONGODB_DATABASE]


def retrieve_metadata(collection_name: str) -> List[Dict]:
    """Fetch distinct file metadata from a collection using the sync client.

    Returns a plain list — safe to iterate multiple times, works in threads.
    """
    db = _get_sync_db()
    collection = db[collection_name]

    pipeline = [
        {
            "$group": {
                "_id": "$metadata.file_name",
                "file_name": {"$first": "$metadata.file_name"},
                "source": {"$first": "$metadata.source"},
                "file_size": {"$first": "$metadata.file_size"},
                "file_path": {"$first": "$metadata.file_path"}
            }
        },
        {
            "$project": {
                "_id": 0,
                "file_name": 1,
                "source": 1,
                "file_size": 1,
                "file_path": 1
            }
        }
    ]

    return list(collection.aggregate(pipeline))


def _resolve_mongo_collection_name(emb_config) -> str:
    """Return the correct MongoDB collection name for an embedding config.

    AgentEmbedding has a dedicated `mongodb_collection` field for MongoDB.
    `index_collection` is the Chroma field and should only be used as a
    fallback when the MongoDB-specific field is absent.
    """
    return (
        getattr(emb_config, 'mongodb_collection', None)
        or getattr(emb_config, 'index_collection', None)
    )


def get_kb_details(embedding: List) -> Dict[str, List[Dict]]:
    all_collections_details = {}

    if not embedding:
        return {}

    for emb_config in embedding:
        try:
            collection_name = _resolve_mongo_collection_name(emb_config)
            if not collection_name:
                continue

            all_collections_details[collection_name] = retrieve_metadata(collection_name)

        except Exception as e:
            logger.error(f"Error getting KB details: {str(e)}")
            continue

    return all_collections_details


def get_kb_filenames(embedding: List) -> List[str]:
    all_filenames = set()

    for emb_config in embedding:
        collection_name = _resolve_mongo_collection_name(emb_config)
        if not collection_name:
            continue

        for doc in retrieve_metadata(collection_name):
            file_name = doc.get("file_name")
            if file_name:
                all_filenames.add(file_name)

    return sorted(all_filenames)
