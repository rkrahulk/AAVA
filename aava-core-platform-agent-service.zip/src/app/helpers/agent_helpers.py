import logging

import httpx

from app.core.config import settings
from app.core.http_client import HTTPClientSingleton
from aava.exception.custom.validation_exception import ValidationException
from aava.exception.custom.system_exception import SystemException

# from app.models.agentLLM import AgentLLM

logger = logging.getLogger(__name__)


class AgentPayload:
    def __init__(self, agentId, Authorization):
        self.agentId = agentId
        self.Authorization = Authorization

    def fetch(self):
        try:
            global settings
            adminurlagent = settings.BASE_API_URL + settings.ADMIN_API_URL_V2_AGENT

            timeout = httpx.Timeout(
                connect=int(settings.REQUEST_TIMEOUT),
                read=int(settings.REQUEST_TIMEOUT),
                write=int(settings.REQUEST_TIMEOUT),
                pool=int(settings.REQUEST_TIMEOUT),
            )
            if adminurlagent == None:
                raise ValidationException(
                    f"❌ Environment variable ADMIN_API_URL_V2_AGENT is not set. "
                    f"Please add value to the ADMIN_API_URL_V2_AGENT environment variable"
                )

            # Use singleton HTTP client for connection pooling
            http_client = HTTPClientSingleton.get_client()
            adminResponse = http_client.get(
                adminurlagent, 
                params={
                    "agentId": self.agentId
                }, 
                headers={
                    "Authorization": self.Authorization,
                    "Content-Type": "application/json",
                }, 
                timeout=timeout
            )
            if adminResponse.status_code>=400:
                if adminResponse.status_code == 401:
                    raise ValidationException("Token is invalid or expired")
                else:
                    raise SystemException(str(e))

            logger.info(
                "Admin agent payload response ----------------- %s", adminResponse.json()
            )

            agentJson = adminResponse.json()
            agent_detail= agentJson.get("agentDetail", None)
            if not agent_detail:
                logger.info("Agent details not found in the response")
                raise ValidationException("Agent details not found in the response")

            return agent_detail
        except Exception as e:
            raise e.__class__(f"[AgentPayload][fetch] {str(e)}") from e
