from app.models.agentDetails import AgentDetails
from app.models.agentEmbedding import AgentEmbedding
from app.models.AgentTools import AgentTools
from app.models.taskDetails import TaskDetails
from app.services.crew_controller.agent_creator import AgentCreatorConfig
from app.services import event_listener


def convert_payload(request, Authorization, validator):

    data = request.model_dump()

    ## Creating langfuse configuration
    langfuse_config = {
        "host": data.get("langfuse_host", ""),
        "public_key": data.get("langfuse_public_key", ""),
        "secret_key": data.get("langfuse_secret_key", ""),
    }

    ## Creating task details
    task_details = TaskDetails(
        description=request.prompt,
        expectedOutput="Provide a comprehensive and accurate response to the user's query.",
    )

    agent_tools = []
    ## Adding RAG tool if enabled
    if data.get("rag_enable", False):
        agent_tools.append(AgentTools(toolName="KnowledgeRAGTool", toolParams={}))

    ## Setup embedding configuration for RAG
    embedding_config = None
    if data.get("rag_enable", False) and data.get("collection_config"):
        # Create embedding configuration from collection_config
        collection_configs = data.get("collection_config", [])
        if collection_configs:
            first_config = collection_configs[0]
            embedding_config = AgentEmbedding(**first_config, **data)

    agent_data = data.get("agent_details") or {}
    ## Creating agent details
    agent_details = AgentDetails(
        id=int(agent_data.get("agent_id", 1)),
        name=agent_data.get("name", "QueryProcessorAgent"),
        role="AI Assistant",
        goal="Process user queries and provide accurate, helpful responses",
        backstory="An intelligent AI assistant capable of understanding complex queries and providing comprehensive answers using various tools and knowledge sources.",
        verbose=agent_data.get("verbose", True),
        allowDelegation=agent_data.get("allowDelegation", False),
        maxIter=agent_data.get("maxIter", 25),
        maxRpm=agent_data.get("maxRpm", 60),
        maxExecutionTime=agent_data.get("maxExecutionTime", 300),
        task=task_details,
        llm=data["agent_details"]["llm"],
        embedding=[embedding_config] if embedding_config else None,
        tools=agent_tools,
        allowCodeExecution=agent_data.get("allowCodeExecution", False),
        isSafeCodeExecution=agent_data.get("isSafeCodeExecution", True),
        colangContent=data.get("colang_content", None),
        yamlContent=data.get("yaml_content", None),
    )

    ## Creating agent creator configuration
    agent_config = AgentCreatorConfig(
        agent_details=agent_details,
        user_inputs={"prompt": request.prompt},
        enable_memory=True,
        langfuse_handler=langfuse_config,
        execution_id=data.get("executionId"),
        subfolder_path=None,
        workflow_id=data.get("executionId"),  # Use executionId as workflow_id for queries
        Authorization=Authorization,
        nemo_guardrails=data.get("nemo_guardrails", "False"),
        reg_enabled=data.get("rag_enable", False),
        rag_mode=data.get("rag_mode", "STRICT"),
        validator=validator,
        agent_id=agent_details.id,
    )

    return agent_config
