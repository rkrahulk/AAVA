"""
OAuth token management for user tools using actual Java APIs.
This is a stop-gap solution that can be enabled/disabled via CLIENT_NAME = 'HP' flag.

Flow:
1. Get userTools with toolId from payload service (already done)
2. For each toolId → GET /api/v1/integration/tool/{toolId}/provider → get provider
3. For each provider → GET /api/v1/integration/{provider}/consent → check consent
   3a. If consent exists → GET /api/v1/integration/{provider}/token → get token + cloudId
   3b. If consent missing → throw exception for UI redirect
"""

import os
import httpx
from typing import Dict, List, Optional
from pydantic import BaseModel
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

# ==================== PROVIDER CONFIGURATION ====================

PROVIDER_REQUIREMENTS = {
    'jira': {
        'requires_cloud_id': True,
        'requires_url': True
    },
    'confluence': {
        'requires_cloud_id': True,
        'requires_url': True
    },
    'git': {
        'requires_cloud_id': False,
        'requires_url': True
    },
    'github': {
        'requires_cloud_id': False,
        'requires_url': False
    },
    'servicenow': {
        'requires_cloud_id': False,
        'requires_url': True
    }
}

# ==================== RESPONSE MODELS ====================

class ProviderMetadata(BaseModel):
    """Metadata from token response"""
    cloudId: Optional[str] = None  # Optional - not all providers need it
    url: Optional[str] = None  # Optional - make it flexible

class ProviderResponse(BaseModel):
    """Response from GET /api/v1/integration/tool/{toolId}/provider"""
    toolId: int
    provider: str  # e.g., "jira", "servicenow"


class ConsentResponse(BaseModel):
    """Response from GET /api/v1/integration/{provider}/consent"""
    provider: str
    consentProvided: bool


class TokenResponse(BaseModel):
    """Response from GET /api/v1/integration/{provider}/token"""
    provider: str
    accessToken: str
    meta: List[ProviderMetadata]


# ==================== WRAPPER MODELS ====================

class JavaApiResponse(BaseModel):
    """Standard Java API response wrapper"""
    data: dict
    status: str


# ==================== EXCEPTIONS ====================
class ProviderNotFoundException(Exception):
    """Raised when provider is not found for a tool"""
    def __init__(self, tool_id: int):
        self.tool_id = tool_id
        self.status_code = 404
        super().__init__(f"Provider not found for tool ID: {tool_id})")

class ConsentMissingException(Exception):
    """Raised when user consent is missing (Step 3.a.ii)"""
    def __init__(self, missing_providers: List[Dict[str, str]]):
        self.missing_providers = missing_providers
        self.status_code = 403
        super().__init__(f"Consent required for: {[p['provider_name'] for p in missing_providers]}")


class ReAuthenticationRequiredException(Exception):
    """Raised when token retrieval fails"""
    def __init__(self, expired_providers: List[Dict[str, str]]):
        self.expired_providers = expired_providers
        self.status_code = 401
        super().__init__(f"Re-authentication required for: {[p['provider_name'] for p in expired_providers]}")

class OAuthServiceException(Exception):
    """Raised when OAuth service calls fail"""
    def __init__(self, message: str, step: str):
        self.step = step
        self.status_code = 500
        super().__init__(f"[{step}] OAuth service error: {message}")


# ==================== JAVA SERVICE CLIENT ====================

class JavaOAuthClientSync:
    """Synchronous client to call Java OAuth services."""
    
    def __init__(self, authorization_header: str):
        self.authorization_header = authorization_header
        self.base_url = settings.OBO_API_BASE_URL # e.g., https://aava-hp-staging.avateam.io/api/v1/integration
        #self.base_url =  os.getenv("OBO_API_BASE_URL")
        self.timeout = 30.0
    
    def get_provider_for_tool(self, tool_id: int) -> Optional[ProviderResponse]:
        """
        Step 2: Call provider service to get provider for toolId.
        
        Endpoint: GET /api/v1/integration/tool/{toolId}/provider
        
        Response:
        {
            "data": {
                "toolId": 141,
                "provider": "jira"
            },
            "status": "SUCCESS"
        }
        """
        try:
            logger.info(f"[Step 2] Calling provider service for toolId: {tool_id}")
            
            with httpx.Client(timeout=self.timeout) as client:
                response = client.get(
                    f"{self.base_url}/tool/{tool_id}/provider",
                    headers={"Authorization": self.authorization_header}
                )
                
                if response.status_code == 404:
                    logger.error(f"[Step 2] No provider found for toolId: {tool_id}")
                    raise ProviderNotFoundException(tool_id)
                
                response.raise_for_status()
                
                api_response = JavaApiResponse(**response.json())
                
                if api_response.status != "SUCCESS":
                    logger.error(
                        f"[Step 2] API status not SUCCESS for toolId {tool_id}: "
                        f"{api_response.status}"
                    )
                    raise OAuthServiceException(
                        f"Provider service returned status: {api_response.status}",
                        "Step 2"
                    )
                
                if not api_response.data:
                    logger.error(f"[Step 2] Empty data in response for toolId {tool_id}")
                    raise OAuthServiceException(
                        f"Provider service returned empty data for tool {tool_id}"
                    )
                
                provider = ProviderResponse(**api_response.data)
                
                # Validate provider is not empty
                if not provider.provider or not provider.provider.strip():
                    logger.error(
                        f"[Step 2] Empty provider name returned for toolId {tool_id}"
                    )
                    raise ProviderNotFoundException(tool_id)
                
                logger.info(
                    f"[Step 2] Got provider for toolId {tool_id}: {provider.provider}")
                
                return provider
            
        except (ProviderNotFoundException, OAuthServiceException):
            raise
        except httpx.TimeoutException as e:
            logger.error(f"[Step 2] Timeout calling provider service for toolId {tool_id}: {e}")
            raise OAuthServiceException(
                f"Provider service timeout for tool ID: {tool_id})",
                "Step 2"
            )
        except Exception as e:
            logger.error(f"[Step 2] Error getting provider for toolId {tool_id}: {e}")
            raise OAuthServiceException(
                f"Failed to get provider for tool ID: {tool_id}): {str(e)}",
                "Step 2"
            )
    
    def check_consent(self, provider_name: str) -> ConsentResponse:
        """
        Step 3: Call consent service to verify user consent.
        
        Endpoint: GET /api/v1/integration/{provider}/consent
        
        Response:
        {
            "data": {
                "provider": "jira",
                "consentProvided": true
            },
            "status": "SUCCESS"
        }

        """
        try:
            logger.info(f"[Step 3] Checking consent for provider: {provider_name}")
            
            # Validate provider_name is not empty
            if not provider_name or not provider_name.strip():
                logger.error(f"[Step 3] Empty provider name provided")
                raise OAuthServiceException(
                    "Provider name cannot be empty",
                    "Step 3"
                )
            
            with httpx.Client(timeout=self.timeout) as client:
                response = client.get(
                    f"{self.base_url}/{provider_name}/consent",
                    headers={"Authorization": self.authorization_header}
                )
                
                response.raise_for_status()
                
                api_response = JavaApiResponse(**response.json())
                
                if api_response.status != "SUCCESS":
                    logger.error(
                    f"[Step 3] API status not SUCCESS for provider {provider_name}: "
                    f"{api_response.status}"
                    )
                    raise OAuthServiceException(
                        f"Consent service returned status: {api_response.status}",
                        "Step 3"
                    )
                # Validate data exists
                if not api_response.data:
                    logger.error(f"[Step 3] Empty data in response for provider {provider_name}")
                    raise OAuthServiceException(
                        f"Consent service returned empty data for provider {provider_name}",
                        "Step 3"
                    )
            
                consent = ConsentResponse(**api_response.data)

                #Validate provider name matches
                if consent.provider != provider_name:
                    logger.warning(
                        f"[Step 3] Provider mismatch: requested {provider_name}, "
                        f"got {consent.provider}"
                    )
                    raise OAuthServiceException(
                        f"Provider mismatch: requested {provider_name}",
                        f"got {consent.provider}"
                    )
                
                if consent.consentProvided:
                    logger.info(f"[Step 3]  Consent verified for provider: {provider_name}")
                else:
                    logger.warning(f"[Step 3] Consent missing for provider: {provider_name}")
                
                return consent
        
        except OAuthServiceException:
            raise
        except httpx.TimeoutException as e:
            logger.error(f"[Step 3] Timeout checking consent for provider {provider_name}: {e}")
            raise OAuthServiceException(
                f"Consent service timeout for provider: {provider_name}",
                "Step 3"
            )
        except Exception as e:
            logger.error(f"[Step 3] Error checking consent for provider {provider_name}: {e}")
            raise OAuthServiceException(
                f"Failed to check consent for provider {provider_name}: {str(e)}",
                "Step 3"
            )
    
    def get_access_token(self, provider_name: str) -> TokenResponse:
        """
        Step 3.a.i.i: Call token service to get latest access token.
        
        Endpoint: GET /api/v1/integration/{provider}/token
        
        Response:
        {
            "data": {
                "provider": "jira",
                "accessToken": "fjuhgdafg",
                "meta": [
                    {
                        "cloudId": "7325285342",
                        "url": "https://aavedemo.atlassian.net"
                    }
                ]
            },
            "status": "SUCCESS"
        }
        """
        try:
            logger.info(f"[Step 3.a.i.i] Fetching access token for provider: {provider_name}")

             # Validate provider_name is not empty
            if not provider_name or not provider_name.strip():
                logger.error(f"[Step 3.a.i.i] Empty provider name provided")
                raise OAuthServiceException(
                    "Provider name cannot be empty",
                    "Step 3.a.i.i"
                )
            
            with httpx.Client(timeout=self.timeout) as client:
                response = client.get(
                    f"{self.base_url}/{provider_name}/token",
                    headers={"Authorization": self.authorization_header}
                )
                
                # Handle authentication failure
                if response.status_code == 401:
                    logger.error(
                        f"[Step 3.a.i.i] Token retrieval failed for {provider_name}. "
                        f"User needs to re-authenticate."
                    )
                    raise ReAuthenticationRequiredException([{
                        'provider_name': provider_name
                    }])
                
                response.raise_for_status()
                
                api_response = JavaApiResponse(**response.json())
                
                if api_response.status != "SUCCESS":
                    logger.error(f"[Step 3.a.i.i] API status not SUCCESS for provider {provider_name}")
                    raise ReAuthenticationRequiredException([{
                        'provider_name': provider_name
                    }])
                
                # Validate data exists
                if not api_response.data:
                    logger.error(f"[Step 3.a.i.i] Empty data in response for provider {provider_name}")
                    raise OAuthServiceException(
                        f"Token service returned empty data for provider {provider_name}",
                        "Step 3.a.i.i"
                    )
                
                token = TokenResponse(**api_response.data)

                #Validate provider name matches
                if token.provider != provider_name:
                    logger.warning(
                        f"[Step 3.a.i.i] Provider mismatch: requested {provider_name}, "
                        f"got {token.provider}"
                    )

                #Validate access token is not empty
                if not token.accessToken or not token.accessToken.strip():
                    logger.error(
                        f"[Step 3.a.i.i] Empty access token returned for provider {provider_name}"
                    )
                    raise ReAuthenticationRequiredException([{
                        'provider_name': provider_name
                    }])
                
                logger.info(
                    f"[Step 3.a.i.i] Got access token for provider: {provider_name} "
                    f"(meta count: {len(token.meta)})"
                )
                
                # Validate meta exists and is not empty
                if not token.meta or len(token.meta) == 0:
                    logger.warning("No metadata - proceeding without meta")
                    return token
                
                # Validate first meta entry has required fields

                
                # ✅ Provider-specific validation using configuration
                first_meta = token.meta[0]
                validate_provider_metadata(
                    provider_name=provider_name,
                    meta=first_meta,
                    step="Step 3.a.i.i"
                )
                
                logger.info(
                    f"[Step 3.a.i.i] Access token fetched for: {provider_name} "
                    f"(token length: {len(token.accessToken)}, meta count: {len(token.meta)}, "
                    f"cloudId: {first_meta.cloudId or 'N/A'}, "
                    f"url: {first_meta.url or 'N/A'})"
                )
                return token
                
        except ReAuthenticationRequiredException:
            raise
        except httpx.TimeoutException as e:
            logger.error(f"[Step 3.a.i.i] Timeout fetching token for provider {provider_name}: {e}")
            raise OAuthServiceException(
                f"Token service timeout for provider: {provider_name}",
                "Step 3.a.i.i"
            )
        except Exception as e:
            logger.error(f"[Step 3.a.i.i] Error getting access token for provider {provider_name}: {e}")
            raise OAuthServiceException(
                f"Failed to get token for provider {provider_name}: {str(e)}",
                "Step 3.a.i.i"
            )


# ==================== MAIN VALIDATION FUNCTION ====================

def validate_consents_and_fetch_tokens_sync(
    cloud_tools: List[Dict],
    authorization: str,
    execution_id: str
) -> Dict[str, Dict[str, any]]:
    """
    Complete OAuth flow following the exact algorithm.
    STRICT: Fails fast on any error - does not continue execution.
    
    Args:
        user_tools: List of user tools from agentDetail.userTools
        pipeline_agents: List of agents with userTools from payload
        authorization: Bearer token
        execution_id: Execution ID
    
    Returns:
        Dict with 'tokens' and 'tool_to_provider' mapping:
        {
            'tokens': {
                'jira': {
                    'access_token': 'fjuhgdafg',
                    'cloud_id': '7325285342',
                    'url': 'https://aavedemo.atlassian.net',
                    'meta': [...]
                }
            },
            'tool_to_provider': {449: 'jira', 450: 'servicenow'}
        }
    
    Raises:
        ProviderNotFoundException: If provider not found for any tool (404)
        ConsentMissingException: If any required consent is missing (403)
        ReAuthenticationRequiredException: If token retrieval fails (401)
        OAuthServiceException: If any service call fails (500)
    """
    logger.info(f"[{execution_id}] ========== Starting OAuth Flow ==========")
    
    try:
        java_client = JavaOAuthClientSync(authorization)
    except Exception as e:
        raise OAuthServiceException(
            f"Failed to initialize OAuth client: {str(e)}",
            "Initialization"
        )
    
    # Step 1: Extract all userTools from payload
    logger.info(f"[{execution_id}] [Step 1] Extracting userTools")
    
    tool_to_provider = {}  # toolId -> provider_name

    for cloud_tool in cloud_tools:
        tool_id = cloud_tool.get('toolId')
        tool_name = cloud_tool.get('toolName')
        
        if tool_id:
            tool_to_provider[tool_id] = None  # Will be populated in Step 2
            logger.info(
                f"[{execution_id}] [Step 1] Found tool: {tool_name} (ID: {tool_id})"
            )
        else:
            # NEW: Log warning for tools without IDs
            logger.warning(
                f"[{execution_id}] [Step 1] Skipping tool without ID: {tool_name}"
            )
    
    if not tool_to_provider:
        logger.error(f"[{execution_id}] [Step 1] No valid tool IDs found in user tools")
        raise OAuthServiceException(
            "No valid tool IDs found in user tools",
            "Step 1"
        )
    
    logger.info(f"[{execution_id}] [Step 1] Found {len(tool_to_provider)} user tools")
    
    # Step 2: Get provider for each tool
    logger.info(f"[{execution_id}] [Step 2] Getting providers for each toolId")
    
    providers_needed = {}  # provider_name -> provider_info
    
    for tool_id in tool_to_provider.keys():

        # STRICT: This will raise ProviderNotFoundException if provider not found (404)
        # STRICT: This will raise OAuthServiceException if service fails

        provider_response = java_client.get_provider_for_tool(tool_id)
        
        if provider_response:
            provider_name = provider_response.provider.strip().lower()
            
            # Validate provider name is not empty after stripping
            if not provider_name:
                logger.error(f"[{execution_id}] [Step 2] Empty provider name for toolId {tool_id}")
                raise OAuthServiceException(
                    f"Empty provider name returned for tool ID {tool_id}",
                    "Step 2"
                )
            
            tool_to_provider[tool_id] = provider_name  # Store mapping

            logger.info(
                f"[{execution_id}] [Step 2] ToolId {tool_id} → Provider: {provider_name}"
            )
            
            if provider_name not in providers_needed:
                providers_needed[provider_name] = {
                    'provider_name': provider_name,
                    'tool_ids': []
                }
            
            providers_needed[provider_name]['tool_ids'].append(tool_id)
    
    if not providers_needed:
        logger.error(f"[{execution_id}] No OAuth providers found for any tools")
        raise OAuthServiceException(
            "No OAuth providers configured for any tools",
            "Step 2"
        )
    
    logger.info(
        f"[{execution_id}]   Found {len(providers_needed)} unique providers: "
        f"{list(providers_needed.keys())}"
    )
    
    # Step 3: Check consent for each provider
    logger.info(f"[{execution_id}] [Step 3] Checking consent for each provider")
    
    missing_consents = []
    providers_with_consent = []
    
    for provider_info in providers_needed.values():
        provider_name = provider_info['provider_name']
        
        # STRICT: This will raise OAuthServiceException if service fails
        consent_response = java_client.check_consent(provider_name)
        
        if not consent_response.consentProvided:
            missing_consents.append({'provider_name': provider_name})
            logger.warning(
                f"[{execution_id}] [Step 3.a.ii] Consent missing for provider: {provider_name}"
            )
        else:
            providers_with_consent.append(provider_name)
            logger.info(
                f"[{execution_id}] [Step 3.a.i]  Consent verified for provider: {provider_name}"
            )
    
    # Step 3.a.ii: If ANY consent is missing, throw exception
    if missing_consents:
        logger.error(
            f"[{execution_id}] [Step 3.a.ii] Cannot proceed - missing {len(missing_consents)} consents"
        )
        raise ConsentMissingException(missing_consents)
    
    # Step 3.a.i.i: Fetch access tokens
    logger.info(f"[{execution_id}] [Step 3.a.i.i] Fetching access tokens...")
    
    access_tokens = {}
    
    for provider_name in providers_with_consent:
        # STRICT: This will raise ReAuthenticationRequiredException if token expired (401)
        # STRICT: This will raise OAuthServiceException if service fails
        token_response = java_client.get_access_token(provider_name)
        
        primary_cloud_id = None
        primary_url = None
        
        if token_response.meta and len(token_response.meta) > 0:
            primary_cloud_id = token_response.meta[0].cloudId
            primary_url = token_response.meta[0].url

             # Log if multiple instances available
            if len(token_response.meta) > 1:
                logger.info(
                    f"[{execution_id}] [Step 3.a.i.i] Provider '{provider_name}' has "
                    f"{len(token_response.meta)} instances available. Primary: {primary_url}"
                )
                logger.debug(
                    f"[{execution_id}] [Step 3.a.i.i] All instances: "
                    f"{[f'{m.url} (cloudId: {m.cloudId})' for m in token_response.meta]}"
                )
                
        access_tokens[provider_name] = {
            'access_token': token_response.accessToken,
            'cloud_id': primary_cloud_id,
            'url': primary_url,
            'meta': [m.model_dump() for m in token_response.meta]
        }
        
        logger.info(
            f"[{execution_id}] [Step 3.a.i.i]   Access token fetched for: {provider_name}"
        )
    
    logger.info(f"[{execution_id}] ========== OAuth Flow Complete ==========")
    logger.info(
        f"[{execution_id}]   Successfully fetched {len(access_tokens)} access tokens: "
        f"{list(access_tokens.keys())}"
    )
    
    # Return both tokens and tool-to-provider mapping
    return {
        'tokens': access_tokens,
        'tool_to_provider': tool_to_provider  # Map toolId -> provider_name
    }




# ==================== HELPERS ====================

def validate_provider_metadata(
    provider_name: str, 
    meta: ProviderMetadata, 
    step: str,
    execution_id: Optional[str] = None
) -> bool:
    """
    Validate metadata based on provider-specific requirements.
    
    Args:
        provider_name: Provider name (e.g., 'jira', 'git')
        meta: Provider metadata from token response
        step: Current step for error reporting (e.g., "Step 3.a.i.i")
        execution_id: Optional execution ID for logging
    
    Returns:
        True if validation passes
    
    Raises:
        OAuthServiceException: If required fields are missing for this provider
    """
    provider_key = provider_name.lower()
    log_prefix = f"[{execution_id}] [{step}]" if execution_id else f"[{step}]"
    
    # Get requirements for this provider
    # Get requirements with inline fallback
    if provider_key in PROVIDER_REQUIREMENTS:
        requirements = PROVIDER_REQUIREMENTS[provider_key]
    else:
        logger.warning(
            f"{log_prefix} Unknown provider '{provider_name}'"
        )
        raise OAuthServiceException(
                f"Unknown provider '{provider_name}'"
            )
    
    
    logger.debug(
        f"{log_prefix} Validating metadata for {provider_name} "
        f"(cloudId required: {requirements.get('requires_cloud_id')}, "
        f"URL required: {requirements.get('requires_url')})"
    )
    
    # ==================== Cloud ID Validation ====================
    if requirements.get('requires_cloud_id'):
        if not meta.cloudId or not meta.cloudId.strip():
            logger.error(
                f"{log_prefix} Missing required cloudId for provider {provider_name}"
            )
            raise OAuthServiceException(
                f"cloudId is required for {provider_name} but was not provided in token response",
                step
            )
        
        logger.info(
            f"{log_prefix}   cloudId validated for {provider_name}: {meta.cloudId}"
        )
    else:
        if meta.cloudId:
            logger.debug(
                f"{log_prefix} cloudId provided for {provider_name}: {meta.cloudId} "
                f"(not required but present)"
            )
        else:
            logger.debug(
                f"{log_prefix} cloudId not provided for {provider_name} (not required)"
            )
    
    # ==================== URL Validation ====================
    if requirements.get('requires_url'):
        if not meta.url or not meta.url.strip():
            logger.error(
                f"{log_prefix} Missing required URL for provider {provider_name}"
            )
            raise OAuthServiceException(
                f"URL is required for {provider_name} but was not provided in token response",
                step
            )
        
        logger.info(
            f"{log_prefix}   URL validated for {provider_name}: {meta.url}"
        )
    else:
        if meta.url:
            logger.debug(
                f"{log_prefix} URL provided for {provider_name}: {meta.url} "
                f"(not required but present)"
            )
        else:
            logger.debug(
                f"{log_prefix} URL not provided for {provider_name} (not required)"
            )
    
    return True