# TODO required in agents?

import copy
import json
import logging

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

adminUrl = settings.BASE_API_URL+settings.API_AGENT_ADMIN_URL



def mask_response(agent_data: dict):
    try:
        for key in ["langfuse", "managerLlm", "masterEmbedding"]:
            agent_data.pop(key, None)
        if "agent" in agent_data and isinstance(agent_data["agent"], dict):
            agent = agent_data["agent"]
            for key in ["llm", "embedding"]:
                agent.pop(key, None)
    except Exception as e:
        logger.warning(f"Error removing sensitive keys: {e}")
    return agent_data


def get_headers(Authorization):
    return {"Content-Type": "application/json", "Authorization": Authorization}


def save_final_execution_history(
    agent_id, executionId, agent_response, finalResponse, Authorization,status
):
    try:
        # {"agent": final_response_payload}
        if not finalResponse:
            payload_object = {}
        elif "agent" in finalResponse:
            payload_object = copy.deepcopy(finalResponse["agent"])
        elif "response" in finalResponse:
            # Parse JSON string if needed
            response_data = finalResponse["response"]
            if isinstance(response_data, str):
                payload_object = json.loads(response_data)
            else:
                payload_object = response_data
        else:
            payload_object = finalResponse
        if payload_object:
            _ = payload_object.pop("file_download_url", None)
            masked_response = mask_response(payload_object)
        else:
            masked_response = {}
        if agent_response and isinstance(agent_response, (tuple, list)) and len(agent_response) >= 2:
            task_output, upload_file_id = agent_response
        else:
            task_output, upload_file_id = None, "Not applicable"
        data = {
            "agentId": agent_id,
            "executionId": executionId,
            "status": status,
            "output": {
                "response": masked_response,
                # "total_tokens": task_output.token_usage.total_tokens,
                # "prompt_tokens": task_output.token_usage.prompt_tokens,
                # "cached_prompt_tokens": task_output.token_usage.cached_prompt_tokens,
                # "completion_tokens": task_output.token_usage.completion_tokens,
                # "successful_requests": task_output.token_usage.successful_requests,
                "upload_file_id": upload_file_id,
            },
        }
        params = dict(
            url=adminUrl,
            headers=get_headers(Authorization),
            json=data
        )

        response = httpx.post(**params)
        if response.status_code>=400:
            raise Exception(response.content)

        logger.info(f"save final execution history response : {response}")

    except Exception as e:
        logger.error(f"Error in save_final_execution_history: {e}")


def send_execution_status(execution_id: str, agent_id: str, status: str, Authorization: str):
    try:
        status_url = settings.BASE_API_URL + settings.API_AGENT_EXECUTION_STATUS
        if not status_url:
            logger.error("API_AGENT_EXECUTION_STATUS environment variable not set")
            return False

        data = {"status": status, "agentId": agent_id, "executionId": execution_id}

        params = dict(
            url=status_url,
            headers=get_headers(Authorization),
            json=data
        )
        response = httpx.put(**params)

        if response.status_code != 200:
            logger.error(
                f"Failed to send execution status. Status code: {response.status_code}"
            )
            return False

        return True
    except Exception as e:
        logger.error(
            f"Error sending execution status for execution_id {execution_id}: {e}"
        )
        return False
