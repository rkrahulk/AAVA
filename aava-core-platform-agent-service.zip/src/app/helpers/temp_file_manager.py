"""
Temporary file manager for safe and automatic cleanup.

Provides a centralized manager for temporary files and directories
with automatic cleanup on exit.
"""

import logging
import os
import shutil
import tempfile
import atexit
from typing import List

logger = logging.getLogger(__name__)


class TempFileManager:
    """
    Manages temporary files and directories with automatic cleanup.
    
    Uses Python's tempfile module for secure temp file creation
    and registers cleanup handlers to ensure files are removed.
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Initialize the temp file manager."""
        self.temp_dirs: List[str] = []
        self.temp_files: List[str] = []
        # Register cleanup on exit
        atexit.register(self.cleanup_all)
        logger.info("TempFileManager initialized with auto-cleanup on exit")
    
    def create_temp_dir(self, prefix: str = "aava_") -> str:
        """
        Create a temporary directory with secure permissions.
        
        Args:
            prefix: Prefix for the directory name
            
        Returns:
            str: Absolute path to the created directory
        """
        try:
            # Create temp dir with 0700 permissions (owner only)
            temp_dir = tempfile.mkdtemp(prefix=prefix)
            self.temp_dirs.append(temp_dir)
            logger.info(f"Created temp directory: {temp_dir}")
            return temp_dir
        except Exception as e:
            logger.error(f"Failed to create temp directory: {e}")
            raise
    
    def create_temp_file(self, suffix: str = "", prefix: str = "aava_") -> str:
        """
        Create a temporary file with secure permissions.
        
        Args:
            suffix: File extension/suffix
            prefix: Prefix for the file name
            
        Returns:
            str: Absolute path to the created file
        """
        try:
            # Create temp file with 0600 permissions (owner only)
            fd, temp_file = tempfile.mkstemp(suffix=suffix, prefix=prefix)
            os.close(fd)  # Close file descriptor
            self.temp_files.append(temp_file)
            logger.info(f"Created temp file: {temp_file}")
            return temp_file
        except Exception as e:
            logger.error(f"Failed to create temp file: {e}")
            raise
    
    def cleanup_temp_dir(self, temp_dir: str):
        """
        Clean up a specific temporary directory.
        
        Args:
            temp_dir: Path to the directory to remove
        """
        try:
            if temp_dir in self.temp_dirs:
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)
                    logger.debug(f"Cleaned up temp directory: {temp_dir}")
                self.temp_dirs.remove(temp_dir)
        except Exception as e:
            logger.warning(f"Failed to cleanup temp dir {temp_dir}: {e}")
    
    def cleanup_temp_file(self, temp_file: str):
        """
        Clean up a specific temporary file.
        
        Args:
            temp_file: Path to the file to remove
        """
        try:
            if temp_file in self.temp_files:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    logger.debug(f"Cleaned up temp file: {temp_file}")
                self.temp_files.remove(temp_file)
        except Exception as e:
            logger.warning(f"Failed to cleanup temp file {temp_file}: {e}")
    
    def cleanup_all(self):
        """Clean up all tracked temporary files and directories."""
        cleaned_dirs = 0
        cleaned_files = 0
        
        # Clean directories
        for temp_dir in list(self.temp_dirs):
            try:
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)
                    cleaned_dirs += 1
            except Exception as e:
                logger.warning(f"Failed to cleanup temp dir {temp_dir}: {e}")
        
        # Clean files
        for temp_file in list(self.temp_files):
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    cleaned_files += 1
            except Exception as e:
                logger.warning(f"Failed to cleanup temp file {temp_file}: {e}")
        
        self.temp_dirs.clear()
        self.temp_files.clear()
        
        if cleaned_dirs > 0 or cleaned_files > 0:
            logger.info(
                f"TempFileManager cleanup complete: "
                f"{cleaned_dirs} directories, {cleaned_files} files"
            )
    
    def get_stats(self) -> dict:
        """Get statistics about tracked temporary files."""
        return {
            "temp_dirs": len(self.temp_dirs),
            "temp_files": len(self.temp_files),
            "total_items": len(self.temp_dirs) + len(self.temp_files)
        }


# Singleton instance
temp_file_manager = TempFileManager()
