import boto3
import base64
from langchain_core.documents import Document
import json

def decode_access_key(key):
    return base64.b64decode(key).decode("utf-8")

def create_embedder(payloadObject):
    embedder_config = {
        "AzureOpenAI": lambda: {
            "provider": "azure",
            "config": {
                "api_key": decode_access_key(payloadObject.embedding_api_key),
                "api_base": payloadObject.embedding_azure_endpoint,
                "api_version": payloadObject.embedding_api_version,
                "model": payloadObject.embedding_deployment_name,
            },
            "chromadb":{
                "chroma_end_point":payloadObject.chroma_end_point,
                "chroma_port":payloadObject.chroma_port,
            }
        },
        "AmazonBedrock": lambda: {
            "provider": "bedrock",
            "config": {
                "session": boto3.Session(
                    aws_access_key_id=decode_access_key(payloadObject.embedding_aws_key),
                    aws_secret_access_key=decode_access_key(payloadObject.embedding_aws_secret_key),
                    region_name=payloadObject.embedding_aws_region
                )
            },
            "chromadb":{
                "chroma_end_point":payloadObject.chroma_end_point,
                "chroma_port":payloadObject.chroma_port,
            }
        }
    }
    
    # Fetch the embedder configuration based on payloadObject.type
    embedder = embedder_config.get(payloadObject.aiEngine, lambda: None)()
    if embedder is None:
        raise ValueError(f"Unsupported embedder type: {payloadObject.aiEngine}")
    return embedder



def parent_doc_retriever(docs):

    matching_documents = []

    text_list = []
    
    child_chunks = docs

    for chunk in child_chunks:

        metadata = json.loads(chunk.metadata["parent_metadata"])

        if chunk.metadata["parent_text"] not in text_list:
            
            matching_documents.append(Document(page_content=chunk.metadata["parent_text"], metadata=metadata))
            
            text_list.append(chunk.metadata["parent_text"])

    return matching_documents
