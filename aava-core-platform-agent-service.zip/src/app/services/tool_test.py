import json
from app.helpers.tool_ops import initialize_user_tool
from app.models.test_tool import TestTool

async def extract_params(payload: TestTool):

    try:
        tool_instance = initialize_user_tool(
            payload.class_name, payload.class_definition
        )

        output = tool_instance._run(**payload.inputs)

        return {
                "status": "success",
                "output": json.dumps(output, default=str) if not isinstance(output, str) else output,
            }

    except Exception as e:
        raise e.__class__(" - " + "params extraction error " + str(e)) from e
