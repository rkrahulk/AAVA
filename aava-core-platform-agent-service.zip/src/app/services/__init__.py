from app.services.crew_controller.EventListener import EventListeners
# Wire CrewAI global event bus so EventListeners hooks actually fire
try:
    from crewai.utilities.events import crewai_event_bus as event_bus  # CrewAIEventsBus singleton
except Exception as _e:
    import logging
    logging.getLogger(__name__).warning(f"Could not import CrewAI event bus: {_e}")
    event_bus = None  # type: ignore

# Instantiate singleton listener and register callbacks on import
event_listener = EventListeners()
try:
    if event_bus is not None:
        event_listener.setup_listeners(event_bus)
        import logging
        logging.getLogger(__name__).info("Registered CrewAI event listeners with crewai_event_bus")
    else:
        import logging
        logging.getLogger(__name__).warning("CrewAI event bus unavailable; listeners not registered")
except Exception as _e:
    import logging
    logging.getLogger(__name__).warning(f"Failed to register CrewAI event listeners: {_e}")
