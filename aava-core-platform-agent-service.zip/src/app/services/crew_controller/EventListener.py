import json
import logging
import uuid
from datetime import datetime

from app.core.config import settings
from app.core.trulens import Trulens
from app.helpers.redis_logs import PipelineAILogs
from app.models.PipelineModel import PipelineModel
from app.models.listeners_metadata import CrewStages
from app.services.crew_controller.agent_creator import AgentCreatorConfig
from app.services.kafka_client import push_logs_to_kafka as plk
from app.core.langfuse_api import get_langfuse_api


logger = logging.getLogger("EventListener")


from crewai.utilities.events import (
    # CrewKickoffStartedEvent,
    # CrewKickoffCompletedEvent,
    # CrewKickoffFailedEvent,

    AgentExecutionStartedEvent,
    AgentExecutionCompletedEvent,
    AgentExecutionErrorEvent,

    TaskStartedEvent,
    TaskCompletedEvent,
    TaskFailedEvent,
    TaskEvaluationEvent,

    ToolUsageStartedEvent,
    ToolUsageFinishedEvent,
    ToolUsageErrorEvent,
    ToolValidateInputErrorEvent,
    ToolExecutionErrorEvent,
    ToolSelectionErrorEvent,

    LLMGuardrailStartedEvent,
    LLMGuardrailCompletedEvent,
    # LLMCallStartedEvent,
    # LLMCallCompletedEvent,
    # LLMCallFailedEvent,
    # LLMStreamChunkEvent,

    # MemoryQueryStartedEvent,
    # MemoryQueryCompletedEvent,
    # MemoryQueryFailedEvent,
    # MemorySaveStartedEvent,
    # MemorySaveCompletedEvent,
    # MemorySaveFailedEvent,
    # MemoryRetrievalStartedEvent,
    # MemoryRetrievalCompletedEvent,
)
from crewai.utilities.events.base_event_listener import BaseEventListener

class EventListeners(BaseEventListener):
    def __init__(self):
        self.metadata_hash = dict() # Redis
        self.plk=plk if not settings.PERSISTENT_LOGGING else None
        
        try:
            self._custom_enabled = getattr(settings, 'CUSTOM_LANGFUSE_ENABLED', False) if settings else False
        except (ImportError, AttributeError) as e:
            logger.warning(f"Could not load settings for EventListener, disabling custom langfuse: {e}")
            self._custom_enabled = False
            
        self.langfuse_api = get_langfuse_api() if self._custom_enabled else None
        
        self.agent_spans = dict()  # Track agent span IDs: {agent_id: span_id}
        self.tool_spans = dict()  # Track tool span IDs: {tool_usage_id: span_id}
        self._run_state = dict()  # Consolidated execution state (Phase 1)
        
        logger.info(f"Metadata Hash: {self.metadata_hash}")
        logger.info(f"[Custom Langfuse] EventListener initialized (enabled={self._custom_enabled})")
        super().__init__()
    
    def send_logs(self, message):
        try:
            if self.plk:
                logger.info(f"Storing logs into KAFKA")
                self.plk(message=message)
            else:
                logger.info(f"Storing logs into DB")
                logs_json = json.dumps(message)
                PipelineAILogs().push_logs_to_database(logs_json=logs_json, execution_id=message["execution_id"])
                logger.info("PERSISTENT LOGGING enabled, skipping Event Listener Message Push.")
        except Exception as e:
            logger.error(f"Failed to send Event listener logs: {str(e)}")

    # ==================== PHASE 1: HELPER METHODS - START ====================
    def _to_utc(self, dt: datetime) -> datetime:
        """Convert any datetime to UTC timezone."""
        import pytz
        try:
            ist_tz = pytz.timezone('Asia/Kolkata')
            if dt.tzinfo is None:
                localized_time = ist_tz.localize(dt)
                return localized_time.astimezone(pytz.utc)
            else:
                return dt.astimezone(pytz.utc)
        except Exception as e:
            logger.error(f"[Custom Langfuse] Failed to convert to UTC: {e}")
            from datetime import timezone
            return datetime.now(timezone.utc)
    
    def _iso_z(self, dt: datetime) -> str:
        """Convert datetime to ISO format with Z suffix (UTC)."""
        utc_dt = self._to_utc(dt)
        return utc_dt.isoformat().replace("+00:00", "Z")
    
    def _get_state(self, execution_id: str) -> dict:
        """Get or create consolidated execution state."""
        if execution_id not in self._run_state:
            self._run_state[execution_id] = {
                "crew": {},
                "agent": {},
                "tasks": [],
                "tools": [],
                "errors": [],
                "tokens": {"total": 0, "prompt": 0, "completion": 0, "cost": 0.0},
                "metadata": {"agent_name": None},
                "kb_context": "",  # KB context extracted from RAG tools
                "flushed": False,
            }
        return self._run_state[execution_id]
    
    def _cleanup_execution_state(self, execution_id: str):
        """Clean up state after execution completes to prevent memory leaks."""
        try:
            # Remove from run state
            if execution_id in self._run_state:
                del self._run_state[execution_id]
                logger.info(f"[Memory] Cleaned up run_state for execution {execution_id}")
            
            # Clean up metadata_hash for this execution - CRITICAL FIX
            metadata_keys_to_remove = []
            for key, value in list(self.metadata_hash.items()):
                if hasattr(value, 'execution_id') and value.execution_id == execution_id:
                    metadata_keys_to_remove.append(key)
            
            for key in metadata_keys_to_remove:
                del self.metadata_hash[key]
                logger.debug(f"[Memory] Cleaned up metadata_hash entry: {key}")
            
            # Clean up agent spans for this execution
            agent_keys_to_remove = []
            for key, value in self.agent_spans.items():
                if isinstance(value, dict):
                    # Check if this span belongs to this execution
                    span_id = value.get('span_id', '')
                    if execution_id in str(span_id) or key.startswith(execution_id) or str(key) == execution_id:
                        agent_keys_to_remove.append(key)
            
            for key in agent_keys_to_remove:
                del self.agent_spans[key]
                logger.debug(f"[Memory] Cleaned up agent span: {key}")
            
            # Clean up tool spans for this execution
            tool_keys_to_remove = [k for k in self.tool_spans.keys() 
                                   if execution_id in str(k)]
            
            for key in tool_keys_to_remove:
                del self.tool_spans[key]
                logger.debug(f"[Memory] Cleaned up tool span: {key}")
            
            if metadata_keys_to_remove or agent_keys_to_remove or tool_keys_to_remove:
                logger.info(
                    f"[Memory] Cleaned up for execution {execution_id}: "
                    f"{len(metadata_keys_to_remove)} metadata entries, "
                    f"{len(agent_keys_to_remove)} agent spans, {len(tool_keys_to_remove)} tool spans"
                )
        except Exception as e:
            logger.warning(f"[Memory] Failed to cleanup execution state for {execution_id}: {e}")
    # ==================== PHASE 1: HELPER METHODS - END ====================
    
    # ==================== PHASE 2: OUTPUT EXTRACTION HELPER - START ====================
    def _extract_readable_output(self, data) -> str:
        """Extract human-readable content from various data formats, including error cases."""
        if data is None:
            return "No output generated"
        
        # Handle Exception objects
        if isinstance(data, Exception):
            return f"Error: {str(data)}"
        
        # If it's a string, return as-is (but not empty)
        if isinstance(data, str):
            return data.strip() if data.strip() else "Empty output"
        
        # Check for .raw attribute first
        if hasattr(data, "raw"):
            return self._extract_readable_output(data.raw)
        
        # If it's a dict, try to extract meaningful content
        if isinstance(data, dict):
            # Check for error keys first (error cases from different event sources)
            for error_key in ["error", "exception", "error_message", "error_info", "stack_trace"]:
                if error_key in data:
                    error_value = data[error_key]
                    if error_value:
                        return f"Error: {self._extract_readable_output(error_value)}"
            
            # Try common output keys
            for key in ["output", "result", "answer", "response", "text", "content", "message", "final_answer"]:
                if key in data:
                    value = data[key]
                    if value is not None and str(value).strip():
                        # Recursively extract in case the value is also a dict
                        return self._extract_readable_output(value)
            
            # If no common keys, try to extract values and format nicely
            if data:
                # Build a readable output from dict values
                output_parts = []
                for key, value in data.items():
                    if value is not None:
                        # Skip template-style keys like ((num))
                        clean_key = key.strip("()").strip()
                        value_str = str(value).strip()
                        if clean_key and value_str:
                            output_parts.append(f"{clean_key}: {value_str}")
                
                if output_parts:
                    return "\n".join(output_parts)
            
            # Last resort: JSON dump with nice formatting
            try:
                import json
                json_output = json.dumps(data, ensure_ascii=False, indent=2)
                return json_output if json_output and json_output != "{}" else "Empty dict output"
            except:
                return "Dict output (serialization failed)"
        
        # For other types (including custom objects), convert to string
        try:
            result = str(data)
            return result if result.strip() else "Empty output"
        except Exception as e:
            return f"Output (conversion failed: {str(e)})"
    # ==================== PHASE 2: OUTPUT EXTRACTION HELPER - END ====================
    
    # ==================== PHASE 3: TOOL & SUMMARY HELPERS - START ====================
    def _create_tool_span(self, execution_id: str, agent_id: str, tool_name: str, 
                          tool_class: str, tool_args: dict) -> dict | None:
        """Create a tool usage span nested under agent span."""
        if not (self._custom_enabled and self.langfuse_api):
            return None
        
        try:
            parent_span_id = None
            if agent_id in self.agent_spans:
                agent_span_info = self.agent_spans[agent_id]
                parent_span_id = agent_span_info.get("span_id")
            
            if not parent_span_id:
                logger.warning(f"[Custom Langfuse] No parent span found for tool {tool_name}")
                return None
            
            span = self.langfuse_api.create_span(
                trace_id=execution_id,
                name=f"Tool: {tool_name}",
                span_type="SPAN",
                parent_span_id=parent_span_id,
                metadata={"tool_class": tool_class},
                input_data={"args": tool_args} if tool_args else {},
            )
            
            logger.info(f"[Custom Langfuse] Created tool span '{tool_name}'")
            return span
        except Exception as e:
            logger.warning(f"[Custom Langfuse] Failed to create tool span: {e}")
            return None
    
    def _end_tool_span(self, span: dict | None, output, 
                       started_at: datetime = None, finished_at: datetime = None):
        """End a tool usage span."""
        if not (self._custom_enabled and self.langfuse_api and span):
            return
        
        try:
            self.langfuse_api.end_span(
                span_id=span.get("span_id"),
                output_data=output,
                start_time=span.get("start_time") if started_at is None else started_at,
                end_time=finished_at or datetime.now(datetime.now().astimezone().tzinfo),
            )
        except Exception as e:
            logger.warning(f"[Custom Langfuse] Failed to end tool span: {e}")
    
    def _flush_consolidated_summary(self, payload: AgentCreatorConfig, final_output=None):
        """Create consolidated summary span with all execution data."""
        if not (self._custom_enabled and self.langfuse_api and payload):
            return
        
        try:
            execution_id = payload.execution_id
            state = self._get_state(execution_id)
            if state.get("flushed"):
                return
            
            summary = {
                "execution_id": execution_id,
                "workflow_id": payload.workflow_id,
                "agent_name": payload.agent_name,
                "agent": {
                    "id": payload.agent_details.id,
                    "name": payload.agent_details.name,
                    "role": payload.agent_details.role,
                    "goal": payload.agent_details.goal,
                },
                "crew": state.get("crew", {}),
                "tasks": state.get("tasks", []),
                "tools": state.get("tools", []),
                "tokens": state.get("tokens", {}),
                "errors": state.get("errors", []),
                "result": final_output,
                "counts": {
                    "tools": len(state.get("tools", [])),
                    "tasks": len(state.get("tasks", [])),
                    "errors": len(state.get("errors", [])),
                },
            }
            
            # Create consolidated span under trace root
            consolidated_span = self.langfuse_api.create_span(
                trace_id=execution_id,
                name="execution-summary",
                span_type="SPAN",
                parent_span_id=f"{execution_id}_root",
                input_data=summary,
                metadata={"type": "consolidated_summary"},
            )
            
            if consolidated_span:
                self.langfuse_api.end_span(
                    span_id=consolidated_span.get("span_id"),
                    output_data=summary,
                    start_time=consolidated_span.get("start_time"),
                )
            
            state["flushed"] = True
            logger.info(f"[Custom Langfuse] Flushed consolidated summary for {execution_id}")
        except Exception as e:
            logger.warning(f"[Custom Langfuse] Failed to flush consolidated summary: {e}")
    # ==================== PHASE 3: TOOL & SUMMARY HELPERS - END ====================
    
    def crew_listeners_meta(self, _id: str,  payload: PipelineModel, event_type: str):
        try:
            # ==================== WORKFLOW NAME FIX - START ====================
            # Extract workflow name with same smart logic as in crew_creator
            raw_name = getattr(payload, "name", "Unknown Pipeline")
            description = getattr(payload, "description", None)
            
            # If name looks like an ID, prefer description
            if raw_name and (raw_name.replace("-", "").replace("_", "").isdigit() or 
                            len(raw_name) > 20 and any(c.isdigit() for c in raw_name)):
                agent_name = description if description else raw_name
            else:
                agent_name = raw_name
            # ==================== WORKFLOW NAME FIX - END ====================
            
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.pipelineId,
                execution_id=payload.executionId,
                name=payload.name,
                user=payload.user,
                description=payload.description,
                user_inputs=payload.userInputs,
                # Add workflow names for proper grouping
                agent_name=agent_name,
            )
        except Exception as e:
            logger.error(
                f"Failed to create crew listener payload for event_type: {event_type}"
                f" crew id: {_id} from {payload} as: {str(e)}"
            )
            return dict()
    
    def agent_listeners_meta(self, _id: str,  payload: AgentCreatorConfig, event_type: str):
        try:
            # ==================== TOOLS AND KB FIX - START ====================
            # Extract tools information
            tools_list = []
            if hasattr(payload.agent_details, 'tools') and payload.agent_details.tools:
                tools_list = [
                    {
                        "tool_name": tool.toolName,
                        "parameters": [p.parameterName for p in tool.parameters]
                    }
                    for tool in payload.agent_details.tools
                ]
            
            # Extract knowledge base information
            knowledge_bases = []
            if hasattr(payload.agent_details, 'embedding') and payload.agent_details.embedding:
                from app.helpers.kb_utils import get_kb_filenames
                # get_kb_filenames expects the full list and processes internally
                kb_files = get_kb_filenames(payload.agent_details.embedding)
                # Add info for each embedding configuration
                for emb in payload.agent_details.embedding:
                    knowledge_bases.append({
                        "collection": emb.index_collection if hasattr(emb, 'index_collection') else None,
                        "model": emb.embedding_model if hasattr(emb, 'embedding_model') else None,
                        "ai_engine": emb.aiEngine if hasattr(emb, 'aiEngine') else None,
                        "files": kb_files or []
                    })
            # ==================== TOOLS AND KB FIX - END ====================
            
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.workflow_id,
                execution_id=payload.execution_id,
                # Business context for grouping
                # Agent details
                agent_id=payload.agent_details.id,
                agent_name=payload.agent_details.name,
                agent_role=payload.agent_details.role,
                # NEW: Add tools and knowledge base
                tools=tools_list,
                knowledge_bases=knowledge_bases,
            )
        except Exception as e:
            logger.error(
                f"Failed to create agent listener payload for event_type: {event_type}"
                f" agent id: {_id} from {payload} as: {str(e)}"
            )
            return dict()
    
    def task_listeners_meta(self, _id: str,  payload: AgentCreatorConfig, event_type: str):
        try:
            # ==================== TOOLS AND KB FIX - START ====================
            # Extract tools and KB (same as in agent_listeners_meta)
            tools_list = []
            if hasattr(payload.agent_details, 'tools') and payload.agent_details.tools:
                tools_list = [
                    {
                        "tool_name": tool.toolName,
                        "parameters": [p.parameterName for p in tool.parameters]
                    }
                    for tool in payload.agent_details.tools
                ]
            
            knowledge_bases = []
            if hasattr(payload.agent_details, 'embedding') and payload.agent_details.embedding:
                from app.helpers.kb_utils import get_kb_filenames
                # get_kb_filenames expects the full list and processes internally
                kb_files = get_kb_filenames(payload.agent_details.embedding)
                # Add info for each embedding configuration
                for emb in payload.agent_details.embedding:
                    knowledge_bases.append({
                        "collection": emb.index_collection if hasattr(emb, 'index_collection') else None,
                        "model": emb.embedding_model if hasattr(emb, 'embedding_model') else None,
                        "ai_engine": emb.aiEngine if hasattr(emb, 'aiEngine') else None,
                        "files": kb_files or []
                    })
            # ==================== TOOLS AND KB FIX - END ====================
            
            return dict(
                event_execution_id=str(uuid.uuid4()),
                pipeline_id=payload.workflow_id,
                execution_id=payload.execution_id,
                # Business context for grouping
                # Task and Agent details
                agent_id=payload.agent_details.id,
                agent_name=payload.agent_details.name,
                expected_output=payload.agent_details.task.expectedOutput,
                description=payload.agent_details.task.description,
                # NEW: Add tools and knowledge base
                tools=tools_list,
                knowledge_bases=knowledge_bases,
            )
        except Exception as e:
            logger.error(
                f"Failed to create task listener payload for event_type: {event_type}"
                f" task id: {_id} from {payload} as: {str(e)}"
            )
            return dict()

    def setup_listeners(self, crewai_event_bus):
        # @crewai_event_bus.on(CrewKickoffStartedEvent)
        # def on_crew_started(source, event):
        #     try:
        #         _id = str(source.id)
        #         event_type = CrewStages.CREW_START.value
        #         payload = self.metadata_hash.get(_id)
        #         if not payload:
        #             logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
        #         data = self.crew_listeners_meta(_id, payload, event_type)
        #         data["type"] = event_type
        #         data["message"] =  f"[CrewAI Listener] Crew started",
        #         logger.info(data)
        #         self.send_logs(message=data)


        #     except Exception as e:
        #         logger.error(
        #             f"Unable to Log the stage: {event_type} "
        #             f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        # @crewai_event_bus.on(CrewKickoffCompletedEvent)
        # def on_crew_completed(source, event):
        #     try:
        #         _id = str(source.id)
        #         event_type = CrewStages.CREW_FINISHED.value
        #         payload = self.metadata_hash.get(_id)
        #         if not payload:
        #             logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
        #         data = self.crew_listeners_meta(_id, payload, event_type)
        #         output = getattr(event, "output", None)
        #         raw_output = getattr(output, "raw", None) or output
                
        #         # ==================== ADD TOKEN & COST SUMMARY - START ====================
        #         # Aggregate token and cost information from all agent spans
        #         total_tokens = 0
        #         prompt_tokens = 0
        #         completion_tokens = 0
        #         total_cost = 0.0
                
        #         try:
        #             # Aggregate from all tracked agent spans
        #             if hasattr(self, 'agent_spans') and self.agent_spans:
        #                 logger.info(f"[Kafka Log] Aggregating token/cost data from {len(self.agent_spans)} agent spans")
                        
        #                 for agent_id, span_info in self.agent_spans.items():
        #                     if isinstance(span_info, dict):
        #                         # Check if this span has recorded usage data
        #                         if span_info.get('usage_recorded', False):
        #                             # Extract from span metadata if available
        #                             span_tokens = span_info.get('tokens', 0)
        #                             span_prompt = span_info.get('prompt_tokens', 0)
        #                             span_completion = span_info.get('completion_tokens', 0)
        #                             span_cost = span_info.get('cost', 0.0)
                                    
        #                             total_tokens += span_tokens
        #                             prompt_tokens += span_prompt
        #                             completion_tokens += span_completion
        #                             total_cost += span_cost
                                    
        #                             logger.debug(
        #                                 f"[Kafka Log] Agent {agent_id}: tokens={span_tokens}, "
        #                                 f"cost=${span_cost:.4f}"
        #                             )
                        
        #                 logger.info(
        #                     f"[Kafka Log] Aggregated totals: tokens={total_tokens}, "
        #                     f"prompt={prompt_tokens}, completion={completion_tokens}, "
        #                     f"cost=${total_cost:.4f}"
        #                 )
                    
        #             # Fallback: Try to extract from crew output if agent span aggregation didn't work
        #             if total_tokens == 0 and hasattr(output, 'token_usage'):
        #                 logger.info("[Kafka Log] Using crew output token_usage as fallback")
        #                 token_data = output.token_usage
        #                 if isinstance(token_data, dict):
        #                     total_tokens = token_data.get('total_tokens', 0)
        #                     prompt_tokens = token_data.get('prompt_tokens', 0)
        #                     completion_tokens = token_data.get('completion_tokens', 0)
        #                 else:
        #                     total_tokens = getattr(token_data, 'total_tokens', 0)
        #                     prompt_tokens = getattr(token_data, 'prompt_tokens', 0)
        #                     completion_tokens = getattr(token_data, 'completion_tokens', 0)
                        
        #                 # Calculate cost using Langfuse API if available
        #                 if total_tokens > 0 and self.langfuse_api:
        #                     # Get model from first agent span if available
        #                     model = None
        #                     if hasattr(self, 'agent_spans') and self.agent_spans:
        #                         first_span = next(iter(self.agent_spans.values()))
        #                         if isinstance(first_span, dict):
        #                             model = first_span.get("model")
                            
        #                     if model:
        #                         total_cost = self.langfuse_api.compute_cost(
        #                             prompt_tokens, completion_tokens, model
        #                         )
        #                         logger.info(f"[Kafka Log] Calculated cost from fallback: ${total_cost:.4f}")
                
        #         except Exception as e:
        #             logger.error(f"[Kafka Log] Failed to extract token/cost data: {e}", exc_info=True)
                
        #         # Calculate individual costs
        #         input_cost = (prompt_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
        #         output_cost = (completion_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
        #         # ==================== ADD TOKEN & COST SUMMARY - END ====================
                
        #         data.update(
        #             timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
        #             message=  f"[CrewAI Listener] Crew Completed",
        #             output=raw_output,
        #             # Token and cost summary
        #             total_tokens=total_tokens,
        #             prompt_tokens=prompt_tokens,
        #             completion_tokens=completion_tokens,
        #             total_cost=round(total_cost, 4),
        #             input_cost=round(input_cost, 4),
        #             output_cost=round(output_cost, 4),
        #             type=event_type
        #         )
                
        #         # Log summary to console as well
        #         if total_tokens > 0:
        #             logger.info(
        #                 f"[Pipeline Summary] Execution {data.get('execution_id')}: "
        #                 f"Tokens={total_tokens} (Input={prompt_tokens}, Output={completion_tokens}), "
        #                 f"Cost=${total_cost:.4f} (Input=${input_cost:.4f}, Output=${output_cost:.4f})"
        #             )
                
        #         logger.info(data)
        #         self.send_logs(message=data)

        #         # Update Langfuse trace with final output AND token/cost data
        #         try:
        #             if self.langfuse_api and data.get("execution_id"):
        #                 self.langfuse_api.update_trace(
        #                     trace_id=data.get("execution_id"),
        #                     total_tokens=total_tokens,
        #                     prompt_tokens=prompt_tokens,
        #                     completion_tokens=completion_tokens,
        #                     total_cost=total_cost,
        #                     output_data=raw_output
        #                 )
        #                 logger.info(
        #                     f"[Custom Langfuse] Trace updated for {data.get('execution_id')}: "
        #                     f"tokens={total_tokens}, cost=${total_cost:.4f}"
        #                 )
        #         except Exception as e:
        #             logger.warning(f"[Custom Langfuse] Failed to update trace on completion: {e}")
                
        #         # Phase 1: Clean up execution state to prevent memory leaks
        #         execution_id = data.get("execution_id")
        #         if execution_id:
        #             self._cleanup_execution_state(execution_id)
        #     except Exception as e:
        #         logger.error(
        #             f"Unable to Log the stage: {event_type} "
        #             f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        # @crewai_event_bus.on(CrewKickoffFailedEvent)
        # def on_crew_failure(source, event):
        #     try:
        #         _id = str(source.id)
        #         event_type = CrewStages.CREW_ERROR.value
        #         payload = self.metadata_hash.get(_id)
        #         if not payload:
        #             logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
        #         data = self.crew_listeners_meta(_id, payload, event_type)
        #         data.update(
        #             timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
        #             message=  f"[CrewAI Listener] Crew Failed",
        #             error=event.error,
        #             type=event_type
        #         )
        #         logger.info(data)
        #         self.send_logs(message=data)
                
        #         # Phase 1: Clean up execution state on failure to prevent memory leaks
        #         execution_id = data.get("execution_id")
        #         if execution_id:
        #             self._cleanup_execution_state(execution_id)
        #     except Exception as e:
        #         logger.error(
        #             f"Unable to Log the stage: {event_type} "
        #             f"for execution_id: {data.get('execution_id')} as: {str(e)}")

        @crewai_event_bus.on(AgentExecutionStartedEvent)
        def on_agent_start(source, event):
            try:
                event_type = CrewStages.AGENT_INITIALIZED.value
                agent = getattr(event, "agent", None)
                logger.debug(f"agent_id: {getattr(agent, 'id', 'N/A')} | source_id: {source.id}")
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    # Try alternative lookups
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for agent {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.agent_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent started",
                    tools = [tool.name for tool in event.tools],
                    task_prompt = event.task_prompt,
                    user_inputs=payload.user_inputs,
                    agent_goal=payload.agent_details.goal,
                    agent_backstory=payload.agent_details.backstory,
                    agent_llm=payload.agent_details.llm,
                )
                logger.info(data)
                self.send_logs(message=data)
                
                # ==================== LANGFUSE INTEGRATION - START ====================
                # Create agent span in Langfuse with comprehensive data
                try:
                    if payload and self.langfuse_api:
                        # Extract model information
                        llm_config = payload.agent_details.llm
                        model_name = llm_config.get("model", "unknown") if isinstance(llm_config, dict) else "unknown"
                        
                        # Build model parameters
                        model_params = {}
                        if isinstance(llm_config, dict):
                            if "temperature" in llm_config:
                                model_params["temperature"] = llm_config["temperature"]
                            if "max_tokens" in llm_config:
                                model_params["maxTokens"] = llm_config["max_tokens"]
                            if "top_p" in llm_config:
                                model_params["topP"] = llm_config["top_p"]
                        
                        # Use helper method for timezone conversion (Phase 1)
                        agent_start_time = self._to_utc(event.timestamp)
                        logger.info(f"[Custom Langfuse] Converted start_time: {event.timestamp} -> UTC={agent_start_time}")
                        
                        agent_span_info = self.langfuse_api.create_span(
                            trace_id=payload.execution_id,
                            name=f"Agent: {payload.agent_details.name}",
                            span_type="GENERATION",
                            metadata={
                                "agent_id": payload.agent_details.id,
                                "agent_role": payload.agent_details.role,
                                "agent_goal": payload.agent_details.goal,
                                "agent_backstory": payload.agent_details.backstory,
                                "tools": [tool.name for tool in event.tools],
                                "max_iter": payload.agent_details.maxIter,
                                "allow_delegation": payload.agent_details.allowDelegation,
                            },
                            # Use only user inputs for Langfuse input to avoid output bleed-through
                            input_data=payload.user_inputs,
                            model=model_name,
                            model_parameters=model_params if model_params else None,
                            start_time=agent_start_time  # Use properly converted UTC timestamp
                        )
                        
                        if agent_span_info:
                            # Store both span_id and start_time for accurate latency
                            agent_span_info["model"] = model_name
                            self.agent_spans[_id] = agent_span_info
                            logger.info(f"[Custom Langfuse] Created agent span: {agent_span_info['span_id']} (model: {model_name})")
                except Exception as e:
                    logger.error(f"[Custom Langfuse] Failed to create agent span: {str(e)}")
                # ==================== LANGFUSE INTEGRATION - END ====================
                
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(AgentExecutionCompletedEvent)
        def on_agent_completion(source, event):
            try:
                event_type = CrewStages.AGENT_FINISHED.value
                agent = getattr(event, "agent", None)
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for agent {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.agent_listeners_meta(_id, payload, event_type)
                task = getattr(event, "task", None)
                task_name = getattr(task, "name", None)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent finished",
                    output=event.output,
                    task = task_name,
                )
                logger.info(data)
                self.send_logs(message=data)
                
                # ==================== LANGFUSE INTEGRATION - START ====================
                # End agent span with output data AND token/cost tracking
                try:
                    if _id in self.agent_spans and self.langfuse_api:
                        agent_span_info = self.agent_spans[_id]
                        agent_span_id = agent_span_info["span_id"]
                        agent_start_time = agent_span_info["start_time"]
                        
                        # Try to extract token usage from agent/task
                        tokens = 0
                        prompt_tokens = 0
                        completion_tokens = 0
                        cost = 0.0
                        
                        # Check if task has token usage info
                        if task and hasattr(task, 'output') and hasattr(task.output, 'token_usage'):
                            token_data = task.output.token_usage
                            logger.info(f"[Custom Langfuse] Found task token_usage: {token_data}")
                            
                            if isinstance(token_data, dict):
                                tokens = token_data.get('total_tokens', 0)
                                prompt_tokens = token_data.get('prompt_tokens', 0)
                                completion_tokens = token_data.get('completion_tokens', 0)
                            else:
                                tokens = getattr(token_data, 'total_tokens', 0)
                                prompt_tokens = getattr(token_data, 'prompt_tokens', 0)
                                completion_tokens = getattr(token_data, 'completion_tokens', 0)
                            
                            # Calculate cost using model-based pricing
                            if tokens > 0:
                                model_for_cost = agent_span_info.get("model")
                                cost = self.langfuse_api.compute_cost(prompt_tokens, completion_tokens, model_for_cost)
                                logger.info(f"[Custom Langfuse] Agent span tokens: {tokens}, cost (model={model_for_cost}): ${cost:.4f}")
                        
                        # Use Phase 2 helper method for output extraction
                        try:
                            output_text = self._extract_readable_output(event.output)
                            # Ensure we never send empty/None
                            if not output_text or output_text.strip() == "":
                                output_text = "Output not captured"
                            
                            logger.info(f"[Custom Langfuse] Agent output preview: {output_text[:200]}...")
                        except Exception as e:
                            logger.warning(f"[Custom Langfuse] Output extraction failed: {e}")
                            output_text = str(getattr(event, "output", "Output extraction error"))

                        # Use helper method for timezone conversion (Phase 1)
                        agent_end_time = self._to_utc(event.timestamp)
                        logger.info(f"[Custom Langfuse] Converted end_time: {event.timestamp} -> UTC={agent_end_time}")
                        
                        # End the span with output data AND usage WITH accurate timing
                        self.langfuse_api.end_span(
                            span_id=agent_span_id,
                            output_data=output_text,
                            tokens=tokens,
                            prompt_tokens=prompt_tokens,
                            completion_tokens=completion_tokens,
                            cost=cost,
                            model=agent_span_info.get("model"),
                            level="DEFAULT",
                            start_time=agent_start_time,  # Pass start time for accurate latency
                            end_time=agent_end_time  # Use properly converted UTC timestamp
                        )
                        
                        # DON'T delete - keep for crew_creator to update with final tokens
                        # Store token/cost data for Kafka log aggregation
                        logger.info(f"[Custom Langfuse] Ended agent span: {agent_span_id} (keeping in memory for token update)")
                        
                        # Store usage data in span info for Kafka log aggregation
                        try:
                            agent_span_info["usage_recorded"] = tokens > 0
                            agent_span_info["tokens"] = tokens
                            agent_span_info["prompt_tokens"] = prompt_tokens
                            agent_span_info["completion_tokens"] = completion_tokens
                            agent_span_info["cost"] = cost
                            self.agent_spans[_id] = agent_span_info
                            logger.info(
                                f"[Kafka Log] Stored usage data for agent {_id}: "
                                f"tokens={tokens}, prompt={prompt_tokens}, completion={completion_tokens}, "
                                f"cost=${cost:.4f}"
                            )
                        except Exception as e:
                            logger.error(f"[Kafka Log] Failed to store usage data in agent span: {e}")
                except Exception as e:
                    logger.error(f"[Custom Langfuse] Failed to end agent span: {str(e)}")
                # ==================== LANGFUSE INTEGRATION - END ====================

                # ==================== TRULENS INTEGRATION - START ====================
                # TruLens is ONLY for RAG/KB evaluation - skip if no KB context
                try:
                    agent_id = payload.agent_details.id
                    kb_context = self._get_state(payload.execution_id).get(f"kb_context_{agent_id}", None)                    
                    if kb_context and kb_context.strip():
                        logger.info(f"[TruLens] Calling for agent {agent_id} (KB context: {len(kb_context)} chars)")
                        Trulens(
                            _input=task.description, 
                            output=event.output, 
                            kb_context=kb_context,
                            agent_config=payload
                        ).register_record()
                    else:
                        logger.info(f"[TruLens] Skipped agent {agent_id} - no KB context")
                except Exception as e:
                    logger.error(f"[TruLens] Error: {str(e)}", exc_info=True)
                # ==================== TRULENS INTEGRATION - END ====================
                
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        @crewai_event_bus.on(AgentExecutionErrorEvent)
        def on_agent_failure(source, event):
            try:
                event_type = CrewStages.AGENT_ERROR.value
                agent = getattr(event, "agent", None)
                _id = getattr(agent, "id", None) or getattr(source, "id")
                _id = str(_id)
                payload = self.metadata_hash.get(_id)
                if not payload:
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                data = self.agent_listeners_meta(_id, payload, event_type)
                task = getattr(event, "task", None)
                task_name = getattr(task, "name", None)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Agent Failed",
                    error=event.error,
                    task = task_name,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        @crewai_event_bus.on(TaskStartedEvent)
        def on_task_start(source, event):
            try:
                event_type = CrewStages.TASK_START.value
                _id = str(source.id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for task {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Started",
                    context = event.context,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(TaskCompletedEvent)
        def on_task_finish(source, event):
            try:
                event_type = CrewStages.TASK_FINISH.value
                _id = str(source.id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for task {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(_id, payload, event_type)
                
                # ==================== AGGREGATE TOKEN/COST DATA - START ====================
                # Aggregate token and cost data from all agent spans at task completion
                # This provides early visibility into token usage before CREW_FINISHED
                total_tokens = 0
                prompt_tokens = 0
                completion_tokens = 0
                total_cost = 0.0
                
                try:
                    if hasattr(self, 'agent_spans') and self.agent_spans:
                        logger.info(f"[Kafka Log] Aggregating token/cost from {len(self.agent_spans)} spans at TASK_FINISH")
                        
                        for agent_id, span_info in self.agent_spans.items():
                            if isinstance(span_info, dict) and span_info.get('usage_recorded', False):
                                span_tokens = span_info.get('tokens', 0)
                                span_prompt = span_info.get('prompt_tokens', 0)
                                span_completion = span_info.get('completion_tokens', 0)
                                span_cost = span_info.get('cost', 0.0)
                                
                                total_tokens += span_tokens
                                prompt_tokens += span_prompt
                                completion_tokens += span_completion
                                total_cost += span_cost
                        
                        if total_tokens > 0:
                            logger.info(
                                f"[Kafka Log] TASK_FINISH aggregated: tokens={total_tokens}, "
                                f"cost=${total_cost:.4f}"
                            )
                except Exception as e:
                    logger.error(f"[Kafka Log] Failed to aggregate token/cost at TASK_FINISH: {e}")
                
                # Calculate individual costs
                input_cost = (prompt_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
                output_cost = (completion_tokens / total_tokens * total_cost) if total_tokens > 0 else 0.0
                # ==================== AGGREGATE TOKEN/COST DATA - END ====================
                
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Finished",
                    output = event.output.model_dump(), # need surity
                    # Add token and cost summary
                    total_tokens=total_tokens,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_cost=round(total_cost, 4),
                    input_cost=round(input_cost, 4),
                    output_cost=round(output_cost, 4),
                )
                
                # Log summary if we have token data
                if total_tokens > 0:
                    _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                    logger.info(
                        f"[Task Summary] Execution {_exec_id}: "
                        f"Tokens={total_tokens}, Cost=${total_cost:.4f}"
                    )
                
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(TaskFailedEvent)
        def on_task_failure(source, event):
            try:
                event_type = CrewStages.TASK_FAILURE.value
                _id = str(source.id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for task {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Failed",
                    error = event.error,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(TaskEvaluationEvent)
        def on_task_evaluation(source, event):
            try:
                event_type = CrewStages.TASK_EVALUATION.value
                _id = str(source.id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for task {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Task Evaluation",
                    evaluation = event.evaluation,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")



        @crewai_event_bus.on(ToolUsageStartedEvent)
        def on_tool_start(source, event):
            try:
                event_type = CrewStages.TOOL_INITIALIZED.value
                task = getattr(source, "task", None)
                task_id = getattr(task, "id", None)
                task_id = str(task_id) if task_id else None
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                agent_id = str(agent_id) if agent_id else None
                
                # Try task_id first, then agent_id
                _id = task_id or agent_id
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload and _id:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool start {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(task_id, payload, event_type) if task_id else self.agent_listeners_meta(agent_id, payload, event_type)
                if not data:
                    logger.info("[CrewAI Listener] Tool Usage started, No Id could be traced to the attached source or event.")
                    return


                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Tool Usage started and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    run_attempts = event.run_attempts,
                )
                logger.info(data)
                self.send_logs(message=data)
                
                # ==================== LANGFUSE INTEGRATION - START ====================
                # Create tool usage span nested under agent span
                try:
                    if payload and self.langfuse_api and _id in self.agent_spans:
                        agent_span_id = self.agent_spans[_id]
                        
                        # Create unique tool event ID
                        tool_event_id = f"{_id}_{event.tool_name}_{int(event.timestamp.timestamp() * 1000)}"
                        
                        # Get agent span info
                        agent_span_info = self.agent_spans.get(_id)
                        
                        # Create tool span under agent span
                        if agent_span_info:
                            tool_span_info = self.langfuse_api.create_span(
                                trace_id=payload.execution_id,
                                name=f"Tool: {event.tool_name}",
                                span_type="SPAN",
                                parent_span_id=agent_span_info["span_id"],
                                metadata={
                                    "tool_class": event.tool_class,
                                    "run_attempts": event.run_attempts,
                                },
                                input_data=event.tool_args,
                                start_time=event.timestamp  # Use actual event timestamp
                            )
                        else:
                            tool_span_info = None
                            logger.warning(f"[Custom Langfuse] Agent span not found for tool creation: {_id}")
                        
                        if tool_span_info:
                            # Store both span_id and start_time
                            self.tool_spans[tool_event_id] = tool_span_info
                            logger.info(f"[Custom Langfuse] Created tool span: {tool_span_info['span_id']}")
                except Exception as e:
                    logger.error(f"[Custom Langfuse] Failed to create tool span: {str(e)}")
                # ==================== LANGFUSE INTEGRATION - END ====================
                
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        @crewai_event_bus.on(ToolUsageFinishedEvent)
        def on_tool_finish(source, event):
            try:
                event_type = CrewStages.TOOL_FINISHED.value
                task = getattr(source, "task", None)
                task_id = getattr(task, "id", None)
                task_id = str(task_id) if task_id else None
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                agent_id = str(agent_id) if agent_id else None
                
                # Try task_id first, then agent_id
                _id = task_id or agent_id
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload and _id:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool finish {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(task_id, payload, event_type) if task_id else self.agent_listeners_meta(agent_id, payload, event_type)
                if not data:
                    logger.info("[CrewAI Listener] Tool Usage Finished, No Id could be traced to the attached source or event.")
                    return
    

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] Tool Usage Finished and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    run_attempts = event.run_attempts,
                    started_at=event.started_at.strftime("%d-%m-%Y %H:%M:%S"),
                    finished_at=event.finished_at.strftime("%d-%m-%Y %H:%M:%S"),
                    from_cache=event.from_cache,
                    output=event.output,
                )
                logger.info(data)
                self.send_logs(message=data)
                
                # ==================== LANGFUSE INTEGRATION - START ====================
                # End tool usage span with output data
                try:
                    if payload and self.langfuse_api:
                        # Reconstruct the tool event ID to match what was created
                        tool_event_id = f"{_id}_{event.tool_name}_{int(event.started_at.timestamp() * 1000)}"
                        
                        if tool_event_id in self.tool_spans:
                            tool_span_info = self.tool_spans[tool_event_id]
                            tool_span_id = tool_span_info["span_id"]
                            tool_start_time = tool_span_info["start_time"]
                            
                            # End the tool span with output and accurate timing
                            self.langfuse_api.end_span(
                                span_id=tool_span_id,
                                output_data=event.output,
                                level="DEFAULT",
                                start_time=tool_start_time,  # Pass start time for accurate latency
                                end_time=event.finished_at  # Use actual finished timestamp
                            )
                            
                            # Clean up
                            del self.tool_spans[tool_event_id]
                            logger.info(f"[Custom Langfuse] Ended tool span: {tool_span_id}")
                        else:
                            logger.warning(f"[Custom Langfuse] Tool span not found for ID: {tool_event_id}")
                except Exception as e:
                    logger.error(f"[Custom Langfuse] Failed to end tool span: {str(e)}")
                # ==================== LANGFUSE INTEGRATION - END ====================
                
                # ==================== KB CONTEXT EXTRACTION - START ====================
                # Extract KB context from RAG tools for TruLens (per-agent isolation)
                try:
                    is_kb_tool = Trulens._is_kb_tool(event.tool_name, event.tool_class)
                    logger.info(f"[KB Context] Is KB tool: {is_kb_tool}")
                    
                    if payload and is_kb_tool:
                        output_text = self._extract_readable_output(event.output)
                        
                        if output_text and output_text.strip():
                            state = self._get_state(payload.execution_id)
                            agent_id_from_payload = payload.agent_details.id
                            kb_context_key = f"kb_context_{agent_id_from_payload}"
                            
                            if state.get(kb_context_key):
                                state[kb_context_key] += f"\n---\n[{event.tool_name}]\n{output_text}"
                            else:
                                state[kb_context_key] = f"[{event.tool_name}]\n{output_text}"
                            
                            logger.info(f"[KB Context] ✓ {event.tool_name} ({agent_id_from_payload}): {len(output_text)} chars")
                        else:
                            logger.debug(f"[KB Context] Skipped {event.tool_name} - empty output")
                except Exception as e:
                    logger.error(f"[KB Context] Error from {event.tool_name}: {e}")
                # ==================== KB CONTEXT EXTRACTION - END ====================
                
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        @crewai_event_bus.on(ToolUsageErrorEvent)
        def on_tool_usage_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                task = getattr(source, "task", None)
                task_id = getattr(task, "id", None)
                task_id = str(task_id) if task_id else None
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                agent_id = str(agent_id) if agent_id else None
                
                # Try task_id first, then agent_id
                _id = task_id or agent_id
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload and _id:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool error {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(task_id, payload, event_type) if task_id else self.agent_listeners_meta(agent_id, payload, event_type)
                if not data:
                    logger.info("[CrewAI Listener] ToolUsageErrorEvent, No Id could be traced to the attached source or event.")
                    return


                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolUsageErrorEvent and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(ToolValidateInputErrorEvent)
        def on_tool_input_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool input error {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolValidateInputErrorEvent execution_id: {data.get('execution_id')} and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(ToolExecutionErrorEvent)
        def on_tool_execution_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                source_id = getattr(source, "id", None)
                _id = agent_id or source_id
                _id = str(_id)
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool execution error {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.agent_listeners_meta(_id, payload, event_type)

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolExecutionErrorEvent and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(ToolSelectionErrorEvent)
        def on_tool_selection_error(source, event):
            try:
                event_type = CrewStages.TOOL_ERROR.value
                task = getattr(source, "task", None)
                task_id = getattr(task, "id", None)
                task_id = str(task_id) if task_id else None
                agent = getattr(event, "agent", None)
                agent_id = getattr(agent, "id", None)
                agent_id = str(agent_id) if agent_id else None
                
                # Try task_id first, then agent_id
                _id = task_id or agent_id
                
                # CRITICAL FIX: Enhanced metadata lookup with fallback chain
                payload = self.metadata_hash.get(_id)
                if not payload and _id:
                    for key in list(self.metadata_hash.keys()):
                        if _id in str(key) or str(key) in _id:
                            payload = self.metadata_hash.get(key)
                            logger.debug(f"[EventListener] Found metadata via fallback key: {key}")
                            break
                
                if not payload:
                    logger.warning(f"[EventListener] No metadata found for tool selection error {_id}. Available keys: {list(self.metadata_hash.keys())}")
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                    return  # Skip processing if no metadata available
                
                data = self.task_listeners_meta(task_id, payload, event_type) if task_id else self.agent_listeners_meta(agent_id, payload, event_type)
                if not data:
                    logger.info("[CrewAI Listener] Tool Usage started, No Id could be traced to the attached source or event.")
                    return
                

                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] ToolSelectionErrorEvent and agent: {data.get('agent_id')}",
                    tool_name = event.tool_name,
                    tool_class = event.tool_class,
                    tool_args = event.tool_args,
                    error = event.error,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        @crewai_event_bus.on(LLMGuardrailStartedEvent)
        def on_llm_guardrails_start(source, event):
            try:
                event_type = CrewStages.LLM_GUARDRAILS_INITIALIZED.value
                _id = str(source.id)
                payload = self.metadata_hash.get(_id)
                if not payload:
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] LLMGuardrailStartedEvent",
                    guardrail = event.guardrail,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")

        @crewai_event_bus.on(LLMGuardrailCompletedEvent)
        def on_llm_guardrails_finished(source, event):
            try:
                event_type = CrewStages.LLM_GUARDRAILS_FINISHED.value
                _id = str(source.id)
                payload = self.metadata_hash.get(_id)
                if not payload:
                    logger.info(f"[CrewAI Listener] No Id could be traced to the attached source or event: {event_type}")
                data = self.task_listeners_meta(_id, payload, event_type)
                data.update(
                    timestamp=event.timestamp.strftime("%d-%m-%Y %H:%M:%S"),
                    type = event_type,
                    message =  f"[CrewAI Listener] LLMGuardrailCompletedEvent",
                    result = event.result,
                    success = event.success,
                    error = event.error,
                    retry_count = event.retry_count,
                )
                logger.info(data)
                self.send_logs(message=data)
            except Exception as e:
                _exec_id = data.get('execution_id') if isinstance(locals().get('data'), dict) else 'unknown'
                logger.error(
                    f"Unable to Log the stage: {event_type} "
                    f"for execution_id: {_exec_id} as: {str(e)}")


        # @crewai_event_bus.on(LLMCallStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMCallCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMCallFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(LLMStreamChunkEvent)
        # def listener(source, event):
        #     pass


        # @crewai_event_bus.on(MemoryQueryStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryQueryCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryQueryFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveCompletedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemorySaveFailedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryRetrievalStartedEvent)
        # def listener(source, event):
        #     pass

        # @crewai_event_bus.on(MemoryRetrievalCompletedEvent)
        # def listener(source, event):
