"""
LangChain Callback Handler for capturing LLM usage metrics.

This callback intercepts LangChain LLM calls to extract token usage and cost information
for Langfuse tracking. It integrates with the llm_usage module to aggregate metrics.
"""
import logging
from typing import Any, Dict, List, Optional
from langchain.callbacks.base import BaseCallbackHandler
from app.core.llm_usage import record_usage, get_current_execution_id
from app.core.langfuse_api import get_langfuse_api

logger = logging.getLogger(__name__)


class AgentUsageCaptureCallback(BaseCallbackHandler):
    """
    Captures token usage from LangChain LLM calls for Langfuse tracking.
    
    This callback handler intercepts on_llm_end events to extract usage metrics
    from the LLM response and records them for later aggregation.
    """
    
    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        """Called when LLM starts. Log for debugging."""
        execution_id = get_current_execution_id()
        if execution_id:
            logger.debug(f"[UsageCapture] LLM call started for execution {execution_id}")
    
    def on_llm_end(self, response, **kwargs: Any) -> None:
        """
        Called when LLM call ends. Extract and record usage metrics.
        
        Args:
            response: The LLM response object containing usage information
            **kwargs: Additional keyword arguments
        """
        try:
            execution_id = get_current_execution_id()
            if not execution_id:
                logger.debug("[UsageCapture] No execution_id in context, skipping usage capture")
                return
            
            # Extract usage from LLM output
            llm_output = getattr(response, 'llm_output', None) or {}
            if isinstance(llm_output, dict):
                usage = llm_output.get('token_usage', {})
            else:
                usage = {}
            
            if usage:
                # Extract token counts with multiple field name attempts
                prompt_tokens = int(
                    usage.get('prompt_tokens') or 
                    usage.get('promptTokens') or 
                    0
                )
                completion_tokens = int(
                    usage.get('completion_tokens') or 
                    usage.get('completionTokens') or 
                    0
                )
                total_tokens = int(
                    usage.get('total_tokens') or 
                    usage.get('totalTokens') or 
                    (prompt_tokens + completion_tokens)
                )
                
                # Extract model name
                model = llm_output.get('model_name', None)
                
                if total_tokens > 0:
                    # Calculate cost using Langfuse API's pricing
                    try:
                        langfuse_api = get_langfuse_api()
                        cost = langfuse_api.compute_cost(prompt_tokens, completion_tokens, model)
                    except Exception as e:
                        logger.warning(f"[UsageCapture] Failed to compute cost: {e}")
                        cost = 0.0
                    
                    # Record usage for aggregation
                    record_usage(
                        execution_id, 
                        prompt_tokens, 
                        completion_tokens, 
                        total_tokens, 
                        cost, 
                        model,
                        raw=usage
                    )
                    
                    logger.info(
                        f"[UsageCapture] Captured {total_tokens} tokens "
                        f"(prompt={prompt_tokens}, completion={completion_tokens}, "
                        f"cost=${cost:.4f}) for model {model} in execution {execution_id}"
                    )
                else:
                    logger.debug("[UsageCapture] Token usage was 0, not recording")
            else:
                logger.debug("[UsageCapture] No token usage found in LLM response")
        
        except Exception as e:
            # Never let callback errors interrupt the LLM flow
            logger.warning(f"[UsageCapture] Failed to capture usage: {e}")
    
    def on_llm_error(
        self, error: Exception, **kwargs: Any
    ) -> None:
        """Called when LLM encounters an error."""
        logger.debug(f"[UsageCapture] LLM error occurred: {error}")
