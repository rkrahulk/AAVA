import logging
import os
from typing import Any

from crewai_tools import DirectoryReadTool, FileWriterTool
from crewai_tools.tools.scrape_website_tool.scrape_website_tool import ScrapeWebsiteTool
from crewai_tools.tools.serper_dev_tool.serper_dev_tool import SerperDevTool
from fastapi import HTTPException
from pydantic import BaseModel

from app.core.redis_client import redis_client
from app.helpers.db_uri import encode_db_uri
from app.helpers.redis_logs import PipelineAILogs
from app.helpers.tool_ops import add_dynamic_user_tools, create_tool_with_oauth
from app.tools.filereadtool import FileReadTool
from app.tools.knowledgeRagTool import KnowledgeRAGTool
from app.tools.memReadWriteTool import MemoryReaderWriterTool
from app.tools.sqltool import SQLTool
from app.tools.GitHubDocAnalysisTool import GitHubDocAnalysisTool
from app.tools.JiraFetcherRead import JiraFetcherReadTool
from app.tools.JiraFetcherReadV2 import JiraFetcherReadToolV2
from app.tools.JiraConnectorTool import JiraConnectorTool
from app.tools.JiraConnectorToolV2 import JiraConnectorToolV2
from app.tools.GithubWriterToolV2 import GithubWriterToolV2
from app.tools.GithubWriterTool import GithubWriterTool
from app.tools.TestRailConnectorTool import TestRailConnectorTool
from app.tools.GithubReadCloud import GithubReadCloud
from app.tools.GithubWriterCloud import GithubWriteCloud


logger = logging.getLogger(__name__)


class ToolParameter(BaseModel):
    """
    Represents a parameter for a tool, such as an API key or configuration value.
    """

    parameterName: str
    value: str | None = None


class AgentTool(BaseModel):
    """
    Represents a tool to be added to an agent, with its name and parameters.
    """

    toolName: str
    parameters: list[ToolParameter] = []


class UserTool(BaseModel):
    """
    Represents a user-defined tool, including its class name and class definition as a string.
    """

    toolClassName: str
    toolClassDef: str


class AgentEmbedding(BaseModel):
    """
    Placeholder for agent embedding configuration.
    Extend with actual fields as needed for embedding providers/models.
    """



class AgentTask(BaseModel):
    """
    Represents a task assigned to an agent, including its description and expected output.
    """

    description: str
    expectedOutput: str | None = None


class AgentData(BaseModel):
    """
    Aggregates all agent configuration data, including tools, user tools, embedding, and task.
    """

    tools: list[AgentTool]
    userTools: list[UserTool] = []
    embedding: AgentEmbedding | None = None
    task: AgentTask


class AgentToolConfigurator:
    """
    Configures and attaches tools to a CrewAI agent based on the provided agent data.
    Handles built-in, user-defined, and file system tools, and logs tool usage events.
    """

    def __init__(
        self,
        agent_data: AgentData,
        agent_model: Any,
        user_inputs: dict[str, str],
        execution_id: str,
        subfolder_path: str | None = None,
        workflow_id: str | None = None,
        tool_tokens: dict = None, # HP_OBO
        auth_token: str | None = None,
        agent_id: int | None = None
    ):
        self.agent_data = agent_data
        self.agent_model = agent_model
        self.user_inputs = user_inputs
        self.execution_id = execution_id
        self.redis_client = redis_client
        self.subfolder_path = subfolder_path
        self.logger = logger
        self.workflow_id = workflow_id
        self.tool_tokens = tool_tokens or {} # HP_OBO changes
        self.auth_token = auth_token
        self.agent_id = agent_id

    async def _add_scrape_website_tool(self, tool: AgentTool):
        """
        Adds a ScrapeWebsiteTool to the agent if a website_url parameter is provided.
        Logs tool usage and raises an error if the URL is missing.
        """
        scrape_website_tool = None
        for param in tool.parameters:
            if (
                param.parameterName == "website_url"
                and param.value
                and param.value.strip()
            ):
                scrape_website_tool = ScrapeWebsiteTool(website_url=param.value)
                break
        if scrape_website_tool is None:
            raise HTTPException(
                status_code=500,
                detail="Website URL not provided for scrape website tool.",
            )
        logger.info("ScrapeWebsiteTool -------------------- %s", scrape_website_tool)
        self.agent_model.tools.append(scrape_website_tool)


    async def _add_memory_reader_writer_tool(self):
        """
        Adds a MemoryReaderWriterTool to the agent for persistent memory operations.
        """
        logger.info("MemoryReaderWriterTool being added to the agent")
        mem_read_write_tool = MemoryReaderWriterTool(execution_id=self.execution_id, llm_details=self.agent_data.llm)
        self.agent_model.tools.append(mem_read_write_tool)


    async def _add_serper_dev_tool(self, tool: AgentTool):
        """
        Adds a SerperDevTool to the agent, setting the SERPER_API_KEY from parameters.
        Logs tool usage and raises an error if the API key is missing.
        """
        serper_dev_tool = SerperDevTool()
        api_key_provided = False
        for param in tool.parameters:
            if (
                param.parameterName.lower() == "serper_api_key"
                and param.value
                and param.value.strip()
            ):
                os.environ["SERPER_API_KEY"] = param.value
                api_key_provided = True
                break
        if not api_key_provided:
            raise HTTPException(
                status_code=500, detail="Serper API key not provided for SerperDevTool."
            )
        logger.info("SerperDevTool -------------------- %s", serper_dev_tool)
        self.agent_model.tools.append(serper_dev_tool)


    async def _add_file_writer_tool(self):
        """
        Adds a FileWriterTool to the agent for file output operations.
        The base directory is set to a folder named after the execution ID.
        """
        logger.info("FileWriterTool being added to the agent")
        base_dir = os.path.join(os.getcwd(), str(self.execution_id))
        file_writer_tool = FileWriterTool(base_dir=base_dir)
        self.agent_model.tools.append(file_writer_tool)


    async def _add_nl2sql_tool(self, tool: AgentTool): # TODO
        """
        Adds an NL2SQL (SQLTool) to the agent if a db_uri parameter is provided.
        Encodes the DB URI and logs tool usage. Raises an error if missing.
        """
        nl2sql_tool = None
        for param in tool.parameters:
            if param.parameterName == "db_uri" and param.value and param.value.strip():
                encoded_uri = encode_db_uri(param.value)
                nl2sql_tool = SQLTool(db_uri=encoded_uri)
                break
        if nl2sql_tool is None:
            raise HTTPException(
                status_code=500, detail="Database URI not provided for NL2SQL tool."
            )
        self.agent_model.tools.append(nl2sql_tool)


    async def _add_user_defined_tools(self):
        """
        Adds user-defined tools to the agent by dynamically instantiating them from class definitions.
        Logs tool usage for each user tool.
        """
        for tool_data in self.agent_data.userTools:
            logger.debug(
                "user tool class name ------------ %s ", tool_data.toolClassName
            )
            logger.debug("user tool class def ------------ ")
            if tool_data.toolType:
                tool_handlers = {
                    'GitHubDocAnalysisTool': self._add_gitHub_doc_analysis_tool,
                    'JiraFetcherReadTool': self._add_jira_fetcher_read_tool,
                    'JiraFetcherReadToolV2': self._add_jira_fetcher_read_tool_v2,
                    'TestRailConnectorTool': self._add_test_rail_connector_tool,
                    "JiraConnectorTool": self._add_jira_issue_create_tool,
                    "JiraConnectorToolV2": self._add_jira_issue_create_tool_v2,
                    "GithubWriterTool": self._add_github_writer_tool,
                    "GithubWriterToolV2": self._add_github_writer_tool_v2,
                }
                tool_handlers.get(tool_data.toolClassName)(tool_data)
            else:
                tool_instance = add_dynamic_user_tools(
                    tool_data.toolClassName, tool_data.toolClassDef
                )
                logger.debug("user tool instance created")
                self.agent_model.tools.append(tool_instance)
        # try:
        #     from app.services.crew_controller.listeners import log_agent_tool_usage
        #     log_agent_tool_usage(
        #         self.agent_model,
        #         self.agent_data,
        #         self.workflow_id,
        #         self.execution_id,
        #         tool_instance,
        #         input_data=None,
        #         output_data=None
        #     )
        # except Exception:
        #     pass


    async def _add_knowledge_rag_tool(self):
        """
        Adds a KnowledgeRAGTool to the agent if embedding information is present.
        Used for retrieval-augmented generation tasks.
        """
        if self.agent_data.embedding:
            
            task_description_with_user_inputs = self.agent_data.task.description

            # Replace user input placeholders in the task description
            for key, value in self.user_inputs.items():
                task_description_with_user_inputs = task_description_with_user_inputs.replace(
                    key, value
                )

            logger.debug("Agent embedding ------------ %s ", self.agent_data.embedding)
            context_tool = KnowledgeRAGTool(
                input=task_description_with_user_inputs,
                agentEmbedding=self.agent_data.embedding,
                llm_details = self.agent_data.llm,
                kwargs={"redis_client": self.redis_client},
                auth_token=self.auth_token,
                agent_id = self.agent_id)
            self.agent_model.tools.append(context_tool)


    async def _add_gitHub_doc_analysis_tool(self, tool: AgentTool | None = None):
        tool_instance = GitHubDocAnalysisTool(llm_details=self.agent_data.llm, service_account_type=tool.toolType, tool_name=tool.toolName)
        self.agent_model.tools.append(tool_instance)

    async def _add_jira_fetcher_read_tool(self, tool: AgentTool | None = None):
        tool_instance = JiraFetcherReadTool(llm_details=self.agent_data.llm, service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    async def _add_jira_fetcher_read_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = JiraFetcherReadToolV2(llm_details=self.agent_data.llm, service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    async def _add_test_rail_connector_tool(self, tool: AgentTool | None = None):
        tool_instance = TestRailConnectorTool(llm_details=self.agent_data.llm)
        self.agent_model.tools.append(tool_instance)

    async def _add_jira_issue_create_tool(self, tool: AgentTool | None = None):
        tool_instance = JiraConnectorTool(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)

    async def _add_jira_issue_create_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = JiraConnectorToolV2(service_account_type=tool.toolType)
        self.agent_model.tools.append(tool_instance)


    async def _add_github_writer_tool(self, tool: AgentTool | None = None):
        tool_instance = GithubWriterTool(service_account_type=tool.toolType, tool_name=tool.toolName)
        self.agent_model.tools.append(tool_instance)

    async def _add_github_writer_tool_v2(self, tool: AgentTool | None = None):
        tool_instance = GithubWriterToolV2(service_account_type=tool.toolType, tool_name=tool.toolName)
        self.agent_model.tools.append(tool_instance)



    # ====================================================== HP OBO change Begin =================================================================      
    def _setup_cloud_tools_with_obo(self, tools):
        """
        Setup user tools with OBO OAuth token injection.
        Only called when CLIENT_NAME=HP.
        """
        
        access_tokens = self.tool_tokens.get('tokens', {})
        tool_to_provider = self.tool_tokens.get('tool_to_provider', {})
        
        logger.info(
            f"[{self.execution_id}] Available OAuth providers: {list(access_tokens.keys())}"
        )
        
        for _tool in tools:
            # Get provider name for the tool
            provider_name = tool_to_provider.get(_tool.toolId)
            
            if provider_name and provider_name in access_tokens:
                # Tool needs OAuth - inject token and cloudId
                token_info = access_tokens[provider_name]
                access_token = token_info['access_token']
                cloud_id = token_info.get('cloud_id', "")
                
                logger.info(
                    f"[{self.execution_id}] Creating tool '{_tool.toolName}' (toolId={_tool.toolId}) "
                    f"with {provider_name} OAuth (cloudId: {cloud_id})"
                )
                tool_instance = create_tool_with_oauth(
                    class_name=_tool.toolClassName,
                    access_token=access_token,
                    cloud_id=cloud_id,
                    provider_name=provider_name,
                    meta=token_info.get('meta', [])
                )
                self.agent_model.tools.append(tool_instance)
            
            logger.info(f"[{self.execution_id}] Added tool: {_tool.toolName}")

    # ====================================================== HP OBO change End =================================================================      



    def setup_file_tools(self):
        """
        Adds file system tools (DirectoryReadTool, FileReadTool) to the agent if a subfolder path is provided.
        Useful for agents that need to read files or directories.
        """
        if self.subfolder_path:
            try:
                dir_tool = DirectoryReadTool(directory=str(self.subfolder_path))
                self.agent_model.tools.append(dir_tool)
                self.logger.info(
                    f"Added DirectoryReadTool for path: {self.subfolder_path}"
                )

            except Exception as e:
                self.logger.error(
                    f"Failed to initialize DirectoryReadTool for {self.subfolder_path}: {e}"
                )
                # Depending on requirements, this could raise an HTTPException

            file_read_tool = FileReadTool(llm_details = self.agent_data.llm, auth_token=self.auth_token)
            self.agent_model.tools.append(file_read_tool)
            self.logger.info("Added FileReadTool.")

# ====================================================== HP OBO change Begin =================================================================      
    def _setup_cloud_tools_with_obo(self, tools):
        """
        Setup user tools with OBO OAuth token injection.
        Only called when CLIENT_NAME=HP.
        """
        access_tokens = self.tool_tokens.get('tokens', {})
        tool_to_provider = self.tool_tokens.get('tool_to_provider', {})
        
        logger.info(
            f"[{self.execution_id}] Available OAuth providers: {list(access_tokens.keys())}"
        )
        
        for _tool in self.agent_data.tools:
            # Get provider name for the tool
            provider_name = tool_to_provider.get(_tool.toolId)
            
            if provider_name and provider_name in access_tokens:
                # Tool needs OAuth - inject token and cloudId
                token_info = access_tokens[provider_name]
                access_token = token_info['access_token']
                cloud_id = token_info.get('cloud_id')
                
                logger.info(
                    f"[{self.execution_id}] Creating tool '{_tool.toolName}' (toolId={_tool.toolId}) "
                    f"with {provider_name} OAuth (cloudId: {cloud_id})"
                )

                tool_instance = create_tool_with_oauth(
                    class_name=_tool.toolClassName,
                    access_token=access_token,
                    cloud_id=cloud_id,
                    provider_name=provider_name,
                    meta=token_info.get('meta', [])
                )
                self.agent_model.tools.append(tool_instance)
                logger.info(f"[{self.execution_id}] Added tool: {_tool.toolName}")
# ====================================================== HP OBO change End =================================================================      


    async def setup_tools(self):
        """
        Configures and adds all tools to the agent model based on agent_data.
        Handles built-in tools, file system tools, user-defined tools, and knowledge RAG tools.
        """
        tool_handlers = {
            "ScrapeWebsiteTool": self._add_scrape_website_tool,
            "MemoryReaderWriterTool": lambda tool: self._add_memory_reader_writer_tool(),
            "SerperDevTool": self._add_serper_dev_tool,
            "FileWriterTool": lambda tool: self._add_file_writer_tool(),
            "NL2SQLTool": self._add_nl2sql_tool,
            'GitHubDocAnalysisTool': self._add_gitHub_doc_analysis_tool,
            'JiraFetcherReadTool': self._add_jira_fetcher_read_tool,
            'JiraFetcherReadToolV2': self._add_jira_fetcher_read_tool_v2,
            'TestRailConnectorTool': self._add_test_rail_connector_tool,
            "JiraConnectorTool": self._add_jira_issue_create_tool,
            "JiraConnectorToolV2": self._add_jira_issue_create_tool_v2,
            "GithubWriterTool": self._add_github_writer_tool,
            "GithubWriterToolV2": self._add_github_writer_tool_v2,
        }
        cloud_tools = []
        
        for tool_config in self.agent_data.tools:
            if tool_config.toolClassName in ["GithubWriteCloud", "GithubReadCloud"]:
                cloud_tools.append(tool_config)
                continue
    
            handler = tool_handlers.get(tool_config.toolClassName)
            if handler:
                await handler(tool_config)
            else:
                logger.warning(f"No handler defined for tool: {tool_config.toolClassName}")

        if self.subfolder_path:
            self.setup_file_tools()

        if os.getenv("CLIENT_NAME", "NA").lower() == "hp" and self.tool_tokens and cloud_tools:
            self._setup_cloud_tools_with_obo(cloud_tools)
        
        await self._add_user_defined_tools()
        
        await self._add_knowledge_rag_tool()
