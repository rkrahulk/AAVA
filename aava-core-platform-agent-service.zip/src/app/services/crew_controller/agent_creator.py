import os
import copy
import logging
from typing import Any, Dict, Optional

from app.helpers.guardrails import GuardRails
from crewai import Agent, Task
from pydantic import BaseModel
from app.helpers.kb_utils import get_kb_filenames

from app.core.config import settings
from app.core.redis_client import redis_client
from app.helpers.redis_logs import PipelineAILogs
from app.models.agentDetails import AgentDetails
from app.core.decorators import handle_agent_creation_exceptions

from app.services.crew_controller.listeners import log_agent_step
from app.services.crew_controller.setup_agent_tools import AgentToolConfigurator
from app.services.kafka_client import get_kafka_client
from app.services.llm_factory.llmfactory import LLMFactory
from app.tools.image_tool import Imagetool
from fastapi import HTTPException
# from aava.exception.custom.validation_exception import ValidationException
from pydantic import ValidationError
from aava.exception.constants.error_codes import ErrorCodes

# from langfuse.callback import CallbackHandler
from pathlib import Path
logger = logging.getLogger(__name__)


# New Pydantic model for Agent Creator configuration
class AgentCreatorConfig(BaseModel):
    agent_details: AgentDetails  # Details of the agent to be created
    user_inputs: dict[str, str]  # User-provided input values for prompt filling
    enable_memory: bool  # Whether to enable agentic memory
    langfuse_handler: Any | None  # Optional Langfuse callback handler
    execution_id: str  # Unique execution ID for the pipeline run
    subfolder_path: str | None = None  # Optional subfolder for file tools
    workflow_id: int | None = None
    agent_id: int | None = None  # Agent ID for EventListener
    agent_name: str | None = None  # Agent name for EventListener

    model_config = {"arbitrary_types_allowed": True}
    Authorization: str | None = None
    rag_enable: bool | None | None = False  # Whether to enable RAG
    rag_mode: str | None | None = "STRICT"  # RAG mode: STRICT or HYBRID
    nemo_guardrails: bool | None | None = False  # Whether to enable NeMo Guardrails
    has_image: bool = False

    tool_tokens: Optional[Dict] = None #HP_OBO


class AgentCreator:
    """
    Responsible for creating CrewAI agents and tasks, wiring up listeners, and configuring tools.
    """

    def __init__(self, setup_config: AgentCreatorConfig):
        self.config = setup_config
        self.logger = logger
        self.redis_client = redis_client
        self.pipeline_ai_logs = PipelineAILogs()
        self.tool_tokens = getattr(setup_config, 'tool_tokens', {}) # HP_OBO
        self.logger.debug(f"Tool tokens in Agent Creator: {self.tool_tokens}") # HP_OBO

    async def step_callback_closure(self, agent, exec_id, workflow_id):
        # agent_data = agent.model_dump()
        def _step_callback_fun(step: Any):
            """
            Callback for agent step events. Invokes listeners for step finish.
            """
            log_agent_step(
                kafka_client=get_kafka_client(),
                step=step,
                agent=agent,
                execution_id=exec_id,
                workflow_id=workflow_id,
            )

        return _step_callback_fun

    # def task_callback_closure(
    #         self,
    #         agent,
    #         agent_model,
    #         task_details,
    #         exec_id,
    #         workflow_id
    #     ):
    #     def task_completion_callback(output):
    #         """
    #         Callback for task completion.Invokes listeners for task finish.
    #         """
    #         log_task_finish(
    #             kafka_client=kafka_client_,
    #             task_details=task_details,
    #             output=output,
    #             agent=agent,
    #             agent_model=agent_model,
    #             execution_id=exec_id,
    #             workflow_id=workflow_id
    #         )
    #     return task_completion_callback

    @handle_agent_creation_exceptions
    async def create_agent_and_task(self, *args, **kwargs) -> tuple[Agent, Task]:
        """
        Creates a CrewAI agent and its associated task, attaches listeners, and configures tools.

        Returns:
            Tuple[Agent, Task]: The created agent and task objects.
        """
        try:
            agent_data = self.config.agent_details
            user_inputs = self.config.user_inputs
            memory_enabled = self.config.enable_memory # TODO
            exec_id = self.config.execution_id
            subfolder_path = self.config.subfolder_path
            workflow_id = self.config.workflow_id

            # Detect if the task description requires image tool
            has_image = self.config.has_image

            # Build the LLM for the agent using the LLMFactory
            llm = LLMFactory.build_llm(agent_data, exec_id, workflow_id)

            # Prepare arguments for CrewAI Agent instantiation
            agent_args = {
                "role": agent_data.role,
                "goal": agent_data.goal,
                "backstory": agent_data.backstory,
                "llm": llm,
                "function_calling_llm": llm,
                "verbose": False,  # FIX: Disable verbose logging, use EventListener for observability
                "max_iter": 15 if agent_data.maxIter == 0 else agent_data.maxIter,  # FIX: Reduced from 25 to 15 for faster failure detection
                "max_rpm": None if agent_data.maxRpm == 0 else agent_data.maxRpm,
                "max_execution_time": (
                    None
                    if agent_data.maxExecutionTime == 0
                    else agent_data.maxExecutionTime
                ),
                "allow_delegation": False,  # FIX: No crew context, disable delegation overhead
                "memory": memory_enabled,
                "cache": False,
                "allow_code_execution": agent_data.allowCodeExecution,
                "code_execution_mode": (
                    "safe" if agent_data.isSafeCodeExecution else "unsafe"
                ),
                "use_system_prompt": ( # TODO what is system prompt?
                    agent_data.useSystemPrompt
                    if settings.USE_SYSTEM_PROMPT
                    else None
                ),
            }

            # Attach step callback for all agents to enable CrewAI listeners
            step_callback = await self.step_callback_closure(
                agent_data, exec_id, workflow_id
            )  # TODO not able to capture the agent id created by crewAI
            agent_args["step_callback"] = step_callback

            # Instantiate the CrewAI Agent
            agent_model = Agent(**agent_args)

            # Listener: agent initialized
            # from app.services.crew_controller.listeners import log_agent_init
            # log_agent_init(agent_model, agent_data, workflow_id, exec_id)

            # Tool instructions to append to the task description if the tool is present
            TOOL_INSTRUCTIONS = {
                "FileWriterTool": "\n\nYou have access to the file_writer_tool. It is advised to use this tool when you have access to it irrespective of whether it's mentioned above to generate or create files explicitly.",
                "SerperDevTool": "\n\nYou have access to the SerperDevTool for web search. It is advised to use this tool when you have access to it irrespective of whether a web search task has been assigned explicitly.",
                "NL2SQLTool": "\n\nYou have access to the NL2SQLTool. It is advised to use this tool when you have access to it irrespective of whether a SQL task has been assigned explicitly.",
                "ScrapeWebsiteTool": "\n\nYou have access to the ScrapeWebsiteTool. It is advised to use this tool when you have access to it irrespective of whether a scraping task has been assigned explicitly.",
                "MemoryReaderWriterTool": "\n\nYou have access to the MemoryReaderWriterTool. It is advised to use this tool when you have access to it irrespective of whether a memory reading/writing task has been assigned explicitly.",
                "KnowledgeRAGTool": "\n\nYou have access to the KnowledgeRAGTool. It is advised to use this tool when you have access to it irrespective of whether a knowledge retrieval task has been assigned explicitly.",
                "GitHubDocAnalysisTool":"\n\nYou have access to the GitHubDocAnalysisTool. Use this tool when analyzing repositories, documentation, READMEs, or code-related content hosted on GitHub. Prefer this tool for understanding project structure, design decisions, or usage instructions.",
                "GithubReadCloud":"\n\nYou have access to the GithubReadCloud. Use this tool when analyzing repositories, documentation, READMEs, or code-related content hosted on GitHub. Prefer this tool for understanding project structure, design decisions, or usage instructions.",
                "S3MultiOperation":"\n\nYou have access to the S3MultiOperation tool. Use this tool for any interaction with Amazon S3, including reading files, writing content, listing objects under a prefix, deleting files, or generating and uploading content. Do not assume S3 contents without using this tool.",
                "JiraFetcherReadTool":"\n\nYou have access to the JiraFetcherReadTool. Use this tool whenever you need to fetch, inspect, or reference Jira issues, tickets, or metadata. Always retrieve data via this tool instead of guessing issue details.",
                "JiraConnectorTool":"\n\nYou have access to the JiraConnectorTool. Use this tool whenever you need to create a new Jira issue (Bug, Story, Task, etc.) in the configured project. Always use this tool to create issues instead of generating mock ticket IDs or pretending an issue was created. Provide all required fields including summary, description, and issue_type. Use optional fields like priority, assignee, and components when relevant.",
                "TestRailConnectorTool":"\n\nYou have access to the TestRailConnectorTool. Use this tool to fetch test cases from TestRail in read-only mode. Use it when tasks involve test coverage, validation, QA analysis, or understanding existing test cases for a project.",
                "GithubWriterTool": "\n\nYou have access to the GithubWriterTool. Use this tool when you need to create or update files in a GitHub repository by committing changes directly to a specific branch. Prefer this tool when generating code, documentation, configuration files, or automated updates that must be persisted in version control. Always provide the repository name, target branch, commit message, file path, and full file content. Ensure the commit message clearly describes the change, and verify that the branch exists or specify that it should be created if supported.",
                "JiraConnectorToolV2": "\nYou have access to JiraConnectorToolV2 — a powerful tool to perform Jira operations such as creating issues, adding comments, bulk ticket creation, and creating subtasks with structured test scenarios. Use this tool whenever you need to interact with Jira instead of guessing or simulating results. ------------------------ 📌 WHEN TO USE ------------------------ Use this tool when the task involves: - Creating Jira tickets (bugs, tasks, stories, etc.) - Adding comments to existing issues - Creating subtasks (especially with structured test scenarios) - Bulk ticket creation from CSV input - Any write/update operation in Jira ------------------------ 🧠 OPERATION MAPPING (IMPORTANT) ------------------------ You can provide natural language for operation — the tool will normalize it: - \"create issue\", \"open ticket\" → create_issue - \"add comment\", \"comment on issue\" → add_comment - \"create subtask\", \"add test scenarios\" → create_subtask_with_scenarios - \"bulk create\", \"upload csv\" → bulk_create Always choose the correct intent. ------------------------ 📥 REQUIRED INPUTS BY OPERATION ------------------------ 1. CREATE ISSUE - base_domain (required) - project_key (required) - summary (required) - description (optional) - issue_type (optional, default = Task) 2. ADD COMMENT - base_domain (required) - issue_key (required, e.g., PROJ-123) - comment_text (required) 3. CREATE SUBTASK WITH TEST SCENARIOS - base_domain (required) - parent_issue_key (required, must be valid like PROJ-123) - test_scenarios (required) 👉 test_scenarios must be a list of structured dictionaries: Example: [{\"Step\": \"Open login page\", \"Expected\": \"Page loads\"}, {\"Step\": \"Enter credentials\", \"Expected\": \"Login successful\"}] 4. BULK CREATE - base_domain (required) - project_key (required) - csv_file_path (required) CSV must include columns like: - summary - issuetype (optional) ------------------------ ⚠️ IMPORTANT RULES ------------------------ - NEVER invent Jira issue keys or URLs — always rely on tool responses - ALWAYS pass clean, trimmed values (no extra spaces) - ENSURE base_domain starts with http/https and is valid - For issue_key and parent_issue_key, ALWAYS use format: ABC-123 - DO NOT call the tool if required fields are missing — instead ask for clarification ------------------------ 💡 BEST PRACTICES ------------------------ - Prefer structured descriptions over raw text when possible - When creating test scenarios, ensure clarity and readability - Use meaningful summaries (not generic like \"Test issue\") - If bulk creation is requested, ensure CSV path is valid and accessible ------------------------ 🚫 FAILURE HANDLING ------------------------ If the tool returns an error: - Clearly explain the failure - Suggest what input might be wrong - Ask user for correction if needed ------------------------ 🎯 GOAL ------------------------ Always use JiraConnectorToolV2 to perform real Jira operations accurately, safely, and efficiently. Avoid assumptions and ensure all inputs are valid before execution.",
                "GithubWriterToolV2": "\n\nYou have access to the GithubWriterToolV2. Use this tool when you need to create or update files in a GitHub repository by committing changes directly to a specific branch. Prefer this tool when generating code, documentation, configuration files, or automated updates that must be persisted in version control. Always provide the repository name, target branch, commit message, file path, and full file content. Ensure the commit message clearly describes the change, and verify that the branch exists or specify that it should be created if supported.",
                "GithubWriteCloud": "\n\nYou have access to the GithubWriteCloud. Use this tool when you need to create or update files in a GitHub repository by committing changes directly to a specific branch. Prefer this tool when generating code, documentation, configuration files, or automated updates that must be persisted in version control. Always provide the repository name, target branch, commit message, file path, and full file content. Ensure the commit message clearly describes the change, and verify that the branch exists or specify that it should be created if supported.",
                "JiraFetcherReadToolV2":"\n\nYou can use the JiraFetcherReadToolV2 to safely read Jira data including tickets, issue details, descriptions, acceptance criteria (what_to_do), comments, attachments, and change history. Use this tool whenever the user asks about tasks, issues, tickets, work items, project data, specific task IDs (like ABC-1), history/changes, or downloading/viewing files. Supported functionalities include: fetching latest tasks from a project, extracting full task details (title, description, comments, files), retrieving change history of a task, and downloading attachments by file ID. Always use this tool to get real Jira data and never guess or fabricate details. The user may give simple or messy natural language (e.g., 'show my tasks', 'abc work', 'what changed in ABC-1', 'download file 123'), so interpret intent and pass it as the operation input without needing strict formats or underscores. The tool automatically detects project keys, task IDs, and attachment IDs from the input. Keep inputs natural, simple, and user-friendly."
            }

            # Append tool instructions to the task description if the tool is present
            # Append KB filenames if available
            code_conversion_task_desc = ""
            if hasattr(agent_data, 'embedding') and agent_data.embedding:
                filenames = get_kb_filenames(agent_data.embedding)

                code_conversion_task_desc+=(
                    "MANDATORY TOOL USAGE:\nYou MUST call the knowledge RAG tool with the user's question\n"
                    "DO NOT attempt to answer without calling the tool first\n"
                    "DO NOT generate synthetic or assumed information\n"
                    "Tool calling is REQUIRED - no exceptions./n"
                )

                if filenames:
                    code_conversion_task_desc += f"From Source {', '.join(sorted(filenames))}"

            # Append uploaded filenames
            if subfolder_path and os.path.exists(subfolder_path):
                uploaded_files = []
                for root, dirs, files in os.walk(subfolder_path):
                    for file in files:
                        uploaded_files.append(file)
                
                if uploaded_files:
                    uploaded_files = sorted(list(set(uploaded_files)))  # Remove duplicates
                    code_conversion_task_desc += (
                        "MANDATORY TOOL USAGE:\n"
                        "You MUST call the DirectoryRead and FileReadTool with the user's question\n"
                        "DO NOT attempt to answer without calling the tool\n"
                        "DO NOT generate synthetic or assumed information\n"
                        "Tool calling is REQUIRED - no exceptions./n"
                    )
                    code_conversion_task_desc += "\n".join(f"  - {f}" for f in uploaded_files)
    

            code_conversion_task_desc += agent_data.task.description
            
            tool_names = [tool.toolClassName for tool in agent_data.tools]
            tool_names += [user_tool.toolClassName for user_tool in agent_data.userTools if user_tool.toolType]

            if "FileWriterTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["FileWriterTool"]
            if "SerperDevTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["SerperDevTool"]
            if "NL2SQLTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["NL2SQLTool"]
            if "ScrapeWebsiteTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["ScrapeWebsiteTool"]
            if "MemoryReaderWriterTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["MemoryReaderWriterTool"]
            if "GitHubDocAnalysisTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["GitHubDocAnalysisTool"]
            if "JiraFetcherReadTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["JiraFetcherReadTool"]
            if "JiraFetcherReadToolV2" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["JiraFetcherReadToolV2"]
            if "TestRailConnectorTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["TestRailConnectorTool"]
            if "JiraConnectorTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["JiraConnectorTool"]
            if "JiraConnectorToolV2" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["JiraConnectorToolV2"]
            if "GithubWriterTool" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["GithubWriterTool"]
            if "GithubWriterToolV2" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["GithubWriterToolV2"]
            if "GithubReadCloud" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["GithubReadCloud"]
            if "GithubWriteCloud" in tool_names:
                code_conversion_task_desc += TOOL_INSTRUCTIONS["GithubWriteCloud"]



            # Replace user input placeholders in the task description
            for key, value in user_inputs.items():
                code_conversion_task_desc = code_conversion_task_desc.replace(
                    key, value
                )

            # task_completion_callback = self.task_callback_closure(
            #     agent_data,
            #     agent_model,
            #     code_conversion_task_desc,
            #     exec_id,
            #     workflow_id
            # )

            # Validation of System Guardrail
            if settings.to_bool("SYSTEM_GUARDRAILS_ENABLED"):
                guardrails_instance = GuardRails(
                    Authorization=self.config.Authorization,
                    request_payload=agent_data.model_dump(),
                    _type="agent_run",
                )
                is_validation_success, validation_result = guardrails_instance.system_validation(code_conversion_task_desc)
                if not is_validation_success:
                    return None, None, validation_result

            validator = None
            guardrails_failed_message = None

            if agent_data.nemo_guardrails:
                validator = GuardRails(
                    Authorization=self.config.Authorization, 
                    request_payload=agent_data.model_dump(),
                    _type="agent_run"
                ).validation_closure()

                try:
                    # validator(self.config.user_inputs)
                    guardrails_result = validator(code_conversion_task_desc)
                    print(f"guardrails result is = {guardrails_result}")

                    if not guardrails_result[0]:
                        guardrails_failed_message = guardrails_result[1]
                        return None, None, guardrails_failed_message
                except Exception as e:
                    logger.error(f"Failed user input validation as: {str(e)}, user_input: {self.config.user_inputs}")

            # Create the CrewAI Task
            task = Task(
                name = agent_data.name,
                description=code_conversion_task_desc,
                expected_output=agent_data.task.expectedOutput,
                agent=agent_model,
                # callback=task_completion_callback,
                guardrail=validator,
                max_retries=0,  # FIX: Disable task-level retries for fail-fast, handle at service level
                async_execution=False,
            )
            # Listener: task start
            # from app.services.crew_controller.listeners import log_task_start
            # log_task_start(task, agent_model, agent_data, workflow_id, exec_id)

            # Add Imagetool if the task requires image processing
            if has_image and 'gpt-5'not in str(agent_model.llm.model).lower():
                agent_model.tools.append(Imagetool(llm=llm))

            # Configure and add tools to the agent
            if 'gpt-5' not in str(agent_model.llm.model).lower():
                tool_configurator = AgentToolConfigurator(
                    agent_data=agent_data,
                    agent_model=agent_model,
                    auth_token=self.config.Authorization,
                    user_inputs=user_inputs,
                    execution_id=exec_id,
                    subfolder_path=subfolder_path if subfolder_path else None,
                    workflow_id=workflow_id,
                    agent_id=self.config.agent_details.id,
                    tool_tokens=self.tool_tokens #HP_OBO
                )
                await tool_configurator.setup_tools()
            else:
                agent_model.tools = []  

            mcp_tools = kwargs.get('mcp_tools')
            if mcp_tools:
                agent_mcp_tools = getattr(agent_data, "mcp_tools", None)
                if agent_mcp_tools:
                    try:
                        available_mcp_tools = {tool.name:tool for tool in mcp_tools}
                        agent_model.tools.extend([available_mcp_tools[tool] for tool in agent_mcp_tools])
                    except Exception as e:
                            logger.warning(
                                f"Unable to FIlter and add MCP tools: for agent: "
                                f"{agent_data.id} execution id: {self.config.execution_id} as {str(e)}"
                                f"going forward without filtering"
                            )
                else:
                    agent_model.tools.extend(mcp_tools)

            return agent_model, task, guardrails_failed_message
        except ValidationError as e:
            raise HTTPException(
                status_code=401,
                detail=f"{str(e)}"
            )
        except Exception as e:
            exception = e.__class__(str(e))
            exception.agent = self.config.agent_details
            exception.execution_id = self.config.execution_id
            exception.workflow_id = self.config.workflow_id
            raise exception from e
