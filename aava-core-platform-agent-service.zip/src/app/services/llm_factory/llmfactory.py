import logging
import os
import re

import boto3
from botocore.exceptions import NoCredentialsError

from app.modified_library.LLM import CustomAzureLLM, CustomBedrockLLM
from crewai import LLM
from fastapi import HTTPException

from app.core.config import settings

logger = logging.getLogger(__name__)

USE_BEDROCK_CREDENTIALS = settings.USE_BEDROCK_CREDENTIALS


def _assume_role_credentials(role_arn: str, region: str, session_name: str = "aava-bedrock-llm"):
    """
    Assume an AWS role and return temporary credentials for Bedrock access.
    Used when USE_BEDROCK_CREDENTIALS is false (IRSA/web-identity or instance profile).
    """
    try:
        # Avoid profile interference in containers
        if "AWS_PROFILE" in os.environ:
            os.environ.pop("AWS_PROFILE", None)

        session = boto3.Session(profile_name=None, region_name=region)
        logger.info("Assuming role %s in region %s", role_arn, region)

        sts = session.client("sts")
        identity = sts.get_caller_identity()
        logger.info(
            "Caller Identity - Account: %s, ARN: %s, UserId: %s",
            identity.get("Account"),
            identity.get("Arn"),
            identity.get("UserId"),
        )

        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName=session_name,
            DurationSeconds=3600,
        )
        logger.info("Successfully assumed role %s", role_arn)
        return response["Credentials"]
    except NoCredentialsError as e:
        logger.error("No AWS credentials available to assume role: %s", str(e))
        raise
    except Exception as e:
        logger.error("Error assuming role for Bedrock access: %s", str(e))
        raise


class LLMFactory:
    """
    Factory class for building LLM (Large Language Model) objects from configuration data.
    Supports Azure OpenAI, Amazon Bedrock, and Google Vertex AI providers.
    Handles validation, error reporting, and listener integration for LLM configuration events.
    """

    @staticmethod
    def build_llm(agentDetails, execution_id=None, workflow_id=None):
        """
        Validates the llm_config_data and builds an LLM object for the specified provider.

        Args:
            llm_config_data (AgentLLM): The agent's LLM configuration (Pydantic model).
            langfuse_cfg (dict, optional): Optional metadata for Langfuse callbacks.

        Returns:
            LLM: Instantiated LLM object.

        Raises:
            HTTPException: If validation fails or the provider is unsupported.
        """
        try:
            llm_config_data = agentDetails.llm
            if agentDetails.modelDetails.get("aiEngine") == "AmazonBedrock":
                
                if "sonnet-4-6" in llm_config_data.get("model"):
                    llm_config_data.pop("top_p", "")
                    llm_config_data.pop("temperature", "")
                    llm_config_data["drop_params"] = True

                logger.info("build_llm called with execution_id=%s workflow_id=%s", execution_id, workflow_id)
                logger.info("USE_BEDROCK_CREDENTIALS=%s", USE_BEDROCK_CREDENTIALS)
                logger.info("llm_config_data (raw)=%s", llm_config_data)

                aws_keys = ["aws_access_key_id", "aws_secret_access_key", "aws_session_token"]
                if not USE_BEDROCK_CREDENTIALS:
                    logger.info("USE_BEDROCK_CREDENTIALS is false: attempting assume-role path for Bedrock")
                    role_arn = settings.AAVA_ASSUME_ROLE_ARN_PLATFORM_AGENT
                    region = llm_config_data.get("aws_region_name") or settings.AWS_REGION
                    logger.info("Assume-role inputs role_arn=%s region=%s", role_arn, region)
                    creds = _assume_role_credentials(
                        role_arn=role_arn,
                        region=region,
                        session_name="aava-bedrock-llm",
                    )
                    logger.info("Assume-role success: AccessKeyId=%s SessionToken_present=%s", creds.get("AccessKeyId"),
                                "SessionToken" in creds)
                    llm_config_data["aws_access_key_id"] = creds["AccessKeyId"]
                    llm_config_data["aws_secret_access_key"] = creds["SecretAccessKey"]
                    llm_config_data["aws_session_token"] = creds["SessionToken"]
                else:
                    logger.info("USE_BEDROCK_CREDENTIALS is true: using provided credentials in llm_config_data")
                    logger.info(
                        "Provided credential keys: has_access_key=%s has_secret_key=%s has_session_token=%s",
                        bool(llm_config_data.get("aws_access_key_id")),
                        bool(llm_config_data.get("aws_secret_access_key")),
                        bool(llm_config_data.get("aws_session_token")),
                    )

                llm_config_data["timeout"] = int(settings.REQUEST_TIMEOUT)
                logger.info("Final llm_config_data before LLM init: provider=%s model=%s region=%s timeout=%s",
                            llm_config_data.get("provider"), llm_config_data.get("model"),
                            llm_config_data.get("aws_region_name"), llm_config_data.get("timeout"))


            # GPT-5 family models use `max_completion_tokens` instead of `max_tokens`.
            # Detect all current/future GPT-5 variants (e.g. gpt-5.1, gpt-5.3-codex, gpt-5.4-pro)
            # and automatically remap the parameter for compatibility with OpenAI Responses API.
            # `additional_drop_params` ensures LiteLLM/CrewAI does not forward the deprecated
            # `max_tokens` parameter alongside `max_completion_tokens`, which can cause
            # provider validation errors for GPT-5 models.
            model = llm_config_data.get("model", "").lower()
            is_gpt5_family = "gpt-5" in model.lower()
            
            # Models that require the Azure Responses API
            uses_responses_api = model.lower() in settings.MODELS_USES_OPENAI_RESPONSE_API.lower() if settings.MODELS_USES_OPENAI_RESPONSE_API else False 
            
            if (
                is_gpt5_family
                and not uses_responses_api
                and "max_tokens" in llm_config_data
            ):
                llm_config_data["max_completion_tokens"] = llm_config_data["max_tokens"]
                logger.info("[LLMFactory] Added max_completion_tokens")
                if "additional_drop_params" not in llm_config_data:
                    llm_config_data["additional_drop_params"] = []

                if "max_tokens" not in llm_config_data["additional_drop_params"]:
                    llm_config_data["additional_drop_params"].append("max_tokens")

                llm_config_data.pop("max_tokens", "")


            # Select the appropriate LLM class

            llm_class = LLM 
            if uses_responses_api:
                llm_class = CustomAzureLLM
            elif "4-6" in model:
                llm_class = CustomBedrockLLM

            # Increase timeout only for Responses API models, while preserving any higher
            # timeout that may already be configured elsewhere.
            if uses_responses_api:
                llm_config_data["timeout"] = max(
                    int(llm_config_data.get("timeout", 60)),
                    120
                )

            return llm_class(**llm_config_data)

        except ValueError as e:  # Catches Pydantic validation errors
            logger.error(f"LLM Configuration Error: {e}. Data: {llm_config_data}")
            try:
                from app.services.crew_controller.listeners import log_llm_config_error

                log_llm_config_error(
                    llm_config_data, None, str(e), execution_id, workflow_id
                )
            except Exception as listener_exc:
                logger.warning(f"Failed to call log_llm_config_error: {listener_exc}")
            raise HTTPException(
                status_code=400, detail=f"Invalid LLM configuration: {e}"
            )

