from datetime import datetime
import errno
import io
import json
import logging
import os
import re
import shutil
import stat
import time
import gc
import weakref
from contextlib import suppress
from typing import Any, Optional
from app.helpers.kb_utils import get_kb_details
from crewai_tools import FileWriterTool, MCPServerAdapter
from fastapi import UploadFile
from app.core.langfuse_api import get_langfuse_api
from app.core.llm_usage import set_current_execution_id, get_aggregated_usage, clear_usage
from crewai.tasks.task_output import TaskOutput
from app.core.config import settings
from app.core.secret_manager import secret_manager
from app.helpers import agent_image_utils
from app.helpers.agent_helpers import AgentPayload
from app.helpers.payload_converter import convert_payload
from app.helpers.redis_logs import PipelineAILogs
from app.helpers.agent_execution_history import save_final_execution_history, send_execution_status
from app.models.agent import Agent
from app.models.agentDetails import AgentDetails
from app.models.AgentModel import AgentModel
from app.models.AgentRequest import AgentRequest
from app.services import event_listener
from app.services.crew_controller.agent_creator import AgentCreator, AgentCreatorConfig
from aava.exception.custom.validation_exception import ValidationException
from aava.exception.custom.business_exception import BusinessException
from aava.exception.custom.system_exception import SystemException
from aava.exception.custom.data_not_found_exception import DataNotFoundException
import zipfile
from pydantic import ValidationError
from aava.exception.constants.error_codes import ErrorCodes
from app.tools.filereadtool import FileReadTool
from app.tools.knowledgeRagTool import KnowledgeRAGTool
from app.tools.image_tool import Imagetool

logger = logging.getLogger(__name__)


class AgentExecutionError(Exception):
    """Custom exception for agent execution errors."""

    def __init__(self, detail: str, status_code: int = 500):
        self.status_code = status_code
        self.detail = detail
        super().__init__(self.detail)


class AgentExecutor:
    """
    Manages the execution flow of a agent request.

    Encapsulates setup, payload preparation, core execution logic,
    response processing, and cleanup steps.
    """

    def __init__(
        self,
        Authorization: str,
        agent_request: AgentRequest,
        files: list[UploadFile] | None = None,
    ):
        self.Authorization: str = Authorization
        self.agent_request: AgentRequest = agent_request
        self.temporary_images: list[str] | None = None
        self.files: list[UploadFile] = files
        self.payload_object: AgentModel = None
        self.unzipped_files_path: str = None
        self.contains_image: bool = False
        self.tool_tokens: Optional[dict] = {}


    def try_parse_json(self,mixed_str):
        """
        Attempts to extract JSON from a string that may contain extra text.
        Returns a dict if successful, otherwise returns original string.
        """
        try:
            match = re.search(r'\{.*\}', mixed_str, re.DOTALL)
            if match:
                json_str = match.group(0)
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    return mixed_str  
            return mixed_str
        except Exception as e:
            logging.warning("Failed to parse output string to JSON: %s", e)


    def remove_readonly(self, func, path, exc):
        excvalue = exc[1]
        if func in (os.rmdir, os.remove) and excvalue.errno == errno.EACCES:

            # ensure parent directory is writeable too
            pardir = os.path.abspath(os.path.join(path, os.path.pardir))
            if not os.access(pardir, os.W_OK):
                os.chmod(pardir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

            os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 0777
            func(path)
        else:
            raise

    def _cleanup(self):
        """Cleans up resources like temporary images and temp directories."""
        from app.helpers.temp_file_manager import temp_file_manager
        if self.temporary_images:
            try:
                agent_image_utils.clean_up_images(self.temporary_images)
                logger.debug("Temporary image cleanup successful.")
                self.temporary_images = None  # Clear the list after cleanup
            except Exception as e:
                # Log error but don't raise, cleanup failure might not be critical
                logger.error(f"Error during temporary image cleanup: {e}")

        # Use TempFileManager for secure cleanup
        try:
            execution_temp_prefix = f"aava_{self.agent_request.executionId}_"
            stats = temp_file_manager.get_stats()
            if stats['total_items'] > 0:
                logger.info(f"TempFileManager cleanup - tracked items: {stats}")
            # Automatic cleanup will happen via atexit, but we can also call explicitly
        except Exception as e:
            logger.error(f"Error during temp file manager cleanup: {e}")


    def _prepare_trace_metadata(self):
        """Prepare metadata for Langfuse tracing."""
        return {
            "agent_id": getattr(self.payload_object.agent, "id", ""),
            "user_inputs":self.payload_object.userInputs,
            "execution_id": self.payload_object.executionId,
            "user": self.payload_object.user,
            "enable_memory": self.payload_object.enableAgenticMemory,
            # "subfolder_path": self.subfolder_path,
            "agent_count": 1,
            "has_manager_llm": bool(self.payload_object.managerLlm),
        }

    
    async def process_image(self):
        # Process images and update userInputs directly on the request object
        self.temporary_images, updated_user_inputs = (
            agent_image_utils.save_temp_images_with_rewrite_inputs(
                self.agent_request.userInputs
            )
        )
        self.agent_request.userInputs = updated_user_inputs
 

    async def prepare_payload(self):
        try:
            # ================= FETCH AGENT =================
            if self.agent_request.agent:
                agent_json = self.agent_request.agent
            else:
                agent_details_fetcher = AgentPayload(
                    self.agent_request.agentId,
                    self.Authorization,
                )
                agent_json = agent_details_fetcher.fetch()

            logger.info("Agent payload fetched")

            # ================= CREATE AGENT MODEL =================
            agent_data = agent_json["agent"] if "agent" in agent_json else agent_json
            agent = AgentDetails(**agent_data)

            self.payload_object = AgentModel(
                id=agent.id,
                agent=agent,
                userInputs=self.agent_request.userInputs,
                executionId=self.agent_request.executionId,
                user=self.agent_request.user,
                name=agent.name,
            )

            # Update shared secret manager
            secret_manager.Authorization = self.Authorization

            # ==================== HP OBO BLOCK ====================
            client_name = os.getenv("CLIENT_NAME", "NA").lower()
            obo_enabled = os.getenv("OBO_ENABLED", "false").lower() == "true"

            if client_name == "hp" and obo_enabled:
                logger.info("HP client detected - checking for user tools")

                cloud_tools = []

                for _tool in agent_json.get("tools", []):
                    # if _tool.get("toolType", "").lower().strip() in ["cloud"]:
                    if _tool.get("toolClassName") in ["GithubReadCloud", "GithubWriteCloud"]:
                        cloud_tools.append(_tool)

                if cloud_tools:
                    try:
                        from app.helpers.hp_obo_tool_handler import (
                            validate_consents_and_fetch_tokens_sync,
                            ConsentMissingException,
                            ReAuthenticationRequiredException,
                            OAuthServiceException,
                            ProviderNotFoundException
                        )

                        self.tool_tokens = validate_consents_and_fetch_tokens_sync(
                            cloud_tools=cloud_tools,
                            authorization=self.Authorization,
                            execution_id=self.agent_request.executionId
                        )

                        logger.info(
                            f"Fetched tokens for providers: {list(self.tool_tokens.get('tokens', {}).keys())}"
                        )

                    except ProviderNotFoundException as e:
                        raise AgentExecutionError(
                            status_code=404,
                            detail={
                                "error_type": "PROVIDER_NOT_FOUND",
                                "message": str(e),
                                "execution_id": self.agent_request.executionId
                            }
                        )

                    except ConsentMissingException as e:
                        raise AgentExecutionError(
                            status_code=403,
                            detail={
                                "error_type": "CONSENT_REQUIRED",
                                "message": str(e),
                                "missing_consents": e.missing_providers,
                                "execution_id": self.agent_request.executionId
                            }
                        )

                    except ReAuthenticationRequiredException as e:
                        raise AgentExecutionError(
                            status_code=401,
                            detail={
                                "error_type": "REAUTH_REQUIRED",
                                "message": str(e),
                                "expired_providers": e.expired_providers,
                                "execution_id": self.agent_request.executionId
                            }
                        )

                    except OAuthServiceException as e:
                        raise AgentExecutionError(
                            status_code=500,
                            detail={
                                "error_type": "OAUTH_SERVICE_ERROR",
                                "message": str(e),
                                "step": e.step,
                                "execution_id": self.agent_request.executionId
                            }
                        )

            # ==================== END HP OBO ====================

            logger.info(
                f"Payload object created for execution: {self.payload_object.executionId}"
            )

        except ValidationError as e:
            raise ValidationException(
                error_code=ErrorCodes.VALIDATION_ERROR,
                message=str(e)
            )

        except Exception as e:
            logger.error(f"Error preparing agent payload: {e}")
            self._cleanup()
            raise AgentExecutionError(
                status_code=getattr(e, "status_code", 500),
                detail=getattr(e, "detail", str(e))
            )


    async def prepare_and_unzip_files(self, files: list[UploadFile]) -> str: # TODO to be changed with Azure blob
        """
        Creates a temporary subfolder and unzips uploaded files into it.
        Returns the path to the created subfolder.
        """
        from app.helpers.temp_file_manager import temp_file_manager
        try:
            logger.info("Current Directory: %s", os.getcwd())
            # Use TempFileManager for secure temp directory creation (0700 permissions)
            subfolder_path = temp_file_manager.create_temp_dir(
                prefix=f"aava_{self.agent_request.executionId}_"
            )
            logger.info("Created secure temp directory: %s", subfolder_path)

            zip_files = [file for file in files if file.filename.endswith(".zip")]
            
            if not zip_files:
                raise ValidationException("Zip file not found, please upload a valid zip file")

            for file_in_list in zip_files:
                logger.info(f"Unzipping file: {file_in_list.filename}")
                zip_bytes = await file_in_list.read()
                zip_folder_name = f"{os.path.splitext(file_in_list.filename)[0]}"
                zip_subfolder_path = os.path.join(subfolder_path, zip_folder_name)
                os.makedirs(zip_subfolder_path, exist_ok=True)

                with zipfile.ZipFile(
                    io.BytesIO(zip_bytes), "r"
                ) as zip_ref:
                    for file_info in zip_ref.infolist():
                        filename = file_info.filename
                        if not filename.startswith(".") and "__MACOSX" not in filename:
                            if not self.contains_image and agent_image_utils.is_image_file(filename):
                                self.contains_image = True
                            zip_ref.extract(file_info, zip_subfolder_path)
                            logger.info(
                                f"Extracted: {filename} to {zip_subfolder_path}"
                            )
                        else:
                            logger.info(f"Skipped hidden/system file: {filename}")
            self.unzipped_files_path = subfolder_path
            return subfolder_path
        except Exception as e:
            logger.error(f"Error preparing and unzipping: {e}")
            
            raise e.__class__(" - " + "file prepare unzip error " + str(e)) from e

    
    async def _get_kb_context(self):

        agent_data = self.payload_object.agent
        agent_detail = agent_data
        context_data = {}
        if hasattr(agent_detail, 'embedding') and agent_detail.embedding:
            context_data = get_kb_details(agent_detail.embedding)

        return context_data


    async def process_response(self, Agent_response: tuple[Any, Any]) -> dict[str, Any]:
        """Processes the agent response and formats the final output."""
        try:
            response_data, file_id = Agent_response

            self.payload_object.tasksOutputs = response_data if response_data else None
            self.payload_object.output = getattr(response_data, "raw", str(response_data))

            final_response_payload = self.payload_object.model_dump()

            if file_id and file_id != "Not applicable":
                final_response_payload["file_download_url"] = f"{settings.BASE_API_URL}/{settings.ADMIN_DOWNLOAD_API_URL}/{file_id}" # TODO

            final_response_payload['context'] = await self._get_kb_context()

            output_str = final_response_payload.get("output", "")
            final_response_payload["output"] = self.try_parse_json(output_str)

            tasks = final_response_payload.get("tasksOutputs", {})

            if isinstance(tasks, str):
                logger.warning("Guardrails returned string output; normalizing tasksOutputs.")
                final_response_payload["tasksOutputs"] = {"raw": tasks}
                raw_str = tasks
            else:
                raw_str = tasks.get("raw")

            if raw_str:
                final_response_payload["tasksOutputs"]["raw"] = self.try_parse_json(raw_str)                   

            logger.debug(f"Final response payload prepared for execution: {self.agent_request.executionId}")

            return {"agent": final_response_payload}

        except Exception as e:
            logger.error(f"Error processing agent response: {e}")
            raise e.__class__(" - " + "response processing error " + str(e)) from e

    # async def file_uploader(self, folder_path):
    #     pipelineId = await self.get_pipelineId()
    #     file_id = zip_and_upload_folder(
    #         pipelineId=pipelineId,
    #         executionId=self.payload_object.executionId,
    #         user=self.payload_object.user,
    #         folder_path=folder_path,
    #         Authorization=self.Authorization
    #     )
    #     return file_id

    async def execute_task(self, unzipped_files_path=None, **kwargs):
        try:
            # Set execution context BEFORE creating agent/task so LiteLLM callbacks can capture usage
            trace_id = self.payload_object.executionId if self.payload_object else None
            if trace_id:
                try:
                    from app.core.llm_usage import set_current_execution_id as _set_exec
                    _set_exec(trace_id)
                    logger.info(f"[COST_DEBUG][agent] Set execution context early: {trace_id}")
                except Exception as e:
                    logger.warning(f"[COST_DEBUG][agent] Failed to set execution context early: {e}")
                    set_current_execution_id(trace_id)

            agent_data = self.payload_object.agent

            creator_config = AgentCreatorConfig(
                agent_details=agent_data,
                user_inputs=self.payload_object.userInputs,
                enable_memory=self.payload_object.enableAgenticMemory,
                langfuse_handler=None,  # Disable SDK integration to avoid duplicate traces
                execution_id=self.payload_object.executionId,
                subfolder_path=unzipped_files_path,
                Authorization=self.Authorization,
                nemo_guardrails=self.payload_object.nemo_guardrails,
                rag_enable=self.payload_object.rag_enable,
                rag_mode=self.payload_object.rag_mode,
                has_image=self.temporary_images is not None or self.contains_image,
                tool_tokens=self.tool_tokens
            )
            
            # Initialize custom Langfuse API handler if enabled
            custom_api = get_langfuse_api() if settings.CUSTOM_LANGFUSE_ENABLED else None
            trace_id = self.payload_object.executionId if self.payload_object else None
            agent_name = getattr(agent_data, "name", None) or getattr(agent_data, "role", "Agent")
            
            # Create simple trace without extra spans (single agent execution, not crew)
            if custom_api and trace_id:
                try:
                    # Create the main trace only - EventListener will handle agent/task/tool spans
                    custom_api.create_trace(
                        agent_name=agent_name,
                        execution_id=trace_id,
                        input_data=self.payload_object.userInputs,
                        metadata={**self._prepare_trace_metadata()},
                        user_id=self.payload_object.user,
                        tags=["agent", "crewai"],
                        public=False,
                    )
                    logger.info(f"[Custom Langfuse][agent] Created trace for single agent: {agent_name}")
                except Exception as e:
                    logger.warning(f"[Custom Langfuse][agent] Failed to init trace: {e}")
            
            # Remove unnecessary span creation - let EventListener handle hierarchy
            custom_agent_creation_span = None
            root_span_id = f"{trace_id}_root" if trace_id else None

            agent_creator = AgentCreator(setup_config=creator_config)
            agent, task, guardrails_failed_message = await agent_creator.create_agent_and_task(**kwargs)
            
            # Close agent-creation span
            if custom_api and custom_agent_creation_span:
                try:
                    custom_api.end_span(
                        span_id=custom_agent_creation_span["span_id"],
                        output_data={
                            "agent_created": True,
                            "tools_count": len(getattr(agent, "tools", [])),
                            "tools": [tool.name for tool in getattr(agent, "tools", [])],
                        },
                        start_time=custom_agent_creation_span["start_time"],
                    )
                except Exception as e:
                    logger.warning(f"[Custom Langfuse][agent] Failed to end agent-creation span: {e}")
            
            # Handle guardrail failures
            if guardrails_failed_message:
                if custom_api and trace_id:
                    try:
                        custom_api.update_trace(
                            trace_id=trace_id,
                            output_data={"guardrail_blocked": True, "message": str(guardrails_failed_message)},
                            total_tokens=0,
                            prompt_tokens=0,
                            completion_tokens=0,
                            total_cost=0.0,
                        )
                    except Exception as e:
                        logger.warning(f"[Custom Langfuse][agent] Failed to update trace with guardrail message: {e}")
                return str(guardrails_failed_message), "Not applicable"

            # Store config in metadata hash for event listeners
            event_listener.metadata_hash[str(agent.id)] = creator_config
            event_listener.metadata_hash[str(task.id)] = creator_config

            # Also store by execution_id for fallback lookup
            event_listener.metadata_hash[trace_id] = creator_config
            
            logger.info(f"[EventListener] Stored metadata for agent:{agent.id}, task:{task.id}, trace:{trace_id}")
            
            # Store root_span_id for event listeners - they create agent/task/tool spans directly under trace
            if hasattr(event_listener, '_trace_root_spans'):
                event_listener._trace_root_spans[trace_id] = None  # No root span for single agent

            # Execute the task - EventListener will create agent/task/tool observations
            # Set execution context so LiteLLM callbacks can attribute usage
            try:
                from app.core.llm_usage import set_current_execution_id as _set_exec
                _set_exec(trace_id)
            except Exception:
                set_current_execution_id(trace_id)

            # FIX: Wrap blocking sync call in executor to prevent event loop blocking
            import asyncio
            loop = asyncio.get_event_loop()
            if 'gpt-5' in str(agent.llm.model).lower():
                has_embedding = hasattr(agent_data, 'embedding') and agent_data.embedding
                has_image_input = bool(self.temporary_images) or self.contains_image
                task_description_parts = [task.description]
                # For filereadTool
                if unzipped_files_path:            
                    file_tool = FileReadTool(auth_token=self.Authorization)
                    
                    for root, dirs, files in os.walk(unzipped_files_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            file_content = file_tool._run(file_path=file_path)
                            task_description_parts.append(f"File: {file_path}\n{file_content}")
  
                # for Konwledge base
                if has_embedding:
                    question = list(self.payload_object.userInputs.values())
                    rag_tool = KnowledgeRAGTool(
                        agent_id=agent_data.id,                        
                        auth_token=self.Authorization
                    )
                    embedding_content = rag_tool._run(question=question[0])                 
                    formatted_content = (
                        f"\n{question}\n"
                        + f"\nKNOWLEDGE BASE ANSWER:\n{embedding_content}\n"
                    )
                    task_description_parts.append(formatted_content)
                # for ImageTool
                
                if has_image_input:                  
                    im_tool = Imagetool(llm=agent.llm)
                    image_path_url = self.temporary_images   
                    for image in image_path_url:
                        if image:
                            image_content = im_tool._run(image_path_url=image)
                            task_description_parts.append(f"UPLOADED IMAGE ANALYSIS RESULT:\n{image_content}")
               
                task.description = "\n\n".join(task_description_parts)
                
            execution_output = await loop.run_in_executor(None, task.execute_sync)
            if isinstance(execution_output, TaskOutput):
                execution_output.description = agent_data.task.description
            logger.info(f"[Performance] Task execution completed without blocking event loop")

            # Update trace with final metrics after execution
            if custom_api and trace_id:
                try:
                    # Aggregate token/cost from agent_spans (matches pipeline service implementation)
                    def _aggregate_totals_with_wait(max_wait_ms: int = 3000):
                        nonlocal total_tokens, prompt_tokens, completion_tokens, total_cost, model_used
                        waited = 0
                        sleep_interval = 0.05  # Start at 50ms for faster response
                        while waited <= max_wait_ms:
                            # reset totals each pass
                            total_tokens = 0
                            prompt_tokens = 0
                            completion_tokens = 0
                            total_cost = 0.0
                            # aggregate
                            if hasattr(event_listener, 'agent_spans') and event_listener.agent_spans:
                                for agent_id, span_info in event_listener.agent_spans.items():
                                    if not isinstance(span_info, dict):
                                        continue
                                    span_id = span_info.get('span_id')
                                    if not span_id or not str(span_id).startswith(f"{trace_id}_"):
                                        continue
                                    if model_used is None:
                                        model_used = span_info.get('model')
                                    if span_info.get('usage_recorded', False):
                                        total_tokens += int(span_info.get('tokens', 0))
                                        prompt_tokens += int(span_info.get('prompt_tokens', 0))
                                        completion_tokens += int(span_info.get('completion_tokens', 0))
                                        total_cost += float(span_info.get('cost', 0.0))
                            # break if we've got anything
                            if total_tokens > 0:
                                break
                            # FIX: Use async sleep to prevent blocking
                            import asyncio
                            try:
                                loop = asyncio.get_event_loop()
                                if loop.is_running():
                                    # Can't await in sync function, use minimal sleep
                                    import time
                                    time.sleep(0.01)  # Reduced to 10ms
                                else:
                                    time.sleep(sleep_interval)
                            except Exception:
                                time.sleep(0.01)  # Fallback to minimal sleep
                            waited += int(sleep_interval * 1000)
                            # Exponential backoff with cap at 200ms (reduced from 500ms)
                            sleep_interval = min(sleep_interval * 2, 0.2)
                        if total_tokens > 0:
                            logger.info(
                                f"[Custom Langfuse][agent] Aggregated totals: tokens={total_tokens}, "
                                f"prompt={prompt_tokens}, completion={completion_tokens}, cost=${total_cost:.4f}"
                            )
                    
                    total_tokens = 0
                    prompt_tokens = 0
                    completion_tokens = 0
                    total_cost = 0.0
                    model_used = None
                    _aggregate_totals_with_wait(500)

                    # Fallback: if totals still 0, first try LiteLLM aggregated usage, then estimate from prompt/response
                    if total_tokens == 0:
                        try:
                            agg_total, agg_prompt, agg_completion, agg_cost, agg_model = get_aggregated_usage(trace_id)
                            if agg_total > 0:
                                total_tokens = agg_total
                                prompt_tokens = agg_prompt
                                completion_tokens = agg_completion
                                total_cost = agg_cost if agg_cost and agg_cost > 0 else float(custom_api.compute_cost(agg_prompt, agg_completion, agg_model or model_used))
                                if model_used is None:
                                    model_used = agg_model
                                logger.info(
                                    f"[Custom Langfuse][agent] Using LiteLLM aggregated totals: tokens={total_tokens}, prompt={prompt_tokens}, "
                                    f"completion={completion_tokens}, cost=${total_cost:.4f} (model={model_used})"
                                )
                            else:
                                # Estimate from prompt/response
                                prompt_text = None
                                try:
                                    prompt_text = getattr(task, 'description', None)
                                except Exception:
                                    prompt_text = None
                                output_text = str(execution_output) if execution_output is not None else ""
                                import math
                                est_prompt = int(math.ceil(len(prompt_text or "") / 4.0))
                                est_completion = int(math.ceil(len(output_text or "") / 4.0))
                                est_total = est_prompt + est_completion
                                if est_total > 0:
                                    total_tokens = est_total
                                    prompt_tokens = est_prompt
                                    completion_tokens = est_completion
                                    try:
                                        total_cost = float(custom_api.compute_cost(prompt_tokens, completion_tokens, model_used))
                                    except Exception:
                                        total_cost = 0.0
                                    logger.info(
                                        f"[Custom Langfuse][agent] Using fallback totals: tokens={total_tokens}, prompt={prompt_tokens}, "
                                        f"completion={completion_tokens}, cost=${total_cost:.4f}"
                                    )
                        except Exception as e:
                            logger.warning(f"[Custom Langfuse][agent] Aggregation/estimation failed: {e}")
                    
                    # Update trace with aggregated totals (guard against duplicate with EventListener)
                    if not (hasattr(event_listener, "_trace_updated") and event_listener._trace_updated.get(trace_id)):
                        logger.info(f"[COST_DEBUG][agent] Updating trace and creating scores with aggregated data: tokens={total_tokens}, cost=${total_cost:.6f}")
                        custom_api.update_trace(
                            trace_id=trace_id,
                            total_tokens=total_tokens,
                            prompt_tokens=prompt_tokens,
                            completion_tokens=completion_tokens,
                            total_cost=total_cost,
                            output_data=str(execution_output),
                            model=model_used,
                        )
                        # Create all trace-level scores with the aggregated totals (same data as trace)
                        try:
                            custom_api.create_score(trace_id=trace_id, name="execution_success", value=1.0, observation_id=None, data_type="BOOLEAN")
                            custom_api.create_score(trace_id=trace_id, name="execution_tokens_total", value=float(total_tokens), observation_id=None, data_type="NUMERIC")
                            custom_api.create_score(trace_id=trace_id, name="execution_cost_usd", value=float(total_cost), observation_id=None, data_type="NUMERIC")
                            # Calculate token efficiency (completion_tokens / total_tokens)
                            token_efficiency = (float(completion_tokens) / float(total_tokens)) if total_tokens > 0 else 0.0
                            custom_api.create_score(trace_id=trace_id, name="token_efficiency", value=token_efficiency, observation_id=None, data_type="NUMERIC")
                            logger.info(f"[SCORE_DEBUG][agent] Created trace-level scores: tokens={total_tokens}, cost=${total_cost:.6f}, efficiency={token_efficiency:.4f}")
                        except Exception as e:
                            logger.error(f"[CRITICAL][agent] Failed to create trace-level scores: {e}")
                        # Set dedup flag so subsequent updates are skipped
                        try:
                            event_listener._trace_updated[trace_id] = True
                        except Exception:
                            pass
                        logger.info(f"[Custom Langfuse][agent] Updated trace with totals: {total_tokens} tokens, ${total_cost:.4f}")
                    else:
                        logger.info(f"[Custom Langfuse][agent] Skipping duplicate final generation update for trace {trace_id} (already handled in EventListener)")
                except Exception as e:
                    logger.warning(f"[Custom Langfuse][agent] Failed to update trace: {e}")
                finally:
                    try:
                        clear_usage(trace_id)
                        set_current_execution_id(None)
                    except Exception:
                        pass
                # Cleanup EventListener metadata to prevent memory leaks
                try:
                    event_listener._cleanup_execution_state(trace_id)
                    logger.info(f"[Memory] Cleaned up EventListener metadata for execution {trace_id}")
                except Exception as cleanup_err:
                    logger.warning(f"[Memory] Failed to cleanup EventListener metadata: {cleanup_err}")

            # CRITICAL: Aggressive CrewAI memory cleanup to prevent RAM buildup
            try:
                # 1. Clear agent tools and internal references
                if hasattr(agent, 'tools') and agent.tools:
                    with suppress(Exception):
                        for tool in agent.tools:
                            # Clear tool caches and internal state
                            if hasattr(tool, '_cache'):
                                tool._cache.clear()
                            if hasattr(tool, 'cache'):
                                tool.cache.clear()
                            # Delete tool references
                            del tool
                        agent.tools.clear()
                        logger.debug(f"[Memory] Cleared agent tools")
                
                # 2. Clear task internal state and caches
                if task:
                    with suppress(Exception):
                        # Clear task output cache
                        if hasattr(task, '_output'):
                            task._output = None
                        if hasattr(task, 'output'):
                            task.output = None
                        # Clear task context and memory
                        if hasattr(task, 'context'):
                            task.context = None
                        if hasattr(task, '_context'):
                            task._context = None
                        logger.debug(f"[Memory] Cleared task internal state")
                
                # 3. Clear agent memory and caches
                if agent:
                    with suppress(Exception):
                        # Clear agent memory
                        if hasattr(agent, 'memory') and agent.memory:
                            if hasattr(agent.memory, 'clear'):
                                agent.memory.clear()
                            agent.memory = None
                        # Clear agent cache
                        if hasattr(agent, '_cache'):
                            agent._cache.clear()
                        if hasattr(agent, 'cache'):
                            agent.cache.clear()
                        # Clear LLM cache
                        if hasattr(agent, 'llm'):
                            llm = agent.llm
                            if hasattr(llm, '_cache'):
                                llm._cache.clear()
                            if hasattr(llm, 'cache'):
                                llm.cache.clear()
                            # Clear LiteLLM internal caches
                            try:
                                import litellm
                                if hasattr(litellm, 'cache') and litellm.cache:
                                    litellm.cache.flush()
                            except Exception:
                                pass
                        logger.debug(f"[Memory] Cleared agent memory and caches")
                
                # 4. Clear CrewAI global caches if accessible
                with suppress(Exception):
                    try:
                        from crewai import Agent as CrewAgent
                        # Clear any class-level caches
                        if hasattr(CrewAgent, '_cache'):
                            CrewAgent._cache.clear()
                    except Exception:
                        pass
                
                agent_id = id(agent) if agent else None
                task_id = id(task) if task else None
                
                
                logger.info(f"[Memory] Deleted agent (id:{agent_id}) and task (id:{task_id})")
                
                # 6. Force garbage collection to free CrewAI memory immediately
                collected = gc.collect(generation=2)  # Full collection including oldest generation
                logger.info(f"[Memory] Aggressive GC collected {collected} objects after CrewAI execution")
                
                # 7. Log memory statistics
                gc_stats = gc.get_stats()
                logger.debug(f"[Memory] GC stats after cleanup: {gc_stats}")
                
            except Exception as gc_err:
                logger.error(f"[Memory] Failed aggressive CrewAI cleanup: {gc_err}", exc_info=True)
                # Attempt minimal cleanup
                with suppress(Exception):
                    gc.collect()

            # folder_path = os.path.join(os.getcwd(), self.payload_object.executionId)
            # file_id = await self.file_uploader(folder_path) # TODO
            
            file_id = None # TODO
            has_file_writer = any(
                isinstance(tool, FileWriterTool) for tool in getattr(agent, "tools", [])
            )


            # 5. Explicitly delete agent and task objects
            del agent
            del task


            return execution_output, (file_id if has_file_writer else "Not applicable")
        except Exception as e:
            error_message = str(e)
            # Check if it's a guardrail validation error
            if "guardrail" in error_message.lower():
                specific_message = error_message.split("Last error:")[-1].strip() if "Last error:" in error_message else "Response blocked by content policy"
                logger.warning(f"Guardrail blocked response: {error_message}")
                # Return a safe, user-friendly response instead of raising an error                
                guardrails_response = TaskOutput(
                    description="Response blocked by content policy",
                    summary="The generated response was blocked by our content safety filters. Please rephrase your question or try a different approach.",
                    raw=str(specific_message),
                    pydantic=None,
                    json_dict=None,
                    output_format="raw",
                    agent="safety_agent"
                )
                logger.info("Returning safe fallback response due to guardrail block")
                return (guardrails_response, "Not applicable")
            raise e

    async def execute_with_mcp(self):
        mcp_server_params = {
            "url": settings.MCP_SERVER_API_URL,
            "transport": "streamable-http",
            "headers": {
                "Authorization": self.Authorization,
                },
            "timeout": settings.MCP_TIMEOUT
        }
        with MCPServerAdapter(mcp_server_params) as mcp_tools:
            return await self.execute_task(
                unzipped_files_path=self.unzipped_files_path, mcp_tools=mcp_tools
            )

    async def execute(self):
        return await self.execute_task(
            unzipped_files_path=self.unzipped_files_path
        )

    async def run(self) -> dict[str, Any]:
        """Orchestrates the agent execution steps."""
        try:
            await self.process_image()
            await self.prepare_payload()
            if self.files:
                await self.prepare_and_unzip_files(self.files)
            logger.info(f"settings.MCP_ENABLED : {settings.MCP_ENABLED}")
            agent_response = await self.execute_with_mcp() if settings.MCP_ENABLED else await self.execute()
            final_result =  await self.process_response(agent_response)
        
            save_final_execution_history(
                self.agent_request.agentId, 
                self.agent_request.executionId, 
                agent_response,
                final_result,
                self.Authorization,
                "SUCCESS"
            )

            send_execution_status(
                self.agent_request.executionId,
                self.agent_request.agentId,
                "SUCCESS", 
                self.Authorization
            )


            return final_result
        except Exception as e:
            status_code = getattr(e, 'status_code', 500)
            detail = getattr(e, 'detail', str(e))            
            logger.error(f"Agent execution failed: {detail} (Status Code: {status_code})")
            try:
                if settings.CUSTOM_LANGFUSE_ENABLED:
                    lf = get_langfuse_api()
                    lf.create_score(
                        trace_id=self.agent_request.executionId, 
                        name="execution_success", 
                        value=0.0, 
                        observation_id=None, 
                        data_type="BOOLEAN"
                    )
                    lf.update_trace(
                        trace_id=self.agent_request.executionId,
                        output_data={"error": str(detail)},
                        total_tokens=0,
                        prompt_tokens=0,
                        completion_tokens=0,
                        total_cost=0.0,
                    )
                empty_final_response = {}
                empty_agent_response = (None, "None")
                save_final_execution_history(self.agent_request.agentId, self.agent_request.executionId,empty_agent_response,empty_final_response, self.Authorization,"FAILED")
            except Exception as lf_e:
                logger.warning(f"[Custom Langfuse][agent] Failed to mark execution failure in Langfuse: {lf_e}")
            raise e.__class__(" - " + "agent run error " + str(e)) from e
        finally:
            self._cleanup()

            # Force garbage collection after cleanup to free CrewAI memory
            with suppress(Exception):
                collected = gc.collect()
                logger.debug(f"[Memory] GC collected {collected} objects in finally block")


class AgentQueryExecutor:
    def __init__(self, request, Authorization, validator):
        self.request = request
        self.Authorization = Authorization
        self.validator = validator

    async def execute_query(self):
        agent_config = convert_payload(self.request, self.Authorization, self.validator)
        # Create agent and task using AgentCreator
        agent_creator = AgentCreator(agent_config)
        agent, task, guardrails_failed_message = await agent_creator.create_agent_and_task()

        if guardrails_failed_message:
            return str(guardrails_failed_message)
        try:
            result = task.execute_sync()
            return result
        finally:
            # Cleanup CrewAI objects and force GC
            with suppress(Exception):
                if agent:
                    # Clear agent tools and memory
                    if hasattr(agent, 'tools') and agent.tools:
                        agent.tools.clear()
                    if hasattr(agent, 'memory') and agent.memory:
                        agent.memory = None
                    del agent
                
                if task:
                    # Clear task state
                    if hasattr(task, 'output'):
                        task.output = None
                    del task
                
                # Force GC
                collected = gc.collect()
                logger.debug(f"[Memory] Query executor GC collected {collected} objects")
