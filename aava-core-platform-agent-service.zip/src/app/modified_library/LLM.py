"""
Custom LLM implementation for CrewAI that supports Azure OpenAI models,
including the new Responses API for models like gpt-5.1-codex.
This module provides a custom LLM class that extends CrewAI's LLM,
implementing a universal completion approach that:
1. Uses responses API for newer models (e.g., gpt-5.1-codex)
"""
import json
import logging
from typing import Any,Dict,List,Optional,Union,Type,Literal
from pydantic import BaseModel
import requests
from crewai.llm import LLM
from crewai.utilities.events.llm_events import LLMCallType

LLM_CONTEXT_WINDOW_SIZES = {

    "azure/gpt-5.1-codex-mini" : "272000",
    "azure/gpt-5.1-codex-max" : "400000",
    "azure/gpt-5.1-codex" : "272000",
    "azure/gpt-5.3-codex" : "400000"
}


logger = logging.getLogger(__name__)


class CustomAzureLLM(LLM):
    """
    Custom LLM implementation for Azure OpenAI that supports both
    standard chat completions and the newer Responses API.
    
    This class provides a universal completion approach that:
    - Uses Responses API for newer models like gpt-5.1-codex
    
    Attributes:
        model (str): The model deployment name (e.g., "gpt-4o", "gpt-5.1-codex")
        api_key (str): Azure OpenAI API key
        api_base (str): Azure OpenAI endpoint URL
        temperature (float): Sampling temperature (default: 1.0)
        max_tokens (int): Maximum tokens for response (default: 128000)
        timeout (int): Request timeout in seconds (default: 60)
    """
    
    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        temperature: Optional[float] = 1.0,
        max_tokens: int = 128000,
        timeout: int = 60,
        **kwargs
    ):
        """
        Initialize the CustomAzureLLM.
        
        Args:
            model: The model deployment name
            api_key: Azure OpenAI API key
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum tokens for the response
            timeout: Request timeout in seconds
            **kwargs: Additional parameters passed to parent class
        """
        # Call parent constructor with required parameters
        super().__init__(model=model, temperature=temperature, api_key=api_key, max_tokens=max_tokens, timeout=timeout, **kwargs)
    
    def _handle_non_streaming_response(
        self,
        params: Dict[str, Any],
        callbacks: Optional[List[Any]] = None,
        available_functions: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Handle a non-streaming response from the LLM.

        Args:
            params: Parameters for the completion call
            callbacks: Optional list of callback functions
            available_functions: Dict of available functions

        Returns:
            str: The response text
        """
        # --- 1) Make the completion call
        try:
            response = self._call_responses_api(**params)
        except Exception as e:
            raise Exception(f"Failed to get response from the responses endpoint: {str(e)}")

        
        text_response = response["choices"][0]["message"]["content"] or ""

        # --- 3) Handle callbacks with usage info
        if callbacks and len(callbacks) > 0:
            for callback in callbacks:
                if hasattr(callback, "log_success_event"):
                    usage_info = getattr(response, "usage", None)
                    if usage_info:
                        callback.log_success_event(
                            kwargs=params,
                            response_obj={"usage": usage_info},
                            start_time=0,
                            end_time=0,
                        )

        # --- 4) Check for tool calls
        tool_calls = response["choices"][0]["message"]["tool_calls"]

        # --- 5) If no tool calls or no available functions, return the text response directly
        if not tool_calls or not available_functions:
            self._handle_emit_call_events(text_response, LLMCallType.LLM_CALL)
            return text_response

        # --- 6) Handle tool calls if present
        tool_result = self._handle_tool_call(tool_calls, available_functions)
        if tool_result is not None:
            return tool_result

        # --- 7) If tool call handling didn't return a result, emit completion event and return text response
        self._handle_emit_call_events(text_response, LLMCallType.LLM_CALL)

        return text_response
    
    def _call_responses_api(
        self,
        model: str,
        # Optional OpenAI params: see https://platform.openai.com/docs/api-reference/chat/create
        messages: List = [],
        timeout: Optional[Union[float, str]] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        n: Optional[int] = None,
        stream: Optional[bool] = None,
        stream_options: Optional[dict] = None,
        stop=None,
        max_completion_tokens: Optional[int] = None,
        max_tokens: Optional[int] = None,
        presence_penalty: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        logit_bias: Optional[dict] = None,
        user: Optional[str] = None,
        # openai v1.0+ new params
        reasoning_effort: Optional[Literal["low", "medium", "high"]] = None,
        response_format: Optional[Union[dict, Type[BaseModel]]] = None,
        seed: Optional[int] = None,
        tools: Optional[List] = None,
        tool_choice: Optional[Union[str, dict]] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        parallel_tool_calls: Optional[bool] = None,
        deployment_id=None,
        extra_headers: Optional[dict] = None,
        # soon to be deprecated params by OpenAI
        functions: Optional[List] = None,
        function_call: Optional[str] = None,
        # set api_base, api_version, api_key
        base_url: Optional[str] = None,
        api_version: Optional[str] = None,
        api_key: Optional[str] = None,
        model_list: Optional[list] = None,  # pass in a list of api_base,keys, etc.
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Call Azure OpenAI Responses API (for models like gpt-5.1-codex).
        
        Args:
            messages: List of message dicts
            tools: Optional list of tool definitions
        
        Returns:
            Standardized chat completion format response
        """
        endpoint = f"{self.base_url}/openai/responses?{self.api_version}"
        
        headers = {
            "Content-Type": "application/json",
            "api-key": self.api_key
        }
        
        # Get base model name without 'azure/' prefix
        base_model = self.model.replace("azure/", "")
        
        payload = {
            "input": messages,
            "max_output_tokens": self.max_tokens,
            "model": base_model
        }

        # Add tools if provided
        if tools and self.supports_function_calling():
            payload["tools"] = tools
        
        # Try with temperature first
        response = None
        try:
            payload["temperature"] = self.temperature
            response = requests.post(
                endpoint,
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response and response.status_code != 200:
                raise Exception(f"Responses API Error {response.status_code}: {response.text}")
                
        except Exception as temp_error:
            # If temperature isn't supported, retry without it
            if "temperature" in str(temp_error).lower():
                del payload["temperature"]
                response = requests.post(
                    endpoint,
                    headers=headers,
                    json=payload,
                    timeout=(self.timeout, 300)
                )
                
                if response and response.status_code != 200:
                    raise Exception(f"Responses API Error {response.status_code}: {response.text}")
            else:
                raise Exception(f"Responses API Error {response.status_code}: {response.text}")
        
        result = response.json()
        
        # Convert Responses API format to standard chat completion format
        content_text = ""
        tool_calls = None
        
        if "output" in result:
            for item in result["output"]:
                if item["type"] == "message":
                    for content in item.get("content", []):
                        if content["type"] == "output_text":
                            content_text += content["text"]
                # Handle function calls from Responses API if present
                elif item["type"] == "function_call":
                    if tool_calls is None:
                        tool_calls = []
                    tool_calls.append({
                        "id": item.get("call_id", item.get("id", "")),
                        "type": "function",
                        "function": {
                            "name": item.get("name", ""),
                            "arguments": item.get("arguments", "{}")
                        }
                    })
        
        return {
            "id": result.get("id"),
            "object": "chat.completion",
            "created": result.get("created_at"),
            "model": result.get("model"),
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": content_text,
                    "tool_calls": tool_calls
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": result.get("usage", {}).get("input_tokens", 0),
                "completion_tokens": result.get("usage", {}).get("output_tokens", 0),
                "total_tokens": result.get("usage", {}).get("total_tokens", 0)
            }
        }
    
    def supports_function_calling(self) -> bool:
        """
        Check if the LLM supports function calling.
        
        Returns:
            True - Azure OpenAI models support function calling
        """
        return True
    
    def supports_stop_words(self) -> bool:
        """
        Check if the LLM supports stop sequences.
        
        Returns:
            True - Azure OpenAI models support stop words
        """
        return True
    
    def get_context_window_size(self) -> int:
        """
        Return the context window size for the model.
        
        Returns:
            Context window size (default 128000 for modern Azure OpenAI models)
        """
        for key, value in LLM_CONTEXT_WINDOW_SIZES.items():
            if self.model.startswith(key):
                return int(value)
        return 128000

class CustomBedrockLLM(LLM):
    def _prepare_completion_params(self, messages, tools=None):
        params = super()._prepare_completion_params(messages, tools)

        final_messages = params.get("messages")
        if not isinstance(final_messages, list) or not final_messages:
            return params

        last_message = final_messages[-1]

        if (
            isinstance(last_message, dict)
            and last_message.get("role") == "assistant"
        ):
            logger.info(
                "Converting trailing assistant message to user for Claude 4.6."
            )

            converted = last_message.copy()
            converted["role"] = "user"

            final_messages = final_messages[:-1] + [converted]
            params["messages"] = final_messages

        logger.info(
            "Normalized Bedrock message roles: %s",
            [
                m.get("role")
                for m in params["messages"]
                if isinstance(m, dict)
            ],
        )

        return params