# AAVA Agent API - Postman Collection Guide

This Postman collection provides a comprehensive interface for testing and interacting with the AAVA Core Platform Agent Service APIs.

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Authentication](#authentication)
- [API Endpoints](#api-endpoints)
- [Setup Instructions](#setup-instructions)
- [Environment Variables](#environment-variables)

---

## Overview

The Agent Collection includes the following endpoint groups:

### Agent Endpoints
- **Agent Run** - Execute agents with user inputs
- **Agent Run Files** - Execute agents with file uploads
- **Agent Query** - Process complex queries with advanced configurations
- **Health Check** - Verify agent service status
- **Config Refresh** - Refresh agent configurations

### Authentication Endpoint
- **Login** - Generate authentication tokens using email credentials

---

## Prerequisites

- **Postman** (Latest version recommended)
- **Active AAVA Agent Service Instance** accessible via network
- **Valid User Email** from your organization

---

## Authentication

### ⚠️ Important: Email-Based Token Generation

**You must provide your own email ID to generate authentication tokens. Do NOT use the default email credentials for production use.**

### Step 1: Generate Access Token

1. **Open the "Login" request** in the collection
2. **Update the email parameter:**
   - Locate the query parameter `email=default@ascendion.com`
   - **Replace it with your own email ID** (e.g., `email=yourname@yourcompany.com`)
3. **Send the request**
4. The response will contain your `access_token`

### Step 2: Automatic Token Management

The collection includes a test script that automatically:
- Extracts the access token from the login response
- Stores it in global variables (`access_token`)
- Stores it in environment variables for the current session
- Makes it available for all subsequent API requests

### Example Login Request

```
POST {{aava-agent}}/api/auth/basic/access/token?email=your-email@company.com

Headers:
Authorization: Basic YWRtaW46YWRtaW4xMjM=
```

### Using the Token

Once authenticated, the token is automatically included in all API requests via the `Authorization` header:

```
Authorization: Bearer {{access_token}}
```

---

## API Endpoints

### 1. **Agent Run** - POST `/agent/v1/run`

Execute an agent with user inputs.

**Request Headers:**
```
Content-Type: application/json
Authorization: Bearer {{access_token}}
```

**Request Body:**
```json
{
    "agentId": 1766,
    "userInputs": {
        "user_input_string_true_input": "Your query here"
    },
    "executionId": "unique-execution-id",
    "user": "your-email@company.com"
}
```

**Response:**
- Agent execution results
- Task outputs with sources and confidence scores
- Audit log references
- Compliance action details

**Use Case:** Simple agent execution with predefined inputs

---

### 2. **Agent Run Files** - POST `/agent/v1/run-files`

Execute an agent with file uploads (multipart form data).

**Request Headers:**
```
Authorization: Bearer {{access_token}}
```

**Request Body (Form Data):**
- `agentId` (text): Agent identifier
- `executionId` (text): Unique execution identifier
- `userInputs` (text): JSON string with input parameters
- `user` (text): User email address
- `files` (file): File to be processed
- `tools` (text): JSON array of tools
- `userTools` (text): JSON array of user-defined tools

**Use Case:** Process documents, images, or other files with agent

---

### 3. **Agent Query** - POST `/agent/v1/query`

Process complex queries with advanced LLM and RAG configurations.

**Request Headers:**
```
Content-Type: application/json
Authorization: Bearer {{access_token}}
```

**Request Body Parameters:**
- `sender` (string): User email address
- `executionId` (string): Unique execution identifier
- `prompt` (string): User query or prompt
- `user` (string): User email
- `use_case` (string): Use case identifier
- `rag_enable` (boolean): Enable RAG (Retrieval-Augmented Generation)
- `rag_mode` (string): RAG mode (STRICT, STANDARD, etc.)
- `nemo_guardrails` (boolean): Enable Nemo Guardrails
- `context_record_number` (integer): Number of context records to retrieve

**Advanced Configuration (Optional):**
- `langfuse_host`, `langfuse_public_key`, `langfuse_secret_key`: Analytics and monitoring
- `chroma_endpoint`, `chroma_port`: Vector database configuration
- `colang_content`: Guard rail rules in ColAng format
- `yaml_content`: Guard rail configuration in YAML format
- `agent_details`: Custom agent configuration
- `collection_config`: Vector embedding collection settings

**Use Case:** Complex query processing with RAG, guardrails, and monitoring

---

### 4. **Health Check** - GET `/agent/v1/health`

Verify the agent service health status.

**Request:**
```
GET {{aava-agent}}/agent/v1/health
```

**Response:**
- Service status (healthy/unhealthy)
- Service metadata

**Use Case:** Service health monitoring and readiness checks

---

### 5. **Config Refresh** - POST `/agent/v1/config-refresh`

Refresh agent configurations.

**Request URL:**
```
POST {{aava-agent}}/agent/v1/config-refresh
```

**Request Headers:**
```
Authorization: Bearer {{access_token}}
```

**Use Case:** Reload agent configurations after updates

---

## Setup Instructions

### Step 1: Import the Collection

1. Open **Postman**
2. Click **Import** button
3. Select **Upload Files** option
4. Choose `agent.json` from this folder
5. Click **Import**

### Step 2: Configure Environment Variables

1. Click on the **Environments** tab
2. Select or create an environment
3. Add/Update the following variables:

| Variable | Value | Example |
|----------|-------|---------|
| `aava-agent` | Base URL of agent service | `https://agent-api.yourcompany.com` |

### Step 3: Generate Authentication Token

1. **Select your environment** from the dropdown
2. **Navigate to the "Login" request** in the Agent Collection
3. **Update the email parameter** with your email ID:
   ```
   email=your-email@company.com
   ```
4. **Send the Login request**
5. The token will be automatically stored in `{{access_token}}`

### Step 4: Execute API Requests

Once authenticated, you can execute any API request in the collection. The `{{access_token}}` will be automatically included.

---

## Environment Variables

### Environment URLs

Choose the appropriate URL based on your environment:

| Environment | URL |
|-------------|-----|
| **Local** | `http://localhost:8002` |
| **Dev** | `https://aava-dev.avateam.io` |
| **QE** | `https://aava-qe.avateam.io` |
| **UAT** | `https://aava-uat.avateam.io` |
| **INT** | `https://aava-int.avateam.io` |

### Required Variables

Create an environment in Postman with the following variables:

```json
{
  "aava-agent": "http://localhost:8002"
}
```

**Update the URL above based on your target environment from the table above.**

**Example for Dev environment:**
```json
{
  "aava-agent": "https://aava-dev.avateam.io"
}
```

### Auto-Generated Variables

These are set automatically after successful login:

```json
{
  "access_token": "your-jwt-token-here"
}
```

---

## Common Use Cases

### 1. Test Agent Execution

```
1. Login with your email
2. Navigate to "Agent" → "agent run"
3. Update the agentId and user email in the request body
4. Send the request
```

### 2. Process Files with Agent

```
1. Login with your email
2. Navigate to "Agent" → "agent run files"
3. Update agentId, user email, and select your file
4. Send the request
```

### 3. Complex Query Processing

```
1. Login with your email
2. Navigate to "Agent" → "agent query"
3. Configure your prompt, RAG settings, and guardrails
4. Send the request
```

### 4. Health Monitoring

```
1. Navigate to "Agent" → "health"
2. Send the request (no authentication required)
3. Check service status
```

---

## Error Handling

### Authentication Errors

**Error:** `401 Unauthorized`
- **Cause:** Invalid or expired access token
- **Solution:** Re-run the Login request with your email ID to generate a new token

### Invalid Email

**Error:** `400 Bad Request`
- **Cause:** Invalid email format or non-existent user
- **Solution:** Verify your email address is correct and active in the system

### Agent Not Found

**Error:** `404 Not Found`
- **Cause:** Agent ID does not exist
- **Solution:** Verify the agent ID exists in your AAVA instance

### Service Unavailable

**Error:** `503 Service Unavailable`
- **Cause:** Agent service is down or unreachable
- **Solution:** Check service health using the Health endpoint

---

## Security Notes

⚠️ **Important Security Considerations:**

1. **Never commit tokens** to version control
2. **Use environment-specific credentials** for different environments (dev, staging, prod)
3. **Rotate tokens regularly** by re-running the Login request
4. **Use strong, organization-specific emails** instead of default credentials
5. **Restrict collection access** to authorized team members
6. **Enable Postman's built-in encryption** for sensitive data

---

## Support & Troubleshooting

### Common Issues

**Issue:** Token not being set after login
- **Solution:** Ensure JavaScript execution is enabled in Postman tests. Check browser console for errors.

**Issue:** CORS errors
- **Solution:** Configure proper CORS headers on the server or use Postman's proxy

**Issue:** File upload failing
- **Solution:** Verify file size limits and supported formats on the server

### Getting Help

For additional support:
- Check the service documentation
- Contact your AAVA platform administrator
- Review server logs for detailed error messages

---

## Collection Information

- **Collection Name:** Agent_Collection
- **Collection ID:** e1902aaf-c3f1-41b8-aa1f-29fc0418b6b5
- **Schema Version:** 2.1.0
- **Last Updated:** December 2024

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Jan 2026 | Initial collection with core endpoints |

---

**Happy Testing!** 🚀
