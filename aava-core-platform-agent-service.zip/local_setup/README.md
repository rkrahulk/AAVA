# Local Setup Guide - Aava Core Platform Agent Service

This directory contains the configuration you need to run the `aava-core-platform-agent-service` stack in a local development environment.

---

## Table of Contents

- [Local Setup Guide - Aava Core Platform Agent Service](#local-setup-guide---aava-core-platform-agent-service)
  - [Table of Contents](#table-of-contents)
  - [TL;DR - Quick Start](#tldr---quick-start)
  - [Docker Setup](#2-docker-setup)
    - [Prerequisites](#prerequisites)
    - [Step 1: Create the External Network](#step-1-create-the-external-network)
    - [Step 2: Build and Start the Service](#step-2-build-and-start-the-service)
    - [Step 3: Verify the Setup](#step-3-verify-the-setup)
    - [Step 4: Access the Service](#step-4-access-the-service)
    - [Docker and Debugpy ports](#docker-and-debugpy-ports)
  - [Technical Details](#technical-details)
    - [Build Optimization (Caching)](#build-optimization-caching)
    - [Volume Mapping (Hot Reload)](#volume-mapping-hot-reload)
    - [SSL Certificates](#ssl-certificates)
    - [Local Debugging (VS Code)](#local-debugging-vs-code)
  - [Troubleshooting](#troubleshooting)
    - [Error: `ModuleNotFoundError: No module named 'app'`](#error-modulenotfounderror-no-module-named-app)
    - [Error: `network aava_network not found`](#error-network-aava_network-not-found)
    - [Docker build is slow](#docker-build-is-slow)
- [venv steps TO BE updated](#venv-steps-to-be-updated)

---

## TL;DR - Quick Start
For experienced developers, run through these steps:

1. **Prepare the wheel package (if required by `pyproject.toml`):**
   - Create `src/whl` if it does not exist:
     ```
     mkdir -p src/whl
     ```
   - Copy the built wheel (e.g., `aava_core_python_starter-1.0.1-py3-none-any.whl`) into `src/whl`.

2. **Ensure you are in the repo root:**
   ```bash
   cd aava-core-platform-agent-service
   ```

3. **Sync the branch you want to work on:**
   ```bash
   git checkout development
   git pull
   ```

4. **Create the shared Docker network (if not already present):**
   ```bash
   docker network create aava_network
   ```

5. **Build and start the service with Docker Compose:**
   ```bash
   docker-compose -f local_setup/docker/docker-compose-local.yml up -d --build
   ```

6. **Watch the primary container logs:**
   ```bash
   docker logs -f agent-service
   ```

Once the container reports that Uvicorn is running on `0.0.0.0:8443`, the service is reachable at `http://localhost:8002`.

---

## Docker Setup

Docker Compose orchestrates the service with caching layers, trusted certificates, and hot reload so every local machine runs the same way.

### Prerequisites

- Docker Desktop (Windows/Mac) or Docker Engine (Linux)
- WSL2 is recommended for Windows environments
- Ensure `local.crt` lives in `local_setup/docker/`

### Step 1: Create the External Network

The Compose file connects to an external network named `aava_network`. Create it once:

```bash
docker network create aava_network
```

### Step 2: Build and Start the Service

From the repository root, run:

```bash
docker-compose -f local_setup/docker/docker-compose-local.yml up -d --build
```

This:

- Points Compose to the local configuration.
- Builds with `Dockerfile.local`, which installs dependencies with `uv` and caches downloads.
- Starts the `agent-service` container in detached mode with hot reload enabled.

### Step 3: Verify the Setup

Monitor the service logs:

```bash
docker logs -f agent-service
```

You should see debugpy attaching and Uvicorn listening on `0.0.0.0:8443`.

### Step 4: Access the Service

| Resource | URL |
|----------|-----|
| API Endpoint | http://localhost:8002 |
| Health Check | http://localhost:8002/health |
| Swagger Docs | http://localhost:8002/docs |


## Technical Details

### Build Optimization (Caching)

The `Dockerfile.local` uses Docker BuildKit Cache Mounts.

**Pip Cache**: Downloaded packages are cached on your host machine. Subsequent builds will skip downloading if `requirements.txt` hasn't changed, making builds up to 10x faster.

### Volume Mapping (Hot Reload)

The `docker-compose-local.yml` maps your local source code into the container:

Changes you make to files in `src/` will trigger an automatic **Hot Reload** of the Uvicorn server inside the container. You do not need to restart the container for code changes.

### SSL Certificates

The build automatically:
- Adds `local.crt` to the system's trusted CA store.
- Appends the certificate to the Python certifi bundle.
- Sets `SSL_CERT_FILE` and `REQUESTS_CA_BUNDLE` environment variables.

### Local Debugging (VS Code)

The container is pre-configured with debugpy listening on port 6667.

1. Go to the **Run and Debug** tab in VS Code.
2. Create a `launch.json` entry:

```json
{
    "name": "Python: Remote Attach (Docker)",
    "type": "python",
    "request": "attach",
    "connect": {
        "host": "localhost",
        "port": 6669
    },
    "pathMappings": [
        {
            "localRoot": "${workspaceFolder}/src",
            "remoteRoot": "/app/src"
        }
    ]
}
```

3. Start the debugger. You can now set breakpoints directly in your local code.

## Troubleshooting

### Error: `ModuleNotFoundError: No module named 'app'`

Make sure `PYTHONPATH` includes `/app/src:/app`. Both the Dockerfile and Compose service already set this, but double-check any overrides in your custom Compose files.

### Error: `network aava_network not found`

Create the network before starting Compose:

```bash
docker network create aava_network
```

### Docker build is slow

Enable BuildKit (`DOCKER_BUILDKIT=1`) and rely on the cached `uv` downloads:

```bash
export DOCKER_BUILDKIT=1
```

Re-run `docker-compose ... up --build` after setting that.

