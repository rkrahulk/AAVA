"""
Main entrypoint for the fileindexer-bedrock microservice.

- Sets up logging and OpenTelemetry tracing.
- Initializes FastAPI app and includes Bedrock-specific API routes.
- To run: `python main.py` or use the provided Dockerfile.

This service provides file indexing using AWS Bedrock cloud services only.
"""

from app.core.config import settings
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from app.api.routes import router as bedrock_router
from app.api.swagger import swagger_router
from aava.exception.handler import exception_handler
from aava.security.jwt import setup_jwt_middleware
from aava.logging.aspect import setup_logging_middleware
from app.core.telemetry import setup_application_insights, instrument_fastapi_app
from app.core.app_insights_middleware import (
    ApplicationInsightsMiddleware,
    create_operation_context,
    close_operation_context
)
import logging

logger = logging.getLogger("fileindexer-bedrock")


# Note: settings.load_remote_config() is already called in config.py at module import time
# We initialize Application Insights after config is loaded

# Wrap startup operations in operation context for correlation
startup_context = create_operation_context("application_startup")

try:
    # Initialize Application Insights with loaded configuration
    setup_application_insights(
        connection_string=settings.APPLICATIONINSIGHTS_CONNECTION_STRING,
        enabled=settings.to_bool('APPLICATIONINSIGHTS_ENABLED'),
        sample_rate=settings.APPLICATIONINSIGHTS_SAMPLE_RATE,
        disable_telemetry=settings.to_bool('APPLICATIONINSIGHTS_DISABLE_TELEMETRY'),
        log_level=settings.APPLICATIONINSIGHTS_LOG_LEVEL,
        service_name="aava-core-platform-fileindexer-aws"
    )
    
    logger.info(f"Application startup: Application Insights initialized (enabled={settings.APPLICATIONINSIGHTS_ENABLED})")
finally:
    close_operation_context(startup_context)

# Define tags metadata for better organization in Swagger UI
tags_metadata = [
    {
        "name": "File Ingestion",
        "description": """
### File Ingestion

Ingest and process files from Amazon S3 using AWS Bedrock for embedding generation.

**Features:**
- S3 file ingestion and validation
- Metadata extraction and processing
- AWS Bedrock embedding generation
- ChromaDB vector storage integration

**Authentication Required:** Yes (JWT Bearer token)
        """
    },
    {
        "name": "File Management",
        "description": """
### File Management

Retrieve file metadata and manage indexed files.

**Capabilities:**
- File metadata retrieval
- File status tracking
- Batch file operations
- File deletion and cleanup

**Authentication Required:** Yes (JWT Bearer token)
        """
    },
    {
        "name": "Search & Query",
        "description": """
### Search & Query

Perform semantic search across indexed files using vector embeddings.

**Features:**
- Text-based semantic search
- Vector similarity queries
- Filtered search with metadata
- Ranked results with relevance scores

**Authentication Required:** Yes (JWT Bearer token)
        """
    },
    {
        "name": "Health & Monitoring",
        "description": """
### Health & Monitoring

Monitor service health and AWS service connectivity.

**Available Endpoints:**
- Service health status
- AWS Bedrock connectivity
- S3 bucket accessibility
- ChromaDB connection status

**Use Cases:**
- Kubernetes liveness/readiness probes
- Infrastructure monitoring
- Service dependency tracking
        """
    }
]

# Initialize FastAPI app with comprehensive metadata
app = FastAPI(
    title="AAVA File Indexer - AWS Bedrock Service",
    description="Microservice for file indexing using AWS Bedrock cloud services. Provides file ingestion, embedding generation, and semantic search capabilities with enterprise-grade security and monitoring.",
    version=getattr(settings, 'SERVICE_VERSION', '1.0.0'),
    docs_url="/fileindexer/bedrock/v1/docs",
    openapi_url="/fileindexer/bedrock/v1/openapi.json",
    contact={
        "name": "AAVA Platform Team",
        "email": "support@aava.platform",
        "url": "https://aava.platform"
    },
    license_info={
        "name": "Proprietary",
        "identifier": "Proprietary"
    },
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "docExpansion": "list",
        "filter": True,
        "showCommonExtensions": True,
        "deepLinking": True,
        "displayRequestDuration": True,
        "persistAuthorization": True,
        "tryItOutEnabled": True,
        "syntaxHighlight": {"theme": "monokai"},
        "layout": "BaseLayout",
        "displayOperationId": False,
        "showExtensions": True,
        "showRequestHeaders": True,
        "defaultModelRendering": "model",
        "requestSnippetsEnabled": True,
        "requestSnippets": {
            "generators": {
                "curl_bash": {"title": "cURL (bash)"},
                "curl_powershell": {"title": "cURL (PowerShell)"},
                "curl_cmd": {"title": "cURL (CMD)"}
            },
            "defaultExpanded": True,
            "languages": None
        }
    },
    swagger_ui_init_oauth={
        "usePkceWithAuthorizationCodeGrant": True
    }
)

# Update FastAPI app to include tags metadata
app.openapi_tags = tags_metadata

# Add security scheme for JWT
def custom_openapi():
    """Custom OpenAPI schema with JWT Bearer authentication."""
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Define JWT Bearer authentication scheme
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter your JWT token in the format: `<token>`"
        }
    }
    
    # Apply security to all endpoints except health checks and docs
    public_paths = ["/health", "/docs", "/redoc", "/openapi.json"]
    
    for path, path_item in openapi_schema.get("paths", {}).items():
        is_public = any(path.endswith(public_path) for public_path in public_paths)
        
        for method, operation in path_item.items():
            if method in ["get", "post", "put", "patch", "delete", "options", "head"]:
                if is_public:
                    operation["security"] = []
                else:
                    operation["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# ==================== MIDDLEWARE SETUP ====================
# Exception handler (outermost - catches all errors)
app.add_exception_handler(Exception, exception_handler(app))

# JWT Authentication
setup_jwt_middleware(app)

# Logging middleware
setup_logging_middleware(app)

# Application Insights middleware (BEFORE CORS)
app.add_middleware(
    ApplicationInsightsMiddleware,
    service_name="aava-core-platform-fileindexer-aws"
)

# CORS (after Application Insights)
cors_origins = getattr(settings, 'CORS_ALLOWED_ORIGINS', '*').split(",") if hasattr(settings, 'CORS_ALLOWED_ORIGINS') else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Bedrock-specific API routes
app.include_router(bedrock_router)
app.include_router(swagger_router, prefix="/fileindexer/bedrock/v1")

# Instrument FastAPI app for Application Insights
instrument_fastapi_app(app)

logger.info("Application startup: FastAPI app initialized with Application Insights middleware")

# To run this service:
#   uvicorn main:app --reload
# The configuration, logging, and tracing will be set up automatically.