# fileindexer-bedrock Microservice Documentation

---

## Overview

fileindexer-bedrock is a microservice designed to ingest, index, and process files using AWS Bedrock for embedding and Amazon S3 for storage. It exposes RESTful APIs for file ingestion, metadata extraction, embedding generation, and integration with the core fileindexer system. The service is built for scalability, security, and extensibility, supporting enterprise-grade document management and semantic search.

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Integrations](#integrations)
- [API Endpoints](#api-endpoints)
- [Configurations](#configurations)
- [Environment Variables](#environment-variables)
- [Packages Used](#packages-used)
- [Logical Architecture](#logical-architecture)
- [Dataflow Diagram](#dataflow-diagram)
- [Sequence Diagrams](#sequence-diagrams)
- [Error Handling](#error-handling)
- [Security](#security)
- [Deployment](#deployment)
- [Extensibility](#extensibility)
- [Testing](#testing)
- [Logging & Monitoring](#logging--monitoring)
- [Troubleshooting](#troubleshooting)
- [Changelog](#changelog)
- [Contributing](#contributing)
- [License](#license)

---

## Architecture

The microservice is built using FastAPI and follows a modular, layered architecture:

- **API Layer**: Handles HTTP requests, authentication, and validation.
- **Service Layer**: Business logic for file ingestion, processing, and orchestration.
- **Integration Layer**: Connects to AWS S3, Bedrock, ChromaDB, and the core orchestrator.
- **Persistence Layer**: Handles metadata and embedding storage.
- **Config Layer**: Manages environment variables and runtime configuration.

### Key Components

- `main.py`: FastAPI app entrypoint.
- `app/api/`: API route definitions.
- `app/services/`: Business logic for file processing, embedding, and storage.
- `app/core/`: Configuration, logging, and error handling.
- `app/interfaces/`: Data models and interface definitions.

---

## Integrations

- **AWS Bedrock**: For embedding and vector storage.
- **Amazon S3**: For file storage and retrieval.
- **fileindexer-core**: For orchestration, notifications, and metadata sync.
- **ChromaDB**: For vector storage and semantic search.
- **Authentication**: AWS IAM credentials for secure access.
- **Monitoring**: Integrates with AWS CloudWatch and X-Ray.

---

## API Endpoints

### File Ingestion

- `POST /files/ingest`
  - **Description**: Ingest a new file from Amazon S3.
  - **Request Body**:
    ```json
    {
      "s3_url": "s3://<bucket>/<file>",
      "metadata": { "source": "user-upload", "tags": ["contract", "2025"] }
    }
    ```
  - **Response**:
    ```json
    {
      "status": "success",
      "file_id": "def456",
      "message": "File ingested and indexed."
    }
    ```
  - **Errors**: 400 (validation), 401 (auth), 500 (internal)

### File Metadata

- `GET /files/{file_id}/metadata`
  - **Description**: Retrieve metadata for a specific file.
  - **Response**:
    ```json
    {
      "file_id": "def456",
      "metadata": { "source": "user-upload", "tags": ["contract", "2025"] },
      "status": "indexed"
    }
    ```

### Search

- `POST /search`
  - **Description**: Search indexed files using text or vector queries.
  - **Request Body**:
    ```json
    {
      "query": "Find all contracts from 2025",
      "top_k": 10
    }
    ```
  - **Response**:
    ```json
    {
      "results": [
        { "file_id": "def456", "score": 0.97, "snippet": "Contract for 2025..." }
      ]
    }
    ```

### Health Check

- `GET /health`
  - **Description**: Service health and readiness probe.
  - **Response**:
    ```json
    { "status": "ok" }
    ```

---

## Configurations

- `.env` and `.env.example`: Define AWS credentials, endpoints, and service configuration.
- `Dockerfile`: Containerization for deployment.
- `requirements.txt`: Python dependencies.
- `main.py`: Entrypoint for the FastAPI application.

---

## Environment Variables

| Variable                | Description                                 | Example Value                                 |
|-------------------------|---------------------------------------------|-----------------------------------------------|
| AWS_ACCESS_KEY_ID       | AWS access key ID                           | <secret>                                      |
| AWS_SECRET_ACCESS_KEY   | AWS secret access key                       | <secret>                                      |
| AWS_REGION              | AWS region                                  | us-east-1                                     |
| S3_BUCKET               | S3 bucket name                              | documents                                     |
| BEDROCK_ENDPOINT        | AWS Bedrock endpoint                        | https://bedrock.us-east-1.amazonaws.com       |
| CHROMADB_URL            | ChromaDB endpoint                           | http://chromadb:8000                          |
| FILEINDEXER_CORE_URL    | Core orchestrator endpoint                  | http://fileindexer-core:8000                  |
| API_KEY                 | API key for authentication                  | <secret>                                      |
| LOG_LEVEL               | Logging level                               | INFO                                          |

---

## Packages Used

- **FastAPI**: API framework.
- **Uvicorn**: ASGI server.
- **boto3**: AWS SDK for Python.
- **langchain**: LLM and embedding orchestration.
- **pydantic**: Data validation.
- **requests**: HTTP client.
- **ChromaDB**: Vector database.
- **pytest**: Testing framework.
- **loguru**: Logging.
- (See requirements.txt for full list.)

---

## Logical Architecture

```mermaid
flowchart TD
    User --> API
    API --> Ingestion
    Ingestion --> S3
    Ingestion --> Bedrock
    Ingestion --> Core
    Ingestion --> ChromaDB
    API --> Auth
```

---

## Dataflow Diagram

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Ingestion
    participant S3
    participant Bedrock
    participant Core
    participant ChromaDB

    User->>API: Upload file
    API->>Ingestion: Validate and process
    Ingestion->>S3: Store file
    Ingestion->>Bedrock: Generate embedding
    Bedrock-->>Ingestion: Embedding result
    Ingestion->>ChromaDB: Store embedding
    ChromaDB-->>Ingestion: Embedding stored
    Ingestion->>Core: Notify core service
    Core-->>Ingestion: Acknowledge
    Ingestion-->>API: Success response
    API-->>User: File indexed
```

---

## Sequence Diagrams

### File Ingestion and Embedding (AWS Bedrock)

```mermaid
sequenceDiagram
    participant User
    participant API
    participant Ingestion
    participant S3
    participant Bedrock
    participant Core
    participant ChromaDB

    User->>API: Upload file
    API->>Ingestion: Validate and process
    Ingestion->>S3: Store file
    Ingestion->>Bedrock: Generate embedding
    Bedrock-->>Ingestion: Embedding result
    Ingestion->>ChromaDB: Store embedding
    ChromaDB-->>Ingestion: Embedding stored
    Ingestion->>Core: Notify core service
    Core-->>Ingestion: Acknowledge
    Ingestion-->>API: Success response
    API-->>User: File indexed
```

---

## Error Handling

- All endpoints return structured error responses with HTTP status codes.
- Common error types: ValidationError, AuthenticationError, StorageError, EmbeddingError.
- Errors are logged with stack traces and correlation IDs for traceability.

**Example Error Response:**
```json
{
  "error": "StorageError",
  "message": "Failed to upload file to S3",
  "code": 500
}
```

---

## Security

- **Authentication**: Supports API key and AWS IAM authentication.
- **Authorization**: Role-based access control (RBAC) for sensitive endpoints.
- **Data Encryption**: Files encrypted at rest in S3.
- **Transport Security**: All APIs served over HTTPS.
- **Audit Logging**: All access and mutation events are logged.

---

## Deployment

### Docker

- Build: `docker build -t fileindexer-bedrock .`
- Run: `docker run --env-file .env -p 8000:8000 fileindexer-bedrock`

### Kubernetes

- Deploy using Helm charts or Kubernetes manifests.
- Configure secrets using Kubernetes Secrets or AWS Secrets Manager.

### AWS ECS/EKS

- Deploy container image to AWS ECS or EKS.

---

## Extensibility

- Add new file processors by extending the `app/services/file_processing.py` module.
- Integrate additional storage backends by implementing the storage interface.
- Add new API endpoints by creating new route modules in `app/api/`.

---

## Testing

- Unit tests in `tests/app/services/` and `tests/app/api/`.
- Run tests: `pytest`
- Use `pytest-cov` for coverage reports.
- Mock AWS and ChromaDB dependencies for isolated testing.

---

## Logging & Monitoring

- Uses `loguru` for structured logging.
- Logs include request IDs, timestamps, and error details.
- Integrates with AWS CloudWatch and X-Ray for metrics and distributed tracing.
- Health and readiness endpoints for liveness probes.

---

## Troubleshooting

- Check logs for error messages and stack traces.
- Verify environment variables and AWS credentials.
- Use `/health` endpoint to check service status.
- Ensure network connectivity to S3, Bedrock, and ChromaDB.

---