# KB Upload Automation

A two-script pipeline for bulk-uploading knowledge base (KB) documents into **MongoDB Atlas** (as vector embeddings) and generating the corresponding **PostgreSQL** insert statements — with an automated **watch-folder daemon** that ties both steps together.

---

## Project Structure

```
scripts/
├── kb_watcher.sh                        # Watch-folder daemon (Step 0 → 1 → 2 → 3)
├── KB_Collection.xlsx                   # Input Excel template
├── User_Realm_Check/
│   ├── user_realm_check.py              # Script 1 — RBAC validation
│   ├── requirements.txt                 # Dependencies for Script 1
│   ├── KB_Collection.xlsx               # Sample input
│   ├── README.md
│   └── EXAMPLES.md
└── kb_upload_mongo/
    └── kb_upload_mongo_script.py        # Script 2 — MongoDB ingestion + Postgres SQL generation
```

---

## Overview

| Step | Script | What it does |
|------|--------|-------------|
| 1 | `user_realm_check.py` | Validates each row in the Excel file against the RBAC PostgreSQL DB — checks realm existence, user existence, and realm membership. Writes `realm_id`, `user_id`, and `validation_status` back into the Excel file. |
| 2 | `kb_upload_mongo_script.py` | Reads the validated Excel, chunks each document, generates embeddings (AWS Bedrock or Azure OpenAI), inserts vectors into MongoDB Atlas, and generates a ready-to-run `.sql` file for PostgreSQL. |
| 0 | `kb_watcher.sh` | Daemon that syncs an S3 inbox, then runs Steps 1 and 2 automatically for every new `.xlsx` file it finds. |

---

## Prerequisites

- Python 3.9+
- PostgreSQL client (`psql`) installed on the machine running the watcher
- AWS CLI configured (for S3 sync and Bedrock embeddings, if used)
- MongoDB Atlas cluster with a vector search index named `vector_index`
- A `kb_backdoor_config_donotuse_as_kb` document seeded in MongoDB (see [Configuration Seeding](#configuration-seeding))

---

### Watcher (`kb_watcher.sh`)

| Variable | Description |
|----------|-------------|
| `POLL_INTERVAL` | Seconds between S3 sync + inbox scans (e.g. `60`) |
| `PG_HOST`, `PG_PORT`, `PG_DB`, `PG_USER`, `PG_PASSWORD` | Passed directly to Script 1 |

---

## Input Excel Format

The input file must contain a sheet named **`Upload Config`** with the following columns:

| Column | Required | Description |
|--------|----------|-------------|
| `realm_name` | ✅ | Name of the realm |
| `user_mail` | ✅ | Email of the uploading user |
| `collection_name` | ✅ | Unique name for the KB collection |
| `collection_description` | ✅ | Description of the collection |
| `file_name` | ✅ | Filename only — full path is constructed from `FILE_LOCATION_PREFIX` |
| `embedding_model` | ✅ | e.g. `amazon.titan-embed-text-v1` or `text-embedding-ada-002` |
| `split_size` | ❌ | Chunk size in tokens (default from MongoDB config) |
| `overlap` | ❌ | Chunk overlap in tokens (default from MongoDB config) |
| `ParentDoc` | ❌ | `Yes` to enable parent-doc chunking strategy |
| `parent_split_size` | ❌ | Parent chunk size (must be > `split_size` when `ParentDoc=Yes`) |
| `practice_area` | ❌ | Practice area name (looked up in `rbac.practice_area`) |
| `tags` | ❌ | Tag name (looked up in `rbac.tags`) |

After Script 1 runs, three columns are written back automatically:

| Column | Description |
|--------|-------------|
| `realm_id` | Resolved realm ID |
| `user_id` | Resolved user ID |
| `validation_status` | `PASSED` or `FAILED: <reason>` |

---

## Usage

### Script 1 — RBAC Validation

```bash
python user_realm_check.py \
  --file KB_Collection.xlsx \
  --host <pg-host> \
  --database <pg-db> \
  --user <pg-user> \
  --password <pg-password> \
  --port 5432
```

### Configuration Seeding (run once per MongoDB environment)

```bash
python kb_upload_mongo_script.py --seed-config
```

This inserts the default infrastructure config document into MongoDB. Edit the Azure endpoint/key/deployment fields directly in MongoDB before using Azure embeddings.

### Script 2 — MongoDB Ingestion + SQL Generation

```bash
python kb_upload_mongo_script.py \
  --config KB_Collection.xlsx \
  --sql-output ./kb_insert_queries.sql
```

Files can also be referenced from S3:

```bash
python kb_upload_mongo_script.py \
  --config s3://my-bucket/KB_Collection.xlsx \
  --sql-output ./kb_insert_queries.sql
```

### Apply the Generated SQL

```bash
psql -h <host> -U <user> -d <db> -f kb_insert_queries.sql
```

---

## Running the Watcher

```bash
export POLL_INTERVAL=60
export MONGO_URI="mongodb+srv://..."
export MONGO_DB="mydb"
export FILE_LOCATION_PREFIX="s3://my-bucket/kb-files"
export PG_HOST="..." PG_USER="..." PG_DB="..." PG_PASSWORD="..."

bash kb_watcher.sh
```

The watcher:
1. Syncs `s3://kb-bulk-upload-bucket-prod/inbox` → local `inbox/` folder every `POLL_INTERVAL` seconds
2. For each new `.xlsx` file found, runs Script 1 (RBAC validation), then Script 2 (MongoDB ingestion + SQL generation), then executes the SQL against PostgreSQL
3. Moves files to `processed/` on success or `failed/` on error
4. Cleans up processed files older than 24 hours

---

## Supported File Types

`.txt`, `.pdf`, `.csv`, `.html`, `.docx`, `.doc`, `.xlsx`, `.xls`, `.pptx`, `.ppt`

---

## Supported Embedding Models

| Model ID | Provider | Dimensions |
|----------|----------|------------|
| `amazon.titan-embed-text-v1` | AWS Bedrock | 1536 |
| `amazon.titan-embed-text-v2:0` | AWS Bedrock | 1024 |
| `text-embedding-ada-002` | Azure OpenAI | 1536 |

---

## Notes

- Rows with `validation_status` starting with `FAILED` are automatically skipped during ingestion.
- If all files in a collection fail MongoDB insert, no SQL is generated for that collection.
- A 300 ms delay is applied between embedding calls to avoid Azure rate limits.
- The generated SQL wraps each collection in a `DO $$ ... END $$` block with duplicate-collection-name guards and automatic rollback on error.

