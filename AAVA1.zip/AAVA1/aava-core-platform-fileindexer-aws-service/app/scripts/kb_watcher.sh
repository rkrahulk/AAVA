#!/bin/bash
# =============================================================================
# KB Upload Automation - Watch Folder (S3 Synced + 1hr Cleanup)
# =============================================================================

BASE_DIR="/usr/bin/kb-upload-poc"
INBOX="$BASE_DIR/inbox"
PROCESSING="$BASE_DIR/processing"
PROCESSED="$BASE_DIR/processed"
FAILED="$BASE_DIR/failed"
SQL_DIR="$BASE_DIR/sql"
LOG_DIR="$BASE_DIR/logs"

# S3 Inbox
S3_INBOX="s3://kb-bulk-upload-bucket-prod/inbox"

# Scripts
SCRIPT1="$BASE_DIR/user_realm_check.py"
SCRIPT2="$BASE_DIR/kb_upload_mongo_script_4.py"

# Python venv
VENV="/home/ec2-user/kb_venv/bin/activate"


# =============================================================================

mkdir -p "$INBOX" "$PROCESSING" "$PROCESSED" "$FAILED" "$SQL_DIR" "$LOG_DIR"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

process_file() {
    local file="$1"
    local filename=$(basename "$file")
    local timestamp=$(date '+%Y%m%d_%H%M%S')
    local log_file="$LOG_DIR/${filename%.xlsx}_${timestamp}.log"
    local sql_file="$SQL_DIR/${filename%.xlsx}_${timestamp}.sql"

    log "========================================" | tee -a "$log_file"
    log "Processing: $filename" | tee -a "$log_file"
    log "========================================" | tee -a "$log_file"

    mv "$file" "$PROCESSING/$filename"
    # Remove from S3 inbox if S3 sync is enabled
    if [ -n "$S3_INBOX" ]; then
        s3_key="${S3_INBOX%/}/$filename"
        aws s3 rm "$s3_key" --quiet 2>/dev/null
        log "Removed from S3: $s3_key" | tee -a "$log_file"
    fi

    local work_file="$PROCESSING/$filename"

    source "$VENV"

    # --------------------------------------------------
    # STEP 1: RBAC Validation
    # --------------------------------------------------
    log "STEP 1: Running RBAC validation..." | tee -a "$log_file"

    python "$SCRIPT1" \
        --file "$work_file" \
        --host "$PG_HOST" \
        --port "$PG_PORT" \
        --database "$PG_DB" \
        --user "$PG_USER" \
        --password "$PG_PASSWORD" \
        >> "$log_file" 2>&1

    if [ $? -ne 0 ]; then
        log "STEP 1 FAILED" | tee -a "$log_file"
        mv "$work_file" "$FAILED/$filename"
        return 1
    fi

    log "STEP 1 PASSED" | tee -a "$log_file"

    # --------------------------------------------------
    # STEP 2: MongoDB Insert + SQL Generation
    # --------------------------------------------------
    log "STEP 2: Running MongoDB ingestion..." | tee -a "$log_file"

    python "$SCRIPT2" \
        --config "$work_file" \
        --sql-output "$sql_file" \
        >> "$log_file" 2>&1

    if [ $? -ne 0 ]; then
        log "STEP 2 FAILED" | tee -a "$log_file"
        mv "$work_file" "$FAILED/$filename"
        return 1
    fi

    if [ ! -f "$sql_file" ] || [ ! -s "$sql_file" ]; then
        log "STEP 2 FAILED: SQL not generated" | tee -a "$log_file"
        mv "$work_file" "$FAILED/$filename"
        return 1
    fi

    log "STEP 2 PASSED" | tee -a "$log_file"

    # --------------------------------------------------
    # STEP 3: Execute SQL
    # --------------------------------------------------
    log "STEP 3: Executing SQL..." | tee -a "$log_file"

    PGPASSWORD="$PG_PASSWORD" psql \
        -h "$PG_HOST" \
        -p "$PG_PORT" \
        -U "$PG_USER" \
        -d "$PG_DB" \
        -f "$sql_file" \
        >> "$log_file" 2>&1

    mv "$work_file" "$PROCESSED/${filename%.xlsx}_${timestamp}.xlsx"

    log "COMPLETE: $filename processed successfully" | tee -a "$log_file"
    log "  Log: $log_file"
    log "  SQL: $sql_file"

}

# =============================================================================
# MAIN LOOP
# =============================================================================

log "KB Upload Watcher started"
log "Watching S3: $S3_INBOX"
log "Sync target: $INBOX"
log "Poll interval: ${POLL_INTERVAL}s"
log ""

while true; do

    # --------------------------------------------------
    # STEP 0: Sync S3 → EC2 Inbox
    # --------------------------------------------------
    log "Syncing S3 inbox to EC2..."

    aws s3 sync "$S3_INBOX" "$INBOX" \
        --exclude "*" \
        --include "*.xlsx"

    if [ $? -ne 0 ]; then
        log "WARNING: S3 sync failed"
    else
        log "S3 sync completed"
    fi

    # --------------------------------------------------
    # Process Files
    # --------------------------------------------------
    for file in "$INBOX"/*.xlsx; do
        [ -f "$file" ] || continue

        sleep 2

        size1=$(stat -c%s "$file" 2>/dev/null || echo 0)
        sleep 1
        size2=$(stat -c%s "$file" 2>/dev/null || echo 0)

        if [ "$size1" != "$size2" ]; then
            log "File still uploading: $(basename $file)"
            continue
        fi

        process_file "$file"
    done

    # --------------------------------------------------
    # Cleanup processed folder (older than 1 hour)
    # --------------------------------------------------
    find "$PROCESSED" -type f -name "*.xlsx" -mmin +1440 -exec rm -f {} \;

    sleep "$POLL_INTERVAL"
done