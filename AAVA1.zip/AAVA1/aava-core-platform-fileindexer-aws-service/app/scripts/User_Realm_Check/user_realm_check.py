"""
User and Realm Checking Script (Excel Batch Mode)
Updates KB_Collection.xlsx with realm_id, user_id, and validation_status.
"""

# Run command:   python user_realm_check.py -f KB_Collection.xlsx -H localhost -d rbac_db -u postgres -p admin123

import psycopg2
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
import sys
import argparse
import os

class UserRealmChecker:
    def __init__(self, host, database, user, password, port=5432):
        self.host = host
        self.database = database
        self.user = user
        self.password = password
        self.port = port
        self.conn = None
        self.results = []

    def connect(self):
        try:
            self.conn = psycopg2.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password,
                port=self.port
            )
            print("✓ Successfully connected to PostgreSQL database")
            return True
        except psycopg2.Error as e:
            print(f"✗ Database connection failed: {e}")
            return False

    def close(self):
        if self.conn:
            self.conn.close()
            print("✓ Database connection closed")

    def check_user_realm(self, realm_name, user_mail, collection_name=None, file_names=None):
        cursor = self.conn.cursor()
        result = {
            'user_id': None,
            'realm_id': None,
            'status_message': ''
        }
        try:
            # PART-1: Fetch realm_id
            cursor.execute("SELECT id FROM rbac.realm WHERE realm_name = %s;", (realm_name,))
            realm_row = cursor.fetchone()
            if not realm_row:
                result['status_message'] = f'FAILED: Realm not found: {realm_name}'
                return result
            realm_id = realm_row[0]
            result['realm_id'] = realm_id

            
            # PART-2: Fetch user_id
            cursor.execute("SELECT user_id FROM rbac.users WHERE email = %s;", (user_mail,))
            user_row = cursor.fetchone()
            if not user_row:
                result['status_message'] = f'FAILED: User not found: {user_mail}'
                return result
            user_id = user_row[0]
            result['user_id'] = user_id


            # PART-3: Check membership
            cursor.execute(
                "SELECT COUNT(*) FROM rbac.user_realm WHERE user_id = %s AND realm_id = %s;",
                (user_id, realm_id)
            )
            count = cursor.fetchone()[0]
            if count == 0:
                result['status_message'] = f'FAILED: {realm_name} User {user_mail} is not a member of the realm {realm_name}'
                return result
            

            # PART-4: Check if collection_name exists for this realm (if collection_name is provided)
            if collection_name:
                cursor.execute(
                    "SELECT collection_name FROM core.knowledgebase_collection_mst WHERE collection_name = %s AND realm_id = %s;",
                    (collection_name, realm_id)
                )
                if cursor.fetchone():
                    result['status_message'] = f'FAILED: Collection name already exists: {collection_name}'
                    return result
            # PART-5: Optionally, validate file_names (if provided)
            if file_names:
                # Example: check for duplicate file names in the list
                file_list = [f.strip() for f in file_names if f.strip()]
                if len(file_list) != len(set(file_list)):
                    result['status_message'] = f'FAILED: Duplicate file names in collection: {collection_name}'
                    return result
            result['status_message'] = 'PASSED'
            return result
        

        except psycopg2.Error as e:
            result['status_message'] = f'FAILED: Database error: {str(e)}'
            return result
        finally:
            cursor.close()


def update_excel(file_path, results_list):
    """Updates the existing Excel file with results and formatting."""
    print(f"Updating {file_path}...")
    
    # Load the workbook and select the first sheet
    wb = load_workbook(file_path)
    ws = wb.active

    # Find column indices (1-based for openpyxl)
    header = [cell.value for cell in ws[1]]
    
    def get_col_idx(name):
        try:
            return header.index(name) + 1
        except ValueError:
            # If column doesn't exist, create it at the end
            new_col = len(header) + 1
            ws.cell(row=1, column=new_col).value = name
            header.append(name)
            return new_col

    idx_realm_name = get_col_idx('realm_name')
    idx_user_mail = get_col_idx('user_mail')
    idx_realm_id = get_col_idx('realm_id')
    idx_user_id = get_col_idx('user_id')
    idx_status = get_col_idx('validation_status')
    idx_collection_name = get_col_idx('collection_name')

    # Styles
    pass_fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")  # Green
    fail_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")  # Red
    white_font = Font(color="FFFFFF", bold=True)
    center_align = Alignment(horizontal='center')

    # Update rows (Skip header row 1)
    for row_idx, result in enumerate(results_list, start=2):
        # Update IDs
        ws.cell(row=row_idx, column=idx_realm_id).value = result['realm_id']
        ws.cell(row=row_idx, column=idx_user_id).value = result['user_id']
        
        # Update Status and Formatting
        status_cell = ws.cell(row=row_idx, column=idx_status)
        status_text = result['status_message']
        status_cell.value = status_text
        status_cell.alignment = center_align

        if status_text == "PASSED":
            status_cell.fill = pass_fill
            status_cell.font = white_font
        elif status_text.startswith("FAILED:"):
            status_cell.fill = fail_fill
            status_cell.font = white_font

    # Set column width for status column to be readable
    ws.column_dimensions[ws.cell(row=1, column=idx_status).column_letter].width = 60
    
    wb.save(file_path)
    print(f"✓ File '{file_path}' updated and formatted successfully.")

def main():
    parser = argparse.ArgumentParser(description='User and Realm Checking Script')
    parser.add_argument('-f', '--file', required=True, help='Input Excel file path (e.g., KB_Collection_Input.xlsx)')
    parser.add_argument('-H', '--host', required=True)
    parser.add_argument('-d', '--database', required=True)
    parser.add_argument('-u', '--user', required=True)
    parser.add_argument('-p', '--password', required=True)
    parser.add_argument('--port', type=int, default=5432)

    args = parser.parse_args()

    if not os.path.exists(args.file):
        print(f"Error: File {args.file} not found.")
        sys.exit(1)

    # Read data using pandas for easy iteration
    try:
        df = pd.read_excel(args.file)
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        sys.exit(1)


    required_cols = ['realm_name', 'user_mail', 'collection_name', 'file_names']
    if not all(col in df.columns for col in required_cols):
        print(f"Excel must contain these columns: {required_cols}")
        sys.exit(1)

    checker = UserRealmChecker(
        host=args.host,
        database=args.database,
        user=args.user,
        password=args.password,
        port=args.port
    )

    if not checker.connect():
        sys.exit(1)

    all_results = []
    try:
        for index, row in df.iterrows():
            realm_val = row['realm_name']
            email_val = row['user_mail']
            collection_val = row['collection_name']
            file_names_val = row['file_names']
            if (
                pd.isna(realm_val) or str(realm_val).strip() == "" or
                pd.isna(email_val) or str(email_val).strip() == "" or
                pd.isna(collection_val) or str(collection_val).strip() == "" or
                pd.isna(file_names_val) or str(file_names_val).strip() == ""
            ):
                print(f"Skipping row {index + 1}: Empty realm, email, collection name, or file_names detected.")
                res = {
                    'user_id': None,
                    'realm_id': None,
                    'status_message': 'FAILED: Missing input data'
                }
            else:
                realm = str(realm_val).strip()
                email = str(email_val).strip()
                collection_name = str(collection_val).strip()
                # Accept multiple files separated by comma or semicolon
                file_names = [f.strip() for f in str(file_names_val).replace(';', ',').split(',') if f.strip()]
                print(f"Record {index + 1}: realm_name='{realm}', user_mail='{email}', collection_name='{collection_name}', file_names={file_names}")
                # Check for duplicate collection_name in the DataFrame (case-insensitive)
                duplicate_count = df['collection_name'].str.strip().str.lower().tolist().count(collection_name.lower())
                if duplicate_count > 1:
                    res = {
                        'user_id': None,
                        'realm_id': None,
                        'status_message': 'FAILED: Duplicate knowledge base found'
                    }
                    print(f"Result for row {index + 1}: {res['status_message']}")
                else:
                    res = checker.check_user_realm(realm, email, collection_name, file_names)
                    print(f"Result for row {index + 1}: {res['status_message']}")
            all_results.append(res)

        # Perform the Excel update
        update_excel(args.file, all_results)
    finally:
        checker.close()

if __name__ == "__main__":
    main()