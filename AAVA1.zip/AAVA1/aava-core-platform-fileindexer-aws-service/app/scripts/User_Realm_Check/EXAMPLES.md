# Command Examples - User and Realm Checking Script

## Batch Mode (Excel Input)

### Example 1: Simple batch check with default port
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H localhost -d rbac_db -u postgres -p admin123
```

### Example 2: Using long-form arguments
```powershell
python user_realm_check.py `
  --file KB_Collection.xlsx `
  --host localhost `
  --database rbac_db `
  --user postgres `
  --password admin123
```

### Example 3: Remote database server
```powershell
python user_realm_check.py `
  -f users.xlsx `
  -H 192.168.1.100 `
  -d rbac_db `
  -u dbadmin `
  -p secure_password123 `
  --port 5432
```

### Example 4: Absolute path for input file
```powershell
python user_realm_check.py `
  -f "C:\data\KB_Collection.xlsx" `
  -H db.company.com `
  -d rbac_db `
  -u admin `
  -p password123 `
  --port 5432
```

### Example 5: Custom port
```powershell
python user_realm_check.py -f users.xlsx -H localhost -d rbac_db -u postgres -p admin123 --port 5433
```

## Argument Reference

### Required Arguments
- `-f, --file`: Path to Excel input file (must contain realm_name and user_email columns)
- `-H, --host`: PostgreSQL server address (localhost, IP address, or hostname)
- `-d, --database`: Database name (e.g., "rbac_db")
- `-u, --user`: Database username (e.g., "postgres", "admin")
- `-p, --password`: Database password

### Optional Arguments
- `--port`: PostgreSQL port (default: 5432)

## Input Excel File Format

Your input Excel file should have at least these two columns:

| realm_name | user_email |
|------------|-----------|
| Ascendion | user1@company.com |
| Accenture | user2@company.com |
| Tech | user3@company.com |

## Output

The script will:
1. Display connection status to the database
2. Process each row in the input Excel file
3. Show progress for each realm/user check
4. Update the Excel file with results and formatting:
   - Green cells for PASSED status
   - Red cells for FAILED status
   - White bold font on colored cells
   - Auto-fitted column widths
5. Add or update three columns in the original Excel file:

### Output Excel Columns (Added to Original File)
- **realm_id** - Realm's ID from database (or None if not found)
- **user_id** - User's ID from database (or None if not found)
- **part1_validation_status** - PASSED or FAILED with detailed message (color-coded)

## Common Connection Strings

### localhost (Development)
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H localhost -d rbac_db -u postgres -p admin123
```

### IP Address
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H 192.168.1.100 -d rbac_db -u postgres -p admin123
```

### Domain Name
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H db.domain.com -d rbac_db -u postgres -p admin123
```

### Different Port
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H localhost -d rbac_db -u postgres -p admin123 --port 5433
```

## Python API Usage

You can also use the script programmatically:

```python
from user_realm_check import UserRealmChecker

# Single check
checker = UserRealmChecker(host='localhost', database='rbac_db', user='postgres', password='admin123')
if checker.connect():
    result = checker.check_user_realm('realm_name', 'user@company.com')
    print(result)
    # Output: {'user_id': 123, 'realm_id': 45, 'status_message': 'Passed'}
    checker.close()
```

## Help

To see all available options:
```powershell
python user_realm_check.py --help
```
