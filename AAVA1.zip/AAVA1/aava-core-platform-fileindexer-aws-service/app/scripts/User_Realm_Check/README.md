# User and Realm Checking Script

A Python script to verify if users belong to specific realms in PostgreSQL using batch processing from Excel files and export results to formatted Excel.

## Features

- ✓ Batch processing from Excel input files
- ✓ Connects to PostgreSQL database
- ✓ Performs 3-part verification (Realm → User → User-Realm association)
- ✓ Handles multiple user checks efficiently
- ✓ Exports results to formatted Excel file
- ✓ Color-coded status (Green=PASS, Red=FAIL)
- ✓ Detailed error messages for debugging

## Requirements

- Python 3.7+
- PostgreSQL database with rbac schema

## Installation

### 1. Install Python dependencies:

```bash
pip install -r requirements.txt
```

Or install individually:
```bash
pip install psycopg2-binary pandas openpyxl
```

### 2. Verify Installation

Test the script to see available options:
```bash
python user_realm_check.py --help
```

## Usage

### Batch Mode (Excel Input)

The script reads realm and user data from an Excel file and exports results to an Excel file.

**Excel Input File Format:**
Your input Excel file must contain these columns:
- `realm_name` - Name of the realm
- `user_email` - Email address of the user

**Basic command:**
```powershell
python user_realm_check.py -f input.xlsx -H localhost -d rbac_db -u postgres -p admin123
```

**With custom port:**
```powershell
python user_realm_check.py -f input.xlsx -H localhost -d rbac_db -u postgres -p admin123 --port 5433
```

**Help message:**
```powershell
python user_realm_check.py --help
```

### Arguments Reference

| Argument | Short | Type | Required | Default | Description |
|----------|-------|------|----------|---------|-------------|
| `--file` | `-f` | string | Yes | - | Input Excel file path |
| `--host` | `-H` | string | Yes | - | PostgreSQL host (localhost, IP, or hostname) |
| `--database` | `-d` | string | Yes | - | Database name |
| `--user` | `-u` | string | Yes | - | Database username |
| `--password` | `-p` | string | Yes | - | Database password |
| `--port` | - | integer | No | 5432 | PostgreSQL port |

### Examples

**Example 1: Basic batch check**
```powershell
python user_realm_check.py -f KB_Collection.xlsx -H localhost -d rbac_db -u postgres -p admin123
```

**Example 2: Remote database server**
```powershell
python user_realm_check.py -f "C:\data\users.xlsx" -H 192.168.1.100 -d rbac_db -u dbuser -p secure_pass --port 5432
```

**Example 3: Custom database credentials**
```powershell
python user_realm_check.py -f users.xlsx -H db.domain.com -d rbac_db -u admin -p password --port 5433
```

### Python API Usage

You can also import and use the `UserRealmChecker` class directly in your Python code:

```python
from user_realm_check import UserRealmChecker

# Initialize
checker = UserRealmChecker(
    host='localhost',
    database='rbac_db',
    user='postgres',
    password='admin123',
    port=5432
)

# Connect
if not checker.connect():
    print("Connection failed")
    exit(1)

# Check single user
result = checker.check_user_realm('realm_name', 'user@example.com')
print(result)
# Output: {'user_id': 123, 'realm_id': 45, 'status_message': 'Passed'}

# Close connection
checker.close()
```
checker.close()
```

## Script Logic

### Verification Process

**PART-1: Fetch Realm ID**
```sql
SELECT id FROM rbac.realm WHERE realm_name = ?
```

**PART-2: Fetch User ID**
```sql
SELECT user_id FROM rbac.users WHERE email = ?
```

**PART-3: Verify User-Realm Association**
```sql
SELECT COUNT(*) FROM rbac.user_realm WHERE user_id = ? AND realm_id = ?
```

## Output

### Console Output Example
```
======================================================================
USER AND REALM CHECKING
======================================================================

Checking Realm: Ascendion, User: user@example.com

======================================================================
SUMMARY
======================================================================
Total checks: 1
Passed: 1
Failed: 0
======================================================================

✓ Results exported to 'results.xlsx'
```

### Excel Output

A formatted Excel file with columns:
- **Realm Name** - The realm that was checked
- **User Email** - The user email that was checked
- **User ID** - The database ID of the user (or blank if not found)
- **Realm ID** - The database ID of the realm (or blank if not found)
- **Status** - PASS or FAIL (color-coded: green for PASS, red for FAIL)
- **Message** - Detailed message explaining the result

### Result Messages

- `"User successfully verified in realm"` - User exists in the realm
- `'Realm "{realm_name}" not found'` - Realm does not exist in database
- `'User "{user_email}" not found'` - User does not exist in database
- `'User not part of realm'` - User exists but is not a member of the realm
- `'Database error: ...'` - A database error occurred

## Troubleshooting

### Connection Issues
- Verify PostgreSQL is running
- Check host, port, username, and password
- Ensure database exists

### Input File Issues
- Ensure Excel file has `realm_name` and `user_email` columns
- Check for empty cells or typos

### Database Schema Issues
- Verify rbac schema exists with tables: realm, users, user_realm
- Check column names: id (realm), email (users), user_id and realm_id (user_realm)
- User ID
- Realm ID
- Status (PASS/FAIL) - Color-coded
- Message

## Error Handling

The script provides detailed error messages for:
- Realm not found
- User not found
- User not part of realm
- Database connection errors
- SQL errors

## Note: SQL Server (MSSQL) Alternative

If you need to use SQL Server instead of PostgreSQL:
1. Replace `psycopg2` with `pymssql`
2. Update connection parameters to SQL Server format
3. Adjust SQL syntax if needed (T-SQL)

```bash
pip install pymssql
```

## Troubleshooting

### Connection Refused
- Check PostgreSQL is running
- Verify host, port, credentials
- Ensure database exists

### Module Not Found
```bash
pip install --upgrade psycopg2-binary pandas openpyxl
```

### Permission Denied
- Verify database user has SELECT permissions on rbac tables
- Check schema ownership
