"""
Script 2: insert_from_sheet.py
KB Creation — MongoDB ingestion + Postgres SQL generation.

Reads the validated Excel (from Script 1) which contains realm_id, user_id,
and validation_status columns. Skips rows marked as FAILED.

Usage:
    python insert_from_sheet.py --config kb_upload_template_validated.xlsx
    python insert_from_sheet.py --config s3://bucket/kb_upload_template_validated.xlsx
    python insert_from_sheet.py --seed-config

Env variables:
    MONGO_URI, MONGO_DB, IAM_AUTH_ENABLED, AWS_ROLE_ARN, AWS_REGION

Prerequisites:
    pip install pymongo openpyxl boto3 llama-index llama-index-vector-stores-mongodb \
        llama-index-embeddings-bedrock llama-index-embeddings-azure-openai \
        llama-index-readers-file
"""

import argparse

import json
import logging
import os
import sys
import tempfile
import time   
from datetime import datetime
import subprocess   # new

import boto3
import openpyxl
import pymongo

from llama_index.core import SimpleDirectoryReader
from llama_index.core.node_parser import SentenceSplitter
from llama_index.vector_stores.mongodb import MongoDBAtlasVectorSearch

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

MONGO_URI = os.environ.get("MONGO_URI", "")
MONGO_DB = os.environ.get("MONGO_DB", "")
CONFIG_COLLECTION = "kb_backdoor_config_donotuse_as_kb"
FILE_LOCATION_PREFIX = os.environ.get("FILE_LOCATION_PREFIX", "").strip() # NEW


#PostGres connection details for fetching tag/practice area IDs
PG_HOST = os.environ.get("PG_HOST", "")
PG_PORT = os.environ.get("PG_PORT", "5432")
PG_USER = os.environ.get("PG_USER", "")
PG_DB = os.environ.get("PG_DB", "")
PG_PASSWORD = os.environ.get("PG_PASSWORD", "")

MODEL_REF_MAP = {
    "amazon.titan-embed-text-v1": 1,
    "text-embedding-ada-002": 6,
}

PG_DEFAULTS = {
    "status": "APPROVED",
    "parent_id": -1,
    "version": 1,
    "isactive": True,
    "vector_db": "mongo",
    "source": "backend_Script",
    "function_type": "",
    "methodology": "",
}

DEFAULT_CONFIG = {
    "_id": "prod",
    "mongo_index": "vector_index",
    "default_chunk_size": 5000,
    "default_overlap": 200,
    "default_dimensions": 1536,
    "aws_region": "us-east-1",
    "azure": {
        "endpoint": "https://<resource>.openai.azure.com/",
        "api_key": "<your-azure-api-key>",
        "deployment": "<your-deployment-name>",
        "api_version": "2024-02-01",
    },
    "supported_models": {
        "amazon.titan-embed-text-v1": {"provider": "bedrock", "dimensions": 1536},
        "amazon.titan-embed-text-v2:0": {"provider": "bedrock", "dimensions": 1024},
        "text-embedding-ada-002": {"provider": "azure", "dimensions": 1536},
    },
}


# =============================================================================
# AWS / MONGO HELPERS
# =============================================================================
def validate_env():
    if not MONGO_URI:
        logger.error("MONGO_URI env variable is not set"); sys.exit(1)
    if not MONGO_DB:
        logger.error("MONGO_DB env variable is not set"); sys.exit(1)
    if not FILE_LOCATION_PREFIX:
        logger.error("FILE_LOCATION_PREFIX env variable is not set. This is required to locate your files."); sys.exit(1) # New validation for FILE_LOCATION_PREFIX
    if not PG_HOST or not PG_USER or not PG_DB or not PG_PASSWORD:
        logger.error("Postgres connection details (PG_HOST, PG_USER, PG_DB, PG_PASSWORD) must be set to fetch tag/practice area IDs"); sys.exit(1)

def get_aws_session(config):
    iam_enabled = os.environ.get("IAM_AUTH_ENABLED", "false").lower() == "true"
    region = os.environ.get("AWS_REGION", config.get("aws_region", "us-east-1"))
    if iam_enabled:
        role_arn = os.environ.get("AWS_ROLE_ARN", "")
        logger.info("IAM Auth: assuming role %s", role_arn)
        session = boto3.Session(region_name=region)
        sts = session.client("sts")
        resp = sts.assume_role(RoleArn=role_arn, RoleSessionName="kb-upload-session", DurationSeconds=3600)
        creds = resp["Credentials"]
        return boto3.Session(
            aws_access_key_id=creds["AccessKeyId"],
            aws_secret_access_key=creds["SecretAccessKey"],
            aws_session_token=creds["SessionToken"],
            region_name=region,
        ), creds
    return boto3.Session(region_name=region), None


def get_mongo_client():
    iam_enabled = os.environ.get("IAM_AUTH_ENABLED", "false").lower() == "true"
    if iam_enabled:
        region = os.environ.get("AWS_REGION", "us-east-1")
        role_arn = os.environ.get("AWS_ROLE_ARN", "")
        session = boto3.Session(region_name=region)
        sts = session.client("sts")
        resp = sts.assume_role(RoleArn=role_arn, RoleSessionName="mongo-session", DurationSeconds=3600)
        creds = resp["Credentials"]
        client = pymongo.MongoClient(MONGO_URI, authMechanism="MONGODB-AWS",
            username=creds["AccessKeyId"], password=creds["SecretAccessKey"],
            authMechanismProperties={"AWS_SESSION_TOKEN": creds["SessionToken"]})
    else:
        client = pymongo.MongoClient(MONGO_URI)
    client.admin.command("ping")
    return client


def seed_config():
    validate_env()
    client = get_mongo_client()
    db = client[MONGO_DB]
    if db[CONFIG_COLLECTION].find_one({"_id": "prod"}):
        logger.info("Config already exists. Drop first to re-seed.")
    else:
        db[CONFIG_COLLECTION].insert_one(DEFAULT_CONFIG)
        logger.info("Config seeded. Update azure endpoint/key/deployment with actual values.")
    client.close()


def load_config():
    client = get_mongo_client()
    config = client[MONGO_DB][CONFIG_COLLECTION].find_one({"_id": "prod"})
    client.close()
    if not config:
        logger.error("Config not found. Run: python insert_from_sheet.py --seed-config"); sys.exit(1)
    logger.info("Loaded config from %s.%s", MONGO_DB, CONFIG_COLLECTION)
    return config


def detect_provider(model_name, config):
    supported = config.get("supported_models", {})
    if model_name in supported:
        return supported[model_name]["provider"], supported[model_name]["dimensions"]
    if "titan" in model_name.lower(): return "bedrock", 1536
    if "ada" in model_name.lower() or "text-embedding" in model_name.lower(): return "azure", 1536
    raise ValueError(f"Unknown model: {model_name}")

# =============================================================================
# FILE HANDLING
# =============================================================================
def download_from_s3(s3_path, download_dir, config):
    parts = s3_path.replace("s3://", "").split("/", 1)
    if len(parts) < 2: raise ValueError(f"Invalid S3 path: {s3_path}")
    bucket, key = parts[0], parts[1]
    local_path = os.path.join(download_dir, os.path.basename(key))
    aws_session, _ = get_aws_session(config)
    aws_session.client("s3").download_file(bucket, key, local_path)
    file_size = os.path.getsize(local_path)
    logger.info("Downloaded: %s (%.2f MB)", os.path.basename(key), file_size / (1024*1024))
    return local_path, file_size


def resolve_file(file_location, download_dir, config):
    fl = file_location.strip()
    if fl.startswith("s3://"): return download_from_s3(fl, download_dir, config)
    elif os.path.exists(fl): return fl, os.path.getsize(fl)
    else: raise FileNotFoundError(f"File not found: {fl}")

# =============================================================================
# EXCEL PARSING (reads validated Excel with realm_id, user_id, validation_status)
# =============================================================================
def read_excel_config(excel_path, infra_config):
    wb = openpyxl.load_workbook(excel_path,data_only=True)
    ws = wb["Upload Config"]
    headers = [cell.value for cell in ws[1]]

    try:
        realm_idx = headers.index("realm_id")
        user_idx = headers.index("user_id")
    except ValueError:
        logger.error("Excel headers must contain 'realm_id' and 'user_id'")
        return []

    configs = []
    skipped = 0

    for row in ws.iter_rows(min_row=2, values_only=True):

        raw_realm = str(row[realm_idx] or "").strip()
        raw_user = str(row[user_idx] or "").strip()

        if not raw_realm or not raw_user:
            skipped += 1
            # Silently skip if totally blank, or log if preferred
            continue

        row_dict = {}
        for h, v in zip(headers, row):
            if h: row_dict[h] = v

        file_name = str(row_dict.get("file_name", "")).strip()
        if not file_name:
            continue

        #Constructing file_location dynamically
        prefix = FILE_LOCATION_PREFIX if FILE_LOCATION_PREFIX.endswith(('/', '\\')) else FILE_LOCATION_PREFIX + '/'
        derived_location = prefix + file_name

        # Skip rows that failed validation in Script 1
        validation_status = str(row_dict.get("validation_status", "")).strip()
        if validation_status.startswith("FAILED"):
            skipped += 1
            logger.warning("  Skipping (validation failed): %s - %s",
                           row_dict.get("file_name", ""), validation_status)
            continue

        model = str(row_dict.get("embedding_model", "amazon.titan-embed-text-v1")).strip()
        provider, dimensions = detect_provider(model, infra_config)
        is_parent_doc = str(row_dict.get("ParentDoc", "No")).strip().lower() == "yes"
        split_size = int(row_dict.get("split_size") or infra_config.get("default_chunk_size", 5000))
        overlap = int(row_dict.get("overlap") or infra_config.get("default_overlap", 200))
        parent_split_size = int(row_dict.get("parent_split_size") or 0) if is_parent_doc else 0

        if is_parent_doc and parent_split_size <= split_size:
            raise ValueError(f"parent_split_size ({parent_split_size}) must be > split_size ({split_size}) "
                             f"for '{row_dict.get('collection_name')}'")
        
        practice_id = fetch_practice_area_id(str(row_dict.get("practice_area", "")).strip()) if row_dict.get("practice_area") else None
        tag_id= fetch_tag_id(str(row_dict.get("tags", "")).strip()) if row_dict.get("tags") else []


        configs.append({
            "realm_name": str(row_dict.get("realm_name", "")).strip(),
            "user_mail": str(row_dict.get("user_mail", "")).strip(),
            "realm_id": int(raw_realm),
            "user_id": int(raw_user),
            "collection_name": str(row_dict.get("collection_name", "")).strip(),
            "collection_description": str(row_dict.get("collection_description", "")).strip(),
            "file_name": file_name,
            "file_location": derived_location, # NEW
            "embedding_model": model,
            "provider": provider,
            "dimensions": dimensions,
            "model_ref": MODEL_REF_MAP.get(model, 1),
            "split_size": split_size,
            "is_parent_doc": is_parent_doc,
            "parent_split_size": parent_split_size,
            "overlap": overlap,
            "practice_area": practice_id,
            "tags": tag_id,
        })

    wb.close()
    if skipped:
        logger.info("Skipped %d row(s) due to validation failure or missing realm_id/user_id", skipped)
    return configs

# =============================================================================
# EMBEDDING
# =============================================================================
def get_embedding_model(doc_config, infra_config):
    provider = doc_config["provider"]
    if provider == "bedrock":
        from llama_index.embeddings.bedrock import BedrockEmbedding
        aws_session, _ = get_aws_session(infra_config)
        return BedrockEmbedding(model_name=doc_config["embedding_model"], client=aws_session.client("bedrock-runtime"))
    elif provider == "azure":
        from llama_index.embeddings.azure_openai import AzureOpenAIEmbedding
        az = infra_config.get("azure", {})
        if not az.get("endpoint") or not az.get("api_key") or not az.get("deployment"):
            raise ValueError("Azure config incomplete in _upload_config.")
        return AzureOpenAIEmbedding(model=doc_config["embedding_model"], deployment_name=az["deployment"],
            api_key=az["api_key"], azure_endpoint=az["endpoint"], api_version=az.get("api_version", "2024-02-01"))
    raise ValueError(f"Unsupported provider: {provider}")

# =============================================================================
# CHUNKING
# =============================================================================
def chunk_normal(documents, chunk_size, overlap):
    nodes = SentenceSplitter(chunk_size=chunk_size, chunk_overlap=overlap).get_nodes_from_documents(documents)
    logger.info("  %d chunks (normal, size=%d, overlap=%d)", len(nodes), chunk_size, overlap)
    return nodes

def chunk_parent_doc(documents, split_size, parent_split_size, overlap):
    base_nodes = SentenceSplitter(chunk_size=parent_split_size).get_nodes_from_documents(documents)
    child_parser = SentenceSplitter(chunk_size=split_size, chunk_overlap=overlap)
    all_nodes = []
    for bn in base_nodes:
        for sn in child_parser.get_nodes_from_documents([bn]):
            sn.metadata["parent_text"] = bn.text
            sn.metadata["parent_metadata"] = json.dumps({
                "page_number": bn.metadata.get("page_number"),
                "file_name": bn.metadata.get("file_name"),
            })
            sn.excluded_llm_metadata_keys = list(sn.metadata.keys())
            sn.excluded_embed_metadata_keys = list(sn.metadata.keys())
            all_nodes.append(sn)
    logger.info("  %d child chunks (parent_doc, parent=%d, child=%d)", len(all_nodes), parent_split_size, split_size)
    return all_nodes

# =============================================================================
# MONGODB INSERTION
# =============================================================================
def insert_to_mongo(doc_config, infra_config, nodes, embed_model):
    mongo_index = infra_config.get("mongo_index", "vector_index")
    client = get_mongo_client()
    vs = MongoDBAtlasVectorSearch(mongodb_client=client, db_name=MONGO_DB,
        collection_name=doc_config["collection_name"], index_name=mongo_index)

    try:
        vs.create_vector_search_index(dimensions=doc_config["dimensions"], path="embedding", similarity="cosine")
        logger.info("  Vector index created (%d dims)", doc_config["dimensions"])
    except Exception as e:
        if "already exists" in str(e).lower(): logger.info("  Vector index already exists")
        else: logger.warning("  Index warning: %s", e)

    logger.info("  Embedding %d nodes (%s)...", len(nodes), doc_config["embedding_model"])
    for i, node in enumerate(nodes):
        node.embedding = embed_model.get_text_embedding(node.get_content(metadata_mode="all"))
        if (i + 1) % 50 == 0: logger.info("    %d/%d", i + 1, len(nodes))
        time.sleep(0.3)  # 300ms delay to avoid Azure rate limit

    logger.info("  Inserting into %s.%s ...", MONGO_DB, doc_config["collection_name"])
    vs.add(nodes)
    count = client[MONGO_DB][doc_config["collection_name"]].count_documents({})
    logger.info("  Total docs in collection: %d", count)
    client.close()
    return count

# =============================================================================
# POSTGRES SQL GENERATION
# =============================================================================
def esc(val):
    if val is None: return "NULL"
    if isinstance(val, bool): return "'t'" if val else "'f'"
    if isinstance(val, (int, float)): return str(val)
    s = str(val).strip()
    if s == "" or s == "None": return "NULL"
    return "'" + s.replace("'", "''") + "'"


def generate_collection_sql(cfg, file_results, realm_id, user_id):
    """Generate a single DO $$ block for one collection with validation, insert, and chaining.
    Wrapped in BEGIN/COMMIT so each collection is an independent transaction."""
    d = PG_DEFAULTS
    col_name = cfg["collection_name"]

    lines = []
    lines.append(f"-- ============================================================")
    lines.append(f"-- Collection: {col_name}")
    lines.append(f"-- ============================================================")
    lines.append(f"DO $$")
    lines.append(f"DECLARE")
    lines.append(f"    v_collection_id INTEGER;")
    lines.append(f"    v_count INTEGER;")
    lines.append(f"BEGIN")
    lines.append(f"")
    lines.append(f"    -- Step 1: Validate collection_name uniqueness")
    lines.append(f"    SELECT COUNT(*) INTO v_count FROM core.knowledgebase_collection_mst")
    lines.append(f"    WHERE collection_name = {esc(col_name)};")
    lines.append(f"")
    lines.append(f"    IF v_count > 0 THEN")
    lines.append(f"        RAISE EXCEPTION 'Collection already exists: %', {esc(col_name)};")
    lines.append(f"    END IF;")
    lines.append(f"")
    lines.append(f"    -- Step 2: INSERT KB Master")
    lines.append(f"    INSERT INTO core.knowledgebase_collection_mst (")
    lines.append(f"        collection_name, description, split_size, parent_split_size, model_ref,")
    lines.append(f"        created_date, created_by, approved_by, approved_at, status, parent_id, version, isactive,")
    lines.append(f"        vector_db, realm_id, practice_area, tags, type, function_type, methodology")
    lines.append(f"    ) VALUES (")
    lines.append(f"        {esc(col_name)}, {esc(cfg['collection_description'])}, {esc(cfg['split_size'])}, "
                 f"{esc(cfg['parent_split_size'] if cfg['is_parent_doc'] else None)}, "
                 f"{esc(cfg['model_ref'])},")
    lines.append(f"        NOW(), {esc(user_id)}, {esc(user_id)}, NOW(), {esc(d['status'])}, {esc(d['parent_id'])}, "
                 f"{esc(d['version'])}, {esc(d['isactive'])},")
    lines.append(f"        {esc(d['vector_db'])}, {esc(realm_id)}, {esc(cfg.get('practice_area'))}, "
                 f"{esc(cfg.get('tags'))}, 'normal', NULL, NULL")
    lines.append(f"    ) RETURNING id INTO v_collection_id;")
    lines.append(f"")
    lines.append(f"    RAISE NOTICE 'Created collection [%] with id=%', {esc(col_name)}, v_collection_id;")
    lines.append(f"")

    # Step 3: INSERT transactions for each file
    for fr in file_results:
        if fr["status"] != "OK":
            continue
        lines.append(f"    -- Step 3: INSERT Transaction for file: {fr['file_name']}")
        lines.append(f"    INSERT INTO core.knowledgebase_collection_transaction (")
        lines.append(f"        collection_id, file_name, file_path, file_size_bytes,")
        lines.append(f"        upload_date, uploaded_by, isactive, source")
        lines.append(f"    ) VALUES (")
        lines.append(f"        v_collection_id, {esc(fr['file_name'])}, {esc(fr['file_path'])}, "
                     f"{esc(fr['file_size_bytes'])},")
        lines.append(f"        NOW(), {esc(user_id)}, {esc(d['isactive'])}, {esc(d['source'])}")
        lines.append(f"    );")
        lines.append(f"")

    # Step 4: INSERT Approval History
    lines.append(f"    -- Step 4: INSERT Approval History")
    lines.append(f"    INSERT INTO core.knowledgebase_collection_mst_approved_history (")
    lines.append(f"        collection_id, collection_name, description, split_size, model_ref, vector_db,")
    lines.append(f"        created_date, created_by, parent_split_size, type, modified_by, modified_at,")
    lines.append(f"        approved_by, approved_at, version, realm_id, parent_id, status,")
    lines.append(f"        practice_area, tags")
    lines.append(f"    ) VALUES (")
    lines.append(f"        v_collection_id, {esc(col_name)}, {esc(cfg['collection_description'])}, "
                 f"{esc(cfg['split_size'])}, {esc(cfg['model_ref'])}, {esc(d['vector_db'])},")
    lines.append(f"        NOW(), {esc(user_id)}, "
                 f"{esc(cfg['parent_split_size'] if cfg['is_parent_doc'] else None)}, "
                 f"'normal', {esc(user_id)}, NOW(),")
    lines.append(f"        {esc(user_id)}, NOW(), {esc(d['version'])}, {esc(realm_id)}, "
                 f"{esc(d['parent_id'])}, {esc(d['status'])},")
    lines.append(f"        {esc(cfg.get('practice_area'))}, {esc(cfg.get('tags'))}")
    lines.append(f"    );")
    lines.append(f"")
    lines.append(f"    RAISE NOTICE 'SUCCESS: Collection [%] fully inserted with id=%', {esc(col_name)}, v_collection_id;")
    lines.append(f"")
    lines.append(f"EXCEPTION")
    lines.append(f"    WHEN raise_exception THEN")
    lines.append(f"        RAISE NOTICE 'SKIPPED: % — %', {esc(col_name)}, SQLERRM;")
    lines.append(f"    WHEN unique_violation THEN")
    lines.append(f"        RAISE NOTICE 'DUPLICATE: Collection [%] already exists in database', {esc(col_name)};")
    lines.append(f"    WHEN OTHERS THEN")
    lines.append(f"        RAISE NOTICE 'FAILED: Collection [%] — Error: %', {esc(col_name)}, SQLERRM;")
    lines.append(f"END $$;")
    lines.append(f"")
    lines.append(f"")

    return "\n".join(lines)

# =============================================================================
# PROCESS ONE COLLECTION
# =============================================================================
def process_collection(col_configs, infra_config, tmp_dir):
    first = col_configs[0]
    col_name = first["collection_name"]
    realm_id = first["realm_id"]
    user_id = first["user_id"]

    logger.info("\n========== Collection: %s (realm=%d, user=%d) ==========", col_name, realm_id, user_id)

    file_results = []
    embed_model = get_embedding_model(first, infra_config)

    for fc in col_configs:
        fname = fc["file_name"]
        logger.info("  File: %s", fname)
        try:
            local_path, file_size = resolve_file(fc["file_location"], tmp_dir, infra_config)
            ext = os.path.splitext(local_path)[1].lower()

            SUPPORTED_TYPES = {
                ".txt", ".pdf", ".csv", ".html",
                ".docx", ".doc",
                ".xlsx", ".xls",
                ".pptx", ".ppt",
            }

            if ext not in SUPPORTED_TYPES:
                raise ValueError(f"Unsupported file type: {ext}. Supported: {', '.join(sorted(SUPPORTED_TYPES))}")

            docs = SimpleDirectoryReader(input_files=[local_path]).load_data()
            logger.info("  Loaded %d page(s)", len(docs))

            if fc["is_parent_doc"]:
                nodes = chunk_parent_doc(docs, fc["split_size"], fc["parent_split_size"], fc["overlap"])
            else:
                nodes = chunk_normal(docs, fc["split_size"], fc["overlap"])

            insert_to_mongo(fc, infra_config, nodes, embed_model)

            file_results.append({"file_name": fname, "file_path": fc["file_location"],
                                 "file_size_bytes": file_size, "chunks": len(nodes), "status": "OK"})

            if fc["file_location"].startswith("s3://") and os.path.exists(local_path):
                os.remove(local_path)
        except Exception as e:
            logger.error("  FAILED: %s - %s", fname, str(e))
            file_results.append({"file_name": fname, "status": "FAILED", "error": str(e)})

    # Only generate SQL if at least one file was successfully inserted into MongoDB
    ok_count = sum(1 for r in file_results if r["status"] == "OK")
    if ok_count == 0:
        logger.warning("  No files succeeded for collection [%s]. Skipping Postgres SQL generation.", col_name)
        return None, file_results

    failed_count = sum(1 for r in file_results if r["status"] == "FAILED")
    if failed_count > 0:
        failed_files = [r["file_name"] for r in file_results if r["status"] == "FAILED"]
        logger.warning("  %d file(s) failed MongoDB insert and will be excluded from Postgres SQL: %s",
                        failed_count, ", ".join(failed_files))

    # Generate single DO $$ block for this collection (only includes OK files)
    sql = generate_collection_sql(first, file_results, realm_id, user_id)
    return sql, file_results

def fetch_tag_id(tag_name):
    """
    Fetches the ID and returns it as a Python list 
    which prints as [ID] (Java-style array).
    """
    #import os

    # Fetch the password from your specific environment variable
    pw = PG_PASSWORD 

    # SQL to get just the ID
    # Note: Variable name here must match the -v flag below
    sql_command = f"SELECT id FROM rbac.tags WHERE name = '{tag_name}';"

    try:
        # Execute psql command
        result = subprocess.run(
            [
                "psql",
                "-h", PG_HOST,
                "-p", PG_PORT,
                "-U", PG_USER,
                "-d", PG_DB,
                "-t", "-A", # -t removes headers, -A removes whitespace
                "-c", sql_command
            ],
            capture_output=True,
            text=True,
            # psql specifically looks for "PGPASSWORD", so we map your 
            # "PG_PASSWORD" to it within the process environment.
            env={**os.environ, "PGPASSWORD": pw} if pw else os.environ
        )

        print(f"Debug: psql return code: {result.returncode}")
        print(result)

        if result.returncode == 0:
            clean_id = result.stdout.strip()
            
            if clean_id:
                # We return a list containing the ID as a string.
                # When you print a Python list, it displays as [value]
                return [int(clean_id)]
            else:
                print(f"Tag '{tag_name}' not found in database.")
                return []
        else:
            return []

    except Exception as e:
        return []
    
def fetch_practice_area_id(practice_area):
    """
    Fetches the ID for a specific practice area and returns it as an integer.
    """
    pw = PG_PASSWORD 

    # Updated query for rbac.practice_area
    sql_command = f"SELECT id FROM rbac.practice_area WHERE name = '{practice_area}';"

    try:
        # Execute psql command
        result = subprocess.run(
            [
                "psql",
                "-h", PG_HOST,
                "-p", PG_PORT,
                "-U", PG_USER,
                "-d", PG_DB,
                "-t", "-A", # -t: tuples only (no headers), -A: unaligned (no padding)
                "-c", sql_command
            ],
            capture_output=True,
            text=True,
            env={**os.environ, "PGPASSWORD": pw} if pw else os.environ
        )

        print(f"Debug: psql return code: {result.returncode}")
        print(result)

        if result.returncode == 0:
            output = result.stdout.strip()
            
            if output:
                return int(output)
            else:
                print(f"Practice area '{practice_area}' not found in database.")
                return None # Or 0, depending on how you want to handle "not found"
        else:
            print(f"Database error: {result.stderr}")
            return None

    except Exception as e:
        print(f"Exception occurred: {e}")
        return None

# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Script 2: KB MongoDB ingestion + Postgres SQL generation")
    parser.add_argument("--config", help="S3 or local path to validated Excel")
    parser.add_argument("--seed-config", action="store_true", help="Seed _upload_config collection")
    parser.add_argument("--sql-output", default="./kb_insert_queries.sql", help="SQL output path")
    args = parser.parse_args()

    validate_env()

    if args.seed_config:
        seed_config(); return

    if not args.config:
        parser.error("--config is required")

    infra_config = load_config()

    with tempfile.TemporaryDirectory() as tmp_dir:
        config_path = args.config
        if config_path.startswith("s3://"):
            config_path, _ = download_from_s3(config_path, tmp_dir, infra_config)
        elif not os.path.exists(config_path):
            logger.error("Config not found: %s", config_path); sys.exit(1)

        all_configs = read_excel_config(config_path, infra_config)
        logger.info("Found %d valid file(s) to process", len(all_configs))

        if not all_configs:
            logger.warning("No valid files. Check validation_status in Excel."); sys.exit(0)

        # Group by collection_name
        collections = {}
        for cfg in all_configs:
            if not cfg["collection_name"]:
                logger.error("collection_name is required"); sys.exit(1)
            collections.setdefault(cfg["collection_name"], []).append(cfg)

        logger.info("Processing %d collection(s)\n", len(collections))

        all_sql = [f"-- KB Creation SQL — Generated {datetime.now().isoformat()}\n",
                   f"-- Each collection is wrapped in a DO $$ block with:\n",
                   f"--   Duplicate collection_name validation\n",
                   f"--   Auto-chained collection_id via RETURNING INTO\n",
                   f"--   Automatic rollback on any error\n",
                   f"-- Run with: psql -h <host> -U <user> -d <db> -f kb_insert_queries.sql\n\n"]
        all_results = []

        for col_name, col_cfgs in collections.items():
            try:
                sql_block, file_results = process_collection(col_cfgs, infra_config, tmp_dir)
                if sql_block is not None:
                    all_sql.append(sql_block)
                else:
                    all_sql.append(f"-- SKIPPED: {col_name} — All files failed MongoDB insert, no Postgres SQL generated\n")
                all_results.extend(file_results)
            except Exception as e:
                logger.error("Collection FAILED: %s - %s", col_name, str(e))
                all_sql.append(f"-- FAILED: {col_name} — {str(e)}\n")
                all_results.append({"file_name": col_name, "status": "FAILED", "error": str(e)})

        # Add summary query at the end
        all_sql.append(f"\n-- ============================================================")
        all_sql.append(f"-- SUMMARY: Check what was inserted in this run")
        all_sql.append(f"-- ============================================================")
        all_sql.append(f"SELECT id, collection_name, status, created_date, created_by")
        all_sql.append(f"FROM core.knowledgebase_collection_mst")
        all_sql.append(f"WHERE created_date > NOW() - INTERVAL '1 hour'")
        all_sql.append(f"AND vector_db = 'mongo'")
        all_sql.append(f"ORDER BY id DESC;")

        with open(args.sql_output, "w") as f:
            f.write("\n".join(all_sql))

        ok = sum(1 for r in all_results if r["status"] == "OK")
        fail = sum(1 for r in all_results if r["status"] == "FAILED")

        logger.info("\n===== UPLOAD SUMMARY =====")
        for r in all_results:
            if r["status"] == "OK":
                logger.info("  OK:     %s (%d chunks, %d bytes)", r["file_name"], r["chunks"], r["file_size_bytes"])
            else:
                logger.info("  FAILED: %s (%s)", r["file_name"], r.get("error", ""))

        logger.info("\nFiles: %d | Success: %d | Failed: %d", len(all_results), ok, fail)
        logger.info("SQL: %s", args.sql_output)
        logger.info("\nNext: Execute %s on the Postgres server.", args.sql_output)


if __name__ == "__main__":
    main()
