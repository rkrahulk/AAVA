from abc import ABC, abstractmethod

class EmbeddingInterface(ABC):
    @abstractmethod
    def create_embedding(self, common_params, embedding_params):
        pass
