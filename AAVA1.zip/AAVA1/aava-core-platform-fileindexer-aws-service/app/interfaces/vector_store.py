from abc import ABC, abstractmethod
from typing import List
from llama_index.core.schema import Document
from llama_index.core import StorageContext, VectorStoreIndex

class VectorStoreInterface(ABC):
    @abstractmethod
    def initialize_store(self, chroma_end_point: str, chroma_port: str, index_collection: str):
        pass

    @abstractmethod
    def create_index(self, vector_store, documents: List, method: str = "normal", **kwargs):
        pass

    def create_index(
        self, 
        vector_store, documents: List[Document], 
        method: str = "normal", 
        **kwargs
    ) -> VectorStoreIndex: # TODO
        """Create vector store index from documents"""
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        if method == "parent_doc_retriever":
            nodes = kwargs.get("nodes")
            if not nodes:
                raise ValueError("Nodes required for parent_doc_retriever method")
            return VectorStoreIndex(
                nodes=nodes,
                storage_context=storage_context,
                show_progress=True
            )
        return VectorStoreIndex.from_documents(
            documents=documents,
            storage_context=storage_context,
            show_progress=True
        )

