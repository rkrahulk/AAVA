from abc import ABC, abstractmethod
from typing import List

class FileProcessingInterface(ABC):
    @abstractmethod
    def get_common_params(self, *args, **kwargs):
        pass

    @abstractmethod
    def generate_file_path(self, file_name: str, service: str, service_params):
        pass

    @abstractmethod
    def get_file_details_azure(self, service: str, service_params) -> List:
        pass

    @abstractmethod
    def get_file_details_github(self, service: str, service_params, path: str = "") -> List:
        pass

    @abstractmethod
    def get_file_details_sharepoint(self, service: str, service_params) -> List:
        pass

    @abstractmethod
    def get_file_details_confluence(self, service: str, service_params) -> List:
        pass

    @abstractmethod
    def get_file_details_database(self, service: str, service_params, **kwargs) -> List:
        pass

    @abstractmethod
    async def get_child_chunks(self, common_params, documents: List, service: str) -> List:
        pass
