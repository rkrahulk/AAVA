from abc import ABC, abstractmethod
from typing import List, Optional
from llama_index.core.schema import Document

class DataIngestionInterface(ABC):
    @abstractmethod
    def read_diff_format_files(self, file_location: str, access_key: str) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_azure(self, params) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_github(self, params, access_key: Optional[str] = None) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_sharepoint(self, params, access_key: Optional[str] = None) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_confluence(self, params, access_key: Optional[str] = None) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_database(self, params, access_key: Optional[str] = None) -> List[Document]:
        pass

    @abstractmethod
    def read_files_from_files(self, params) -> List[Document]:
        pass