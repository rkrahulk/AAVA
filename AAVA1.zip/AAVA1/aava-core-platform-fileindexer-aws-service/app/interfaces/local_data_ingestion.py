from typing import List
from llama_index.core.schema import Document
from app.interfaces.data_ingestion import DataIngestionInterface

class LocalDataIngestionService(DataIngestionInterface):
    def __init__(self, logger=None, settings=None, file_extractor=None):
        self.logger = logger
        self.settings = settings
        self.file_extractor = file_extractor

    def read_diff_format_files(self, file_location: str) -> List[Document]:
        # Implement local file reading logic here
        raise NotImplementedError("Local file ingestion not yet implemented.")

    def read_files_from_azure(self, params):
        raise NotImplementedError("Not supported in LocalDataIngestionService")

    def read_files_from_github(self, params):
        raise NotImplementedError("Not supported in LocalDataIngestionService")

    def read_files_from_sharepoint(self, params):
        raise NotImplementedError("Not supported in LocalDataIngestionService")

    def read_files_from_confluence(self, params):
        raise NotImplementedError("Not supported in LocalDataIngestionService")

    def read_files_from_database(self, params):
        raise NotImplementedError("Not supported in LocalDataIngestionService")
