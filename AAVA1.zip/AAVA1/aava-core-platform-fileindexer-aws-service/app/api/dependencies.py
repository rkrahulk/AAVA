# Dependency overrides and shared FastAPI dependencies for fileindexer service.
