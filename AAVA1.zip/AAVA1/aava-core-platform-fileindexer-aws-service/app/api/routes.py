from app.core.config import settings
import importlib
from typing import Annotated, Dict, Any, List, Optional
from fastapi import APIRouter, Request, Depends, HTTPException, Header
from .models import (
    CommonParams, FileDetail,
    SOURCE_MODELS, BedrockEmbedParams, FilesParams
)
from app.core.exceptions import InvalidServiceException
from app.services.bedrock.file_processing import BedrockFileProcessingService
from app.services.bedrock.embedding import BedrockEmbeddingService
from app.services.bedrock.data_ingestion import RemoteDataIngestionService
from llama_index.core import Settings
from aava.logging.annotation.performance_logging import performance_logging
import httpx
from llama_index.core.schema import Document
from pathlib import Path
import os
import logging
logger = logging.getLogger("fileindexer-bedrock")

router = APIRouter()
file_processing = BedrockFileProcessingService()
embedding_engine = BedrockEmbeddingService(logger, settings)
remote_data_ingestion = RemoteDataIngestionService(logger=logger, settings=settings)

from io import BytesIO
import mimetypes

CONTENT_TYPE_MAPPING = {
    '.pdf': 'application/pdf',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.doc': 'application/msword',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    '.ppt': 'application/vnd.ms-powerpoint',
}

@router.get("/fileindexer/bedrock/v1/health", summary="Health Check",
    description=""" **Comprehensive health check endpoint** that provides deailted information about:
    """, response_description="Detailed health check information",
    tags=["Health & Monitoring"])

async def health_check():
    """
    Check if the Confluence File Indexer service is running.
    """
    return {"status": "healthy"}
  
@router.post("/fileindexer/bedrock/v1/create_files", summary="Creating files from sources", tags=["CreateFile"])
@performance_logging(threshold=int(settings.AAVA_LOGGING_PERFORMANCE_SLOW_THRESHOLD), description="Create files operation")
async def create_files(
    source: Annotated[str, Header()] , 
    request: Request,    
    access_key: Annotated[str | None, Header()] = None,
    common_params: CommonParams = Depends(file_processing.get_common_params),
):
    form_data = await request.form()
    form_dict = dict(form_data.multi_items())

    try:
        embedding_params = BedrockEmbedParams(**form_dict)        
        ingest_source = source.lower()
        logger.info(f"Received ingestion service from header ... {ingest_source}")
        if ingest_source not in SOURCE_MODELS:
            raise HTTPException(status_code=400, detail=f"Invalid source: {ingest_source}")
        ## Handling direct file uploads
        if ingest_source == "files":
            files = form_data.getlist("files")
            if not files:
                raise HTTPException(status_code=400, detail="No files provided")
            
            logger.info(f"Received {len(files)} files for processing")
            for i, file in enumerate(files):
                logger.info(f"File {i+1}: {file.filename} (size: {getattr(file, 'size', 'unknown')})")
            
            source_params = FilesParams(files=files)
        else:
            ## Handling other services normally
            SourceModel = SOURCE_MODELS[ingest_source]
            source_params = SourceModel(**form_dict)

    except KeyError as e:
        logger.error(f"KeyError in parameter processing: {str(e)}")
        raise HTTPException(400, f"Invalid service or embedding type: {str(e)}")
    except ValueError as e:
        logger.error(f"ValueError in parameter processing: {str(e)}")
        raise HTTPException(400, f"Invalid parameters: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error in parameter processing: {str(e)}")
        raise HTTPException(500, f"Internal server error: {str(e)}")

    return await _process_indexing(source, common_params, source_params, embedding_params, access_key)


async def _process_indexing(
    service: str,
    common_params: CommonParams,
    source_params: Any,
    embedding_params,
    access_key: Optional[str] = None
) -> List[FileDetail]:
    """Process indexing based on service type"""
    embedding = embedding_engine.create_embedding(common_params, embedding_params)
    Settings.embed_model = embedding
    Settings.chunk_size = common_params.split_size
    Settings.chunk_overlap = common_params.overlap
    
    

    if service == "files":
        return await _process_local_files(
            source_params=source_params, 
            common_params=common_params,
            embedding_params=embedding_params,
        )

    else:
        return await _process_service_files(
            service=service, 
            source_params=source_params, 
            common_params=common_params,
            embedding_params=embedding_params,
            access_key=access_key, 
        )    
    # return await _process_service_files(service, source_params, common_params, vector_store, access_key)

async def _process_local_files(
    source_params: Any,
    common_params: CommonParams,
    embedding_params: BedrockEmbedParams,
) -> List[FileDetail]:
    """Process local files for indexing; all stored in /tmp with correct file size"""
    tmp_path = Path("/tmp")
    tmp_path.mkdir(exist_ok=True)
    
    final_documents = []
    doc_details = []
    
    for file in source_params.files:
        file_location = tmp_path / file.filename
        try:
            # Read file content
            content = await file.read()

            # Write every file to /tmp
            with open(file_location, "wb") as f:
                f.write(content)

            file_extension = file.filename.split('.')[-1].lower() if '.' in file.filename else ''

            # For text files, decode content
            if file_extension in ['txt', 'md', 'py', 'js', 'html', 'css', 'json', 'xml', 'csv']:
                # Text-based files
                try:
                    text_content = content.decode('utf-8')
                except UnicodeDecodeError:
                    text_content = content.decode('latin-1', errors='ignore')

                doc = Document(
                    text=text_content,
                    metadata={
                        'file_name': Path(file.filename).name,
                        'file_path': str(file_location),
                        'file_size': os.path.getsize(file_location),
                        'content_type': getattr(file, 'content_type', 'unknown'),
                        'source': 'files'
                    }
                )
                final_documents.append(doc)
                doc_details.append(_create_file_detail(doc, source_params, "files"))

            else:
                # Binary files (PDF, DOCX, etc.)
                response = parse_with_tika(str(file_location))
                documents = Document(**response)

                # Ensure metadata has correct filename, path, and size
                documents.metadata['file_name'] = Path(file_location).name
                documents.metadata['file_path'] = str(file_location)
                documents.metadata['file_size'] = os.path.getsize(file_location)

                final_documents.append(documents)
                doc_details.append(_create_file_detail(documents, source_params, "files"))

            try:
                os.remove(file_location)
            except FileNotFoundError:
                pass

        except Exception as e:
            logger.error(f"File processing error: {str(e)}")
            raise

    # Create vector index
    await _create_index(
        documents=final_documents, 
        common_params=common_params,
        embedding_params=embedding_params,
        service='files', 
        )

    return doc_details

def _create_file_detail(document, service_params, service: str) -> FileDetail:
    """Create file detail from document"""
    metadata = document.metadata
    file_name = metadata.get("file_name", "unknown_file") 
    if service =='azure':
        file_path = f"{service_params.container_name}/{file_name}"
    else:
        file_path=document.metadata.get("file_path",file_name)
     
    logger.info(f"Document metadata for service '{service}': {metadata}")
   
    return FileDetail(
        file_name=file_name,
        file_path=file_path,
        file_size=metadata.get("file_size", 0),
        source=service
    )

def get_content_type(filename: str) -> str:
    # Method 1: Use mimetypes library
    detected_type = mimetypes.guess_type(filename)[0]
    if detected_type:
        return detected_type
    
    # Method 2: Use custom mapping
    file_ext = Path(filename).suffix.lower()
    if file_ext in CONTENT_TYPE_MAPPING:
        return CONTENT_TYPE_MAPPING[file_ext]
    
def parse_with_tika(file_path):
    try:
        tika_url = settings.TIKA_URL
        
        # Read file
        file_content = open(file_path, "rb").read()
        logger.info(f"File to parse: {file_path}")
        logger.info(f"File size: {len(file_content)} bytes")
        logger.info(f"File exists: {Path(file_path).exists()}")
        
        # Prepare request
        file_stream = BytesIO(file_content)
        payload = dict(source="file")
        content_type = get_content_type(filename=file_path)
        
        files = [
            ('file', (file_path, file_stream, content_type))
        ]
        
        logger.info(f"Sending request to Tika...")
        resp = httpx.post(
            url=tika_url, 
            data=payload,
            timeout=int(settings.request_timeout),
            files=files, 
        )
        
        logger.info(f"Tika response status: {resp.status_code}")
        
        result = resp.json()
        logger.info(f"Tika response keys: {list(result.keys())}")
        
        return result
        
    except httpx.TimeoutException as e:
        logger.error(f"Tika timeout: {str(e)}")
        return {"error_message": f"Tika timeout: {str(e)}"}
    except Exception as e:
        if logger:
            logger.error(f"Tika error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"An error occurred during file parsing: {e}")



async def _process_service_files(
    service: str,
    source_params: Dict[str, Any],
    common_params: CommonParams,
    embedding_params: BedrockEmbedParams,
    access_key: Optional[str] = None
) -> List[FileDetail]:
    """Process files from external services for indexing"""
    reader_method = f"read_files_from_{service}"
    
    if not hasattr(remote_data_ingestion, reader_method):
        raise InvalidServiceException(service)

    logger.info(f"Calling {reader_method} with source_params type: {type(source_params)}")

    ## Dynamically calling the ingestion method (which calls the API)
    documents = await getattr(remote_data_ingestion, reader_method)(source_params, access_key)

    if service=='azure':
        doc_details = [_create_file_detail(document, source_params, "azure") for document in documents]
    else:
        ## Using stored file details from response
        doc_details = [FileDetail(**fd) for fd in remote_data_ingestion.last_file_details]

    # Index the documents
    await _create_index(
        documents=documents, 
        common_params=common_params,
        embedding_params=embedding_params,
        service=service, 
    )
    return doc_details


async def _create_index(documents, common_params: CommonParams, embedding_params: BedrockEmbedParams, service):
    module = importlib.import_module(f"app.services.VectorAdaptors.{common_params.vector_type}")
    vector_class = getattr(module, "VectorStoreService")
    # MongoDB VectorStoreService requires both common_config and params
    if common_params.vector_type == "mongodb":
        vector_service = vector_class(common_config=common_params, params=embedding_params)
    else:
        vector_service = vector_class(common_config=common_params)
    vector_store = vector_service.initialize_store()

    """Create vector store index"""
    
    logger.info("Starting indexing...")
    if common_params.method == "parent_doc_retriever":
        nodes = await file_processing.get_child_chunks(
            common_params, documents, service
        )
        vector_service.create_index(
            vector_store, 
            documents, 
            method=common_params.method,
            nodes=nodes
        )
    else:
        vector_service.create_index(vector_store, documents)

    logger.info("Indexing completed successfully")