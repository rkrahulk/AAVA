from typing import Optional, List
from pydantic import BaseModel, Field
from fastapi import UploadFile
from app.services.bedrock.db_models import ChromaConfig, MongoDBConfig, OpenSearchConfig

class CommonParams(BaseModel):
    chroma_detail: Optional[ChromaConfig] = None
    open_search_detail: Optional[OpenSearchConfig] = None
    mongodb_detail: Optional[MongoDBConfig] = None
    embedding_model: str = Field("text-embedding-ada-002", description="The name of the embedding model to be used.")
    index_collection: str = Field("my_index", description="Name of the index collection to use in the vector store.")
    overlap: int = Field(50, description="Number of overlapping tokens between chunks.")
    split_size: int = Field(500, description="Size of each text chunk for splitting.")
    parent_split_size: int = Field(1000, description="Parent chunk size in hierarchical chunking.")
    child_split_size: int = Field(250, description="Child chunk size in hierarchical chunking.")
    method: str = Field("normal", description="Text splitting method. Options: 'normal', 'recursive', etc.")
    vector_type: str = Field(..., description="Vector Db Type")

class AzureEmbedParams(BaseModel):
    embedding_deployment_name: str = Field("embedding-deployment", description="Deployment name for the Azure embedding model.")
    embedding_api_version: str = Field("2023-05-15", description="API version to use with Azure OpenAI embedding.")
    embedding_access_key: str = Field("your-azure-access-key", description="Access key for authenticating with Azure OpenAI.")
    embedding_azure_endpoint: str = Field("https://your-resource.openai.azure.com", description="Endpoint for the Azure OpenAI embedding service.")
    embedding_type: str = Field("azure", description="Type of embedding provider. Default is 'azure'.")

class BedrockEmbedParams(BaseModel):
    region: str = Field("us-east-1", description="AWS region for the Bedrock service.")
    access_key_encoded: Optional[str] = Field("QUtJQVNJQVNJ...", description="Base64-encoded AWS access key.")
    secret_key_encoded: Optional[str] = Field("U0VDUkVUU0VDUkVU...", description="Base64-encoded AWS secret key.")
    bedrock_model_id: Optional[str] = Field("amazon.titan-embed-text-v1", description="Model ID to use in Bedrock.")
    embedding_type: str = Field("bedrock", description="Type of embedding provider. Default is 'bedrock'.")

class GoogleEmbedParams(BaseModel):
    gcp_project_id: Optional[str] = Field("my-gcp-project", description="Google Cloud project ID.")
    gcp_location: Optional[str] = Field("us-central1", description="Location/region of the Google Cloud project.")
    embedding_type: str = Field("google", description="Type of embedding provider. Default is 'google'.")

class FilesParams(BaseModel):
    files: List[UploadFile] = Field(..., description="List of files to be uploaded and processed.")

class AzureParams(BaseModel):
    connection_string: str = Field("DefaultEndpointsProtocol=https;AccountName=...;", description="Azure Blob Storage connection string.")
    container_name: str = Field("my-container", description="Name of the Azure Blob Storage container.")

class GithubParams(BaseModel):
    github_token: str = Field("ghp_12345abcde", description="GitHub personal access token.")
    owner: str = Field("openai", description="Owner of the GitHub repository.")
    repo: str = Field("my-repo", description="Name of the GitHub repository.")
    branch: str = Field("main", description="Branch name in the GitHub repository.")

class SharepointParams(BaseModel):
    client_id: str = Field("abc12345-1234-5678-abcd-123456abcdef", description="Client ID for the SharePoint OAuth2 app.")
    client_secret: str = Field("your-client-secret", description="Client secret for the SharePoint OAuth2 app.")
    tenant_id: str = Field("your-tenant-id", description="Tenant ID of the SharePoint organization.")
    sharepoint_site_name: str = Field("mysite", description="Name of the SharePoint site.")
    sharepoint_folder_path: str = Field("/Shared Documents/Reports", description="Path to the folder in SharePoint to access files.")

class ConfluenceParams(BaseModel):
    base_url: str = Field("https://yourcompany.atlassian.net/wiki", description="Base URL of the Confluence instance.")
    api_token: str = Field("your-api-token", description="API token to access Confluence.")
    email: str = Field("user@example.com", description="Email address associated with the Confluence account.")
    space_key: Optional[str] = Field("DEV", description="Confluence space key to query pages from.")
    page_ids: Optional[List[str]] = Field(["123456", "7891011"], description="List of specific Confluence page IDs.")
    cql: Optional[str] = Field("type=page AND title~'Project'", description="CQL (Confluence Query Language) to filter pages.")
    include_attachments: bool = Field(True, description="Whether to include page attachments.")
    max_num_results: Optional[int] = Field(100, description="Maximum number of results to return.")

class DatabaseParams(BaseModel):
    scheme: Optional[str] = Field("postgresql", description="Database scheme (e.g., 'postgresql').")
    host: Optional[str] = Field("localhost", description="Host address of the database server.")
    port: Optional[str] = Field("5432", description="Port number for the database connection.")
    user: Optional[str] = Field("admin", description="Username for the database.")
    password: Optional[str] = Field("securepassword", description="Password for the database.")
    dbname: str = Field("mydatabase", description="Name of the database.")
    query: str = Field("SELECT * FROM users;", description="SQL query to run against the database.")

class FileDetail(BaseModel):
    file_name: str = Field("report.pdf", description="Name of the file.")
    file_path: str = Field("/data/files/report.pdf", description="Path to the file.")
    file_size: Optional[int] = Field(204800, description="Size of the file in bytes.")
    source: str = Field("github", description="Source of the file (e.g., 'github', 'sharepoint').")

# Model mappings
EMBEDDING_MODELS = {
    "AzureOpenAI": AzureEmbedParams,
    "AmazonBedrock": BedrockEmbedParams,
    "Google": GoogleEmbedParams
}

SOURCE_MODELS = {
    "azure": AzureParams,
    "github": GithubParams,
    "sharepoint": SharepointParams,
    "confluence": ConfluenceParams,
    "database": DatabaseParams,
    "files": FilesParams
}
