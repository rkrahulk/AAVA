import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.logger_config import logger, tracer

class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        with tracer.start_as_current_span(f"API {request.method} {request.url.path}"):
            logger.info(f"API Request: {request.method} {request.url.path}")
            logger.debug(f"Headers: {dict(request.headers)}")
            try:
                body = await request.body()
                logger.debug(f"Body: {body.decode('utf-8') if body else '<empty>'}")
            except Exception as e:
                logger.debug(f"Could not read request body: {e}")
            response = await call_next(request)
            duration = (time.time() - start_time) * 1000
            logger.info(f"API Response: {request.method} {request.url.path} - Status {response.status_code} - {duration:.2f}ms")
            return response
