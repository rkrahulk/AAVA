# API initialization for fileindexer service.
# API initialization for fileindexer service.
from .routes import router
# from .swagger import swagger_router


# router.include_router(swagger_router)
