from fastapi import APIRouter, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse,HTMLResponse
from app.api.models import CommonParams 
from fastapi.openapi.docs import get_swagger_ui_html

swagger_router = APIRouter()

# Custom CSS for Professional Swagger UI
SWAGGER_CUSTOM_CSS = """
<style>
    /* Import Professional Font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    /* Main Layout */
    body {
        background: #f8fafc !important;
    }
    
    .swagger-ui {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
        max-width: 1400px !important;
        margin: 0 auto !important;
    }
    
    /* Topbar Styling - Premium Gradient */
    .swagger-ui .topbar {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        padding: 24px 0 !important;
        box-shadow: 0 4px 24px rgba(102, 126, 234, 0.25) !important;
        border-bottom: 1px solid rgba(255,255,255,0.1) !important;
    }
    
    .swagger-ui .topbar .download-url-wrapper {
        display: none !important;
    }
    
    .swagger-ui .topbar-wrapper img[alt="Swagger UI"] {
        content: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="140" height="45" viewBox="0 0 140 45"><text x="10" y="30" font-family="Inter,Arial" font-size="26" font-weight="800" fill="white" letter-spacing="-0.5">AAVA</text><text x="75" y="30" font-family="Inter,Arial" font-size="20" font-weight="500" fill="rgba(255,255,255,0.9)">API</text></svg>') !important;
        height: 45px !important;
    }
    
    /* Info Section - Enhanced */
    .swagger-ui .info {
        margin: 40px 0 !important;
        padding: 32px !important;
        background: white !important;
        border-radius: 16px !important;
        box-shadow: 0 2px 12px rgba(0,0,0,0.06) !important;
        border: 1px solid #e2e8f0 !important;
    }
    
    .swagger-ui .info .title {
        font-size: 2.75rem !important;
        font-weight: 800 !important;
        color: #1a202c !important;
        margin-bottom: 16px !important;
        letter-spacing: -0.5px !important;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        -webkit-background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        background-clip: text !important;
    }
    
    .swagger-ui .info .description {
        font-size: 1.125rem !important;
        color: #64748b !important;
        line-height: 1.75 !important;
        font-weight: 500 !important;
    }
    
    .swagger-ui .info .base-url {
        font-size: 0.95rem !important;
        color: #667eea !important;
        font-weight: 600 !important;
        background: #f1f5f9 !important;
        padding: 12px 16px !important;
        border-radius: 8px !important;
        margin-top: 20px !important;
        border: 1px solid #e2e8f0 !important;
    }
    
    /* Authorization Button - Premium Design */
    .swagger-ui .btn.authorize {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        border: none !important;
        color: white !important;
        padding: 12px 32px !important;
        border-radius: 10px !important;
        font-weight: 700 !important;
        font-size: 0.95rem !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        box-shadow: 0 4px 14px rgba(102, 126, 234, 0.4) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        position: relative !important;
        overflow: hidden !important;
    }
    
    .swagger-ui .btn.authorize::before {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        left: -100% !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent) !important;
        transition: left 0.5s !important;
    }
    
    .swagger-ui .btn.authorize:hover::before {
        left: 100% !important;
    }
    
    .swagger-ui .btn.authorize:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5) !important;
    }
    
    .swagger-ui .btn.authorize svg {
        fill: white !important;
        margin-right: 8px !important;
    }
    
    .swagger-ui .btn.authorize.unlocked {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
    }
    
    /* Operation Tags - Modern Card Design */
    .swagger-ui .opblock-tag {
        border-bottom: none !important;
        padding: 20px 24px !important;
        margin: 32px 0 16px 0 !important;
        background: white !important;
        border-radius: 14px !important;
        border-left: 6px solid #667eea !important;
        box-shadow: 0 2px 10px rgba(0,0,0,0.08) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        border: 1px solid #e2e8f0 !important;
        border-left: 6px solid #667eea !important;
    }
    
    .swagger-ui .opblock-tag:hover {
        transform: translateX(8px) translateY(-2px) !important;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.15) !important;
        border-left-color: #764ba2 !important;
    }
    
    .swagger-ui .opblock-tag-section {
        font-size: 1.65rem !important;
        font-weight: 800 !important;
        color: #1a202c !important;
        letter-spacing: -0.3px !important;
        display: flex !important;
        align-items: center !important;
    }
    
    .swagger-ui .opblock-tag-section::before {
        content: '📋' !important;
        margin-right: 12px !important;
        font-size: 1.5rem !important;
    }
    
    .swagger-ui .opblock-tag small {
        font-size: 0.85rem !important;
        color: #94a3b8 !important;
        font-weight: 500 !important;
        margin-left: 12px !important;
    }
    
    /* Operation Blocks - Enhanced Card Design */
    .swagger-ui .opblock {
        border-radius: 14px !important;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06) !important;
        margin-bottom: 20px !important;
        border: 1px solid #e2e8f0 !important;
        overflow: hidden !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        background: white !important;
    }
    
    .swagger-ui .opblock:hover {
        box-shadow: 0 8px 24px rgba(0,0,0,0.12) !important;
        transform: translateY(-3px) !important;
    }
    
    .swagger-ui .opblock .opblock-summary {
        padding: 18px 24px !important;
        border: none !important;
        align-items: center !important;
    }
    
    .swagger-ui .opblock.opblock-post {
        border-left: 6px solid #10b981 !important;
        background: linear-gradient(to right, rgba(16, 185, 129, 0.03), white) !important;
    }
    
    .swagger-ui .opblock.opblock-post:hover {
        border-left-color: #059669 !important;
    }
    
    .swagger-ui .opblock.opblock-get {
        border-left: 6px solid #3b82f6 !important;
        background: linear-gradient(to right, rgba(59, 130, 246, 0.03), white) !important;
    }
    
    .swagger-ui .opblock.opblock-get:hover {
        border-left-color: #2563eb !important;
    }
    
    .swagger-ui .opblock.opblock-put {
        border-left: 6px solid #f59e0b !important;
        background: linear-gradient(to right, rgba(245, 158, 11, 0.03), white) !important;
    }
    
    .swagger-ui .opblock.opblock-put:hover {
        border-left-color: #d97706 !important;
    }
    
    .swagger-ui .opblock.opblock-delete {
        border-left: 6px solid #ef4444 !important;
        background: linear-gradient(to right, rgba(239, 68, 68, 0.03), white) !important;
    }
    
    .swagger-ui .opblock.opblock-delete:hover {
        border-left-color: #dc2626 !important;
    }
    
    /* HTTP Method Badges - Premium Pills */
    .swagger-ui .opblock .opblock-summary-method {
        border-radius: 8px !important;
        padding: 8px 20px !important;
        font-weight: 800 !important;
        font-size: 0.8125rem !important;
        min-width: 85px !important;
        text-align: center !important;
        box-shadow: 0 3px 8px rgba(0,0,0,0.15) !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        transition: all 0.3s ease !important;
    }
    
    .swagger-ui .opblock .opblock-summary-method:hover {
        transform: scale(1.05) !important;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2) !important;
    }
    
    .swagger-ui .opblock-summary-path {
        font-weight: 600 !important;
        font-size: 1.05rem !important;
        color: #334155 !important;
        font-family: 'Monaco', 'Consolas', monospace !important;
    }
    
    .swagger-ui .opblock-summary-description {
        font-size: 0.95rem !important;
        color: #64748b !important;
        font-weight: 500 !important;
    }
    
    /* Parameters */
    .swagger-ui .parameters-col_description {
        font-size: 1rem !important;
        color: #4a5568 !important;
    }
    
    .swagger-ui table thead tr th {
        background: #f8f9fa !important;
        font-weight: 700 !important;
        color: #1a202c !important;
        padding: 14px !important;
        border-bottom: 2px solid #e2e8f0 !important;
    }
    
    .swagger-ui table tbody tr td {
        padding: 14px !important;
        border-bottom: 1px solid #f1f3f5 !important;
    }
    
    /* Response Section */
    .swagger-ui .responses-inner h4, 
    .swagger-ui .responses-inner h5 {
        font-weight: 700 !important;
        color: #1a202c !important;
        margin: 16px 0 !important;
    }
    
    .swagger-ui .response-col_status {
        font-weight: 700 !important;
        font-size: 1.1rem !important;
    }
    
    /* Models */
    .swagger-ui .model-box {
        border-radius: 8px !important;
        background: #f8f9fa !important;
        border: 1px solid #e2e8f0 !important;
        padding: 16px !important;
    }
    
    .swagger-ui .model-title {
        font-weight: 700 !important;
        color: #1a202c !important;
    }
    
    /* Try it out Button - Premium Design */
    .swagger-ui .try-out__btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 10px 24px !important;
        font-weight: 700 !important;
        font-size: 0.9rem !important;
        box-shadow: 0 3px 10px rgba(102, 126, 234, 0.35) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    .swagger-ui .try-out__btn:hover {
        background: linear-gradient(135deg, #5568d3 0%, #6a41a0 100%) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 16px rgba(102, 126, 234, 0.45) !important;
    }
    
    .swagger-ui .btn.cancel {
        background: #64748b !important;
        color: white !important;
        border-radius: 8px !important;
        padding: 10px 24px !important;
        font-weight: 700 !important;
        transition: all 0.3s ease !important;
    }
    
    .swagger-ui .btn.cancel:hover {
        background: #475569 !important;
        transform: translateY(-1px) !important;
    }
    
    /* Execute Button - Premium Action Button */
    .swagger-ui .btn.execute {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
        color: white !important;
        border: none !important;
        border-radius: 10px !important;
        padding: 14px 40px !important;
        font-weight: 800 !important;
        font-size: 1rem !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        position: relative !important;
        overflow: hidden !important;
    }
    
    .swagger-ui .btn.execute::before {
        content: '▶' !important;
        margin-right: 8px !important;
        font-size: 0.85rem !important;
    }
    
    .swagger-ui .btn.execute:hover {
        transform: translateY(-3px) scale(1.02) !important;
        box-shadow: 0 8px 20px rgba(16, 185, 129, 0.5) !important;
        background: linear-gradient(135deg, #059669 0%, #047857 100%) !important;
    }
    
    .swagger-ui .btn.execute:active {
        transform: translateY(-1px) scale(0.98) !important;
    }
    
    /* Scrollbar Styling */
    ::-webkit-scrollbar {
        width: 12px !important;
        height: 12px !important;
    }
    
    ::-webkit-scrollbar-track {
        background: #f1f3f5 !important;
        border-radius: 10px !important;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        border-radius: 10px !important;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #5568d3 0%, #653a8e 100%) !important;
    }
    
    /* Input Fields - Modern Design */
    .swagger-ui input[type=text],
    .swagger-ui input[type=password],
    .swagger-ui input[type=email],
    .swagger-ui textarea,
    .swagger-ui select {
        border: 2px solid #e2e8f0 !important;
        border-radius: 8px !important;
        padding: 12px 16px !important;
        font-size: 0.95rem !important;
        transition: all 0.3s ease !important;
        background: white !important;
    }
    
    .swagger-ui input[type=text]:focus,
    .swagger-ui input[type=password]:focus,
    .swagger-ui input[type=email]:focus,
    .swagger-ui textarea:focus,
    .swagger-ui select:focus {
        border-color: #667eea !important;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
        outline: none !important;
    }
    
    .swagger-ui textarea {
        font-family: 'Monaco', 'Consolas', monospace !important;
        min-height: 120px !important;
    }
    
    /* Response Section - Enhanced */
    .swagger-ui .responses-wrapper {
        padding: 20px !important;
        background: #f8f9fa !important;
        border-radius: 12px !important;
        margin-top: 20px !important;
    }
    
    .swagger-ui .response {
        border-radius: 10px !important;
        overflow: hidden !important;
        border: 1px solid #e2e8f0 !important;
    }
    
    .swagger-ui .response .response-col_status {
        padding: 12px 16px !important;
        font-weight: 800 !important;
        border-radius: 8px !important;
    }
    
    .swagger-ui .highlight-code {
        background: #1e293b !important;
        border-radius: 8px !important;
        padding: 20px !important;
    }
    
    .swagger-ui .highlight-code code {
        color: #e2e8f0 !important;
        font-family: 'Monaco', 'Consolas', monospace !important;
        font-size: 0.9rem !important;
        line-height: 1.6 !important;
    }
    
    /* Loading Animation */
    .swagger-ui .loading-container {
        animation: fadeIn 0.5s ease-in !important;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    /* Filter Input */
    .swagger-ui .filter-container input {
        border: 2px solid #e2e8f0 !important;
        border-radius: 10px !important;
        padding: 12px 20px !important;
        font-size: 1rem !important;
        width: 100% !important;
        transition: all 0.3s ease !important;
    }
    
    .swagger-ui .filter-container input:focus {
        border-color: #667eea !important;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
    }
    
    /* Schema/Model Section */
    .swagger-ui .model {
        border-radius: 10px !important;
        border: 1px solid #e2e8f0 !important;
        background: white !important;
        padding: 16px !important;
    }
    
    .swagger-ui .model-title {
        font-size: 1.1rem !important;
        font-weight: 700 !important;
        color: #1a202c !important;
        padding: 8px 0 !important;
    }
    
    /* Download Button */
    .swagger-ui .download-contents {
        background: #667eea !important;
        color: white !important;
        border-radius: 8px !important;
        padding: 8px 16px !important;
        font-weight: 600 !important;
        transition: all 0.3s ease !important;
    }
    
    .swagger-ui .download-contents:hover {
        background: #5568d3 !important;
        transform: translateY(-2px) !important;
    }
    
    /* Filter Input */
    .swagger-ui .filter-container input {
        border: 2px solid #e2e8f0 !important;
        border-radius: 8px !important;
        padding: 12px 16px !important;
        font-size: 1rem !important;
        transition: all 0.3s ease !important;
    }
    
    .swagger-ui .filter-container input:focus {
        outline: none !important;
        border-color: #667eea !important;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
    }
</style>
"""

@swagger_router.get("/", include_in_schema=False)
async def redirect_to_custom_docs():
    try:
        return RedirectResponse(url="/fileindexer/bedrock/v1/docs")
    except HTTPException as e:
        return JSONResponse(content={"url": "/fileindexer/bedrock/v1/docs"}, status_code=e.status_code)

@swagger_router.get("/swagger-ui-custom.css", include_in_schema=False)
async def swagger_custom_css():
    """Serve custom CSS for Swagger UI."""
    return HTMLResponse(content=SWAGGER_CUSTOM_CSS, media_type="text/css")
    
@swagger_router.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    """Default Swagger UI documentation."""

    return get_swagger_ui_html(
        openapi_url="/fileindexer/sharepoint/v1/openapi.json",
        title="AAVA Core Platform - API Documentation",
        swagger_ui_parameters={
            "deepLinking": True,
            "displayRequestDuration": True,
            "filter": True,
            "showExtensions": True,
            "showCommonExtensions": True,
            "syntaxHighlight.theme": "monokai",
            "persistAuthorization": True,
            "docExpansion": "none",
            "defaultModelsExpandDepth": 1,
            "defaultModelExpandDepth": 1,
            "displayOperationId": True,
            "tryItOutEnabled": True
        }
    )

@swagger_router.get("/rapidoc", include_in_schema=False)
async def rapidoc_html():
    """
    Serve Rapidoc interactive OpenAPI documentation.
    """
    html_content = """
    <!DOCTYPE html>
    <html>
      <head>
        <title>fileindexer-bedrock-Microservice - Rapidoc</title>
        <meta charset="utf-8"/>
        <script type="module" src="https://unpkg.com/rapidoc/dist/rapidoc-min.js"></script>
        <style>
          body { margin: 0; padding: 0; }
          rapi-doc { width: 100vw; height: 100vh; }
        </style>
      </head>
      <body>
        <rapi-doc
          spec-url="/fileindexer/bedrock/v1/openapi.json"
          render-style="read"
          layout="column"
          theme="dark"
          bg-color="#1e1e1e"
          text-color="#ffffff"
          primary-color="#007acc"
          allow-server-selection="true"
          allow-authentication="true"
          allow-try="true"
          show-header="true"
          show-info="true"
          show-components="true"
          allow-search="true"
          allow-advanced-search="true"
        ></rapi-doc>
      </body>
    </html>
    """
    return HTMLResponse(content=html_content, status_code=200)