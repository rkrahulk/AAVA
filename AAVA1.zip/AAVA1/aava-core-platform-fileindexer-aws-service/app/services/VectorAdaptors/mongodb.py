import logging
import os

from app.services.bedrock.db_models import MongoDBConfig
from app.core.config import settings
from fastapi import HTTPException, status
from app.api.models import CommonParams, BedrockEmbedParams
from app.interfaces.vector_store import VectorStoreInterface
import pymongo
from llama_index.vector_stores.mongodb import MongoDBAtlasVectorSearch
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

logger = logging.getLogger(__name__)


class VectorStoreService(VectorStoreInterface):

    """MongoDB vector adapter supporting both Legacy and Boto3 IAM Auth."""

    def __init__(self, common_config: CommonParams, params: BedrockEmbedParams):

        logger.info("Initializing VectorStoreService")

        try:
            logger.info("Assigning configuration objects")

            self.common_config = common_config
            logger.debug("CommonParams received: %s", common_config)

            self.params = params
            logger.debug("BedrockEmbedParams received: %s", params)

            self.config: MongoDBConfig = common_config.mongodb_detail
            logger.debug("MongoDBConfig extracted: %s", self.config)

            self.logger = logger

            logger.info("VectorStoreService initialized successfully")

        except Exception as e:
            logger.error("VectorStoreService initialization failed: %s", str(e))
            raise HTTPException(detail=str(e), status_code=status.HTTP_400_BAD_REQUEST)


    def _assume_role_credentials(self):

        """Assume the AWS Role and return temporary STS credentials"""

        logger.info("Starting AWS Assume Role process")

        role_arn = settings.AAVA_ASSUME_ROLE_ARN_FILEINDEXER_AZURE

        logger.info("Role ARN: %s", role_arn)
        logger.info("AWS Region from params: %s", self.params.region)

        logger.info("=== AWS Environment Diagnostics ===")

        logger.info("AWS_ROLE_ARN: %s", os.environ.get("AWS_ROLE_ARN", "NOT SET"))
        logger.info("AWS_WEB_IDENTITY_TOKEN_FILE: %s", os.environ.get("AWS_WEB_IDENTITY_TOKEN_FILE", "NOT SET"))
        logger.info("AWS_PROFILE: %s", os.environ.get("AWS_PROFILE", "NOT SET"))
        logger.info("AWS_CONFIG_FILE: %s", os.environ.get("AWS_CONFIG_FILE", "NOT SET"))
        logger.info("AWS_DEFAULT_REGION: %s", os.environ.get("AWS_DEFAULT_REGION", "NOT SET"))
        logger.info("AWS_REGION: %s", os.environ.get("AWS_REGION", "NOT SET"))

        try:

            logger.info("Creating boto3 session")

            if 'AWS_PROFILE' in os.environ:
                logger.info("Removing AWS_PROFILE from environment")
                del os.environ['AWS_PROFILE']

            logger.info("AWS_PROFILE after removal: %s", os.environ.get("AWS_PROFILE", "NOT SET"))

            session = boto3.Session(
                profile_name=None,
                region_name=self.params.region
            )

            logger.info("Boto3 session created successfully")

            logger.info("Fetching session credentials provider")

            credentials = session.get_credentials()

            logger.info("Session credentials provider: %s", credentials)

            logger.info("Creating STS client")

            sts = session.client("sts")

            logger.info("Calling STS get_caller_identity")

            identity = sts.get_caller_identity()

            logger.info(
                "Caller identity verified. Account: %s ARN: %s UserId: %s",
                identity.get("Account"),
                identity.get("Arn"),
                identity.get("UserId"),
            )

            logger.info("Attempting to assume role: %s", role_arn)

            response = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName="fileindexer-aws-session",
                DurationSeconds=3600
            )

            logger.info("Role assumed successfully")

            creds = response["Credentials"]

            logger.debug("Temporary credentials received")

            return creds

        except NoCredentialsError as e:

            logger.error("NO AWS CREDENTIALS FOUND. IRSA may not be working properly")
            logger.error("Error details: %s", str(e))

            raise


    def connect(self):

        """Connect to MongoDB using IAM or Legacy authentication"""

        self.logger.info("========== MongoDB connect() method called ==========")

        try:

            iam_enabled = settings.to_bool("IAM_AUTH_ENABLED")

            self.logger.info("IAM_AUTH_ENABLED value: %s", iam_enabled)

            if not iam_enabled:

                self.logger.info("Using Standard / Legacy MongoDB authentication")

                if settings.MONGODB_USERNAME not in self.config.mongodb_uri:

                    self.logger.info("Injecting username/password into MongoDB URI")

                    mongo_uri = self.config.mongodb_uri.replace(
                        "mongodb+srv://",
                        f"mongodb+srv://{settings.MONGODB_USERNAME}:{settings.MONGODB_PASSWORD}@"
                    )

                else:

                    self.logger.info("Credentials already present in MongoDB URI")

                    mongo_uri = self.config.mongodb_uri

                self.logger.info("Creating MongoDB client with legacy authentication")

                client = pymongo.MongoClient(
                    mongo_uri,
                    tls=True,
                    tlsAllowInvalidCertificates=False
                )

                self.logger.info("MongoDB client created successfully (legacy auth)")

                return client

            self.logger.info("IAM authentication enabled")

            self.logger.info("MongoDB URI: %s", self.config.mongodb_uri)

            self.logger.info("Fetching temporary AWS credentials")

            creds = self._assume_role_credentials()

            self.logger.info("Temporary AWS credentials obtained")

            self.logger.info("Creating MongoDB client using MONGODB-AWS mechanism")

            client = pymongo.MongoClient(
                self.config.mongodb_uri,
                authMechanism="MONGODB-AWS",
                username=creds["AccessKeyId"],
                password=creds["SecretAccessKey"],
                authMechanismProperties={
                    "AWS_SESSION_TOKEN": creds["SessionToken"]
                },
                tls=True,
                tlsAllowInvalidCertificates=False
            )

            self.logger.info("MongoDB client created successfully with IAM authentication")

            return client

        except Exception as e:

            self.logger.error("Failed to connect to MongoDB")

            self.logger.error("Exception type: %s", type(e))
            self.logger.error("Exception message: %s", str(e))
            self.logger.error("Exception args: %s", e.args)

            raise HTTPException(
                detail=f"Failed to connect to MongoDB: {str(e)}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


    def initialize_store(self) -> MongoDBAtlasVectorSearch:

        """Initialize MongoDB vector store"""

        logger.info("Initializing MongoDB Atlas Vector Store")

        try:

            logger.info("Connecting to MongoDB")

            client = self.connect()

            logger.info("MongoDB connection established")

            logger.info("Creating MongoDBAtlasVectorSearch store")

            store = MongoDBAtlasVectorSearch(
                mongodb_client=client,
                db_name=self.config.mongodb_database,
                collection_name=self.config.mongodb_collection,
                index_name=self.config.mongodb_index,
            )

            logger.info(
                "Vector store initialized. DB: %s Collection: %s Index: %s",
                self.config.mongodb_database,
                self.config.mongodb_collection,
                self.config.mongodb_index
            )

            logger.info("Checking if vector search index already exists")

            indexes = client[self.config.mongodb_database][self.config.mongodb_collection].list_search_indexes()

            logger.debug("Existing search indexes retrieved")

            if not any(i["name"] == self.config.mongodb_index for i in indexes):

                logger.warning(
                    "Vector index '%s' not found. Creating new vector search index",
                    self.config.mongodb_index
                )

                store.create_vector_search_index(
                    dimensions=1536,
                    path="embedding",
                    similarity="cosine"
                )

                logger.info("Vector search index successfully created")

            else:
                logger.info("Vector search index '%s' already exists", self.config.mongodb_index)
                store.update_vector_search_index(
                    dimensions=1536,
                    path="embedding",
                    similarity="cosine"
                )

            logger.info("MongoDB Vector Store initialization completed")

            return store

        except Exception as e:

            logger.error("MongoDB initialization error occurred")

            logger.error("Error message: %s", str(e))

            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"MongoDB initialization error: {str(e)}"
            )