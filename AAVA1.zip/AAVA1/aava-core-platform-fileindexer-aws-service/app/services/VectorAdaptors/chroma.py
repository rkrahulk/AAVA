import logging
import chromadb
from app.api.models import CommonParams
from llama_index.vector_stores.chroma import ChromaVectorStore
from app.interfaces.vector_store import VectorStoreInterface


logger = logging.getLogger(__name__)


class VectorStoreService(VectorStoreInterface):

    def __init__(self, common_config: CommonParams):
        self.common_config = common_config
        self.chroma_client = chromadb.HttpClient
        self.config = self.common_config.chroma_detail 
        self.logger = logger     
        
    def connect(self) -> bool:
        try:
            return self.chroma_client(
                host=self.config.chroma_end_point, 
                port=self.config.chroma_port
            )
        except Exception as e:
            logger.error(f"Failed to connect to ChromaDB: {str(e)}")
            raise e

    def initialize_store(self) -> ChromaVectorStore: # TODO
        """Initialize ChromaDB vector store"""
        try:
            client = self.connect()
            collection = client.get_or_create_collection(
                name=self.common_config.index_collection,
                metadata={"hnsw:space": "cosine"}
            )
            return ChromaVectorStore(chroma_collection=collection)
        except Exception as e:
            self.logger.error(f"ChromaDB initialization error: {str(e)}")
            raise e
