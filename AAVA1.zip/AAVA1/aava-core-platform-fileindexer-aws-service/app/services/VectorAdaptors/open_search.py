import logging
from fastapi import HTTPException, status
from app.api.models import CommonParams
from app.interfaces.vector_store import VectorStoreInterface
from app.services.bedrock.db_models import OpenSearchConfig
from requests_aws4auth import AWS4Auth
from opensearchpy import OpenSearch 
from llama_index.vector_stores.opensearch import (
    OpensearchVectorStore,
    OpensearchVectorClient,
)

from opensearchpy import RequestsHttpConnection

logger = logging.getLogger(__name__)

class VectorStoreService(VectorStoreInterface):
    """AWS OpenSearch vector adapter."""
    def __init__(self, common_config: CommonParams):
        try:
            self.common_config = common_config
            self.config = common_config.open_search_detail
        except Exception as e:
            raise HTTPException(
                detail=str(e),
                status_code=status.HTTP_400_BAD_REQUEST
            )

    def create_collection(self, opensearch_client, **kwargs) -> bool:
        """Create a new OpenSearch index with vector settings."""
        
        # Index settings for k-NN
        settings = {
            "settings": {
                "index": {
                    "knn": True,
                    "knn.algo_param.ef_search": kwargs.get("ef_search", 512)
                }
            },
            "mappings": {
                "properties": {
                    "id": {
                        "type": "keyword"
                    },
                    "vector": {
                        "type": "knn_vector",
                        "dimension": self.config.os_dimension,
                        "method": {
                            "name": "hnsw",
                            "space_type": kwargs.get("space_type", "cosinesimil"),
                            "engine": "faiss",
                            "parameters": {
                                "ef_construction": kwargs.get("ef_construction", 512),
                                "m": kwargs.get("m", 16)
                            }
                        }
                    },
                    "content": {
                        "type": "text"
                    },
                    "metadata": {
                        "type": "object",
                        "enabled": True
                    }
                }
            }
        }
        
        # Create index
        opensearch_client.indices.create(index=self.common_config.index_collection, body=settings)
 

    def get_or_create_index(self, auth):

        opensearch_client = OpenSearch(
            hosts=[{"host": self.config.os_host.split("//")[-1], "port": self.config.os_port}],
            http_auth=auth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection,
        )
        self.client = opensearch_client
        if not opensearch_client.indices.exists(self.common_config.index_collection):
            try:
                self.create_collection(opensearch_client=opensearch_client)
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail = str(e)
                )


    def connect(self):
        """Connect to AWS OpenSearch."""
        try:
            auth = None
            
            # Setup authentication - prioritize basic auth, then AWS IAM

            auth = AWS4Auth(
                self.config.os_aws_access_key,
                self.config.os_aws_secret_access_key,
                self.config.os_region,
                'es'
            )


            self.get_or_create_index(auth=auth)

            return OpensearchVectorClient(
                endpoint=f"{self.config.os_host}",
                index=self.common_config.index_collection,
                dim=self.config.os_dimension,
                http_auth=auth,
                use_ssl=self.config.os_use_ssl,
                verify_certs=self.config.os_verify_certs,
                connection_class=RequestsHttpConnection
            )    
            
        except Exception as e:
            raise HTTPException(
                detail=f"Failed to connect to AWS OpenSearch: {str(e)}",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


    def initialize_store(self): # TODO
        """Initialize ChromaDB vector store"""
        try:
            client = self.connect()
            return OpensearchVectorStore(client)
        except Exception as e:
            logger.error(f"ChromaDB initialization error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"ChromaDB initialization error: {str(e)}"
            )