from typing import Optional
from pydantic import BaseModel

class ChromaConfig(BaseModel):
    chroma_end_point: str
    chroma_port: str

class OpenSearchConfig(BaseModel):
    os_host: str
    os_port: str
    os_region: str
    os_aws_access_key: str
    os_aws_secret_access_key: str
    os_dimension: str
    os_http_auth: Optional[str] =None
    os_use_ssl: Optional[str] = None
    os_verify_certs: Optional[str] = None

class MongoDBConfig(BaseModel):
    mongodb_uri: str
    mongodb_database: str
    mongodb_collection: str
    mongodb_index: str

class VectorConfigFactory:
    def __init__(self, config, _type):
        self.config = config
        self.vector_type = _type
    
    def get_vector_config(self):
        if self.vector_type == "chroma":
            return ChromaConfig(**self.config)
        elif self.vector_type == "open_search":
            return OpenSearchConfig(**self.config)