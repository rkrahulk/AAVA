from app.interfaces.data_ingestion import DataIngestionInterface
from typing import List, Optional
from llama_index.core.schema import Document
from app.api.models import AzureParams, ConfluenceParams, FilesParams, SharepointParams,DatabaseParams, GithubParams
from app.interfaces.data_ingestion import DataIngestionInterface
import httpx
from llama_index.readers.azstorage_blob import AzStorageBlobReader
import asyncio
from app.core.exceptions import FileProcessingException
from azure.storage.blob import BlobServiceClient


class RemoteDataIngestionService(DataIngestionInterface):
    def __init__(self, logger=None, settings=None, file_extractor=None):
        self.logger = logger
        self.settings = settings
        self.file_extractor = file_extractor
    
    def read_diff_format_files(self, file_location: str):
        raise NotImplementedError("Not supported in AzureDataIngestionService")

    async def read_files_from_azure(self, params: AzureParams, access_key: str) -> List[Document]:
        if self.logger:
            self.logger.info(f"Reading files from Azure Blob Storage: container={params.container_name}")
            self.logger.debug(f"Params: {params}")
        try:
            self.logger.debug("Initializing AzStorageBlobReader")
            loader = AzStorageBlobReader(
                container_name=params.container_name,
                connection_string=params.connection_string,
                file_extractor=self.file_extractor,
            )

            self.logger.debug("Calling loader.load_data() asynchronously using to_thread()")
            documents = await asyncio.to_thread(loader.load_data)
            # Get blob client to fetch file sizes
            blob_service_client = BlobServiceClient.from_connection_string(params.connection_string)
            container_client = blob_service_client.get_container_client(params.container_name)
            
            # Create a mapping of file names to sizes
            blob_sizes = {}
            for blob in container_client.list_blobs():
                blob_sizes[blob.name] = blob.size

            # Add file size to document metadata
            for doc in documents:
                file_name = doc.metadata.get("file_name")
                if file_name and file_name in blob_sizes:
                    doc.metadata["file_size"] = blob_sizes[file_name]

            if self.logger:
                self.logger.info(f"Successfully read {len(documents)} documents from Azure Blob Storage")
                self.logger.debug(f"Document metadata: {[doc.metadata for doc in documents]}")
            return documents
        except Exception as e:
            if self.logger:
                self.logger.error(f"Azure Blob Storage error: {str(e)}")
            raise FileProcessingException(str(e))
    

    async def read_files_from_github(self, service_params: GithubParams, access_key: Optional[str] = None) -> List[Document]:
        """
        Makes POST request to ingestion API and returns list of Document objects.
        """
        try:
            payload = service_params.model_dump()
            header = {"accept": "application/json", "content-type": "application/json"}

            # Handle JWT Access Key if enabled
            jwt_enabled = False
            if hasattr(self.settings, "to_bool"):
                jwt_enabled = self.settings.to_bool("AAVA_SECURITY_JWT_ENABLED")
            elif hasattr(self.settings, "AAVA_SECURITY_JWT_ENABLED"):
                jwt_enabled = bool(self.settings.AAVA_SECURITY_JWT_ENABLED)

            if access_key is not None and jwt_enabled:
                header["access-key"] = access_key

            async with httpx.AsyncClient(timeout=int(self.settings.request_timeout)) as client: # TODO: check timeout
                response = await client.post(
                    url=self.settings.github_ingestion_api_url,
                    json=payload,
                    headers=header
                )
                response.raise_for_status()
                result = response.json()

                documents = [Document(**doc) for doc in result["documents"]]
                self.last_file_details = result["file_details"]
                return documents

        except Exception as e:
            self.logger.error("Error calling Github ingestion API")
            raise RuntimeError(f"Github Ingestion API failed: {e}")
        except httpx.ReadTimeout:
            self.logger.error("Github Ingestion API timed out")
            raise RuntimeError("Github Ingestion API timed out after 60 seconds")

    async def read_files_from_sharepoint(self, service_params: SharepointParams, access_key: Optional[str] = None) -> List[Document]:
        """
        Makes POST request to ingestion API and returns list of Document objects.
        """
        try:
            payload = service_params.model_dump()
            header = {"accept": "application/json", "content-type": "application/json"}

            # Handle JWT Access Key if enabled
            jwt_enabled = False
            if hasattr(self.settings, "to_bool"):
                jwt_enabled = self.settings.to_bool("AAVA_SECURITY_JWT_ENABLED")
            elif hasattr(self.settings, "AAVA_SECURITY_JWT_ENABLED"):
                jwt_enabled = bool(self.settings.AAVA_SECURITY_JWT_ENABLED)

            if access_key is not None and jwt_enabled:
                header["access-key"] = access_key

            async with httpx.AsyncClient(timeout=int(self.settings.request_timeout)) as client: # TODO: check timeout
                response = await client.post(
                    url=self.settings.sharepoint_ingestion_api_url,
                    json=payload,
                    headers=header
                )
                response.raise_for_status()
                result = response.json()

                documents = [Document(**doc) for doc in result["documents"]]
                self.last_file_details = result["file_details"]
                return documents

        except Exception as e:
            self.logger.error("Error calling Sharepoint ingestion API")
            raise RuntimeError(f"Sharepoint Ingestion API failed: {e}")
        except httpx.ReadTimeout:
            self.logger.error("Sharepoint Ingestion API timed out")
            raise RuntimeError("Sharepoint Ingestion API timed out after 60 seconds")

    async def read_files_from_confluence(self, service_params: ConfluenceParams, access_key: Optional[str] = None) -> List[Document]:
        """
        Makes POST request to ingestion API and returns list of Document objects.
        """
        try:
            payload = service_params.model_dump()
            header = {"accept": "application/json", "content-type": "application/json"}

            # Handle JWT Access Key if enabled
            jwt_enabled = False
            if hasattr(self.settings, "to_bool"):
                jwt_enabled = self.settings.to_bool("AAVA_SECURITY_JWT_ENABLED")
            elif hasattr(self.settings, "AAVA_SECURITY_JWT_ENABLED"):
                jwt_enabled = bool(self.settings.AAVA_SECURITY_JWT_ENABLED)

            if access_key is not None and jwt_enabled:
                header["access-key"] = access_key

            async with httpx.AsyncClient(timeout=int(self.settings.request_timeout)) as client: # TODO: check timeout
                response = await client.post(
                    url=self.settings.confluence_ingestion_api_url,
                    json=payload,
                    headers=header
                )
                response.raise_for_status()
                result = response.json()

                documents = [Document(**doc) for doc in result["documents"]]
                self.last_file_details = result["file_details"]
                return documents

        except Exception as e:
            self.logger.error("Error calling Confluence ingestion API")
            raise RuntimeError(f"Confluence Ingestion API failed: {e}")
        except httpx.ReadTimeout:
            self.logger.error("Confluence Ingestion API timed out")
            raise RuntimeError("Confluence Ingestion API timed out after 60 seconds")
        

    async def read_files_from_database(self, service_params: DatabaseParams, access_key: Optional[str] = None) -> List[Document]:
        """
        Makes POST request to ingestion API and returns list of Document objects.
        """
        try:
            payload = service_params.model_dump()
            header = {"accept": "application/json", "content-type": "application/json"}

            # Handle JWT Access Key if enabled
            jwt_enabled = False
            if hasattr(self.settings, "to_bool"):
                jwt_enabled = self.settings.to_bool("AAVA_SECURITY_JWT_ENABLED")
            elif hasattr(self.settings, "AAVA_SECURITY_JWT_ENABLED"):
                jwt_enabled = bool(self.settings.AAVA_SECURITY_JWT_ENABLED)

            if access_key is not None and jwt_enabled:
                header["access-key"] = access_key

            async with httpx.AsyncClient(timeout=int(self.settings.request_timeout)) as client: # TODO: check timeout
                response = await client.post(
                    url=self.settings.database_ingestion_api_url,
                    json=payload,
                    headers=header
                )
                response.raise_for_status()
                result = response.json()

                documents = [Document(**doc) for doc in result["documents"]]
                self.last_file_details = result["file_details"]
                return documents

        except Exception as e:
            self.logger.error("Error calling Database ingestion API")
            raise RuntimeError(f"Database Ingestion API failed: {e}")
        except httpx.ReadTimeout:
            self.logger.error("Database Ingestion API timed out")
            raise RuntimeError("Database Ingestion API timed out after 60 seconds")


    async def read_files_from_files(self, service_params: FilesParams, access_key:str) -> List[Document]:
        """
        Read and process uploaded files directly for AWS Bedrock service
        """
        # Add tracing if you have it set up
        # with tracer.start_as_current_span("AWSDataIngestionService.read_files_from_files"):
        self.logger.info(f"Processing {len(service_params.files)} uploaded files")
        
        documents = []
        file_details = []
        
        for file in service_params.files:
            try:
                self.logger.info(f"Processing file: {file.filename}")
                
                # Read file content
                content = await file.read()
                
                # Determine file type and process accordingly
                file_extension = file.filename.split('.')[-1].lower() if '.' in file.filename else ''
                
                if file_extension in ['txt', 'md', 'py', 'js', 'html', 'css', 'json', 'xml', 'csv']:
                    # Text-based files
                    try:
                        text_content = content.decode('utf-8')
                    except UnicodeDecodeError:
                        try:
                            text_content = content.decode('latin-1')
                        except UnicodeDecodeError:
                            self.logger.warning(f"Could not decode {file.filename} as text, skipping")
                            continue
                elif file_extension in ['pdf']:
                    # PDF files - basic handling
                    text_content = f"PDF file: {file.filename} (content extraction requires PDF parser)"
                    self.logger.info(f"PDF file detected: {file.filename}. Consider implementing PDF text extraction.")
                elif file_extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp']:
                    # Image files - basic handling
                    text_content = f"Image file: {file.filename} (OCR not implemented)"
                    self.logger.info(f"Image file detected: {file.filename}. Consider implementing OCR.")
                elif file_extension in ['doc', 'docx']:
                    # Word documents - basic handling
                    text_content = f"Word document: {file.filename} (content extraction requires docx parser)"
                    self.logger.info(f"Word document detected: {file.filename}. Consider implementing docx text extraction.")
                else:
                    # Unknown file type, try to read as text
                    try:
                        text_content = content.decode('utf-8')
                    except UnicodeDecodeError:
                        text_content = f"Binary file: {file.filename} (content not readable as text)"
                        self.logger.warning(f"Binary file detected: {file.filename}. Content may not be properly extracted.")
                
                # Create document
                doc = Document(
                    text=text_content,
                    metadata={
                        'file_name': file.filename,
                        'file_path': file.filename,
                        'file_size': len(content),
                        'content_type': getattr(file, 'content_type', 'unknown'),
                        'source': 'files'
                    }
                )
                documents.append(doc)
                
                # Store file details
                file_details.append({
                    'file_name': file.filename,
                    'file_path': file.filename,
                    'file_size': len(content),
                    'source': 'files'
                })
                
                self.logger.info(f"Successfully processed file: {file.filename} ({len(content)} bytes)")
                
            except Exception as e:
                self.logger.error(f"Error processing file {file.filename}: {str(e)}")
                # Continue processing other files even if one fails
                continue
            finally:
                # Reset file pointer for potential future reads
                try:
                    await file.seek(0)
                except:
                    pass  # Some file types might not support seek
        
        self.last_file_details = file_details
        
        self.logger.info(f"Successfully processed {len(documents)} out of {len(service_params.files)} files")
        return documents