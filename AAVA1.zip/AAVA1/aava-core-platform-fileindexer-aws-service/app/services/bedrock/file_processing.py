from typing import List, Optional
from fastapi import Form
from app.api.models import CommonParams
from app.interfaces.file_processing import FileProcessingInterface
from llama_index.core.node_parser import SentenceSplitter
import json
from llama_index.core.schema import Document
from app.core.config import settings
from app.services.bedrock.db_models import ChromaConfig, MongoDBConfig, OpenSearchConfig


class BedrockFileProcessingService(FileProcessingInterface):
    def __init__(self, logger=None, settings=None):
        self.logger = logger
        self.settings = settings

    def get_common_params(
        self,
        embedding_model: str = Form(...),
        chroma_end_point: Optional[str] = Form(None),
        chroma_port: Optional[str] = Form(None),
        index_collection: str = Form(...),
        split_size: Optional[int] = Form(0),
        overlap: Optional[int] = Form(0),
        child_split_size: Optional[int] = Form(0),
        parent_split_size: Optional[int] = Form(0),
        method: str = Form("normal"),
        vector_type: str = Form(settings.VECTOR_TYPE),
        os_host: Optional[str]= Form(None),
        os_port: Optional[str]= Form(None),
        os_region: Optional[str]= Form(None),
        os_aws_access_key: Optional[str]= Form(None),
        os_aws_secret_access_key: Optional[str]= Form(None),
        os_dimension: Optional[str]= Form(None),
        mongodb_uri: Optional[str] = Form(settings.mongo_db_uri),
        mongodb_database: Optional[str] = Form(settings.MONGODB_DATABASE),
        mongodb_index: Optional[str] = Form(settings.MONGODB_INDEX),
    ): 
        chroma_details = None; open_search_details = None; mongodb_detail=None
        if vector_type == "chroma":
            chroma_details = ChromaConfig(
                chroma_end_point= chroma_end_point,
                chroma_port = chroma_port
            )
        elif vector_type == "open_search":
            open_search_details = OpenSearchConfig(
                os_host=os_host,
                os_port=os_port,
                os_region=os_region,
                os_aws_access_key=os_aws_access_key,
                os_aws_secret_access_key=os_aws_secret_access_key,
                os_dimension=os_dimension
            )
        elif vector_type == "mongodb":
            mongodb_detail = MongoDBConfig(
                mongodb_uri=mongodb_uri,
                mongodb_database=mongodb_database,
                mongodb_collection=index_collection,
                mongodb_index=mongodb_index,
            )
        
        common_params_kwargs = dict(
                embedding_model=embedding_model,
                chroma_end_point=chroma_end_point,
                chroma_port=chroma_port,
                index_collection=index_collection,
                overlap=overlap,
                method=method,
                vector_type=vector_type,
                chroma_detail=chroma_details,
                open_search_detail=open_search_details,
                mongodb_detail=mongodb_detail,
            )
        
        if method == "normal" or method == "multi_query":
            return CommonParams(
                **common_params_kwargs,
                split_size=split_size,
            )
        elif method == "parent_doc_retriever":
            return CommonParams(
                **common_params_kwargs,
                child_split_size=child_split_size,
                parent_split_size=parent_split_size,
            )


    async def get_child_chunks(
        self,
        common_params, 
        documents: List[Document], 
        service: str
    ) -> List[Document]:
        """Generate child chunks for parent document retrieval"""
        try:
            node_parser = SentenceSplitter(chunk_size=common_params.parent_split_size)
            base_nodes = node_parser.get_nodes_from_documents(documents=documents)
            sub_node_parser = SentenceSplitter(
                chunk_size=common_params.child_split_size,
                chunk_overlap=common_params.overlap
            )
            all_nodes = []
            for base_node in base_nodes:
                sub_nodes = sub_node_parser.get_nodes_from_documents([base_node])
                for sn in sub_nodes:
                    sn.metadata["parent_text"] = base_node.text
                    parent_metadata = {
                        "page_number": base_node.metadata.get("page_number"),
                        "file_name": base_node.metadata.get("file_name"),
                    }
                    if service == "sharepoint":
                        parent_metadata.update({
                            "url": base_node.metadata.get("url"),
                            "file_id": base_node.metadata.get("file_id"),
                        })
                    sn.metadata["parent_metadata"] = json.dumps(parent_metadata)
                    sn.excluded_llm_metadata_keys = list(sn.metadata.keys())
                    sn.excluded_embed_metadata_keys = list(sn.metadata.keys())
                all_nodes.extend(sub_nodes)
            if self.logger:
                self.logger.info("Child chunks created successfully")
            else:
                print("Child chunks created successfully")
            return all_nodes
        except Exception as e:
            if self.logger:
                self.logger.error(f"Error creating child chunks: {str(e)}")
            else:
                print(f"Error creating child chunks: {str(e)}")
            raise


    def generate_file_path(self, file_name: str, service: str, service_params):
        return file_name

    def get_file_details_azure(self, service: str, service_params):
        raise NotImplementedError("Not supported in BedrockFileProcessingService")

    def get_file_details_github(self, service: str, service_params, path: str = ""):
        raise NotImplementedError("Not supported in BedrockFileProcessingService")

    def get_file_details_sharepoint(self, service: str, service_params):
        raise NotImplementedError("Not supported in BedrockFileProcessingService")

    def get_file_details_confluence(self, service: str, service_params):
        raise NotImplementedError("Not supported in BedrockFileProcessingService")

    def get_file_details_database(self, service: str, service_params, **kwargs):
        raise NotImplementedError("Not supported in BedrockFileProcessingService")