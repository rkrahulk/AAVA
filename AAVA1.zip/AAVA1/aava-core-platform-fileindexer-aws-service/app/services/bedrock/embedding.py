import boto3
from llama_index.embeddings.bedrock import BedrockEmbedding
from app.interfaces.embedding import EmbeddingInterface
from app.api.models import BedrockEmbedParams, CommonParams
from app.services.VectorAdaptors.mongodb import VectorStoreService
import os

class BedrockEmbeddingService(EmbeddingInterface):
    def __init__(self, logger=None, settings=None):
        self.logger = logger
        self.settings = settings

    def create_embedding(self, common_params: CommonParams, params: BedrockEmbedParams) -> BedrockEmbedding:
        use_bedrock_credentials = self.settings.use_bedrock_credentials if self.settings else False
        if self.logger:
            self.logger.debug(f"Params: {params}")
            self.logger.debug(f"Use Bedrock credentials: {use_bedrock_credentials}")
        if use_bedrock_credentials:
            if self.logger:
                self.logger.info("Instantiating BedrockEmbedding with explicit credentials")

            creds = VectorStoreService(common_config=common_params, params=params)._assume_role_credentials()
            
            self.logger.info("AWS_PROFILE value before creating BedrockEmbedding: %s", os.environ.get("AWS_PROFILE", "NOT SET"))

            return BedrockEmbedding(
                model_name=params.bedrock_model_id,
                aws_access_key_id=creds["AccessKeyId"],
                aws_secret_access_key=creds["SecretAccessKey"],
                region_name=params.region,
                aws_session_token=creds["SessionToken"]
            )
        if self.logger:
            self.logger.info("Instantiating BedrockEmbedding with default credentials")
        return BedrockEmbedding(
            model_name=params.bedrock_model_id,
            region_name=params.region,
        )