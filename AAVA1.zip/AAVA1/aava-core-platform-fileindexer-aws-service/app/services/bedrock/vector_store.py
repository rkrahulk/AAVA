from app.interfaces.vector_store import VectorStoreInterface

from abc import ABC, abstractmethod
import chromadb
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import StorageContext, VectorStoreIndex
from llama_index.core.settings import Settings
from llama_index.core.schema import Document
from typing import List


class VectorStoreService(VectorStoreInterface):
    def __init__(self, chroma_client=None, logger=None):
        self.chroma_client = chroma_client or chromadb.HttpClient # Do we only use chroma client?
        # logger should be injected for testability; fallback to print if not provided
        self.logger = logger

    def initialize_store(self, chroma_end_point: str, chroma_port: str, index_collection: str) -> ChromaVectorStore:
        """Initialize ChromaDB vector store"""
        try:
            client = self.chroma_client(
                host=chroma_end_point, 
                port=chroma_port
            )
            collection = client.get_or_create_collection(
                name=index_collection,
                metadata={"hnsw:space": "cosine"}
            )
            return ChromaVectorStore(chroma_collection=collection)
        except Exception as e:
            if self.logger:
                self.logger.error(f"ChromaDB initialization error: {str(e)}")
            else:
                print(f"ChromaDB initialization error: {str(e)}")
            raise

    def create_index(self, vector_store: ChromaVectorStore, documents: List[Document], method: str = "normal", **kwargs) -> VectorStoreIndex:
        """Create vector store index from documents"""
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        if method == "parent_doc_retriever":
            nodes = kwargs.get("nodes")
            if not nodes:
                raise ValueError("Nodes required for parent_doc_retriever method")
            return VectorStoreIndex(
                nodes=nodes,
                storage_context=storage_context,
                show_progress=True
            )
        return VectorStoreIndex.from_documents(
            documents=documents,
            storage_context=storage_context,
            show_progress=True
        )
