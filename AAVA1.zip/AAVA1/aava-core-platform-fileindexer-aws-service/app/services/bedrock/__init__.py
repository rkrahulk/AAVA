# Bedrock-specific service implementations for embedding, file processing, and vector store.
