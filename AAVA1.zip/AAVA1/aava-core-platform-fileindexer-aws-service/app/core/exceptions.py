from fastapi import HTTPException, status

class FileIndexerException(HTTPException):
    def __init__(self, detail: str, status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR):
        super().__init__(status_code=status_code, detail=detail)

class InvalidServiceException(FileIndexerException):
    def __init__(self, service: str):
        super().__init__(detail=f"Unsupported service: {service}", status_code=status.HTTP_400_BAD_REQUEST)

class FileProcessingException(FileIndexerException):
    def __init__(self, error: str):
        super().__init__(detail=f"Failed to process files: {error}")

class DatabaseException(FileIndexerException):
    def __init__(self, error: str):
        super().__init__(detail=f"Database error: {error}")

class ConfluenceException(FileIndexerException):
    def __init__(self, error: str):
        super().__init__(detail=f"Confluence error: {error}")
