# Core initialization for fileindexer service.
