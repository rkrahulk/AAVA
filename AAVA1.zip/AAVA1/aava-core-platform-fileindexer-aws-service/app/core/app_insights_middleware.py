"""
Application Insights Middleware for Correlation Context Management

This middleware ensures that every request has consistent correlation identifiers
and accurate Azure Application Insights metadata including operation context,
request IDs, and duration metrics.
"""

import time
import uuid
import logging
from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

try:
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode
    from opentelemetry.context import attach, detach, get_current
    TELEMETRY_AVAILABLE = True
except ImportError:
    TELEMETRY_AVAILABLE = False

logger = logging.getLogger("fileindexer-aws")


class ApplicationInsightsMiddleware(BaseHTTPMiddleware):
    """
    Middleware that manages Application Insights operation context for each request.
    
    - Pushes operation context before FastAPI handlers execute
    - Refreshes context once the definitive request ID is available
    - Records request duration metrics
    - Ensures consistent correlation identifiers across all telemetry
    """
    
    def __init__(self, app, service_name: str = "aava-core-platform-fileindexer-aws"):
        super().__init__(app)
        self.service_name = service_name
        
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Process each request with proper operation context management.
        """
        start_time = time.time()
        request_id = None
        token = None
        
        if not TELEMETRY_AVAILABLE:
            # If telemetry is not available, just pass through
            return await call_next(request)
        
        try:
            # Generate or extract request ID from headers
            request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
            
            # Get the current tracer
            tracer = trace.get_tracer(__name__)
            
            # Create a new span for this request with the service name
            with tracer.start_as_current_span(
                f"{request.method} {request.url.path}",
                kind=trace.SpanKind.SERVER,
                attributes={
                    "http.method": request.method,
                    "http.url": str(request.url),
                    "http.route": request.url.path,
                    "http.scheme": request.url.scheme,
                    "http.host": request.headers.get("host", "unknown"),
                    "http.user_agent": request.headers.get("user-agent", "unknown"),
                    "request.id": request_id,
                    "service.name": self.service_name,
                    "cloud.role.name": self.service_name,
                    "cloud.role.instance": self.service_name,
                }
            ) as span:
                # Store request ID in request state for access in handlers
                request.state.request_id = request_id
                request.state.operation_id = span.get_span_context().trace_id
                
                try:
                    # Process the request
                    response = await call_next(request)
                    
                    # Record response status
                    span.set_attribute("http.status_code", response.status_code)
                    
                    # Set span status based on HTTP status code
                    if response.status_code >= 500:
                        span.set_status(Status(StatusCode.ERROR))
                    elif response.status_code >= 400:
                        span.set_status(Status(StatusCode.ERROR))
                    else:
                        span.set_status(Status(StatusCode.OK))
                    
                    # Add request ID to response headers
                    response.headers["x-request-id"] = request_id
                    
                    return response
                    
                except Exception as e:
                    # Record exception in span
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    raise
                    
                finally:
                    # Calculate and record duration
                    duration_ms = (time.time() - start_time) * 1000
                    span.set_attribute("http.duration_ms", duration_ms)
                    
                    # Log request completion
                    logger.info(
                        f"Request completed: {request.method} {request.url.path} "
                        f"[{response.status_code if 'response' in locals() else 'error'}] "
                        f"in {duration_ms:.2f}ms - request_id={request_id}"
                    )
                    
        except Exception as e:
            logger.error(f"Error in Application Insights middleware: {e}", exc_info=True)
            # Continue processing even if telemetry fails
            return await call_next(request)


def get_operation_context() -> dict:
    """
    Get the current operation context for correlation.
    
    Returns:
        Dictionary containing operation_id, trace_id, and span_id
    """
    if not TELEMETRY_AVAILABLE:
        return {
            "operation_id": None,
            "trace_id": None,
            "span_id": None,
            "trace_flags": None
        }
    
    try:
        current_span = trace.get_current_span()
        span_context = current_span.get_span_context()
        
        return {
            "operation_id": format(span_context.trace_id, "032x") if span_context.trace_id else None,
            "trace_id": format(span_context.trace_id, "032x") if span_context.trace_id else None,
            "span_id": format(span_context.span_id, "016x") if span_context.span_id else None,
            "trace_flags": span_context.trace_flags if hasattr(span_context, "trace_flags") else None
        }
    except Exception as e:
        logger.warning(f"Failed to get operation context: {e}")
        return {
            "operation_id": None,
            "trace_id": None,
            "span_id": None,
            "trace_flags": None
        }


def create_operation_context(operation_name: str) -> dict:
    """
    Create a new operation context for background workflows or startup operations.
    
    Args:
        operation_name: Name of the operation (e.g., "startup", "config_load")
        
    Returns:
        Dictionary with context token and operation details
    """
    if not TELEMETRY_AVAILABLE:
        return {"token": None, "context": {}}
    
    try:
        tracer = trace.get_tracer(__name__)
        span = tracer.start_span(
            operation_name,
            kind=trace.SpanKind.INTERNAL,
            attributes={
                "operation.name": operation_name,
                "cloud.role.name": "aava-core-platform-fileindexer-aws",
                "cloud.role.instance": "aava-core-platform-fileindexer-aws"
            }
        )
        
        token = trace.set_span_in_context(span)
        context = get_operation_context()
        
        return {
            "token": token,
            "span": span,
            "context": context
        }
    except Exception as e:
        logger.warning(f"Failed to create operation context: {e}")
        return {"token": None, "context": {}}


def close_operation_context(context_info: dict) -> None:
    """
    Close an operation context created with create_operation_context.
    
    Args:
        context_info: Dictionary returned from create_operation_context
    """
    if not TELEMETRY_AVAILABLE or not context_info.get("span"):
        return
    
    try:
        span = context_info.get("span")
        if span:
            span.end()
    except Exception as e:
        logger.warning(f"Failed to close operation context: {e}")
