"""
HTTP Dependency Instrumentation for Application Insights

This module provides resilient HTTP client instrumentation that wraps httpx sync/async calls
and emits HTTP dependency spans with method, URL, and status code classification.
"""

import logging
from typing import Optional

try:
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode, SpanKind
    TELEMETRY_AVAILABLE = True
except ImportError:
    TELEMETRY_AVAILABLE = False

logger = logging.getLogger("fileindexer-aws")


class InstrumentedHttpClient:
    """
    Wrapper for httpx client that automatically creates dependency spans.
    """
    
    def __init__(self, client, service_name: str = "aava-core-platform-fileindexer-aws"):
        """
        Initialize the instrumented HTTP client.
        
        Args:
            client: httpx.Client or httpx.AsyncClient instance
            service_name: Service name for telemetry
        """
        self._client = client
        self._service_name = service_name
        self._tracer = trace.get_tracer(__name__) if TELEMETRY_AVAILABLE else None
    
    def _create_span(self, method: str, url: str):
        """Create a dependency span for HTTP request."""
        if not TELEMETRY_AVAILABLE or not self._tracer:
            return None
            
        return self._tracer.start_as_current_span(
            f"HTTP {method}",
            kind=SpanKind.CLIENT,
            attributes={
                "http.method": method,
                "http.url": str(url),
                "dependency.type": "HTTP",
                "service.name": self._service_name,
            }
        )
    
    def _record_response(self, span, response):
        """Record response details in the span."""
        if not span:
            return
            
        try:
            status_code = response.status_code
            span.set_attribute("http.status_code", status_code)
            
            # Set span status based on HTTP status
            if status_code >= 500:
                span.set_status(Status(StatusCode.ERROR, f"HTTP {status_code}"))
            elif status_code >= 400:
                span.set_status(Status(StatusCode.ERROR, f"HTTP {status_code}"))
            else:
                span.set_status(Status(StatusCode.OK))
        except Exception as e:
            logger.debug(f"Failed to record response in span: {e}")
    
    def _record_exception(self, span, exception):
        """Record exception in the span."""
        if not span:
            return
            
        try:
            span.record_exception(exception)
            span.set_status(Status(StatusCode.ERROR, str(exception)))
        except Exception as e:
            logger.debug(f"Failed to record exception in span: {e}")
    
    def get(self, url, **kwargs):
        """Instrumented GET request."""
        span = self._create_span("GET", url)
        try:
            response = self._client.get(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    def post(self, url, **kwargs):
        """Instrumented POST request."""
        span = self._create_span("POST", url)
        try:
            response = self._client.post(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    def put(self, url, **kwargs):
        """Instrumented PUT request."""
        span = self._create_span("PUT", url)
        try:
            response = self._client.put(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    def delete(self, url, **kwargs):
        """Instrumented DELETE request."""
        span = self._create_span("DELETE", url)
        try:
            response = self._client.delete(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    async def aget(self, url, **kwargs):
        """Instrumented async GET request."""
        span = self._create_span("GET", url)
        try:
            response = await self._client.get(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    async def apost(self, url, **kwargs):
        """Instrumented async POST request."""
        span = self._create_span("POST", url)
        try:
            response = await self._client.post(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    async def aput(self, url, **kwargs):
        """Instrumented async PUT request."""
        span = self._create_span("PUT", url)
        try:
            response = await self._client.put(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    async def adelete(self, url, **kwargs):
        """Instrumented async DELETE request."""
        span = self._create_span("DELETE", url)
        try:
            response = await self._client.delete(url, **kwargs)
            self._record_response(span, response)
            return response
        except Exception as e:
            self._record_exception(span, e)
            raise
        finally:
            if span:
                span.end()
    
    def __getattr__(self, name):
        """Proxy other attributes to the underlying client."""
        return getattr(self._client, name)


def create_instrumented_client(sync: bool = True, **kwargs):
    """
    Create an instrumented httpx client.
    
    Args:
        sync: If True, create sync client; if False, create async client
        **kwargs: Additional arguments to pass to httpx.Client or httpx.AsyncClient
        
    Returns:
        InstrumentedHttpClient wrapping httpx client
    """
    try:
        import httpx
        
        if sync:
            client = httpx.Client(**kwargs)
        else:
            client = httpx.AsyncClient(**kwargs)
            
        return InstrumentedHttpClient(client)
    except ImportError:
        logger.error("httpx not available. Cannot create instrumented client.")
        raise
