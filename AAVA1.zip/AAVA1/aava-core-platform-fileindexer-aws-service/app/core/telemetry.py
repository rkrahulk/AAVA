"""
Application Insights Telemetry Configuration

This module sets up Azure Monitor OpenTelemetry for the application.
It configures automatic instrumentation for FastAPI, HTTP requests, and logging.
Exposes operation_context and global helper functions that guard against missing SDK methods.
"""

import logging
from typing import Optional, Dict, Any

try:
    from azure.monitor.opentelemetry import configure_azure_monitor
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry import trace
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME, SERVICE_INSTANCE_ID
    TELEMETRY_AVAILABLE = True
except ImportError:
    TELEMETRY_AVAILABLE = False
    configure_azure_monitor = None
    FastAPIInstrumentor = None

logger = logging.getLogger("fileindexer-aws")

# Global service identity
SERVICE_IDENTITY = "aava-core-platform-fileindexer-aws"
_telemetry_initialized = False


def setup_application_insights(
    connection_string: str,
    enabled: bool = True,
    sample_rate: float = 1.0,
    disable_telemetry: bool = False,
    log_level: str = "WARNING",
    service_name: str = None
) -> None:
    """
    Configure Application Insights telemetry using Azure Monitor OpenTelemetry.
    
    Args:
        connection_string: Azure Application Insights connection string
        enabled: Whether Application Insights is enabled
        sample_rate: Sampling rate for telemetry (0.0 to 1.0)
        disable_telemetry: If True, disables all telemetry collection
        log_level: Logging level for Application Insights (DEBUG, INFO, WARNING, ERROR)
        service_name: Override service name (defaults to SERVICE_IDENTITY)
    """
    global _telemetry_initialized
    
    # Return early if Application Insights is disabled or telemetry is disabled
    if not enabled or disable_telemetry:
        logger.info("Application Insights is disabled")
        return
    
    # Check if telemetry SDK is available
    if not TELEMETRY_AVAILABLE or configure_azure_monitor is None:
        logger.warning("Azure Monitor OpenTelemetry SDK not available. Telemetry disabled.")
        return
    
    # Validate connection string
    if not connection_string:
        logger.warning("Application Insights connection string is not configured. Telemetry disabled.")
        return
    
    try:
        # Use service identity for cloud role name and instance
        svc_name = service_name or SERVICE_IDENTITY
        
        # Create resource with service identity
        resource = Resource.create({
            SERVICE_NAME: svc_name,
            SERVICE_INSTANCE_ID: svc_name,
            "cloud.role.name": svc_name,
            "cloud.role.instance": svc_name,
        })
        
        # Configure Azure Monitor with OpenTelemetry
        configure_azure_monitor(
            connection_string=connection_string,
            resource=resource,
            logger_name="fileindexer-aws",
            disable_offline_storage=False,
        )
        
        
        # Set logging level for Azure Monitor
        azure_logger = logging.getLogger("azure")
        azure_logger.setLevel(getattr(logging, log_level.upper(), logging.WARNING))
        
        _telemetry_initialized = True
        
        logger.info(
            f"Application Insights configured successfully with sample rate: {sample_rate}, "
            f"service: {svc_name}"
        )
        
    except Exception as e:
        logger.error(f"Failed to configure Application Insights: {e}", exc_info=True)


def instrument_fastapi_app(app) -> None:
    """
    Instrument FastAPI application for automatic telemetry collection.
    
    Args:
        app: FastAPI application instance
    """
    
    if not TELEMETRY_AVAILABLE or FastAPIInstrumentor is None:
        logger.warning("FastAPI instrumentation not available")
        return
        
    try:
        FastAPIInstrumentor.instrument_app(app)
        logger.info("FastAPI instrumentation enabled for Application Insights")
    except Exception as e:
        logger.error(f"Failed to instrument FastAPI app: {e}", exc_info=True)


def get_operation_context():
    """
    Get the current operation context for correlation.
    Guards against missing SDK methods during warm-up.
    
    Returns:
        Dictionary containing operation_id, trace_id, and span_id
    """
    if not TELEMETRY_AVAILABLE or not _telemetry_initialized:
        return {
            "operation_id": None,
            "trace_id": None,
            "span_id": None
        }
    
    try:
        current_span = trace.get_current_span()
        if current_span is None:
            return {
                "operation_id": None,
                "trace_id": None,
                "span_id": None
            }
            
        span_context = current_span.get_span_context()
        
        return {
            "operation_id": format(span_context.trace_id, "032x") if span_context.trace_id else None,
            "trace_id": format(span_context.trace_id, "032x") if span_context.trace_id else None,
            "span_id": format(span_context.span_id, "016x") if span_context.span_id else None,
        }
    except Exception as e:
        logger.debug(f"Failed to get operation context: {e}")
        return {
            "operation_id": None,
            "trace_id": None,
            "span_id": None
        }


def is_telemetry_enabled() -> bool:
    """
    Check if telemetry is enabled and initialized.
    
    Returns:
        True if telemetry is available and initialized
    """
    return TELEMETRY_AVAILABLE and _telemetry_initialized
