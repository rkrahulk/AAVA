"""
Configuration management for fileindexer-bedrock microservice.

- All configuration is loaded from environment variables (.env file) or a configuration service.
- No hardcoded values: defaults should be set in .env, not in code.
- If CONFIG_SERVICE_URL is set, config is fetched from the remote service and overrides .env values.
- If CONFIG_REFRESH_ENABLED is true, config is periodically refreshed from the config service.
- This pattern should be used in all microservices for unified config management.

See .env.example for all available variables and documentation.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
import os
import httpx
import threading
import time
from urllib.parse import quote_plus
import logging
logger = logging.getLogger("fileindexer-aws")

def _get_operation_context():
    """Helper to get operation context for logging correlation."""
    try:
        from app.core.telemetry import get_operation_context
        return get_operation_context()
    except ImportError:
        return {"operation_id": None}

class ServiceSettings(BaseSettings):
    model_config = SettingsConfigDict(extra='allow')
    # Application name
    app_name: str=""

    # Logging level (DEBUG, INFO, WARNING, ERROR)
    log_level: str="INFO"

    confluence_ingestion_api_url:str = "https://aava-dev.avateam.io/fileindexer/confluence/v1/ingestion"
    sharepoint_ingestion_api_url:str = "https://aava-dev.avateam.io/fileindexer/sharepoint/v1/ingestion"
    database_ingestion_api_url:str = "https://aava-dev.avateam.io/fileindexer/database/v1/ingestion"
    github_ingestion_api_url:str = "https://aava-dev.avateam.io/fileindexer/github/v1/ingestion"

    TIKA_URL : str = ""

    # Any other Bedrock-specific config variables...
    use_bedrock_credentials: bool = True
    # Optional: URL of a configuration service (e.g., Azure App Configuration, Consul, etcd)
    APP_CONFIG_URL: str | None = None

    # Optional: Enable config refresh (true/false)
    config_refresh_enabled: bool = False

    request_timeout:int = 1000

    APP_CONFIG_URL: str = ""
    COMMON_CONFIG_URL: str = ""

    # Optional: Config refresh interval in seconds (default: 300)
    config_refresh_interval: int = 300
    
    AAVA_CORE_ENABLED: bool = True
    # Logging Configuration (Optional - defaults provided)
    AAVA_LOGGING_ENABLED: bool = True
    AAVA_LOGGING_APP_NAME: str = "aava-core-fileindexer-aws"
    AAVA_LOGGING_ENVIRONMENT: str = "dev"
    AAVA_LOGGING_JSON_FORMAT: bool = False
    AAVA_LOGGING_CONSOLE_ENABLED: bool = True
    AAVA_LOGGING_FILE_ENABLED: bool = False
    AAVA_LOGGING_FILE_PATH: str = "logs/app.log"
    AAVA_LOGGING_ASPECT_ENABLED: bool = True
    # Performance Logging
    AAVA_LOGGING_PERFORMANCE_ENABLED: bool = True
    AAVA_LOGGING_PERFORMANCE_SLOW_THRESHOLD: int = 1000
    AAVA_LOGGING_PERFORMANCE_LOG_DATABASE_OPERATIONS: bool = True
    AAVA_LOGGING_PERFORMANCE_LOG_METHOD_EXECUTIONS: bool = True
    # JWT Security Configuration
    AAVA_SECURITY_JWT_ENABLED: bool = False
    LIBRARY_ENDPOINT_EXCEPTIONS: str = "login,logout,swagger-ui,api-docs,health,docs,rapidocs,openapi.json"

    # Application Insights Configuration
    APPLICATIONINSIGHTS_CONNECTION_STRING: str = ""
    APPLICATIONINSIGHTS_ENABLED: str = "false"
    APPLICATIONINSIGHTS_SAMPLE_RATE: float = 1.0
    APPLICATIONINSIGHTS_DISABLE_TELEMETRY: str = "false"
    APPLICATIONINSIGHTS_LOG_LEVEL: str = "WARNING"
    
    VECTOR_TYPE: str = "mongodb"
    IAM_AUTH_ENABLED: str = "False"

    MONGODB_URI: str = ""
    MONGODB_DATABASE: str = ""
    MONGODB_COLLECTION: str = "documents"
    MONGODB_INDEX: str = "vector_index"

    MONGODB_HOST: str = ""
    MONGODB_PORT: str =""
    MONGODB_USERNAME: str =""
    MONGODB_PASSWORD: str =""
    MONGODB_AUTH_SOURCE: str =""
    AAVA_ASSUME_ROLE_ARN_FILEINDEXER_AZURE: str = ""

    @property
    def mongo_db_uri(self):
        host = self.MONGODB_HOST.strip()
        # Detect if SRV should be used
        # - Hostnames from MongoDB Atlas contain .mongodb.net
        # - Or if user explicitly included "mongodb+srv://"
        use_srv = host.startswith("mongodb+srv://") or ".mongodb.net" in host
        # Normalize host (remove scheme if accidentally included)
        host = host.replace("mongodb+srv://", "").replace("mongodb://", "")

        # Choose the correct scheme
        scheme = "mongodb+srv" if use_srv else "mongodb"

        # IAM AUTH (no username/password)
        if self.to_bool("IAM_AUTH_ENABLED"):
            if use_srv:
                return f"{scheme}://{host}/{self.MONGODB_DATABASE}"
            else:
                return f"{scheme}://{host}:{self.MONGODB_PORT}/{self.MONGODB_DATABASE}"

        # USERNAME/PASSWORD AUTH
        username = quote_plus(self.MONGODB_USERNAME)
        password = quote_plus(self.MONGODB_PASSWORD)

        if use_srv:
            # SRV URIs DO NOT allow ports or authSource in the URL
            return (
                f"{scheme}://{username}:{password}"
                f"@{host}/{self.MONGODB_DATABASE}"
            )
        else:
            return (
                f"{scheme}://{username}:{password}"
                f"@{host}:{self.MONGODB_PORT}/{self.MONGODB_DATABASE}"
                f"?authSource={self.MONGODB_AUTH_SOURCE}"
            )


    # @property
    # def APPLICATIONINSIGHTS_ENABLED(self) -> bool:
    #     """Convert string 'true'/'false' to boolean."""
    #     val = getattr(self, '_applicationinsights_enabled', 'false')
    #     return str(val).lower() == 'true'
    
    # @APPLICATIONINSIGHTS_ENABLED.setter
    # def APPLICATIONINSIGHTS_ENABLED(self, value):
    #     self._applicationinsights_enabled = value
    
    # @property
    # def APPLICATIONINSIGHTS_DISABLE_TELEMETRY(self) -> bool:
    #     """Convert string 'true'/'false' to boolean."""
    #     val = getattr(self, '_applicationinsights_disable_telemetry', 'false')
    #     return str(val).lower() == 'true'
    
    # @APPLICATIONINSIGHTS_DISABLE_TELEMETRY.setter
    # def APPLICATIONINSIGHTS_DISABLE_TELEMETRY(self, value):
    #     self._applicationinsights_disable_telemetry = value

    def to_bool(self, key):
        value = getattr(self, key, False)
        return str(value).strip().lower() in ("true", "1", "yes")

    def load_remote_config(self):
        """
        Fetch configuration from remote services and update settings + os.environ.
        Loads from both APP_CONFIG_URL and COMMON_CONFIG_URL.
        """
        # Load from APP_CONFIG_URL
        app_url = self.APP_CONFIG_URL or os.environ.get("APP_CONFIG_URL")
        if app_url:
            self._load_config_from_url(app_url)
        
        # Load from COMMON_CONFIG_URL (for shared configs like Application Insights)
        common_url = self.COMMON_CONFIG_URL or os.environ.get("COMMON_CONFIG_URL")
        if common_url:
            self._load_config_from_url(common_url)
    
    def _load_config_from_url(self, url: str):
        """
        Helper method to fetch configuration from a specific URL.
        Includes operation context for correlation in Application Insights.
        """
        # Get operation context for correlation
        ctx = _get_operation_context()
        operation_id = ctx.get("operation_id", "none")
        
        try:
            resp = httpx.get(url, timeout=5)
            resp.raise_for_status()
            remote_config = resp.json()

            keys_loaded = 0

            # Expecting a list of configs
            for item in remote_config:
                key = item.get("configKey")
                value = item.get("configValue")

                if key and hasattr(self, key):
                    setattr(self, key, value)  # Update the Settings object
                    os.environ[key] = str(value)  # Also update environment
                    keys_loaded+=1
            
            logger.info(
                f"Loaded {keys_loaded} configs from {url} "
                f"[operation_id={operation_id}]"
            )
        except Exception as e:
            logger.warning(
                f"Failed to load config from {url}: {e} "
                f"[operation_id={operation_id}]"
            )


    def start_config_refresh(self):
        """
        If CONFIG_REFRESH_ENABLED is true, start a background thread to periodically refresh config.
        """
        if str(self.config_refresh_enabled) == "True":
            def refresh_loop():
                while True:
                    self.load_remote_config()
                    time.sleep(int(self.config_refresh_interval))
            thread = threading.Thread(target=refresh_loop, daemon=True)
            thread.start()


settings = ServiceSettings()
settings.load_remote_config()
settings.start_config_refresh()